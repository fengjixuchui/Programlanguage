// Implementation of the CMAPIProviderCommand
#include "stdafx.h"
#include "OLEDBMail.h"
//Added by Chuck Wood
//This is to ensure that only one set of non-extern mapi 
//functions are declared.
#define MAIN
#include "MAPIProviderRS.h"
/////////////////////////////////////////////////////////////////////////////
// CMAPIProviderCommand
HRESULT CMAPIProviderCommand::Execute(IUnknown * pUnkOuter, REFIID riid, DBPARAMS * pParams, 
								 LONG * pcRowsAffected, IUnknown ** ppRowset)
{
	CMAPIProviderRowset* pRowset;
	return CreateRowset(pUnkOuter, riid, pParams, pcRowsAffected, ppRowset, pRowset);
}
