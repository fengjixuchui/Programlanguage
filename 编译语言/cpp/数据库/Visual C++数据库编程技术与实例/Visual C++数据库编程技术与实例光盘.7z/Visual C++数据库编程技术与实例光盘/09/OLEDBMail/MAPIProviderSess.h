// Session.h : Declaration of the CMAPIProviderSession
#ifndef __CMAPIProviderSession_H_
#define __CMAPIProviderSession_H_
#include "resource.h"       // main symbols
#include "MAPIProviderRS.h"
class CMAPIProviderSessionTRSchemaRowset;
class CMAPIProviderSessionColSchemaRowset;
class CMAPIProviderSessionPTSchemaRowset;
/////////////////////////////////////////////////////////////////////////////
// CMAPIProviderSession
class ATL_NO_VTABLE CMAPIProviderSession : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IGetDataSourceImpl<CMAPIProviderSession>,
	public IOpenRowsetImpl<CMAPIProviderSession>,
	public ISessionPropertiesImpl<CMAPIProviderSession>,
	public IObjectWithSiteSessionImpl<CMAPIProviderSession>,
	public IDBSchemaRowsetImpl<CMAPIProviderSession>,
	public IDBCreateCommandImpl<CMAPIProviderSession, CMAPIProviderCommand>
{
public:
	CMAPIProviderSession()
	{
	}
	HRESULT FinalConstruct()
	{
		return FInit();
	}
	STDMETHOD(OpenRowset)(IUnknown *pUnk, DBID *pTID, DBID *pInID, REFIID riid,
					   ULONG cSets, DBPROPSET rgSets[], IUnknown **ppRowset)
	{
		CMAPIProviderRowset* pRowset;
		return CreateRowset(pUnk, pTID, pInID, riid, cSets, rgSets, ppRowset, pRowset);
	}
BEGIN_PROPSET_MAP(CMAPIProviderSession)
	BEGIN_PROPERTY_SET(DBPROPSET_SESSION)
		PROPERTY_INFO_ENTRY(SESS_AUTOCOMMITISOLEVELS)
	END_PROPERTY_SET(DBPROPSET_SESSION)
END_PROPSET_MAP()
BEGIN_COM_MAP(CMAPIProviderSession)
	COM_INTERFACE_ENTRY(IGetDataSource)
	COM_INTERFACE_ENTRY(IOpenRowset)
	COM_INTERFACE_ENTRY(ISessionProperties)
	COM_INTERFACE_ENTRY(IObjectWithSite)
	COM_INTERFACE_ENTRY(IDBCreateCommand)
	COM_INTERFACE_ENTRY(IDBSchemaRowset)
END_COM_MAP()
BEGIN_SCHEMA_MAP(CMAPIProviderSession)
	SCHEMA_ENTRY(DBSCHEMA_TABLES, CMAPIProviderSessionTRSchemaRowset)
	SCHEMA_ENTRY(DBSCHEMA_COLUMNS, CMAPIProviderSessionColSchemaRowset)
	SCHEMA_ENTRY(DBSCHEMA_PROVIDER_TYPES, CMAPIProviderSessionPTSchemaRowset)
END_SCHEMA_MAP()
};
class CMAPIProviderSessionTRSchemaRowset : 
	public CRowsetImpl< CMAPIProviderSessionTRSchemaRowset, CTABLESRow, CMAPIProviderSession>
{
public:
	HRESULT Execute(LONG* pcRowsAffected, ULONG, const VARIANT*)
	{
		USES_CONVERSION;
		CTABLESRow trData;
		lstrcpyW(trData.m_szType, OLESTR("TABLE"));
		lstrcpyW(trData.m_szDesc, OLESTR("The Mail Table"));
		lstrcpynW(trData.m_szTable, 
			T2OLE("Mail"), 
			SIZEOF_MEMBER(CTABLESRow, m_szTable));
		if (!m_rgRowData.Add(trData))
			return E_OUTOFMEMORY;
		*pcRowsAffected = 1;
		return S_OK;
	}
};
class CMAPIProviderSessionColSchemaRowset : 
	public CRowsetImpl< CMAPIProviderSessionColSchemaRowset, CCOLUMNSRow, CMAPIProviderSession>
{
public:
	HRESULT Execute(LONG* pcRowsAffected, ULONG, const VARIANT*)
	{
		const int NUMBERCOLUMNS = 4;
		USES_CONVERSION;
		CCOLUMNSRow crColumnInfo[NUMBERCOLUMNS];
		//******
 
		// Initialize crColumnInfo to null
		memset(crColumnInfo, 0, sizeof(CCOLUMNSRow)*NUMBERCOLUMNS);
		// Fill out common fields between columns
		for (int column=0; column<NUMBERCOLUMNS; column++) {
			lstrcpyW(crColumnInfo[column].m_szTableName, 
				T2OLE("Mail"));
				crColumnInfo[column].m_ulOrdinalPosition = column+1;
				crColumnInfo[column].m_bIsNullable = VARIANT_FALSE;
				crColumnInfo[column].m_bColumnHasDefault = VARIANT_FALSE;
				crColumnInfo[column].m_ulColumnFlags = 0;
				crColumnInfo[column].m_nDataType = DBTYPE_STR;
			// Declare new schema row
				m_rgRowData.Add(crColumnInfo[column]);
		}
	// column names
		lstrcpyW(crColumnInfo[0].m_szColumnName, OLESTR("Author"));
		lstrcpyW(crColumnInfo[1].m_szColumnName, OLESTR("Subject"));
		lstrcpyW(crColumnInfo[2].m_szColumnName, OLESTR("Date"));
		lstrcpyW(crColumnInfo[3].m_szColumnName, OLESTR("Body"));
	// column descriptions
		lstrcpyW(crColumnInfo[0].m_szDescription, OLESTR("Class"));
		lstrcpyW(crColumnInfo[1].m_szDescription, OLESTR("Subject"));
		lstrcpyW(crColumnInfo[2].m_szDescription, OLESTR("Date"));
		lstrcpyW(crColumnInfo[3].m_szDescription, OLESTR("Body"));
	// column sizes
		crColumnInfo[0].m_ulCharMaxLength = 50;
		crColumnInfo[1].m_ulCharMaxLength = 256;
		crColumnInfo[2].m_ulCharMaxLength = 20;
		crColumnInfo[3].m_ulCharMaxLength = 1024;
		*pcRowsAffected = NUMBERCOLUMNS;  // for the four columns
		//******
		return S_OK;
	}
};
class CMAPIProviderSessionPTSchemaRowset : 
	public CRowsetImpl< CMAPIProviderSessionPTSchemaRowset, CPROVIDER_TYPERow, CMAPIProviderSession>
{
public:
	HRESULT Execute(LONG* pcRowsAffected, ULONG, const VARIANT*)
	{
		return S_OK;
	}
};
#endif //__CMAPIProviderSession_H_
