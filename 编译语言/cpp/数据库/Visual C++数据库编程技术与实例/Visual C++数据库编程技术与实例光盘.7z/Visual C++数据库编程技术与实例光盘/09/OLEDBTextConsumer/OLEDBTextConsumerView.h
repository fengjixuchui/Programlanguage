// OLEDBTextConsumerView.h : interface of the COLEDBTextConsumerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBTEXTCONSUMERVIEW_H__1A082C0C_C8D8_11D2_9949_D68A87749F4B__INCLUDED_)
#define AFX_OLEDBTEXTCONSUMERVIEW_H__1A082C0C_C8D8_11D2_9949_D68A87749F4B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class COLEDBTextConsumerSet;

class COLEDBTextConsumerView : public COleDBRecordView
{
protected: // create from serialization only
	COLEDBTextConsumerView();
	DECLARE_DYNCREATE(COLEDBTextConsumerView)

public:
	//{{AFX_DATA(COLEDBTextConsumerView)
	enum{ IDD = IDD_OLEDBTEXTCONSUMER_FORM };
	COLEDBTextConsumerSet* m_pSet;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	COLEDBTextConsumerDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBTextConsumerView)
	public:
	virtual CRowset* OnGetRowset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnMove(UINT nIDMoveCommand);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLEDBTextConsumerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COLEDBTextConsumerView)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in OLEDBTextConsumerView.cpp
inline COLEDBTextConsumerDoc* COLEDBTextConsumerView::GetDocument()
   { return (COLEDBTextConsumerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBTEXTCONSUMERVIEW_H__1A082C0C_C8D8_11D2_9949_D68A87749F4B__INCLUDED_)
