// OLEDBTextConsumerView.cpp : implementation of the COLEDBTextConsumerView class
//

#include "stdafx.h"
#include "OLEDBTextConsumer.h"

#include "OLEDBTextConsumerSet.h"
#include "OLEDBTextConsumerDoc.h"
#include "OLEDBTextConsumerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBTextConsumerView

IMPLEMENT_DYNCREATE(COLEDBTextConsumerView, COleDBRecordView)

BEGIN_MESSAGE_MAP(COLEDBTextConsumerView, COleDBRecordView)
	//{{AFX_MSG_MAP(COLEDBTextConsumerView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBTextConsumerView construction/destruction

COLEDBTextConsumerView::COLEDBTextConsumerView()
	: COleDBRecordView(COLEDBTextConsumerView::IDD)
{
	//{{AFX_DATA_INIT(COLEDBTextConsumerView)
		// NOTE: the ClassWizard will add member initialization here
	m_pSet = NULL;
	//}}AFX_DATA_INIT
}

COLEDBTextConsumerView::~COLEDBTextConsumerView()
{
}

void COLEDBTextConsumerView::DoDataExchange(CDataExchange* pDX)
{
	COleDBRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COLEDBTextConsumerView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
	//Added by Chuck Wood for data transfer
	DDX_Text(pDX, IDC_CLASS, m_pSet->m_strClass, 51);
	DDX_Text(pDX, IDC_SECTION, m_pSet->m_strSectionID, 12);
	DDX_Text(pDX, IDC_YEAR, m_pSet->m_strYear, 7);
	DDX_Text(pDX, IDC_TERM, m_pSet->m_strTerm, 31);
	DDX_Text(pDX, IDC_INSTRUCTOR, m_pSet->m_strInstructor, 51);
	DDX_Text(pDX, IDC_ASSIGNMENT, m_pSet->m_strAssignment, 256);
	DDX_Text(pDX, IDC_SCORE, m_pSet->m_strScore, 23);
	DDX_Text(pDX, IDC_STUDENT, m_pSet->m_strStudent, 36);
	DDV_MaxChars(pDX, m_pSet->m_strClass, 51);
	DDV_MaxChars(pDX, m_pSet->m_strSectionID, 12);
	DDV_MaxChars(pDX, m_pSet->m_strYear, 7);
	DDV_MaxChars(pDX, m_pSet->m_strTerm, 31);
	DDV_MaxChars(pDX, m_pSet->m_strInstructor, 51);
	DDV_MaxChars(pDX, m_pSet->m_strAssignment, 256);
	DDV_MaxChars(pDX, m_pSet->m_strScore, 23);
	DDV_MaxChars(pDX, m_pSet->m_strStudent, 36);
}

BOOL COLEDBTextConsumerView::PreCreateWindow(CREATESTRUCT& cs)
{
	return COleDBRecordView::PreCreateWindow(cs);
}

void COLEDBTextConsumerView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_oLEDBTextConsumerSet;
	{
		CWaitCursor wait;
		HRESULT hr = m_pSet->Open();
		if (hr != S_OK)
		{
			AfxMessageBox(_T("Record set failed to open."), MB_OK);
			m_bOnFirstRecord = TRUE;
			m_bOnLastRecord = TRUE;
		}				
	}
	COleDBRecordView::OnInitialUpdate();

}

/////////////////////////////////////////////////////////////////////////////
// COLEDBTextConsumerView diagnostics

#ifdef _DEBUG
void COLEDBTextConsumerView::AssertValid() const
{
	COleDBRecordView::AssertValid();
}

void COLEDBTextConsumerView::Dump(CDumpContext& dc) const
{
	COleDBRecordView::Dump(dc);
}

COLEDBTextConsumerDoc* COLEDBTextConsumerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(COLEDBTextConsumerDoc)));
	return (COLEDBTextConsumerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBTextConsumerView database support
CRowset* COLEDBTextConsumerView::OnGetRowset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// COLEDBTextConsumerView message handlers

BOOL COLEDBTextConsumerView::OnMove(UINT nIDMoveCommand) 
{
	return COleDBRecordView::OnMove(nIDMoveCommand);
}
