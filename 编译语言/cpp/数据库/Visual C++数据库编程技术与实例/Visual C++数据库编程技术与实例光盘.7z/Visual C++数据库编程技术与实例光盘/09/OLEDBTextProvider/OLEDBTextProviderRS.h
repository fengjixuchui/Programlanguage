// OLEDBTextProviderRS.h : Declaration of the COLEDBTextProviderRowset
#ifndef __COLEDBTextProviderRowset_H_
#define __COLEDBTextProviderRowset_H_
#include "resource.h"       // main symbols
// Added by Chuck Wood for text file support
#include <stdio.h>
//Remove inheritance from class
class CTextFile
{
public:
	TCHAR strClass[51];
	TCHAR strSectionID[12];
	TCHAR strYear[7];
	TCHAR strTerm[31];
	TCHAR strInstructor[51];
	TCHAR strAssignment[256];
	TCHAR strScore[23];
	TCHAR strStudent[36];
BEGIN_PROVIDER_COLUMN_MAP(CTextFile)
	PROVIDER_COLUMN_ENTRY_STR("Class", 1, strClass)
	PROVIDER_COLUMN_ENTRY_STR("SectionID", 2, strSectionID)
	PROVIDER_COLUMN_ENTRY_STR("Year", 3, strYear)
	PROVIDER_COLUMN_ENTRY_STR("Term", 4, strTerm)
	PROVIDER_COLUMN_ENTRY_STR("Instructor", 5, strInstructor)
	PROVIDER_COLUMN_ENTRY_STR("Assignment", 6, strAssignment)
	PROVIDER_COLUMN_ENTRY_STR("Score", 7, strScore)
	PROVIDER_COLUMN_ENTRY_STR("Student", 8, strStudent)
END_PROVIDER_COLUMN_MAP()
};
// COLEDBTextProviderCommand
class ATL_NO_VTABLE COLEDBTextProviderCommand : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IAccessorImpl<COLEDBTextProviderCommand>,
	public ICommandTextImpl<COLEDBTextProviderCommand>,
	public ICommandPropertiesImpl<COLEDBTextProviderCommand>,
	public IObjectWithSiteImpl<COLEDBTextProviderCommand>,
	public IConvertTypeImpl<COLEDBTextProviderCommand>,
	public IColumnsInfoImpl<COLEDBTextProviderCommand>
{
public:
BEGIN_COM_MAP(COLEDBTextProviderCommand)
	COM_INTERFACE_ENTRY(ICommand)
	COM_INTERFACE_ENTRY(IObjectWithSite)
	COM_INTERFACE_ENTRY(IAccessor)
	COM_INTERFACE_ENTRY(ICommandProperties)
	COM_INTERFACE_ENTRY2(ICommandText, ICommand)
	COM_INTERFACE_ENTRY(IColumnsInfo)
	COM_INTERFACE_ENTRY(IConvertType)
END_COM_MAP()
// ICommand
public:
	HRESULT FinalConstruct()
	{
		HRESULT hr = CConvertHelper::FinalConstruct();
		if (FAILED (hr))
			return hr;
		hr = IAccessorImpl<COLEDBTextProviderCommand>::FinalConstruct();
		if (FAILED(hr))
			return hr;
		return CUtlProps<COLEDBTextProviderCommand>::FInit();
	}
	void FinalRelease()
	{
		IAccessorImpl<COLEDBTextProviderCommand>::FinalRelease();
	}
	HRESULT WINAPI Execute(IUnknown * pUnkOuter, REFIID riid, DBPARAMS * pParams, 
						  LONG * pcRowsAffected, IUnknown ** ppRowset);
	static ATLCOLUMNINFO* GetColumnInfo(COLEDBTextProviderCommand* pv, ULONG* pcInfo)
	{
		return CTextFile::GetColumnInfo(pv,pcInfo);
	}
BEGIN_PROPSET_MAP(COLEDBTextProviderCommand)
	BEGIN_PROPERTY_SET(DBPROPSET_ROWSET)
		PROPERTY_INFO_ENTRY(IAccessor)
		PROPERTY_INFO_ENTRY(IColumnsInfo)
		PROPERTY_INFO_ENTRY(IConvertType)
		PROPERTY_INFO_ENTRY(IRowset)
		PROPERTY_INFO_ENTRY(IRowsetIdentity)
		PROPERTY_INFO_ENTRY(IRowsetInfo)
		PROPERTY_INFO_ENTRY(IRowsetLocate)
		PROPERTY_INFO_ENTRY(BOOKMARKS)
		PROPERTY_INFO_ENTRY(BOOKMARKSKIPPED)
		PROPERTY_INFO_ENTRY(BOOKMARKTYPE)
		PROPERTY_INFO_ENTRY(CANFETCHBACKWARDS)
		PROPERTY_INFO_ENTRY(CANHOLDROWS)
		PROPERTY_INFO_ENTRY(CANSCROLLBACKWARDS)
		PROPERTY_INFO_ENTRY(LITERALBOOKMARKS)
		PROPERTY_INFO_ENTRY(ORDEREDBOOKMARKS)
	END_PROPERTY_SET(DBPROPSET_ROWSET)
END_PROPSET_MAP()
};
class COLEDBTextProviderRowset : 
		public CRowsetImpl< COLEDBTextProviderRowset, 
			CTextFile, COLEDBTextProviderCommand>
{
private:
	void ColumnCopy(char* row, char* column, int length) {
        column[length] = 0;     //Null Terminate 
        StrTrim(column);        //Trim for users
	}

public:
	static char* GetFileName() {
		//Change this file name 
		//if you want to use a different one
		return "C:\\StudentTextFile.txt";
	}
	static void StrTrim(char *instring) {
		static char strBlank[] = " \n";    // chars to strip
	// remove trailing spaces or newlines
		for (char *pchEnd = instring + strlen(instring);
			pchEnd != instring && strchr(
				strBlank, *(pchEnd - 1)) != NULL;
					*--pchEnd = '\0');
	// remove leading spaces or newlines
		char *pchStart = &instring[strspn(instring, strBlank)];
		memmove(instring, pchStart, 
			sizeof(char) * (pchEnd - pchStart + 1));
	}
	HRESULT Execute(DBPARAMS * pParams, LONG* pcRowsAffected)
	{
		CTextFile tf;
		FILE *fp;       //Text file pointer
		char row[500];  //row buffer;
		*pcRowsAffected = 0;
		fp = fopen(
			GetFileName(), 
			"r+");	    //Open for reading and writing
		if (fp == NULL) {
			return DB_E_INVALID;
		}
		while (fgets(row, 500, fp)) {	//Go until EOF
			ColumnCopy(row, tf.strClass, 50);
			ColumnCopy(row+50, tf.strSectionID, 11);
			ColumnCopy(row+61, tf.strYear, 6);
			ColumnCopy(row+67, tf.strTerm, 30);
			ColumnCopy(row+97, tf.strInstructor, 50);
			ColumnCopy(row+147, tf.strAssignment, 255);
			ColumnCopy(row+402, tf.strScore, 22);
			ColumnCopy(row+424, tf.strStudent, 35);
			if (!m_rgRowData.Add(tf))
				return E_OUTOFMEMORY;
			*pcRowsAffected++;		
		}
		fclose(fp);
		return S_OK;
	}
};
#endif //__COLEDBTextProviderRowset_H_
