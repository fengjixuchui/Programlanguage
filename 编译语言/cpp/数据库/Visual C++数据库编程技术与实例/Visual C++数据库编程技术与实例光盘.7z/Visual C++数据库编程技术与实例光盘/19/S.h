#if !defined(AFX_S_H__B7FFBB99_9BAF_4B26_9B6B_29F853FD3F70__INCLUDED_)
#define AFX_S_H__B7FFBB99_9BAF_4B26_9B6B_29F853FD3F70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// S.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// S recordset

class S : public CRecordset
{
public:
	S(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(S)

// Field/Param Data
	//{{AFX_FIELD(S, CRecordset)
	CString	m_au_id;
	CString	m_au_lname;
	CString	m_au_fname;
	CString	m_phone;
	CString	m_address;
	CString	m_city;
	CString	m_state;
	CString	m_zip;
	BOOL	m_contract;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(S)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_S_H__B7FFBB99_9BAF_4B26_9B6B_29F853FD3F70__INCLUDED_)
