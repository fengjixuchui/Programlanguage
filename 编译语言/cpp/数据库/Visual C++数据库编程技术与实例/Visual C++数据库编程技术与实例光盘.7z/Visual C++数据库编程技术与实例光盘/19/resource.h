//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by lhwy.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_LHWY_DIALOG                 102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_BADIALOG                    129
#define IDD_ADDDIALOG                   131
#define IDD_DELECTDIALOG                132
#define IDD_FINDDIALOG                  133
#define IDC_CURSOR1                     135
#define IDD_NADIALOG                    136
#define IDD_CADIALOG                    137
#define IDD_EDITDIALOG                  138
#define IDI_ICON1                       139
#define IDC_TAB1                        1000
#define IDC_COMBO1                      1001
#define IDC_BUTTON1                     1002
#define IDC_START                       1002
#define IDC_BUTTON2                     1003
#define IDC_ADD                         1003
#define IDC_BUTTON3                     1004
#define IDC_DELECT                      1004
#define IDC_BUTTON4                     1005
#define IDC_EDIT                        1005
#define IDC_BUTTON5                     1006
#define IDC_FIND                        1006
#define IDC_BUTTON6                     1007
#define IDC_ALL                         1007
#define IDC_LIST1                       1008
#define IDC_LIST2                       1009
#define IDC_LIST3                       1010
#define IDC_BUTTON7                     1011
#define IDC_EXPORT                      1011
#define IDC_XUEHAO                      1012
#define IDC_NAME                        1013
#define IDC_MATHS                       1014
#define IDC_PHYCICAL                    1015
#define IDC_CHMISTRY                    1016
#define IDC_ENGLISH                     1017
#define IDC_POLITIC                     1018
#define IDC_PASS                        1020
#define IDC_COMBO2                      1023
#define IDC_STATIC1                     1024
#define IDC_STATICALL                   1025
#define IDC_SHOW                        1026
#define IDC_XUE                         1027
#define IDC_PHYSICAL                    1030
#define IDC_CHEMISTRY                   1031

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
