// BRecordset1.cpp : implementation file
//

#include "stdafx.h"
#include "lhwy.h"
#include "BRecordset1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// BRecordset

IMPLEMENT_DYNAMIC(BRecordset, CDaoRecordset)

BRecordset::BRecordset(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(BRecordset)
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString BRecordset::GetDefaultDBName()
{
	return _T("F:\Visual C++ 6.0���ݿ�ϵͳ����ʵ������\VC���������ݿ��̰���\��7��\ʵ��63-ѧ���ɼ�����\LHWY.MDB");
}

CString BRecordset::GetDefaultSQL()
{
	return _T("");
}

void BRecordset::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(BRecordset)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// BRecordset diagnostics

#ifdef _DEBUG
void BRecordset::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void BRecordset::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
