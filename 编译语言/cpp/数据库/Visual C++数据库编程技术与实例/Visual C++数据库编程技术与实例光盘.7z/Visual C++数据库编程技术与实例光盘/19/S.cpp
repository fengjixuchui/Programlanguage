// S.cpp : implementation file
//

#include "stdafx.h"
#include "lhwy.h"
#include "S.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// S

IMPLEMENT_DYNAMIC(S, CRecordset)

S::S(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(S)
	m_au_id = _T("");
	m_au_lname = _T("");
	m_au_fname = _T("");
	m_phone = _T("");
	m_address = _T("");
	m_city = _T("");
	m_state = _T("");
	m_zip = _T("");
	m_contract = FALSE;
	m_nFields = 9;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString S::GetDefaultConnect()
{
	return _T("ODBC;DSN=SQLServer");
}

CString S::GetDefaultSQL()
{
	return _T("[dbo].[authors]");
}

void S::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(S)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[au_id]"), m_au_id);
	RFX_Text(pFX, _T("[au_lname]"), m_au_lname);
	RFX_Text(pFX, _T("[au_fname]"), m_au_fname);
	RFX_Text(pFX, _T("[phone]"), m_phone);
	RFX_Text(pFX, _T("[address]"), m_address);
	RFX_Text(pFX, _T("[city]"), m_city);
	RFX_Text(pFX, _T("[state]"), m_state);
	RFX_Text(pFX, _T("[zip]"), m_zip);
	RFX_Bool(pFX, _T("[contract]"), m_contract);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// S diagnostics

#ifdef _DEBUG
void S::AssertValid() const
{
	CRecordset::AssertValid();
}

void S::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
