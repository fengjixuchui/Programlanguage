// BRecordsets.cpp : implementation file
//

#include "stdafx.h"
#include "lhwy.h"
#include "BRecordsets.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// BRecordsets

IMPLEMENT_DYNAMIC(BRecordsets, CRecordset)

BRecordsets::BRecordsets(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(BRecordsets)
	m_column1 = _T("");
	m_column2 = 0.0f;
	m_column3 = 0.0f;
	m_column4 = 0;
	m_column5 = 0;
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString BRecordsets::GetDefaultConnect()
{
	return _T("ODBC;DSN=Student");
}

CString BRecordsets::GetDefaultSQL()
{
	return _T("[dbo].[NO1OBJECT]");
}

void BRecordsets::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(BRecordsets)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[��Ŀ]"), m_column1);
	RFX_Single(pFX, _T("[�ܳɼ�]"), m_column2);
	RFX_Single(pFX, _T("[ƽ���ɼ�]"), m_column3);
	RFX_Long(pFX, _T("[��������]"), m_column4);
	RFX_Long(pFX, _T("[��������]"), m_column5);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// BRecordsets diagnostics

#ifdef _DEBUG
void BRecordsets::AssertValid() const
{
	CRecordset::AssertValid();
}

void BRecordsets::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
