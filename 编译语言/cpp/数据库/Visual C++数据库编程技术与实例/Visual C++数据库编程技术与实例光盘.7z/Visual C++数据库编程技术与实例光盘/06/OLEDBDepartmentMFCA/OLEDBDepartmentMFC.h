// OLEDBDepartmentMFC.h : main header file for the OLEDBDEPARTMENTMFC application
//

#if !defined(AFX_OLEDBDEPARTMENTMFC_H__3D2A2365_4C1D_11D2_9949_D84454558644__INCLUDED_)
#define AFX_OLEDBDEPARTMENTMFC_H__3D2A2365_4C1D_11D2_9949_D84454558644__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCApp:
// See OLEDBDepartmentMFC.cpp for the implementation of this class
//

class COLEDBDepartmentMFCApp : public CWinApp
{
public:
	COLEDBDepartmentMFCApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBDepartmentMFCApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(COLEDBDepartmentMFCApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBDEPARTMENTMFC_H__3D2A2365_4C1D_11D2_9949_D84454558644__INCLUDED_)
