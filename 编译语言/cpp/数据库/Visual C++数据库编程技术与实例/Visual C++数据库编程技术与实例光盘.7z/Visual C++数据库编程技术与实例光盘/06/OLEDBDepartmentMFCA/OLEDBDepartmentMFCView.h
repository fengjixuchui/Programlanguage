// OLEDBDepartmentMFCView.h : interface of the COLEDBDepartmentMFCView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBDEPARTMENTMFCVIEW_H__3D2A236D_4C1D_11D2_9949_D84454558644__INCLUDED_)
#define AFX_OLEDBDEPARTMENTMFCVIEW_H__3D2A236D_4C1D_11D2_9949_D84454558644__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class COLEDBDepartmentMFCSet;

class COLEDBDepartmentMFCView : public COleDBRecordView
{
protected: // create from serialization only
	COLEDBDepartmentMFCView();
	DECLARE_DYNCREATE(COLEDBDepartmentMFCView)

public:
	//{{AFX_DATA(COLEDBDepartmentMFCView)
	enum{ IDD = IDD_OLEDBDEPARTMENTMFC_FORM };
	COLEDBDepartmentMFCSet* m_pSet;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	COLEDBDepartmentMFCDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBDepartmentMFCView)
	public:
	virtual CRowset* OnGetRowset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLEDBDepartmentMFCView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COLEDBDepartmentMFCView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in OLEDBDepartmentMFCView.cpp
inline COLEDBDepartmentMFCDoc* COLEDBDepartmentMFCView::GetDocument()
   { return (COLEDBDepartmentMFCDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBDEPARTMENTMFCVIEW_H__3D2A236D_4C1D_11D2_9949_D84454558644__INCLUDED_)
