// OLEDBDepartmentMFCView.cpp : implementation of the COLEDBDepartmentMFCView class
//

#include "stdafx.h"
#include "OLEDBDepartmentMFC.h"
#include "OLEDBDepartmentMFCSet.h"
#include "OLEDBDepartmentMFCDoc.h"
#include "OLEDBDepartmentMFCView.h"
#include "OpenDepartment.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCView

IMPLEMENT_DYNCREATE(COLEDBDepartmentMFCView, COleDBRecordView)

BEGIN_MESSAGE_MAP(COLEDBDepartmentMFCView, COleDBRecordView)
	//{{AFX_MSG_MAP(COLEDBDepartmentMFCView)
	ON_WM_DESTROY()
	ON_COMMAND(ID_EDIT_DELETETCTRLDEL, OnEditDeletetctrldel)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_EN_CHANGE(IDC_DEPARTMENTCODE, OnChangeDepartmentcode)
	ON_EN_CHANGE(IDC_DEPARTMENTNAME, OnChangeDepartmentname)
	ON_EN_CHANGE(IDC_EMAIL, OnChangeEmail)
	ON_EN_CHANGE(IDC_INSTRUCTORNAME, OnChangeInstructorname)
	ON_EN_CHANGE(IDC_NOTES, OnChangeNotes)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCView construction/destruction

COLEDBDepartmentMFCView::COLEDBDepartmentMFCView()
	: COleDBRecordView(COLEDBDepartmentMFCView::IDD)
{
	//{{AFX_DATA_INIT(COLEDBDepartmentMFCView)
		// NOTE: the ClassWizard will add member initialization here
	m_pSet = NULL;
	//}}AFX_DATA_INIT
	m_bAddingRecord = FALSE;
	m_bChangesMade = FALSE;
}

COLEDBDepartmentMFCView::~COLEDBDepartmentMFCView()
{
}

void COLEDBDepartmentMFCView::DoDataExchange(CDataExchange* pDX)
{
	COleDBRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COLEDBDepartmentMFCView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_DEPARTMENTCODE, m_pSet->m_DepartmentCode, 5);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentCode, 4);
	DDX_Text(pDX, IDC_DEPARTMENTNAME, m_pSet->m_DepartmentName, 51);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentName, 50);
	DDX_Text(pDX, IDC_INSTRUCTORNAME, m_pSet->m_Name, 51);
	DDV_MaxChars(pDX, m_pSet->m_Name, 50);
	DDX_Text(pDX, IDC_EMAIL, m_pSet->m_EMAIL, 51);
	DDV_MaxChars(pDX, m_pSet->m_EMAIL, 50);
	DDX_Text(pDX, IDC_NOTES, m_pSet->m_Notes, 1025);
	DDV_MaxChars(pDX, m_pSet->m_Notes, 1024);
}

BOOL COLEDBDepartmentMFCView::PreCreateWindow(CREATESTRUCT& cs)
{
	return COleDBRecordView::PreCreateWindow(cs);
}

void COLEDBDepartmentMFCView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_oLEDBDepartmentMFCSet;
	{
		CWaitCursor wait;
		HRESULT hr = m_pSet->Open();
		if (hr != S_OK)
		{
			AfxMessageBox(_T("Record set failed to open."), MB_OK);
			// Disable the Next and Previous record commands,
			// since attempting to change the current record without an
			// open RecordSet will cause a crash.
			m_bOnFirstRecord = TRUE;
			m_bOnLastRecord = TRUE;
		}				
	}
	COleDBRecordView::OnInitialUpdate();

}

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCView diagnostics

#ifdef _DEBUG
void COLEDBDepartmentMFCView::AssertValid() const
{
	COleDBRecordView::AssertValid();
}

void COLEDBDepartmentMFCView::Dump(CDumpContext& dc) const
{
	COleDBRecordView::Dump(dc);
}

COLEDBDepartmentMFCDoc* COLEDBDepartmentMFCView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(COLEDBDepartmentMFCDoc)));
	return (COLEDBDepartmentMFCDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCView database support
CRowset* COLEDBDepartmentMFCView::OnGetRowset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCView message handlers

BOOL COLEDBDepartmentMFCView::OnMove(UINT nIDMoveCommand) 
{
	SaveRecord();
	return COleDBRecordView::OnMove(nIDMoveCommand);
}

void COLEDBDepartmentMFCView::OnDestroy() 
{
	if (m_bChangesMade) {
		//Yes was chosen.  Save out record
		if (AfxMessageBox(
			"Do you want to save changes to the database?",
			MB_YESNO) == IDYES) {
			SaveRecord();
			OnFileSave();
		}
	}
	COleDBRecordView::OnDestroy();
}

void COLEDBDepartmentMFCView::OnEditDeletetctrldel() 
{
	if (AfxMessageBox(	//Be sure to verify your deletes
			"Are you sure you want to delete?",
			MB_YESNO)
		!= IDYES) {
		return;
	}
	//Delete record and test
	if (m_bAddingRecord) {
		//Just abort the add
		m_bAddingRecord = FALSE;
	}
	else if (FAILED(m_pSet->Delete())) {	//Delete and test
		AfxMessageBox("Delete Failed:\n", MB_ICONEXCLAMATION);
	}
	else {	//Set changes to true if Delete worked.
		m_bChangesMade = TRUE;
	}
	ResetRowSet();
}

void COLEDBDepartmentMFCView::OnFileNew() 
{
	SaveRecord();
	AddRecord();
}

void COLEDBDepartmentMFCView::OnFileOpen() 
{
	COpenDepartment od;	//Query dialog box declaration

	SaveRecord();		//Save any changes first
	od.DoModal();		//Show the query dialog box
	if (od.m_bAnswer) {		//OK was clicked?
		CString newFilter;	//Define a new filter
		if (od.m_strDepartment > "") {	//Anything entered?
			//Fill the new filter with a WHERE clause
			newFilter =
				" WHERE Department.DepartmentCode = '" +
				od.m_strDepartment +"'";
		}
		else {
			//Empty out the filter if nothing entered
			newFilter = "";
		}
		if (m_pSet->m_strFilter.CompareNoCase(newFilter)) {
			//Strings are different
			m_pSet->m_strFilter = newFilter;
			//Close and open to requery
			m_pSet->Close();
			m_pSet->Open();
			ResetRowSet();	//Display results
		}
	}
}

void COLEDBDepartmentMFCView::AddRecord()
{
	m_bAddingRecord = TRUE;
	m_pSet->ClearFields();
	UpdateData(FALSE);		// Show cleared values on window
}

BOOL COLEDBDepartmentMFCView::SaveRecord()
{
	if (!UpdateData(TRUE)) {	//Save changes from the screen
		return FALSE;
	}
	if (m_bAddingRecord) {
		m_bAddingRecord = FALSE;
		if (FAILED(m_pSet->Insert())) {
			AfxMessageBox("Insert failed",
				MB_ICONEXCLAMATION);
			m_pSet->MoveFirst();
			UpdateData(FALSE);		// Show cleared values on window
			return FALSE;
		}
	}
	else if (FAILED(m_pSet->SetData(0))) {	//Save changes from this accessor
		AfxMessageBox("Update via SetData failed",
			MB_ICONEXCLAMATION);
		UpdateData(FALSE);		// Show cleared values on window
		return FALSE;
	}
	return TRUE;
}

void COLEDBDepartmentMFCView::ResetRowSet()
{
	if (m_pSet->MoveNext() != S_OK) {	//Go to next record
		if (m_pSet->MoveFirst() != S_OK) {
			AfxMessageBox("No more records",
				MB_ICONEXCLAMATION);
			//No records, so set up an add record
			AddRecord();
		}
	}
	UpdateData(FALSE);	//Write changes to window
}

void COLEDBDepartmentMFCView::OnFileSave() 
{
	if (m_bChangesMade) {
		SaveRecord();
		m_bChangesMade = FALSE;
		if (FAILED(m_pSet->Update())) {
			AfxMessageBox("Update failed in OnFileSave",
				MB_ICONEXCLAMATION);
		}
	}
}

void COLEDBDepartmentMFCView::OnChangeDepartmentcode() 
{
	m_bChangesMade = TRUE;
}

void COLEDBDepartmentMFCView::OnChangeDepartmentname() 
{
	m_bChangesMade = TRUE;
}

void COLEDBDepartmentMFCView::OnChangeEmail() 
{
	m_bChangesMade = TRUE;
}

void COLEDBDepartmentMFCView::OnChangeInstructorname() 
{
	m_bChangesMade = TRUE;
}

void COLEDBDepartmentMFCView::OnChangeNotes() 
{
	m_bChangesMade = TRUE;
}

