// OpenDepartment.cpp : implementation file
//

#include "stdafx.h"
#include "OLEDBDepartmentMFC.h"
#include "OpenDepartment.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COpenDepartment dialog


COpenDepartment::COpenDepartment(CWnd* pParent /*=NULL*/)
	: CDialog(COpenDepartment::IDD, pParent)
{
	//{{AFX_DATA_INIT(COpenDepartment)
	m_strDepartment = _T("");
	//}}AFX_DATA_INIT
	m_bAnswer = FALSE;	//Initialize answer to false.
}

void COpenDepartment::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COpenDepartment)
	DDX_Text(pDX, IDC_FINDDEPARTMENT, m_strDepartment);
	DDV_MaxChars(pDX, m_strDepartment, 4);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COpenDepartment, CDialog)
	//{{AFX_MSG_MAP(COpenDepartment)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COpenDepartment message handlers

void COpenDepartment::OnOK() 
{
	m_bAnswer = TRUE;
	CDialog::OnOK();
}

void COpenDepartment::OnCancel() 
{
	m_bAnswer = FALSE;
	CDialog::OnCancel();
}
