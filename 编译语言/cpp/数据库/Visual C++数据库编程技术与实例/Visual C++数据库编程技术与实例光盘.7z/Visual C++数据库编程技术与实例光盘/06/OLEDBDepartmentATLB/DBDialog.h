// DBDialog.h : Declaration of the CDBDialog

#ifndef __DBDIALOG_H_
#define __DBDIALOG_H_

#include "resource.h"       // main symbols
//Added by Chuck Wood for OLE DB support
#include "Department.h"
#include <atlhost.h>

/////////////////////////////////////////////////////////////////////////////
// CDBDialog
class CDBDialog : 
	public CAxDialogImpl<CDBDialog>
{
/*
	Protected variables and function prototypes added by 
	Chuck Wood for Visual C++ Database Developer's Guide
*/
protected:
	CDepartment* m_pSet;
	BOOL m_bAddingRecord;
	BOOL m_bChangesMade;
	enum {	FIRST = 0,
			LAST = 1,
			NEXT = 2,
			PREV = 3 };
	void DisplayError(char *strMessage, HRESULT hr = S_OK, char *strFunction = NULL);
	void DisplayStatus(char *strMessage);
	HRESULT SaveDepartment();
	void OnMove(int position);
	void AddRecord();
	void ResetRowSet();
	void UpdateData(BOOL bSaveChangesToSet = TRUE);
	HRESULT UpdateDepartment();

public:
	CDBDialog()
	{
		//Added by Chuck Wood to open & initialize the dialog box
		m_pSet = new CDepartment();
		m_bChangesMade = FALSE;
		m_bAddingRecord = FALSE;
		DoModal();
	}

	~CDBDialog()
	{
		delete m_pSet;
	}

	enum { IDD = IDD_DBDIALOG };

BEGIN_MSG_MAP(CDBDialog)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	COMMAND_HANDLER(IDC_ADD, BN_CLICKED, OnClickedAdd)
	COMMAND_HANDLER(IDC_DELETE, BN_CLICKED, OnClickedDelete)
	COMMAND_HANDLER(IDC_FINDEPARTMENT, BN_CLICKED, OnClickedFindepartment)
	COMMAND_HANDLER(IDC_SAVE, BN_CLICKED, OnClickedSave)
	COMMAND_HANDLER(IDC_FIRST, BN_CLICKED, OnClickedFirst)
	COMMAND_HANDLER(IDC_LAST, BN_CLICKED, OnClickedLast)
	COMMAND_HANDLER(IDC_NEXT, BN_CLICKED, OnClickedNext)
	COMMAND_HANDLER(IDC_PREV, BN_CLICKED, OnClickedPrev)
	COMMAND_HANDLER(IDC_DEPARTMENTCODE, EN_CHANGE, OnChangeDepartmentcode)
	COMMAND_HANDLER(IDC_DEPARTMENTNAME, EN_CHANGE, OnChangeDepartmentname)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		_Module.Lock();
		SendMessage(GetDlgItem(IDC_DEPARTMENTCODE), 
			EM_LIMITTEXT, (WPARAM)4, 0);
		SendMessage(GetDlgItem(IDC_DEPARTMENTNAME), 
			EM_LIMITTEXT, (WPARAM)50, 0);
		SendMessage(GetDlgItem(IDC_FINDDEPARTMENTEDIT), 
			EM_LIMITTEXT, (WPARAM)50, 0);
		HRESULT hr = m_pSet->Open();
		if (FAILED(hr)) {
			DisplayError("Open Rowset failed", hr, "OnInitDialog");
			exit(1);	//Better not start
		}
		//Start DB Transaction
		hr = m_pSet->m_session.StartTransaction();
		if (FAILED(hr)) {
			DisplayError("StartTransaction failed", hr, "OnInitDialog");
		}
		m_pSet->MoveFirst();
		UpdateData(FALSE);	//Write Values to Window
		return 1;  // Let the system set the focus
	}

	LRESULT OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		if (m_bChangesMade) {
			if (MessageBox(
				"Changes were made.  Do you wish to save?", 
				"Save Changes?", MB_YESNO) == IDYES) {
				UpdateDepartment();
			}
		}
		m_pSet->m_session.Abort();	//Rollback the transaction
		EndDialog(wID);	//Close the dialog box
		_Module.Unlock(); //Exit this program
		return 0;
	}
	LRESULT OnClickedAdd(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		if (FAILED(SaveDepartment())) {
			return 0;
		}
		AddRecord();
		return 0;
	}
	LRESULT OnClickedDelete(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		if (MessageBox(	//Be sure to verify your deletes
				"Are you sure you want to delete?", "",
				MB_YESNO)
			!= IDYES) {
			return 0;
		}
		//Delete record and test
		if (m_bAddingRecord) {
			//Just abort the add
			m_bAddingRecord = FALSE;
		}
		else {
			//Delete the current row in the rowset
			HRESULT hr = m_pSet->Delete();
			if (FAILED(hr)) {	//Test Delete
				DisplayError("Delete Failed", hr, "OnClickedDelete");
			}
			else {	//Set changes to true if Delete worked.
				m_bChangesMade = TRUE;
			}
		}
		ResetRowSet();
		return 0;
	}
	LRESULT OnClickedFindepartment(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		char filterDepartment[5];
		if (FAILED(SaveDepartment())) {
			return 0;
		}
		GetDlgItemText(IDC_FINDDEPARTMENTEDIT,
			filterDepartment, 5);
		delete m_pSet->m_strFilter;
		m_pSet->m_strFilter = new char[25];
		strcpy (m_pSet->m_strFilter, "DepartmentCode = '");
		strcat (m_pSet->m_strFilter, filterDepartment);
		strcat (m_pSet->m_strFilter, "'");
		//Requery for new filter
		m_pSet->Close();
		m_pSet->OpenRowset();
		m_pSet->MoveFirst();
		UpdateData(FALSE);	//Update the window
		return 0;
	}
	LRESULT OnClickedSave(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		UpdateDepartment();
		return 0;
	}
	LRESULT OnClickedFirst(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		OnMove(FIRST);
		return 0;
	}
	LRESULT OnClickedLast(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		OnMove(LAST);
		return 0;
	}
	LRESULT OnClickedNext(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		OnMove(NEXT);
		return 0;
	}
	LRESULT OnClickedPrev(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		OnMove(PREV);
		return 0;
	}
	LRESULT OnChangeDepartmentcode(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		m_bChangesMade = TRUE;
		return 0;
	}
	LRESULT OnChangeDepartmentname(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		m_bChangesMade = TRUE;
		return 0;
	}
};

#endif //__DBDIALOG_H_

