// DBDialog.cpp : Implementation of CDBDialog
#include "stdafx.h"
#include "DBDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CDBDialog

/**********************************************
	The following were added by Chuck Wood for
	Visual C++ Database Developer's Guide
**********************************************/
	void CDBDialog::OnMove(int position)
	{
		//This OnMove is not really an event, but
		//rather is called by other move functions
		HRESULT hr;
		if (FAILED(SaveDepartment())) {
			DisplayStatus("Save failed.  No move is possible.");
			return;		//End if save did not work.
		}
		DisplayStatus("");
		switch (position) {
		case (FIRST) :
			hr = m_pSet->MoveFirst();
			break;
		case (NEXT) :
			hr = m_pSet->MoveNext();
			if (hr != S_OK) {	//EOF
				DisplayStatus("Last record reached.");
				hr = m_pSet->MoveLast();
			}
			break;
		case (LAST) :
			hr = m_pSet->MoveLast();
			break;
		case (PREV) :
			hr = m_pSet->MovePrev();
			if (hr != S_OK) {	//BOF
				DisplayStatus("First record reached.");
				hr = m_pSet->MoveFirst();
			}
			break;
		}
		if (FAILED(hr)) {
			DisplayError("No records found. Adding new record");
			DisplayStatus("No records found.");
			AddRecord();
		}
		UpdateData(FALSE);	//Update Screen
	}
	void CDBDialog::ResetRowSet()
	{
		if (m_pSet->MoveNext() != S_OK) {	//Go to next record
			if (m_pSet->MoveFirst() != S_OK) {
				MessageBox("No more records", "",
					MB_ICONEXCLAMATION);
				//No records, so set up an add record
				AddRecord();
			}
		}
		UpdateData(FALSE);	//Write changes to window
	}
	void CDBDialog::AddRecord()
	{
		m_pSet->ClearRecord();
		m_bAddingRecord = TRUE;
		UpdateData(FALSE);	//Update the window
	}
	HRESULT CDBDialog::SaveDepartment()
	{
		UpdateData(TRUE);	//Read from screen
		HRESULT hr;
		if (m_bAddingRecord) {
			hr = m_pSet->Insert();	//Insert New rew
		}
		else {
			hr = m_pSet->SetData();	//Update current row
		}
		if (FAILED(hr)) {
			DisplayError("Update Failed.", hr, "SaveDepartment");
		}
		else {
			m_bAddingRecord = FALSE;
		}
		return hr;
	}
	HRESULT CDBDialog::UpdateDepartment() {
		m_bChangesMade = FALSE;
		HRESULT hr = SaveDepartment();
		if (FAILED(hr)) {
			return hr;
		}
		hr = m_pSet->m_session.Commit();	//Make Changes permanent
		if (FAILED(hr)){
			DisplayError("Commit failed", hr, "UpdateDepartment");
		}
		//Restart transaction
		hr = m_pSet->m_session.StartTransaction();
		if (FAILED(hr)){
			DisplayError("StartTransaction failed", hr, "UpdateDepartment");
		}
		return hr;
	}
	void CDBDialog::UpdateData(BOOL bSaveChangesToSet)
	{
		if (bSaveChangesToSet) {
			//Read From Screen
			GetDlgItemText(IDC_DEPARTMENTCODE,
				(char *) m_pSet->m_DepartmentCode, 5);
			GetDlgItemText(IDC_DEPARTMENTNAME,
				(char *) m_pSet->m_DepartmentName, 51);
		}
		else {
			//First preserve change variable
			BOOL ChangesMade = m_bChangesMade;
			//Write to Screen
			SetDlgItemText(IDC_DEPARTMENTCODE,
				(char *) m_pSet->m_DepartmentCode);
			SetDlgItemText(IDC_DEPARTMENTNAME,
				(char *) m_pSet->m_DepartmentName);
			//Now preserve change variable
			m_bChangesMade = ChangesMade;
		}
	}
	void CDBDialog::DisplayStatus(char *strMessage)
	{
		SetDlgItemText(IDC_STATUS, strMessage);
	}
	void CDBDialog::DisplayError(char *strMessage, HRESULT hresult, char *strFunction)
	{
		//Allow 1 k for the error message
		char message[1024];
		strcpy(message, strMessage);
		if (strFunction) {	//Check for function equal to null
			//Function was passed, so see what function it was
			strcat(message, " in the ");
			strcat(message, strFunction);
			strcat(message, " function ");
		}
		if (FAILED(hresult)) {
			char holdmessage[512];	//Allow 512 bytes for HR message
			sprintf(holdmessage, "\n\nHRESULT was %ld", hresult);
			strcat(message, holdmessage);
		}
		MessageBox(message, "An error has occurred");
	}