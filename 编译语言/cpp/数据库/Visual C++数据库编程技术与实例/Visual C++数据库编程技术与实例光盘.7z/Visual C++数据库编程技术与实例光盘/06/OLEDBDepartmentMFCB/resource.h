//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OLEDBDepartmentMFC.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_OLEDBDEPARTMENTMFC_FORM     101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_MAINFRAME                   128
#define IDR_OLEDBDTYPE                  129
#define IDD_FINDDEPARTMENT              130
#define IDC_DEPARTMENTCODE              1000
#define IDC_FINDDEPARTMENT              1000
#define IDC_DEPARTMENTNAME              1001
#define ID_EDIT_DELETETCTRLDEL          32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
