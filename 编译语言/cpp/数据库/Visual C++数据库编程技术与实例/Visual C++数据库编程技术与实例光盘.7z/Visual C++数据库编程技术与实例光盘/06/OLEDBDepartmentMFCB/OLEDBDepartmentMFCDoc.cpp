// OLEDBDepartmentMFCDoc.cpp : implementation of the COLEDBDepartmentMFCDoc class
//

#include "stdafx.h"
#include "OLEDBDepartmentMFC.h"

#include "OLEDBDepartmentMFCSet.h"
#include "OLEDBDepartmentMFCDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCDoc

IMPLEMENT_DYNCREATE(COLEDBDepartmentMFCDoc, CDocument)

BEGIN_MESSAGE_MAP(COLEDBDepartmentMFCDoc, CDocument)
	//{{AFX_MSG_MAP(COLEDBDepartmentMFCDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCDoc construction/destruction

COLEDBDepartmentMFCDoc::COLEDBDepartmentMFCDoc()
{
	// TODO: add one-time construction code here

}

COLEDBDepartmentMFCDoc::~COLEDBDepartmentMFCDoc()
{
}

BOOL COLEDBDepartmentMFCDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCDoc serialization

void COLEDBDepartmentMFCDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCDoc diagnostics

#ifdef _DEBUG
void COLEDBDepartmentMFCDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void COLEDBDepartmentMFCDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCDoc commands
