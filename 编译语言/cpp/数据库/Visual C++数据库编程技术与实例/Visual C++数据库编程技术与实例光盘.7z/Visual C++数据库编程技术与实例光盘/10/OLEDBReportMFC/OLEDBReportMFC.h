// OLEDBReportMFC.h : main header file for the OLEDBREPORTMFC application
//

#if !defined(AFX_OLEDBREPORTMFC_H__52C04158_4E05_11D2_9949_F7F727FAE648__INCLUDED_)
#define AFX_OLEDBREPORTMFC_H__52C04158_4E05_11D2_9949_F7F727FAE648__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "OLEDBReportMFC_i.h"

/////////////////////////////////////////////////////////////////////////////
// COLEDBReportMFCApp:
// See OLEDBReportMFC.cpp for the implementation of this class
//

class COLEDBReportMFCApp : public CWinApp
{
public:
	COLEDBReportMFCApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBReportMFCApp)
	public:
	virtual BOOL InitInstance();
		virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(COLEDBReportMFCApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL m_bATLInited;
private:
	BOOL InitATL();
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBREPORTMFC_H__52C04158_4E05_11D2_9949_F7F727FAE648__INCLUDED_)
