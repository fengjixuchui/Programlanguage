// OLEDBReportMFCView.cpp : implementation of the COLEDBReportMFCView class
//

#include "stdafx.h"
#include "OLEDBReportMFC.h"

#include "OLEDBReportMFCDoc.h"
#include "OLEDBReportMFCView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBReportMFCView

IMPLEMENT_DYNCREATE(COLEDBReportMFCView, CScrollView)

BEGIN_MESSAGE_MAP(COLEDBReportMFCView, CScrollView)
	//{{AFX_MSG_MAP(COLEDBReportMFCView)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBReportMFCView construction/destruction

COLEDBReportMFCView::COLEDBReportMFCView()
{
}

COLEDBReportMFCView::~COLEDBReportMFCView()
{
	m_pSet->Close();
}

BOOL COLEDBReportMFCView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// COLEDBReportMFCView drawing

void COLEDBReportMFCView::OnDraw(CDC* pDC)
{
	OutputReport(pDC);	//Display contents
}

void COLEDBReportMFCView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
	//Limit size to 8" x 20"
	CSize sizeTotal(800, 2000);
	//Because of MM_LOENGLISH, Sizes are in .01 of an inch
	SetScrollSizes(MM_LOENGLISH, sizeTotal);
	//Set the window title
	GetDocument()->SetTitle("OLE DB Students Per Class Report");
	//Set the m_pSet pointer to the m_dbSet recordset
	m_pSet = &GetDocument()->m_StudentsPerClass;
	//Open the recordset
	HRESULT hr = m_pSet->Open();
	if (hr != S_OK)
	{
		AfxMessageBox(_T("Row set failed to open."), MB_OK);
	}
}

/////////////////////////////////////////////////////////////////////////////
// COLEDBReportMFCView printing

BOOL COLEDBReportMFCView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void COLEDBReportMFCView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void COLEDBReportMFCView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

/////////////////////////////////////////////////////////////////////////////
// COLEDBReportMFCView diagnostics

#ifdef _DEBUG
void COLEDBReportMFCView::AssertValid() const
{
	CScrollView::AssertValid();
}

void COLEDBReportMFCView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

COLEDBReportMFCDoc* COLEDBReportMFCView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(COLEDBReportMFCDoc)));
	return (COLEDBReportMFCDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBReportMFCView message handlers


void COLEDBReportMFCView::OnPrint(CDC* pDC, CPrintInfo* pInfo) 
{
	OutputReport(pDC, pInfo);	//Display contents
}

void COLEDBReportMFCView::OutputReport(CDC* pDC, CPrintInfo* pInfo)
{
	CString line;	//This is the print line
	TEXTMETRIC metrics;	//Font measurements
	int y = 0;		//Current y position on report
	CFont TitleFont;	//Font for Title
	CFont HeadingFont;	//Font for headings
	CFont DetailFont;	//Font for detail lines
	CFont FooterFont;	//Font for footer
	//Tab stops at 1 inch, 2.5 inches, and 6.5 inches
	int TabStops[] = {300, 650};
	//Tab stops at 3.5 inches and 6.5 inches
	int FooterTabStops[] = {350, 650};
	HRESULT m_hrMoveResult = S_OK;
	if (!pInfo || pInfo->m_nCurPage == 1) {
		//Set the recordset at the beginning
		m_hrMoveResult = m_pSet->MoveFirst();
	}
	//Bold font for Title
	TitleFont.CreateFont(44, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY, DEFAULT_PITCH | FF_ROMAN, 
		"Times New Roman");
	//Bold and underlined font for headings
	HeadingFont.CreateFont(36, 0, 0, 0, FW_BOLD, FALSE, TRUE, 0,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY, DEFAULT_PITCH | FF_ROMAN, 
		"Times New Roman");
	//Normal font for detail
	DetailFont.CreateFont(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY, DEFAULT_PITCH | FF_ROMAN, 
		"Times New Roman");
	//Small font for footer
	FooterFont.CreateFont(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY, DEFAULT_PITCH | FF_ROMAN, 
		"Times New Roman");
	//Capture default settings when setting the title font
	CFont* OldFont = (CFont*) pDC->SelectObject(&TitleFont);
	//Retrieve the heading font measurements
	pDC->GetTextMetrics(&metrics);
	//Compute the heading line height
	int LineHeight = metrics.tmHeight + metrics.tmExternalLeading;
	//Set Y to the line height.
	y -= LineHeight;	
	pDC->TextOut(100, 0, "OLE DB Students Per Class Report");
/*
	Y must be set to negative numbers because MM_LOENGLISH was
	used in the CODBCReportView::OnInitialUpdate funciton.
*/
	//Set the Heading font
	pDC->SelectObject(&HeadingFont);
	//Format the heading
	line.Format("%s \t%s \t%s","Dept", "Class", "Students");
	//Output the heading at (2, y) using 2 tabs
	pDC->TabbedTextOut(2, y, line, 2, TabStops, 0);
	//Compute the detail line height
	LineHeight = metrics.tmHeight + metrics.tmExternalLeading;
	y -= LineHeight;	//Adjust y position
	//Set the detail font
	pDC->SelectObject(&DetailFont);
	//Retrieve detail font measurements
	pDC->GetTextMetrics(&metrics);
	//Compute the detail line height
	LineHeight = metrics.tmHeight + metrics.tmExternalLeading;
	//Scroll through the recordset
	while (m_hrMoveResult == S_OK) {
		if (pInfo && abs(y) > 1000) {
			pInfo->SetMaxPage(pInfo->m_nCurPage + 1);
			break;
		}
		//Format the detail line
		line.Format("%s \t%s \t%d",
			m_pSet->m_DepartmentName,
			m_pSet->m_Description,
			m_pSet->m_NumberOfStudents);
		//Output the print line at (2, y) using 2 tabs
		pDC->TabbedTextOut(2, y, line, 2, TabStops, 0);
		//Get the next recordset number
		y -= LineHeight;	//Adjust y position
		m_hrMoveResult = m_pSet->MoveNext();
	}
	if (pInfo) {
		//Set the footer font
		pDC->SelectObject(&FooterFont);
		//Format the footer
		line.Format(
			"OLE DB Report \tPage %d \tVisual C++ DB Guide",
			pInfo->m_nCurPage);
		//Output the footer at the bottom using tabs
		pDC->TabbedTextOut(1, -1025, line, 2, FooterTabStops, 0);
	}
	//Restore default settings
	pDC->SelectObject(OldFont);
}
