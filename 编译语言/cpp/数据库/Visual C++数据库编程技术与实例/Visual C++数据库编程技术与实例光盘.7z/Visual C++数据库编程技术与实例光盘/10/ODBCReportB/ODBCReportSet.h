#if !defined(AFX_ODBCREPORTSET_H__FA789BA3_4121_11D2_9949_B5757778F646__INCLUDED_)
#define AFX_ODBCREPORTSET_H__FA789BA3_4121_11D2_9949_B5757778F646__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ODBCReportSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CODBCReportSet recordset

class CODBCReportSet : public CRecordset
{
public:
	CODBCReportSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CODBCReportSet)

// Field/Param Data
	//{{AFX_FIELD(CODBCReportSet, CRecordset)
	CString	m_ClassID;
	CString	m_Description;
	int		m_Credits;
	CString	m_DepartmentCode;
	CString	m_DepartmentName;
	long	m_InstructorID;
	CString	m_Name;
	CString	m_DepartmentCode2;
	CString	m_EMAIL;
	CString	m_Notes;
	long	m_SectionID;
	CString	m_ClassID2;
	int		m_SectionNumber;
	BOOL	m_IsLab;
	CString	m_Term;
	int		m_Year;
	CString	m_Room;
	long	m_InstructorID2;
	long	m_LabsParentSectionID;
	CString	m_Notes2;
	long	m_StudentID;
	CString	m_FirstName;
	CString	m_MidName;
	CString	m_LastName;
	CString	m_Address;
	CString	m_City;
	CString	m_StateOrProvince;
	CString	m_PostalCode;
	CString	m_PhoneNumber;
	CString	m_EMAIL2;
	CString	m_Major;
	CString	m_StudentSSN;
	long	m_StudentID2;
	long	m_SectionID2;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CODBCReportSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ODBCREPORTSET_H__FA789BA3_4121_11D2_9949_B5757778F646__INCLUDED_)
