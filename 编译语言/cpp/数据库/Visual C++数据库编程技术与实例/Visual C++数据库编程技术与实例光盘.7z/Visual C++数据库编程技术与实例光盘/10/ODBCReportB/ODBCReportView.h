// ODBCReportView.h : interface of the CODBCReportView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ODBCREPORTVIEW_H__FA789B9B_4121_11D2_9949_B5757778F646__INCLUDED_)
#define AFX_ODBCREPORTVIEW_H__FA789B9B_4121_11D2_9949_B5757778F646__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ODBCReportSet.h"

class CODBCReportView : public CScrollView
{
protected: // create from serialization only
	CODBCReportView();
	DECLARE_DYNCREATE(CODBCReportView)

// Attributes
public:
	CODBCReportDoc* GetDocument();
	CODBCReportSet* m_pSet;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CODBCReportView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CODBCReportView();
	void OutputReport(CDC* pDC, CPrintInfo* pInfo = NULL);
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CODBCReportView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ODBCReportView.cpp
inline CODBCReportDoc* CODBCReportView::GetDocument()
   { return (CODBCReportDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ODBCREPORTVIEW_H__FA789B9B_4121_11D2_9949_B5757778F646__INCLUDED_)
