// CODBCReportSet.cpp : implementation file
//

#include "stdafx.h"
#include "ODBCReport.h"
#include "ODBCReportSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCODBCReportSet

IMPLEMENT_DYNAMIC(CODBCReportSet, CRecordset)

CODBCReportSet::CODBCReportSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CODBCReportSet)
	m_ClassID = _T("");
	m_Description = _T("");
	m_Credits = 0;
	m_DepartmentCode = _T("");
	m_DepartmentName = _T("");
	m_InstructorID = 0;
	m_Name = _T("");
	m_DepartmentCode2 = _T("");
	m_EMAIL = _T("");
	m_Notes = _T("");
	m_SectionID = 0;
	m_ClassID2 = _T("");
	m_SectionNumber = 0;
	m_IsLab = FALSE;
	m_Term = _T("");
	m_Year = 0;
	m_Room = _T("");
	m_InstructorID2 = 0;
	m_LabsParentSectionID = 0;
	m_Notes2 = _T("");
	m_StudentID = 0;
	m_FirstName = _T("");
	m_MidName = _T("");
	m_LastName = _T("");
	m_Address = _T("");
	m_City = _T("");
	m_StateOrProvince = _T("");
	m_PostalCode = _T("");
	m_PhoneNumber = _T("");
	m_EMAIL2 = _T("");
	m_Major = _T("");
	m_StudentSSN = _T("");
	m_StudentID2 = 0;
	m_SectionID2 = 0;
	m_nFields = 34;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
	m_strSort = "Department.DepartmentCode, \
				Instructor.Name, \
				Student.LastName";
	m_strFilter = "Instructor.DepartmentCode \
					= Department.DepartmentCode \
				AND Section.InstructorID \
					= Instructor.InstructorID \
				AND Section.ClassID \
					= Class.ClassID \
				AND StudentClass.StudentID \
					= Student.StudentID \
				AND StudentClass.SectionID \
					= Section.SectionID";
}


CString CODBCReportSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=Classes");
}

CString CODBCReportSet::GetDefaultSQL()
{
	return _T("[Class],[Department],[Instructor],[Section],[Student],[StudentClass]");
}

void CODBCReportSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CODBCReportSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[Class].[ClassID]"), m_ClassID);
	RFX_Text(pFX, _T("[Description]"), m_Description);
	RFX_Int(pFX, _T("[Credits]"), m_Credits);
	RFX_Text(pFX, _T("[Department].[DepartmentCode]"), m_DepartmentCode);
	RFX_Text(pFX, _T("[DepartmentName]"), m_DepartmentName);
	RFX_Long(pFX, _T("[Instructor].[InstructorID]"), m_InstructorID);
	RFX_Text(pFX, _T("[Name]"), m_Name);
	RFX_Text(pFX, _T("[Instructor].[DepartmentCode]"), m_DepartmentCode2);
	RFX_Text(pFX, _T("[Instructor].[EMAIL]"), m_EMAIL);
	RFX_Text(pFX, _T("[Instructor].[Notes]"), m_Notes);
	RFX_Long(pFX, _T("[Section].[SectionID]"), m_SectionID);
	RFX_Text(pFX, _T("[Section].[ClassID]"), m_ClassID2);
	RFX_Int(pFX, _T("[SectionNumber]"), m_SectionNumber);
	RFX_Bool(pFX, _T("[IsLab]"), m_IsLab);
	RFX_Text(pFX, _T("[Term]"), m_Term);
	RFX_Int(pFX, _T("[Year]"), m_Year);
	RFX_Text(pFX, _T("[Room]"), m_Room);
	RFX_Long(pFX, _T("[Section].[InstructorID]"), m_InstructorID2);
	RFX_Long(pFX, _T("[LabsParentSectionID]"), m_LabsParentSectionID);
	RFX_Text(pFX, _T("[Section].[Notes]"), m_Notes2);
	RFX_Long(pFX, _T("[Student].[StudentID]"), m_StudentID);
	RFX_Text(pFX, _T("[FirstName]"), m_FirstName);
	RFX_Text(pFX, _T("[MidName]"), m_MidName);
	RFX_Text(pFX, _T("[LastName]"), m_LastName);
	RFX_Text(pFX, _T("[Address]"), m_Address);
	RFX_Text(pFX, _T("[City]"), m_City);
	RFX_Text(pFX, _T("[StateOrProvince]"), m_StateOrProvince);
	RFX_Text(pFX, _T("[PostalCode]"), m_PostalCode);
	RFX_Text(pFX, _T("[PhoneNumber]"), m_PhoneNumber);
	RFX_Text(pFX, _T("[Student].[EMAIL]"), m_EMAIL2);
	RFX_Text(pFX, _T("[Major]"), m_Major);
	RFX_Text(pFX, _T("[StudentSSN]"), m_StudentSSN);
	RFX_Long(pFX, _T("[StudentClass].[StudentID]"), m_StudentID2);
	RFX_Long(pFX, _T("[StudentClass].[SectionID]"), m_SectionID2);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CODBCReportSet diagnostics

#ifdef _DEBUG
void CODBCReportSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CODBCReportSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
