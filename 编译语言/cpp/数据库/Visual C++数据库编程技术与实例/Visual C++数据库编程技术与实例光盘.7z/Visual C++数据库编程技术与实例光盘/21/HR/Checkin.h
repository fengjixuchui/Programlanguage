// Checkin.h: interface for the CCheckin class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHECKIN_H__DAC0E5C6_61EC_4AA1_80B4_328F23E8C011__INCLUDED_)
#define AFX_CHECKIN_H__DAC0E5C6_61EC_4AA1_80B4_328F23E8C011__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCheckin  
{
private:
	CString CheckDate;
	int Emp_Id;
	float qqDays;
	float ccDays;
	float bjDays;
	float sjDays;
	float kgDays;
	float fdxjDays;
	float nxjDays;
	float dxjDays;
	int cdMinutes;
	int ztMinutes;
	float ot1Days;
	float ot2Days;
	float ot3Days;
	CString Memo;
public:
	CCheckin();
	virtual ~CCheckin();
	
	CString GetCheckDate();
	void SetCheckDate(CString cDate);
	int GetEmp_Id();
	void SetEmp_Id(int iEmp_Id);
	float GetqqDays();
	void SetqqDays(float fqqDays);
	float GetccDays();
	void SetccDays(float fccDays);
	float GetbjDays();
	void SetbjDays(float fbjDays);
	float GetsjDays();
	void SetsjDays(float fsjDays);
	float GetkgDays();
	void SetkgDays(float fkgDays);
	float GetfdxjDays();
	void SetfdxjDays(float ffdxjDays);
	float GetnxjDays();
	void SetnxjDays(float fnxjDays);
	float GetdxjDays();
	void SetdxjDays(float fdxjDays);
	int GetcdMinutes();
	void SetcdMinutes(int icdMinutes);
	int GetztMinutes();
	void SetztMinutes(int iztMinutes);
	float Getot1Days();
	void Setot1Days(float fot1Days);
	float Getot2Days();
	void Setot2Days(float fot2Days);
	float Getot3Days();
	void Setot3Days(float fot3Days);
	CString GetMemo();
	void SetMemo(CString cMemo);

	//���ݿ����
	int HaveRecord(CString cCheckDate, CString cEmp_Id); //�ж�ָ��Ա��/���ڵĿ��ڼ�¼�Ƿ����
	void sql_insert(); 
	void sql_update(CString cCheckDate, CString cEmp_Id);
	void sql_delete(CString cCheckDate, CString cEmp_Id);
	void sql_deleteByEmp(CString cEmp_Id);
};

#endif // !defined(AFX_CHECKIN_H__DAC0E5C6_61EC_4AA1_80B4_328F23E8C011__INCLUDED_)
