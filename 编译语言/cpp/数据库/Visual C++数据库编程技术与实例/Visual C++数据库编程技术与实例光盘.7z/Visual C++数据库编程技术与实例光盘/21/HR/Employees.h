// Employees.h: interface for the CEmployees class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EMPLOYEES_H__B8063B4E_329F_4C28_BE56_5B92252C2935__INCLUDED_)
#define AFX_EMPLOYEES_H__B8063B4E_329F_4C28_BE56_5B92252C2935__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ADOConn.h"
class CEmployees  
{
private:
	int Emp_Id;
	CString Emp_Name;
	CString Sex;
	CString Nationality;
	CString Birth;
	CString Political_Party;
	CString Culture_Level;
	CString Marital_Condition;
	CString Family_Place;
	CString Id_Card;
	CString BadgeId;
	CString Office_phone;
	CString Mobile;
	CString Files_Keep_Org;
	CString Hukou;
	CString HireDate;
	int Dep_Id;
	CString Position;
	CString Title;
	int State;
	int UpperId;
	CString Contract_Duration;
	CString Memo;
	CString Fillin_Person;
	CString Fillin_Time;
public:
	CEmployees();
	virtual ~CEmployees();
	
	int GetEmp_Id();
	void SetEmp_Id(int iEmp_Id);
	CString GetEmp_Name();
	void SetEmp_Name(CString cEmp_Name);
	CString GetSex();
	void SetSex(CString cSex);
	CString GetNationality();
	void SetNationality(CString cNationality);
	CString GetBirth();
	void SetBirth(CString cBirth);
	CString GetPolitical_Party();
	void SetPolitical_Party(CString cParty);
	CString GetCulture_Level();
	void SetCulture_Level(CString cLevel);
	CString GetMarital_Condition();
	void SetMarital_Condition(CString cCondition);
	CString GetFamily_Place();
	void SetFamily_Place(CString cPlace);
	CString GetId_Card();
	void SetId_Card(CString cCard);
	CString GetBadgeId();
	void SetBadgeId(CString cBadgeId);
	CString GetOffice_phone();
	void SetOffice_phone(CString cOffice);
	CString GetMobile();
	void SetMobile(CString cMobile);
	CString GetFiles_Keep_Org();
	void SetFiles_Keep_Org(CString cOrg);
	CString GetHukou();
	void SetHukou(CString cHukou);
	CString GetHireDate();
	void SetHireDate(CString cHireDate);
	int GetDep_Id();
	void SetDep_Id(int iDep_Id);
	CString GetPosition();
	void SetPosition(CString cPosition);
	CString GetTitle();
	void SetTitle(CString cTitle);
	int GetState();
	void SetState(int iState);
	int GetUpperId();
	void SetUpperId(int iUpperId);
	CString GetContract_Duration();
	void SetContract_Duration(CString cDuration);
	CString GetMemo();
	void SetMemo(CString cMemo);
	CString GetFillin_Person();
	void SetFillin_Person(CString cPerson);
	CString GetFillin_Time();
	void SetFillin_Time(CString cTime);

	//���ݿ����
	int HaveName(CString cEmp_Name); //�ж�ָ����Ա�������Ƿ����
	CString GetName(CString cEmp_id);  //����ָ����Ա����ŷ���Ա������
	void sql_insert();
	void sql_update(CString cEmp_Id);
	void sql_updateDep(CString cEmp_Id); //���²�����Ϣ���ڵ�ת����ʱ����
	void sql_delete(CString cEmp_Id);
	//����Ա����Ŷ�ȡ�����ֶ�ֵ
	void GetData(CString cEmp_Id);

};

#endif // !defined(AFX_EMPLOYEES_H__B8063B4E_329F_4C28_BE56_5B92252C2935__INCLUDED_)
