// Experience.h: interface for the CExperience class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EXPERIENCE_H__7E8126BB_2794_467C_B96A_BE13F85121D2__INCLUDED_)
#define AFX_EXPERIENCE_H__7E8126BB_2794_467C_B96A_BE13F85121D2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CExperience  
{
private:
	int Id;
	int Emp_Id;
	CString Start_Date;
	CString End_Date;
	CString School_Org;
	CString Title;
public:
	CExperience();
	virtual ~CExperience();
	
	int GetId();
	void SetId(int iId);
	int GetEmp_Id();
	void SetEmp_Id(int iEmp_Id);
	CString GetStart_Date();
	void SetStart_Date(CString cDate);
	CString GetEnd_Date();
	void SetEnd_Date(CString cDate);
	CString GetSchool_Org();
	void SetSchool_Org(CString cOrg);
	CString GetTitle();
	void SetTitle(CString cTitle);

	//���ݿ����
	void sql_insert();
	void sql_update(CString cId);
	void sql_delete(CString cId);
	void sql_deleteByEmp(CString cEmp_Id);
};

#endif // !defined(AFX_EXPERIENCE_H__7E8126BB_2794_467C_B96A_BE13F85121D2__INCLUDED_)
