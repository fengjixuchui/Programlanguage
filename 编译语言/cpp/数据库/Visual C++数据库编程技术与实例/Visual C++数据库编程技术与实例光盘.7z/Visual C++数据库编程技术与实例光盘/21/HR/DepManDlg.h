#include "Departments.h"

#if !defined(AFX_DEPMANDLG_H__BDB98248_5F3F_440E_8713_C89D2CCB9F48__INCLUDED_)
#define AFX_DEPMANDLG_H__BDB98248_5F3F_440E_8713_C89D2CCB9F48__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DepManDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDepManDlg dialog

class CDepManDlg : public CDialog
{
public:
	HTREEITEM m_root;  //����Tree�ؼ��ĸ��ڵ�
	CDepartments dep;  //CDepartments����
	CImageList m_treeImageList; //����ͼ���б�

// Construction
public:
	CDepManDlg(CWnd* pParent = NULL);   // standard constructor
	void AddtoTree(HTREEITEM m_node, int UpperId);
// Dialog Data
	//{{AFX_DATA(CDepManDlg)
	enum { IDD = IDD_DEPMAN_DIALOG };
	CTreeCtrl	m_tree;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDepManDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDepManDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnAddButton();
	afx_msg void OnCloseButton();
	afx_msg void OnModiButton();
	afx_msg void OnDelButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEPMANDLG_H__BDB98248_5F3F_440E_8713_C89D2CCB9F48__INCLUDED_)
