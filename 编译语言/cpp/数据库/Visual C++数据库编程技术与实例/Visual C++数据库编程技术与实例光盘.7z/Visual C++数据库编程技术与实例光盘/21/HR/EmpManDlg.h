//{{AFX_INCLUDES()
#include "adodc.h"
#include "datagrid.h"
//}}AFX_INCLUDES
#if !defined(AFX_EMPMANDLG_H__16916530_BFD9_4BD5_9F33_C8144D33D6F5__INCLUDED_)
#define AFX_EMPMANDLG_H__16916530_BFD9_4BD5_9F33_C8144D33D6F5__INCLUDED_

#include "Departments.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EmpManDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEmpManDlg dialog

class CEmpManDlg : public CDialog
{
public:
	HTREEITEM m_root;  //����Tree�ؼ��ĸ��ڵ�
	CDepartments dep;  //CDepartments����
	CImageList m_treeImageList; //����ͼ���б�

// Construction
public:
	CEmpManDlg(CWnd* pParent = NULL);   // standard constructor
    void AddtoTree(HTREEITEM m_node, int UpperId);
	void Refresh_Data();

// Dialog Data
	//{{AFX_DATA(CEmpManDlg)
	enum { IDD = IDD_EMPMAN_DIALOG };
	CComboBox	m_combo;
	CTreeCtrl	m_tree;
	CAdodc	m_Adodc;
	CDataGrid	m_datagrid;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEmpManDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEmpManDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeTypeCombo();
	afx_msg void OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnAddButton();
	afx_msg void OnModiButton();
	afx_msg void OnDelButton();
	afx_msg void OnTransferButton();
	afx_msg void OnFamilyButton();
	afx_msg void OnExpButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EMPMANDLG_H__16916530_BFD9_4BD5_9F33_C8144D33D6F5__INCLUDED_)
