// HrSysDlg.h : header file
//
#include "Users.h"

#if !defined(AFX_HRSYSDLG_H__A5E8F301_2869_4E3A_A08E_09AAE47DDF9E__INCLUDED_)
#define AFX_HRSYSDLG_H__A5E8F301_2869_4E3A_A08E_09AAE47DDF9E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CHrSysDlg dialog

class CHrSysDlg : public CDialog
{
public:
// Construction
public:
	CHrSysDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CHrSysDlg)
	enum { IDD = IDD_HRSYS_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHrSysDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CHrSysDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnExit();
	afx_msg void OnDep();
	afx_msg void OnEmp();
	afx_msg void OnCheck();
	afx_msg void OnEva();
	afx_msg void OnUserman();
	afx_msg void OnPwdman();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HRSYSDLG_H__A5E8F301_2869_4E3A_A08E_09AAE47DDF9E__INCLUDED_)
