//{{AFX_INCLUDES()
#include "adodc.h"
#include "datagrid.h"
//}}AFX_INCLUDES
#if !defined(AFX_FAMILYMANDLG_H__C6A8065D_7BB1_4F39_B9E5_85133F060ED7__INCLUDED_)
#define AFX_FAMILYMANDLG_H__C6A8065D_7BB1_4F39_B9E5_85133F060ED7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FamilyManDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFamilyManDlg dialog

class CFamilyManDlg : public CDialog
{
public:
	int iEmpId;  //���ڱ��浱ǰԱ�����
// Construction
public:
	CFamilyManDlg(CWnd* pParent = NULL);   // standard constructor
	void Refresh_Data();
// Dialog Data
	//{{AFX_DATA(CFamilyManDlg)
	enum { IDD = IDD_FAMILYMAN_DIALOG };
	CAdodc	m_adodc;
	CDataGrid	m_datagrid;
	CString	m_EmpName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFamilyManDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFamilyManDlg)
	afx_msg void OnAddButton();
	virtual BOOL OnInitDialog();
	afx_msg void OnModiButton();
	afx_msg void OnDelButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FAMILYMANDLG_H__C6A8065D_7BB1_4F39_B9E5_85133F060ED7__INCLUDED_)
