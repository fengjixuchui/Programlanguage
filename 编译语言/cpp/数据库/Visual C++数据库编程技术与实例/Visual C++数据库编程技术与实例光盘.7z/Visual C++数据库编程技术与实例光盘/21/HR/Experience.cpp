// Experience.cpp: implementation of the CExperience class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HrSys.h"
#include "Experience.h"
#include "ADOConn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CExperience::CExperience()
{
	Id = 0;
	Emp_Id = 0;
	Start_Date = "";
	End_Date = "";
	School_Org = "";
	Title = ""; 
}

CExperience::~CExperience()
{

}

int CExperience::GetId()
{
	return Id;
}

void CExperience::SetId(int iId)
{
	Id = iId;
}

int CExperience::GetEmp_Id()
{
	return Emp_Id;
}

void CExperience::SetEmp_Id(int iEmp_Id)
{
	Emp_Id = iEmp_Id;
}

CString CExperience::GetStart_Date()
{
	return Start_Date;
}

void CExperience::SetStart_Date(CString cDate)
{
	Start_Date = cDate;
}

CString CExperience::GetEnd_Date()
{
	return End_Date;
}

void CExperience::SetEnd_Date(CString cDate)
{
	End_Date = cDate;
}

CString CExperience::GetSchool_Org()
{
	return School_Org;
}

void CExperience::SetSchool_Org(CString cOrg)
{
	School_Org = cOrg;
}

CString CExperience::GetTitle()
{
	return Title;
}

void CExperience::SetTitle(CString cTitle)
{
	Title = cTitle;
}

	//���ݿ����
	void sql_insert();
	void sql_update(CString cId);
	void sql_delete(CString cId);
	void sql_deleteByEmp(CString cEmp_Id);

void CExperience::sql_insert()
{	
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����INSERT���
	CString strEmp_Id;
	strEmp_Id.Format("%d", Emp_Id);

	_bstr_t vSQL;
	vSQL = "INSERT INTO Experience (Emp_Id, Start_Date, End_Date, School_Org, Title) VALUES(" 
		+ strEmp_Id + ",'" + Start_Date + "','" + End_Date + "','" + School_Org + "','" 
		+ Title + "')";	
	//ִ��INSERT���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CExperience::sql_update(CString cId)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����UPDATE���
	CString strEmp_Id;
	strEmp_Id.Format("%d", Emp_Id);

	_bstr_t vSQL;
	vSQL = "UPDATE Experience SET Emp_Id=" + strEmp_Id + ", Start_Date='" 
		+ Start_Date +"', End_Date='" + End_Date + "', School_Org='" + School_Org
		+ "', Title='" + Title + "' WHERE Id=" + cId;
	//ִ��UPDATE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CExperience::sql_delete(CString cId)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����DELETE���
	_bstr_t vSQL;
	vSQL = "DELETE FROM Experience WHERE Id=" + cId;
	//ִ��DELETE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CExperience::sql_deleteByEmp(CString cEmp_Id)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����DELETE���
	_bstr_t vSQL;
	vSQL = "DELETE FROM Experience WHERE Emp_Id=" + cEmp_Id;
	//ִ��DELETE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}
