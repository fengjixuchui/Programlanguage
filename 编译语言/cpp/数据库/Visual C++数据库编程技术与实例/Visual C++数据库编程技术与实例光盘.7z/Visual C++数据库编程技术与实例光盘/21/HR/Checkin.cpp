// Checkin.cpp: implementation of the CCheckin class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HrSys.h"
#include "Checkin.h"
#include "ADOConn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCheckin::CCheckin()
{
	CheckDate = "";
	Emp_Id = 0;
	qqDays = 0;
	ccDays = 0;
	bjDays = 0;
	sjDays = 0;
	kgDays = 0;
	fdxjDays = 0;
	nxjDays = 0;
	dxjDays = 0;
	cdMinutes = 0;
	ztMinutes = 0;
	ot1Days = 0;
	ot2Days = 0;
	ot3Days = 0;
	Memo = "";
}

CCheckin::~CCheckin()
{

}

CString CCheckin::GetCheckDate()
{
	return CheckDate;
}

void CCheckin::SetCheckDate(CString cDate)
{
	CheckDate = cDate;
}

int CCheckin::GetEmp_Id()
{
	return Emp_Id;
}

void CCheckin::SetEmp_Id(int iEmp_Id)
{
	Emp_Id = iEmp_Id;
}

float CCheckin::GetqqDays()
{
	return qqDays;
}

void CCheckin::SetqqDays(float fqqDays)
{
	qqDays = fqqDays;
}

float CCheckin::GetccDays()
{
	return ccDays;
}

void CCheckin::SetccDays(float fccDays)
{
	ccDays = fccDays;
}

float CCheckin::GetbjDays()
{
	return bjDays;
}

void CCheckin::SetbjDays(float fbjDays)
{
	bjDays = fbjDays;
}

float CCheckin::GetsjDays()
{
	return sjDays;
}

void CCheckin::SetsjDays(float fsjDays)
{
	sjDays = fsjDays;
}

float CCheckin::GetkgDays()
{
	return kgDays;
}

void CCheckin::SetkgDays(float fkgDays)
{
	kgDays = fkgDays;
}

float CCheckin::GetfdxjDays()
{
	return fdxjDays;
}

void CCheckin::SetfdxjDays(float ffdxjDays)
{
	fdxjDays = ffdxjDays;
}

float CCheckin::GetnxjDays()
{
	return nxjDays;
}

void CCheckin::SetnxjDays(float fnxjDays)
{
	nxjDays = fnxjDays;
}

float CCheckin::GetdxjDays()
{
	return dxjDays;
}

void CCheckin::SetdxjDays(float fdxjDays)
{
	dxjDays = fdxjDays;
}

int CCheckin::GetcdMinutes()
{
	return cdMinutes;
}

void CCheckin::SetcdMinutes(int icdMinutes)
{
	cdMinutes = icdMinutes;
}

int CCheckin::GetztMinutes()
{
	return ztMinutes;
}

void CCheckin::SetztMinutes(int iztMinutes)
{
	ztMinutes = iztMinutes;
}

float CCheckin::Getot1Days()
{
	return ot1Days;
}

void CCheckin::Setot1Days(float fot1Days)
{
	ot1Days = fot1Days;
}

float CCheckin::Getot2Days()
{
	return ot2Days;
}

void CCheckin::Setot2Days(float fot2Days)
{
	ot2Days = fot2Days;
}

float CCheckin::Getot3Days()
{
	return ot3Days;
}

void CCheckin::Setot3Days(float fot3Days)
{
	ot3Days = fot3Days;
}

CString CCheckin::GetMemo()
{
	return Memo;
}

void CCheckin::SetMemo(CString cMemo)
{
	Memo = cMemo;
}

int CCheckin::HaveRecord(CString cCheckDate, CString cEmp_Id)
{	
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����SELECT���
	_bstr_t vSQL;
	vSQL = "SELECT * FROM Checkin WHERE CheckDate='" + cCheckDate 
		+ "' AND Emp_Id=" + cEmp_Id;
	
	//ִ��SELECT���
	_RecordsetPtr m_pRecordset;
	m_pRecordset = m_AdoConn.GetRecordSet(vSQL);
	if (m_pRecordset->adoEOF)
		return -1;
	else
		return 1;

	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

	
void CCheckin::sql_insert()
{	
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����INSERT���
	CString strEmp_Id;
	strEmp_Id.Format("%d", Emp_Id);
	CString strqq;
	strqq.Format("%f", qqDays);
	CString strcc;
	strcc.Format("%f", ccDays);
	CString strbj;
	strbj.Format("%f", bjDays);
	CString strsj;
	strsj.Format("%f", sjDays);
	CString strkg;
	strkg.Format("%f", kgDays);
	CString strfdxj;
	strfdxj.Format("%f", fdxjDays);
	CString strnxj;
	strnxj.Format("%f", nxjDays);
	CString strdxj;
	strdxj.Format("%f", dxjDays);
	CString strcd;
	strcd.Format("%d", cdMinutes);
	CString strzt;
	strzt.Format("%f", ztMinutes);
	CString strot1;
	strot1.Format("%f", ot1Days);
	CString strot2;
	strot2.Format("%f", ot2Days);
	CString strot3;
	strot3.Format("%f", ot3Days);


	_bstr_t vSQL;
	vSQL = "INSERT INTO Checkin VALUES('" + CheckDate + "'," + strEmp_Id + "," 
		+ strqq + "," + strcc + "," + strbj + "," + strsj + "," + strkg + ","
		+ strfdxj + "," + strnxj + "," + strdxj + "," + strcd + "," + strzt
		+ "," + strot1 + "," + strot2 + "," + strot3 + ",'" + Memo + "')";	
	//ִ��INSERT���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CCheckin::sql_update(CString cCheckDate, CString cEmp_Id)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����UPDATE���
	CString strEmp_Id;
	strEmp_Id.Format("%d", Emp_Id);
	CString strqq;
	strqq.Format("%f", qqDays);
	CString strcc;
	strcc.Format("%f", ccDays);
	CString strbj;
	strbj.Format("%f", bjDays);
	CString strsj;
	strsj.Format("%f", sjDays);
	CString strkg;
	strkg.Format("%f", kgDays);
	CString strfdxj;
	strfdxj.Format("%f", fdxjDays);
	CString strnxj;
	strnxj.Format("%f", nxjDays);
	CString strdxj;
	strdxj.Format("%f", dxjDays);
	CString strcd;
	strcd.Format("%d", cdMinutes);
	CString strzt;
	strzt.Format("%f", ztMinutes);
	CString strot1;
	strot1.Format("%f", ot1Days);
	CString strot2;
	strot2.Format("%f", ot2Days);
	CString strot3;
	strot3.Format("%f", ot3Days);

	_bstr_t vSQL;
	vSQL = "UPDATE Checkin SET qqDays=" + strqq + ", ccDays=" + strcc 
		+ ", bjDays=" + strbj + ", sjDays=" + strsj +", kgDays=" + strkg 
		+ ", fdxjDays=" + strfdxj + ", nxjDays=" + strnxj + ", dxjDays=" 
		+ strdxj + ", cdMinutes=" + strcd + ", ztMinutes=" + strzt
		+ ", ot1Days=" + strot1 + ", ot2Days=" + strot2 + ", ot3Days=" 
		+ strot3 + ", Memo='" + Memo + "' WHERE CheckDate='" + cCheckDate
		+ "' AND Emp_Id=" + cEmp_Id;
	//ִ��UPDATE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CCheckin::sql_delete(CString cCheckDate, CString cEmp_Id)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����DELETE���
	_bstr_t vSQL;
	vSQL = "DELETE FROM Checkin WHERE CheckDate='" + cCheckDate
		+ "' AND Emp_Id=" + cEmp_Id;
	//ִ��DELETE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CCheckin::sql_deleteByEmp(CString cEmp_Id)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����DELETE���
	_bstr_t vSQL;
	vSQL = "DELETE FROM Checkin WHERE Emp_Id=" + cEmp_Id;
	//ִ��DELETE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}
