//{{AFX_INCLUDES()
#include "adodc.h"
#include "datalist.h"
//}}AFX_INCLUDES
#if !defined(AFX_EMPSELDLG_H__540B0544_EB5D_4D25_BAA4_94CC73B29C32__INCLUDED_)
#define AFX_EMPSELDLG_H__540B0544_EB5D_4D25_BAA4_94CC73B29C32__INCLUDED_

#include "Departments.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EmpSelDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEmpSelDlg dialog

class CEmpSelDlg : public CDialog
{
public:
	HTREEITEM m_root;  //����Tree�ؼ��ĸ��ڵ�
	CDepartments dep;  //CDepartments����
	CImageList m_treeImageList; //����ͼ���б�
	int Emp_Id;  //���ڱ���ѡ���Ա�����
	CString Emp_name; //���ڱ���ѡ���Ա������

// Construction
public:
	CEmpSelDlg(CWnd* pParent = NULL);   // standard constructor
    void AddtoTree(HTREEITEM m_node, int UpperId);
	void Refresh_List();
// Dialog Data
	//{{AFX_DATA(CEmpSelDlg)
	enum { IDD = IDD_EMPSEL_DIALOG };
	CComboBox	m_Combo;
	CTreeCtrl	m_tree;
	CAdodc	m_Adodc;
	CDataList	m_datalist;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEmpSelDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEmpSelDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnClickTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangeTypeCombo();
	afx_msg void OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult);
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EMPSELDLG_H__540B0544_EB5D_4D25_BAA4_94CC73B29C32__INCLUDED_)
