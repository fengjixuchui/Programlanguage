// UserEditDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HrSys.h"
#include "UserEditDlg.h"
#include "Users.h"

extern CUsers curUser;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUserEditDlg dialog


CUserEditDlg::CUserEditDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUserEditDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUserEditDlg)
	m_UserName = _T("");
	//}}AFX_DATA_INIT
}


void CUserEditDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUserEditDlg)
	DDX_Control(pDX, IDC_USERTYPE_COMBO, m_UserType);
	DDX_Text(pDX, IDC_USERNAME_EDIT, m_UserName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUserEditDlg, CDialog)
	//{{AFX_MSG_MAP(CUserEditDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUserEditDlg message handlers

BOOL CUserEditDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_UserType.SetCurSel(iUserType - 1);
	
	if (curUser.GetUserName() != "Admin")
		GetDlgItem(IDC_USERTYPE_COMBO)->EnableWindow(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CUserEditDlg::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);

	CUsers usr;
	usr.SetUserName(m_UserName);
	usr.SetPwd("111111");
	usr.SetUser_type(m_UserType.GetCurSel()+1);
	
	if (usr.HaveName(m_UserName) == 1) //������ڵ�ǰ�û�
	{
		MessageBox("��ǰ�û��Ѵ��ڣ���ѡ�������û���");
		return;
	}
	//�����û���¼
	usr.sql_insert();

	CDialog::OnOK();
}
