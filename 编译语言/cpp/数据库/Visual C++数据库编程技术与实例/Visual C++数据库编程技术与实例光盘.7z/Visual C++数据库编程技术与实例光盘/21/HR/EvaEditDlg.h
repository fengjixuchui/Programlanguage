#if !defined(AFX_EVAEDITDLG_H__3D20D9AE_7F57_486A_B86D_84029C04B266__INCLUDED_)
#define AFX_EVAEDITDLG_H__3D20D9AE_7F57_486A_B86D_84029C04B266__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EvaEditDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEvaEditDlg dialog

class CEvaEditDlg : public CDialog
{
public:
	int iEmpId;
// Construction
public:
	CEvaEditDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEvaEditDlg)
	enum { IDD = IDD_EVAEDIT_DIALOG };
	int		m_cfAmount;
	CString	m_cfReason;
	CString	m_EmpName;
	int		m_jlAmount;
	CString	m_jlReason;
	CString	m_Memo;
	CString	m_Month;
	CString	m_Zt;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEvaEditDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEvaEditDlg)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EVAEDITDLG_H__3D20D9AE_7F57_486A_B86D_84029C04B266__INCLUDED_)
