// Family.cpp: implementation of the CFamily class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HrSys.h"
#include "Family.h"
#include "ADOConn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFamily::CFamily()
{
	Id = 0;
	Emp_Id = 0;
	Name = "";
	Sex = "";
	Age = 0;
	Relationship = "";
	WorkingOrg = "";
}

CFamily::~CFamily()
{

}

int CFamily::GetId()
{
	return Id;
}

void CFamily::SetId(int iId)
{
	Id = iId;
}

int CFamily::GetEmp_Id()
{
	return Emp_Id;
}

void CFamily::SetEmp_Id(int iEmp_Id)
{
	Emp_Id = iEmp_Id;
}

CString CFamily::GetName()
{
	return Name;
}

void CFamily::SetName(CString cName)
{
	Name = cName;
}

CString CFamily::GetSex()
{
	return Sex;
}

void CFamily::SetSex(CString cSex)
{
	Sex = cSex;
}

int CFamily::GetAge()
{
	return Age;
}

void CFamily::SetAge(int iAge)
{
	Age = iAge;
}

CString CFamily::GetRelationship()
{
	return Relationship;
}

void CFamily::SetRelationship(CString cRelationship)
{
	Relationship = cRelationship;
}

CString CFamily::GetWorkingOrg()
{
	return WorkingOrg;
}

void CFamily::SetWorkingOrg(CString cWorkingOrg)
{
	WorkingOrg = cWorkingOrg;
}

void CFamily::sql_insert()
{	
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����INSERT���
	CString strAge;
	strAge.Format("%d", Age);
	CString strEmp_Id;
	strEmp_Id.Format("%d", Emp_Id);

	_bstr_t vSQL;
	vSQL = "INSERT INTO Family (Emp_Id, Name, Sex, Age, Relationship, WorkingOrg) VALUES(" 
		+ strEmp_Id + ",'" + Name + "','" + Sex + "'," + strAge + ",'" 
		+ Relationship + "','" + WorkingOrg + "')";	
	//ִ��INSERT���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CFamily::sql_update(CString cId)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����UPDATE���
	CString strAge;
	strAge.Format("%d", Age);
	CString strEmp_Id;
	strEmp_Id.Format("%d", Emp_Id);

	_bstr_t vSQL;
	vSQL = "UPDATE Family SET Emp_Id=" + strEmp_Id + ", Name='" 
		+ Name +"', Sex='" + Sex + "', Age=" + strAge + ", Relationship='"
		+ Relationship + "', WorkingOrg='" + WorkingOrg + "' WHERE Id=" + cId;
	//ִ��UPDATE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CFamily::sql_delete(CString cId)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����DELETE���
	_bstr_t vSQL;
	vSQL = "DELETE FROM Family WHERE Id=" + cId;
	//ִ��DELETE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CFamily::sql_deleteByEmp(CString cEmp_Id)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����DELETE���
	_bstr_t vSQL;
	vSQL = "DELETE FROM Family WHERE Emp_Id=" + cEmp_Id;
	//ִ��DELETE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}
