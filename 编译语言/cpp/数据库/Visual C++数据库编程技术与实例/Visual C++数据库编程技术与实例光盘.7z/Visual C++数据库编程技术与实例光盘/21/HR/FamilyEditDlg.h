#if !defined(AFX_FAMILYEDITDLG_H__135A5A4F_A951_4277_9DCB_987BA1E93B42__INCLUDED_)
#define AFX_FAMILYEDITDLG_H__135A5A4F_A951_4277_9DCB_987BA1E93B42__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FamilyEditDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFamilyEditDlg dialog

class CFamilyEditDlg : public CDialog
{
public:
	int iEmpId;  //���ڱ��浱ǰ�༭�ļ�¼����Ա���ı��
	CString cId;  //���ڱ��浱ǰ��¼�ı�ţ����Ϊ""�����ʾ�����¼
	CString cSex; //���ڱ��浱ǰ��¼���Ա���Ϣ
// Construction
public:
	CFamilyEditDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFamilyEditDlg)
	enum { IDD = IDD_FAMILYEDIT_DIALOG };
	CComboBox	m_Sex;
	int		m_Age;
	CString	m_Name;
	CString	m_Relation;
	CString	m_Org;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFamilyEditDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFamilyEditDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FAMILYEDITDLG_H__135A5A4F_A951_4277_9DCB_987BA1E93B42__INCLUDED_)
