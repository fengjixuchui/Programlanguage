// EvaEditDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HrSys.h"
#include "EvaEditDlg.h"
#include "Evaluation.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEvaEditDlg dialog


CEvaEditDlg::CEvaEditDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEvaEditDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEvaEditDlg)
	m_cfAmount = 0;
	m_cfReason = _T("");
	m_EmpName = _T("");
	m_jlAmount = 0;
	m_jlReason = _T("");
	m_Memo = _T("");
	m_Month = _T("");
	m_Zt = _T("");
	//}}AFX_DATA_INIT
}


void CEvaEditDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEvaEditDlg)
	DDX_Text(pDX, IDC_CFAMOUNT_EDIT, m_cfAmount);
	DDX_Text(pDX, IDC_CFREASON_EDIT, m_cfReason);
	DDX_Text(pDX, IDC_EMPNAME_STATIC, m_EmpName);
	DDX_Text(pDX, IDC_JLAMOUNT_EDIT, m_jlAmount);
	DDX_Text(pDX, IDC_JLRESAON_EDIT, m_jlReason);
	DDX_Text(pDX, IDC_MEMO_EDIT, m_Memo);
	DDX_Text(pDX, IDC_MONTH_STATIC, m_Month);
	DDX_Text(pDX, IDC_ZT_EDIT, m_Zt);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEvaEditDlg, CDialog)
	//{{AFX_MSG_MAP(CEvaEditDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEvaEditDlg message handlers

void CEvaEditDlg::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);
	if (m_Zt == "")
	{
		MessageBox("����������������");
		return;
	}

	CEvaluation eva;
	eva.SetEmp_Id(iEmpId);  //Ա�����
	eva.SetEvaMonth(m_Month); //�����·�
	eva.SetztEva(m_Zt); //��������
	eva.SetjlReason(m_jlReason); //��������
	eva.SetjlAmount(m_jlAmount); //�������
	eva.SetcfReason(m_cfReason); //��������
	eva.SetcfAmount(m_cfAmount); //�������
	eva.SetMemo(m_Memo); //��ע
	
	CString cEmpId;
	cEmpId.Format("%d", iEmpId);
	//�����ǰ��¼���ڣ����޸ģ���������¼
	if (eva.HaveRecord(m_Month, cEmpId) == 1)
		eva.sql_update(m_Month, cEmpId);
	else
		eva.sql_insert();
	
	CDialog::OnOK();
}
