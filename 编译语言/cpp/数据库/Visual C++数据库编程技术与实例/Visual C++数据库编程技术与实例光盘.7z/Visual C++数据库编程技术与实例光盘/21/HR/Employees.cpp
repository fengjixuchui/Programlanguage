// Employees.cpp: implementation of the CEmployees class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HrSys.h"
#include "Employees.h"
#include "ADOConn.h"
#include "Family.h"
#include "Experience.h"
#include "Checkin.h"
#include "Evaluation.h"
#include "Users.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEmployees::CEmployees()
{

}

CEmployees::~CEmployees()
{
	Emp_Id = 0;
	Emp_Name = "";
	Sex = "";
	Nationality = "";
	Birth = "";
	Political_Party = "";
	Culture_Level = "";
	Marital_Condition = "";
	Family_Place = "";
	Id_Card = "";
	BadgeId = "";
	Office_phone = "";
	Mobile = "";
	Files_Keep_Org = "";
	Hukou = "";
	HireDate = "";
	Dep_Id = 0;
	Position = "";
	Title = "";
	State = 0;
	UpperId = 0;
	Contract_Duration = "";
	Memo = "";
	Fillin_Person = "";
	Fillin_Time = "";
}

int CEmployees::GetEmp_Id()
{
	return Emp_Id;
}

void CEmployees::SetEmp_Id(int iEmp_Id)
{
	Emp_Id = iEmp_Id;
}

CString CEmployees::GetEmp_Name()
{
	return Emp_Name;
}

void CEmployees::SetEmp_Name(CString cEmp_Name)
{
	Emp_Name = cEmp_Name;
}

CString CEmployees::GetSex()
{
	return Sex;
}

void CEmployees::SetSex(CString cSex)
{
	Sex = cSex;
}

CString CEmployees::GetNationality()
{
	return Nationality;
}

void CEmployees::SetNationality(CString cNationality)
{
	Nationality = cNationality;
}

CString CEmployees::GetBirth()
{
	return Birth;
}

void CEmployees::SetBirth(CString cBirth)
{
	Birth = cBirth;
}

CString CEmployees::GetPolitical_Party()
{
	return Political_Party;
}

void CEmployees::SetPolitical_Party(CString cParty)
{
	Political_Party = cParty;
}

CString CEmployees::GetCulture_Level()
{
	return Culture_Level;
}

void CEmployees::SetCulture_Level(CString cLevel)
{
	Culture_Level = cLevel;
}

CString CEmployees::GetMarital_Condition()
{
	return Marital_Condition;
}

void CEmployees::SetMarital_Condition(CString cCondition)
{
	Marital_Condition = cCondition;
}

CString CEmployees::GetFamily_Place()
{
	return Family_Place;
}

void CEmployees::SetFamily_Place(CString cPlace)
{
	Family_Place = cPlace;
}

CString CEmployees::GetId_Card()
{
	return Id_Card;
}

void CEmployees::SetId_Card(CString cCard)
{
	Id_Card = cCard;
}

CString CEmployees::GetBadgeId()
{
	return BadgeId;
}

void CEmployees::SetBadgeId(CString cBadgeId)
{
	BadgeId = cBadgeId;
}

CString CEmployees::GetOffice_phone()
{
	return Office_phone;
}

void CEmployees::SetOffice_phone(CString cOffice)
{
	Office_phone = cOffice;
}

CString CEmployees::GetMobile()
{
	return Mobile;
}

void CEmployees::SetMobile(CString cMobile)
{
	Mobile = cMobile;
}

CString CEmployees::GetFiles_Keep_Org()
{
	return Files_Keep_Org;
}

void CEmployees::SetFiles_Keep_Org(CString cOrg)
{
	Files_Keep_Org = cOrg;
}

CString CEmployees::GetHukou()
{
	return Hukou;
}

void CEmployees::SetHukou(CString cHukou)
{
	Hukou = cHukou;
}

CString CEmployees::GetHireDate()
{
	return HireDate;
}

void CEmployees::SetHireDate(CString cHireDate)
{
	HireDate = cHireDate;
}

int CEmployees::GetDep_Id()
{
	return Dep_Id;
}

void CEmployees::SetDep_Id(int iDep_Id)
{
	Dep_Id = iDep_Id;
}

CString CEmployees::GetPosition()
{
	return Position;
}

void CEmployees::SetPosition(CString cPosition)
{
	Position = cPosition;
}

CString CEmployees::GetTitle()
{
	return Title;
}

void CEmployees::SetTitle(CString cTitle)
{
	Title = cTitle;
}

int CEmployees::GetState()
{
	return State;
}

void CEmployees::SetState(int iState)
{
	State = iState;
}

int CEmployees::GetUpperId()
{
	return UpperId;
}

void CEmployees::SetUpperId(int iUpperId)
{
	UpperId = iUpperId;
}

CString CEmployees::GetContract_Duration()
{
	return Contract_Duration;
}

void CEmployees::SetContract_Duration(CString cDuration)
{
	Contract_Duration = cDuration;
}

CString CEmployees::GetMemo()
{
	return Memo;
}

void CEmployees::SetMemo(CString cMemo)
{
	Memo = cMemo;
}

CString CEmployees::GetFillin_Person()
{
	return Fillin_Person;
}

void CEmployees::SetFillin_Person(CString cPerson)
{
	Fillin_Person = cPerson;
}

CString CEmployees::GetFillin_Time()
{
	return Fillin_Time;
}

void CEmployees::SetFillin_Time(CString cTime)
{
	Fillin_Time = cTime;
}

int CEmployees::HaveName(CString cEmp_Name)
{	
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����SELECT���
	_bstr_t vSQL;
	vSQL = "SELECT * FROM Employees WHERE Emp_name='" + cEmp_Name + "'";
	
	//ִ��SELECT���
	_RecordsetPtr m_pRecordset;
	m_pRecordset = m_AdoConn.GetRecordSet(vSQL);
	if (m_pRecordset->adoEOF)
		return -1;
	else
		return 1;
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

CString CEmployees::GetName(CString cEmp_id)
{	
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����SELECT���
	_bstr_t vSQL;
	vSQL = "SELECT Emp_Name FROM Employees WHERE Emp_Id=" + cEmp_id;
	
	//ִ��SELECT���
	_RecordsetPtr m_pRecordset;
	m_pRecordset = m_AdoConn.GetRecordSet(vSQL);
	if (m_pRecordset->adoEOF)
		return "";
	else
		return (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Emp_Name");

	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CEmployees::sql_insert()
{	
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����INSERT���
	CString strDep_Id;
	strDep_Id.Format("%d", Dep_Id);
	CString strState;
	strState.Format("%d", State);
	CString strUpperId;
	strUpperId.Format("%d", UpperId);

	_bstr_t vSQL;
	vSQL = "INSERT INTO Employees (Emp_Name, Sex, Nationality, Birth, Political_Party,";
	vSQL = vSQL + " Culture_Level, Marital_Condition, Family_Place, Id_Card, BadgeID, Office_phone,";
	vSQL = vSQL + " Mobile, Files_Keep_Org, Hukou, HireDate, Dep_Id, Position, Title, State,";
	vSQL = vSQL + " UpperId, Contract_Duration, Memo, Fillin_Person, Fillin_Time) VALUES('";
	vSQL = vSQL + Emp_Name + "','" + Sex + "','" + Nationality + "','" + Birth + "','"; 
	vSQL = vSQL + Political_Party + "','" + Culture_Level + "','" + Marital_Condition;
	vSQL = vSQL + "','" + Family_Place + "','" + Id_Card + "','" + BadgeId + "','";
	vSQL = vSQL + Office_phone + "','" + Mobile + "','" + Files_Keep_Org + "','";
	vSQL = vSQL + Hukou + "','" + HireDate + "'," + strDep_Id + ",'" + Position;
	vSQL = vSQL + "','" + Title + "'," + strState + "," + strUpperId + ",'";
	vSQL = vSQL + Contract_Duration + "','" + Memo + "','" + Fillin_Person + "','";
	vSQL = vSQL + Fillin_Time + "')";	
	//ִ��INSERT���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CEmployees::sql_update(CString cEmp_Id)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����UPDATE���
	CString strState;
	strState.Format("%d", State);
	CString strUpperId;
	strUpperId.Format("%d", UpperId);

	_bstr_t vSQL;
	vSQL = "UPDATE Employees SET Emp_name='" + Emp_Name + "', Sex='" + Sex;
	vSQL = vSQL + "', Nationality='" + Nationality + "', Birth='" + Birth;
	vSQL = vSQL + "', Political_Party='" + Political_Party + "', Culture_Level='"; 
	vSQL = vSQL + Culture_Level + "', Marital_Condition='" + Marital_Condition; 
	vSQL = vSQL + "', Family_Place='" + Family_Place + "', Id_Card='" + Id_Card;
	vSQL = vSQL + "', BadgeId='" + BadgeId + "', Office_phone='" + Office_phone;
	vSQL = vSQL + "', Mobile='" + Mobile + "', Files_Keep_Org='" + Files_Keep_Org;
	vSQL = vSQL + "', Hukou='" + Hukou + "', HireDate='" + HireDate + "', Position='"; 
	vSQL = vSQL + Position + "', Title='" + Title + "', State=" + strState + ", UpperId=";
	vSQL = vSQL + strUpperId + ", Contract_Duration='" + Contract_Duration + "', Memo='"; 
	vSQL = vSQL + Memo + "', Fillin_Person='" + Fillin_Person + "', Fillin_Time='"; 
	vSQL = vSQL + Fillin_Time + "' WHERE Emp_id=" + cEmp_Id;
	//ִ��UPDATE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CEmployees::sql_updateDep(CString cEmp_Id)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����UPDATE���
	CString strId;
	strId.Format("%d", Dep_Id);

	_bstr_t vSQL;
	vSQL = "UPDATE Employees SET Dep_Id=" + strId + " WHERE Emp_id=" + cEmp_Id;
	//ִ��UPDATE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CEmployees::sql_delete(CString cEmp_Id)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����DELETE���
	_bstr_t vSQL;
	vSQL = "DELETE FROM Employees WHERE Emp_id=" + cEmp_Id;
	//ִ��DELETE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
	//ɾ����Family�е����Ա����¼
	CFamily fam;
	fam.sql_deleteByEmp(cEmp_Id);
	//ɾ����Experience�е����Ա����¼
	CExperience exp;
	exp.sql_deleteByEmp(cEmp_Id);
	//ɾ����Checkin�е����Ա����¼
	CCheckin check;
	check.sql_deleteByEmp(cEmp_Id);
	//ɾ����Evaluation�е����Ա����¼
	CEvaluation eva;
	eva.sql_deleteByEmp(cEmp_Id);
}

//����Ա����Ŷ�ȡ�����ֶ�ֵ
void CEmployees::GetData(CString cEmp_Id)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����SELECT���
	_bstr_t vSQL;
	vSQL = "SELECT * FROM Employees WHERE Emp_id=" + cEmp_Id;
	//ִ��SELETE���
	_RecordsetPtr m_pRecordset;
	m_pRecordset = m_AdoConn.GetRecordSet(vSQL);

	//���ظ��е�ֵ
	if (m_pRecordset->adoEOF)
		CEmployees();
	else
	{
		Emp_Id = atoi(cEmp_Id);
		Emp_Name = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Emp_Name");
		Sex = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Sex");
		Nationality = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Nationality");
		Birth = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Birth");
		Political_Party = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Political_Party");
		Culture_Level = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Culture_Level");
		Marital_Condition = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Marital_Condition");
		Family_Place = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Family_Place");
		Id_Card = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Id_Card");
		BadgeId = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("BadgeID");
		Office_phone = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Office_phone");
		Mobile = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Mobile");
		Files_Keep_Org = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Files_Keep_Org");
		Hukou = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Hukou");
		HireDate = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("HireDate");
		Dep_Id = atoi((LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Dep_Id"));
		Position = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Position");
		Title = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Title");
		State = atoi((LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("State"));
		UpperId = atoi((LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("UpperId"));
		Contract_Duration = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Contract_Duration");
		Memo = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Memo");
		Fillin_Person = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Fillin_Person");
		Fillin_Time = (LPCTSTR)(_bstr_t)m_pRecordset->GetCollect("Fillin_Time");

	}
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

