#if !defined(AFX_EMPEDITDLG_H__ABB18B41_936D_4F79_9F4D_F46C86F0C02C__INCLUDED_)
#define AFX_EMPEDITDLG_H__ABB18B41_936D_4F79_9F4D_F46C86F0C02C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EmpEditDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEmpEditDlg dialog

class CEmpEditDlg : public CDialog
{
public:
	int EmpId;  //���ڱ��浱ǰ�༭Ա���ı��
	CString EmpName;  //���ڱ��浱ǰ�༭Ա��������
	int DepId;  //���ڱ��浱ǰ�༭Ա���Ĳ��ű��
	int UpperId;  //���ڱ��浱ǰ�༭Ա�����ϼ�Ա�����
	CString cSex;  //���ڱ��浱ǰԱ�����Ա�
	int iState;  //���ڱ��浱ǰԱ����״̬

	HBITMAP	m_hBitmap;  //����һ��λͼ��������ڱ����ȡ��λͼ
// Construction
public:
	CEmpEditDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEmpEditDlg)
	enum { IDD = IDD_EMPEDIT_DIALOG };
	CComboBox	m_State;
	CComboBox	m_Sex;
	CString	m_Badge;
	CString	m_Contract;
	CString	m_EmpName;
	CString	m_Culture;
	CString	m_Family;
	CString	m_File;
	CString	m_Fillperson;
	CString	m_Filltime;
	CString	m_Hukou;
	CString	m_Idcard;
	CString	m_Marital;
	CString	m_Memo;
	CString	m_Mobile;
	CString	m_Nation;
	CString	m_Office;
	CString	m_Political;
	CString	m_Position;
	CString	m_Title;
	CTime	m_Birth;
	CTime	m_HireDate;
	CString	m_Upper;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEmpEditDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEmpEditDlg)
	virtual void OnOK();
	afx_msg void OnEmpselButton();
	virtual BOOL OnInitDialog();
	afx_msg void OnSetphotoButton();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EMPEDITDLG_H__ABB18B41_936D_4F79_9F4D_F46C86F0C02C__INCLUDED_)
