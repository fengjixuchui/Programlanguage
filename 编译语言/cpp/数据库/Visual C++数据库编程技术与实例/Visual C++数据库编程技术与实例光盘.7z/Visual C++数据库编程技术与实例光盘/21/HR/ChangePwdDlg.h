#if !defined(AFX_CHANGEPWDDLG_H__EED4A5E3_6760_455F_838B_B6C67CBD8C89__INCLUDED_)
#define AFX_CHANGEPWDDLG_H__EED4A5E3_6760_455F_838B_B6C67CBD8C89__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ChangePwdDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CChangePwdDlg dialog

class CChangePwdDlg : public CDialog
{
// Construction
public:
	CChangePwdDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CChangePwdDlg)
	enum { IDD = IDD_CHANGEPWD_DIALOG };
	CString	m_NewPwd1;
	CString	m_NewPwd2;
	CString	m_OldPwd;
	CString	m_UserName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChangePwdDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CChangePwdDlg)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHANGEPWDDLG_H__EED4A5E3_6760_455F_838B_B6C67CBD8C89__INCLUDED_)
