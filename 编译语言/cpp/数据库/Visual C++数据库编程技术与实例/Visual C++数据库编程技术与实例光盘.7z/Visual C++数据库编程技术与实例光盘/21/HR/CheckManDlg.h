//{{AFX_INCLUDES()
#include "datagrid.h"
#include "adodc.h"
//}}AFX_INCLUDES
#if !defined(AFX_CHECKMANDLG_H__3EA82714_3496_4AA3_8239_535685C0207A__INCLUDED_)
#define AFX_CHECKMANDLG_H__3EA82714_3496_4AA3_8239_535685C0207A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CheckManDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCheckManDlg dialog

class CCheckManDlg : public CDialog
{
public:
	int iDepId;  //���ڱ��浱ǰѡ��Ĳ��ű��

// Construction
public:
	CCheckManDlg(CWnd* pParent = NULL);   // standard constructor
	void Refresh_Data();

// Dialog Data
	//{{AFX_DATA(CCheckManDlg)
	enum { IDD = IDD_CHECKMAN_DIALOG };
	CDataGrid	m_datagrid;
	CTime	m_date;
	CString	m_DepName;
	CAdodc	m_adodc;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCheckManDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCheckManDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSetdepButton();
	afx_msg void OnSetButton();
	afx_msg void OnSumButton();
	afx_msg void OnDatetimechangeDatetimepicker1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHECKMANDLG_H__3EA82714_3496_4AA3_8239_535685C0207A__INCLUDED_)
