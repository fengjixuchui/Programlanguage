// ExpManDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HrSys.h"
#include "ExpManDlg.h"
#include "COMDEF.H"
#include "Columns.h"
#include "Column.h"
#include "ExpEditDlg.h"
#include "_recordset.h"
#include "Experience.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExpManDlg dialog


CExpManDlg::CExpManDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CExpManDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CExpManDlg)
	m_EmpName = _T("");
	//}}AFX_DATA_INIT
}


void CExpManDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExpManDlg)
	DDX_Control(pDX, IDC_ADODC1, m_adodc);
	DDX_Control(pDX, IDC_DATAGRID1, m_datagrid);
	DDX_Text(pDX, IDC_EMPNAME_STATIC, m_EmpName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExpManDlg, CDialog)
	//{{AFX_MSG_MAP(CExpManDlg)
	ON_BN_CLICKED(IDC_ADD_BUTTON, OnAddButton)
	ON_BN_CLICKED(IDC_MODI_BUTTON, OnModiButton)
	ON_BN_CLICKED(IDC_DEL_BUTTON, OnDelButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExpManDlg message handlers
void CExpManDlg::Refresh_Data()
{
	CString cEmpId;
	cEmpId.Format("%d", iEmpId);
	//���ü�¼Դ
	CString cSource;
	cSource = "SELECT Id, Start_Date AS ��ʼ����, End_Date AS ��������, School_Org AS ѧУ��λ����,";
	cSource	+= " Title AS ְ�� FROM Experience WHERE Emp_Id=" + cEmpId;
	m_adodc.SetRecordSource(cSource);
	m_adodc.Refresh();
	//���ñ����п���
	_variant_t vIndex;
	vIndex = long(0);
	m_datagrid.GetColumns().GetItem(vIndex).SetWidth(0);
	vIndex = long(1);
	m_datagrid.GetColumns().GetItem(vIndex).SetWidth(100);
	vIndex = long(2);
	m_datagrid.GetColumns().GetItem(vIndex).SetWidth(100);
	vIndex = long(3);
	m_datagrid.GetColumns().GetItem(vIndex).SetWidth(150);
	vIndex = long(4);
	m_datagrid.GetColumns().GetItem(vIndex).SetWidth(100);
}

void CExpManDlg::OnAddButton() 
{
	// TODO: Add your control notification handler code here
	CExpEditDlg dlg;
	dlg.cId = "";
	dlg.iEmpId = iEmpId;
	if (dlg.DoModal() == IDOK)
		Refresh_Data();	
}

BOOL CExpManDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	Refresh_Data();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CExpManDlg::OnModiButton() 
{
	// TODO: Add your control notification handler code here
	if (m_adodc.GetRecordset().GetEof()) 
	{
		MessageBox("��ѡ��Ҫ�޸ĵļ�¼");
		return;
	}
	CExpEditDlg dlg;
	dlg.cId = m_datagrid.GetItem(0); //��¼���
	dlg.iEmpId = iEmpId;  //Ա�����
	dlg.m_Sdate = m_datagrid.GetItem(1); //��ʼ����
	dlg.m_Edate = m_datagrid.GetItem(2); //��������
	dlg.m_Org = m_datagrid.GetItem(3); //��λ/ѧУ
	dlg.m_Title = m_datagrid.GetItem(4); //ְ��

	if (dlg.DoModal() == IDOK)
		Refresh_Data();	
}

void CExpManDlg::OnDelButton() 
{
	// TODO: Add your control notification handler code here
	if (m_adodc.GetRecordset().GetEof()) 
	{
		MessageBox("��ѡ��Ҫɾ���ļ�¼");
		return;
	}
	if (MessageBox("�Ƿ�ɾ����ǰ��¼","��ȷ��", MB_YESNO) == IDYES)
	{
		CExperience exp;
		exp.sql_delete(m_datagrid.GetItem(0));
		Refresh_Data();
	}	
}
