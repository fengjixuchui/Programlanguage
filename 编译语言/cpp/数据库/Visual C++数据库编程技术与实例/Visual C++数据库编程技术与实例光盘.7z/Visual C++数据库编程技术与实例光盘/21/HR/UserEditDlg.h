#if !defined(AFX_USEREDITDLG_H__8957B3E4_011B_496E_BF6E_CA283BDCB307__INCLUDED_)
#define AFX_USEREDITDLG_H__8957B3E4_011B_496E_BF6E_CA283BDCB307__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UserEditDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUserEditDlg dialog

class CUserEditDlg : public CDialog
{
public:
	int iUserType;
// Construction
public:
	CUserEditDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUserEditDlg)
	enum { IDD = IDD_USEREDIT_DIALOG };
	CComboBox	m_UserType;
	CString	m_UserName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUserEditDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUserEditDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USEREDITDLG_H__8957B3E4_011B_496E_BF6E_CA283BDCB307__INCLUDED_)
