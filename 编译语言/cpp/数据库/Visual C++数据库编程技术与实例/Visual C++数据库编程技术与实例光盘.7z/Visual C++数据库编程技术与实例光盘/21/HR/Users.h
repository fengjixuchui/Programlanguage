// Users.h: interface for the CUsers class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_USERS_H__451F3215_5B38_48AF_8D6D_A4361016F23E__INCLUDED_)
#define AFX_USERS_H__451F3215_5B38_48AF_8D6D_A4361016F23E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CUsers  
{
private:
	CString UserName;
	CString Pwd;
	int User_type;
public:
	CUsers();
	virtual ~CUsers();
	
	CString GetUserName();
	void SetUserName(CString cUserName);
	CString GetPwd();
	void SetPwd(CString cPwd);
	int GetUser_type();
	void SetUser_type(int iUser_type);

	//���ݿ����
	int HaveName(CString cUserName); //�ж�ָ���û����Ƿ����
	void sql_insert();  
	void sql_updatePwd(CString cUserName);
	void sql_delete(CString cUserName);
	//��ȡ�����ֶ�ֵ
	void GetData(CString cUserName);
};

#endif // !defined(AFX_USERS_H__451F3215_5B38_48AF_8D6D_A4361016F23E__INCLUDED_)
