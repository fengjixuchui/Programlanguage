// TransferDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HrSys.h"
#include "TransferDlg.h"
#include "DepSelDlg.h"
#include "Employees.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTransferDlg dialog


CTransferDlg::CTransferDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTransferDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTransferDlg)
	m_New = _T("");
	m_Old = _T("");
	//}}AFX_DATA_INIT
}


void CTransferDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTransferDlg)
	DDX_Text(pDX, IDC_NEW_STATIC, m_New);
	DDX_Text(pDX, IDC_OLD_STATIC, m_Old);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTransferDlg, CDialog)
	//{{AFX_MSG_MAP(CTransferDlg)
	ON_BN_CLICKED(IDC_DEPSEL_BUTTON, OnDepselButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTransferDlg message handlers

void CTransferDlg::OnDepselButton() 
{
	// TODO: Add your control notification handler code here
	CDepSelDlg dlg;
	dlg.DoModal();
	
	DepId = dlg.DepId;
	m_New = dlg.DepName;
	UpdateData(FALSE);
}

void CTransferDlg::OnOK() 
{
	// TODO: Add extra validation here
	if (DepId == 0)
	{
		MessageBox("��ѡ���²���");
		return;
	}
	CEmployees emp;
	emp.SetDep_Id(DepId);
	emp.sql_updateDep(cEmpId);

	CDialog::OnOK();
}
