#if !defined(AFX_EXPEDITDLG_H__88E17643_80E0_45A3_88D5_B95851AF0FC7__INCLUDED_)
#define AFX_EXPEDITDLG_H__88E17643_80E0_45A3_88D5_B95851AF0FC7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ExpEditDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CExpEditDlg dialog

class CExpEditDlg : public CDialog
{
public:
	int iEmpId;  //���ڱ��浱ǰ�༭�ļ�¼����Ա���ı��
	CString cId;  //���ڱ��浱ǰ��¼�ı�ţ����Ϊ""�����ʾ�����¼
// Construction
public:
	CExpEditDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CExpEditDlg)
	enum { IDD = IDD_EXPEDIT_DIALOG };
	CString	m_Edate;
	CString	m_Org;
	CString	m_Sdate;
	CString	m_Title;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExpEditDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CExpEditDlg)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXPEDITDLG_H__88E17643_80E0_45A3_88D5_B95851AF0FC7__INCLUDED_)
