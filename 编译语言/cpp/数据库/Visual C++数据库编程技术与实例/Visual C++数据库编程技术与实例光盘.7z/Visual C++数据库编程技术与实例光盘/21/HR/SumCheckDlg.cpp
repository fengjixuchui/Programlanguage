// SumCheckDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HrSys.h"
#include "SumCheckDlg.h"
#include "DepSelDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSumCheckDlg dialog


CSumCheckDlg::CSumCheckDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSumCheckDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSumCheckDlg)
	m_DepName = _T("");
	//}}AFX_DATA_INIT
}


void CSumCheckDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSumCheckDlg)
	DDX_Control(pDX, IDC_YEAR_COMBO, m_year);
	DDX_Control(pDX, IDC_MONTH_COMBO, m_month);
	DDX_Control(pDX, IDC_ADODC1, m_adodc);
	DDX_Control(pDX, IDC_DATAGRID1, m_datagrid);
	DDX_Text(pDX, IDC_DEPNAME_STATIC, m_DepName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSumCheckDlg, CDialog)
	//{{AFX_MSG_MAP(CSumCheckDlg)
	ON_BN_CLICKED(IDC_SETDEP_BUTTON, OnSetdepButton)
	ON_CBN_SELCHANGE(IDC_YEAR_COMBO, OnSelchangeYearCombo)
	ON_CBN_SELCHANGE(IDC_MONTH_COMBO, OnSelchangeMonthCombo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSumCheckDlg message handlers
void CSumCheckDlg::Refresh_Data()
{
	CString cSource;
	CString cDepId;
	cDepId.Format("%d", iDepId);
	//��ȡ�·���Ϣ
	CString cYear, cMonth;
	int index;
	index = m_year.GetCurSel();
	m_year.GetLBText(index, cYear);
	index = m_month.GetCurSel();
	m_month.GetLBText(index, cMonth);

	cSource = "SELECT Emp_Name AS Ա������, SumQq AS ȫ������, SumCc AS ��������,";
	cSource += " SumBj AS ��������, SumSj AS �¼�����, SumKg AS ��������,";
	cSource += " SumFdxj AS �����ݼ�����, SumNxj AS ���ݼ�����, SumDxj AS ���ݼ�����,";
	cSource += " SumCd AS �ٵ�ʱ��, SumZt AS ����ʱ��, SumOt1 AS һ��Ӱ�����,";
	cSource += " SumOt2 AS ����Ӱ�����, SumOt3 AS ����Ӱ�����";
	cSource += " FROM v_SumCheck WHERE CheckMonth = '";
	cSource += cYear + "-" + cMonth + "' AND Dep_Id=" + cDepId;

	m_adodc.SetRecordSource(cSource);
	m_adodc.Refresh();
}

BOOL CSumCheckDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CTime t = CTime::GetCurrentTime();  //��ȡ��ǰϵͳ����
	int iYear, iMonth;
	iYear = t.GetYear();	
	iMonth = t.GetMonth();

	m_year.SetCurSel(iYear - 2000);
	m_month.SetCurSel(iMonth - 1);
	
	Refresh_Data();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSumCheckDlg::OnSetdepButton() 
{
	// TODO: Add your control notification handler code here
	CDepSelDlg dlg;
	//��ѡ���ŶԻ���
	dlg.DoModal();
	//�ӶԻ����ж�ȡѡ���ŵ���Ϣ
	iDepId = dlg.DepId;
	m_DepName = dlg.DepName;
	UpdateData(FALSE);
	//����ѡ��Ĳ�����Ϣ��ˢ�±�������
	Refresh_Data();	
}

void CSumCheckDlg::OnSelchangeYearCombo() 
{
	// TODO: Add your control notification handler code here
	Refresh_Data();		
}

void CSumCheckDlg::OnSelchangeMonthCombo() 
{
	// TODO: Add your control notification handler code here
	Refresh_Data();	
}
