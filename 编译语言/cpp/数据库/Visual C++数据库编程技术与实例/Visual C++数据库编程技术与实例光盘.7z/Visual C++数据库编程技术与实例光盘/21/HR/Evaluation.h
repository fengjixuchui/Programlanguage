// Evaluation.h: interface for the CEvaluation class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EVALUATION_H__B1597646_2B55_40CD_8A1A_31A0DD69C57C__INCLUDED_)
#define AFX_EVALUATION_H__B1597646_2B55_40CD_8A1A_31A0DD69C57C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CEvaluation  
{
private:
	CString EvaMonth;
	int Emp_Id;
	CString ztEva;
	CString jlReason;
	int jlAmount;
	CString cfReason;
	int cfAmount;
	CString Memo;
public:
	CEvaluation();
	virtual ~CEvaluation();

	CString GetEvaMonth();
	void SetEvaMonth(CString cEvaMonth);
	int GetEmp_Id();
	void SetEmp_Id(int iEmp_Id);
	CString GetztEva();
	void SetztEva(CString cztEva);
	CString GetjlReason();
	void SetjlReason(CString cjlReason);
	int GetjlAmount();
	void SetjlAmount(int ijlAmount);
	CString GetcfReason();
	void SetcfReason(CString ccfReason);
	int GetcfAmount();
	void SetcfAmount(int icfAmount);
	CString GetMemo();
	void SetMemo(CString cMemo);
	
	//���ݿ����
	int HaveRecord(CString cEvaMonth, CString cEmp_Id); //�ж�ָ��Ա��/�·ݵĿ�����¼�Ƿ����
	void sql_insert();  
	void sql_update(CString cEvaMonth, CString cEmp_Id);
	void sql_delete(CString cEvaMonth, CString cEmp_Id);
	void sql_deleteByEmp(CString cEmp_Id);

};

#endif // !defined(AFX_EVALUATION_H__B1597646_2B55_40CD_8A1A_31A0DD69C57C__INCLUDED_)
