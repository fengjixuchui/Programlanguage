// Global.h: interface for the CGlobal class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLOBAL_H__CEC853C9_17C8_4FF8_A441_013F30A73A3C__INCLUDED_)
#define AFX_GLOBAL_H__CEC853C9_17C8_4FF8_A441_013F30A73A3C__INCLUDED_
#include "Users.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CGlobal  
{
public:
	CUsers curUser;
	CGlobal();
	virtual ~CGlobal();

};

#endif // !defined(AFX_GLOBAL_H__CEC853C9_17C8_4FF8_A441_013F30A73A3C__INCLUDED_)
