// EvaManDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HrSys.h"
#include "EvaManDlg.h"
#include "EvaEditDlg.h"
#include "DepSelDlg.h"
#include "_recordset.h"
#include "COMDEF.H"
#include "Columns.h"
#include "Column.h"

extern CUsers curUser;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEvaManDlg dialog


CEvaManDlg::CEvaManDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEvaManDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEvaManDlg)
	m_DepName = _T("");
	//}}AFX_DATA_INIT
}


void CEvaManDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEvaManDlg)
	DDX_Control(pDX, IDC_YEAR_COMBO, m_year);
	DDX_Control(pDX, IDC_MONTH_COMBO, m_month);
	DDX_Control(pDX, IDC_ADODC1, m_adodc);
	DDX_Control(pDX, IDC_DATAGRID1, m_datagrid);
	DDX_Text(pDX, IDC_DEPNAME_STATIC, m_DepName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEvaManDlg, CDialog)
	//{{AFX_MSG_MAP(CEvaManDlg)
	ON_BN_CLICKED(IDC_SET_BUTTON, OnSetButton)
	ON_BN_CLICKED(IDC_SETDEP_BUTTON, OnSetdepButton)
	ON_CBN_SELCHANGE(IDC_MONTH_COMBO, OnSelchangeMonthCombo)
	ON_CBN_SELCHANGE(IDC_YEAR_COMBO, OnSelchangeYearCombo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEvaManDlg message handlers
void CEvaManDlg::Refresh_Data()
{
	CString cSource;
	CString cDepId;
	cDepId.Format("%d", iDepId);
	//��ȡ�·���Ϣ
	CString cYear, cMonth;
	int index;
	index = m_year.GetCurSel();
	m_year.GetLBText(index, cYear);
	index = m_month.GetCurSel();
	m_month.GetLBText(index, cMonth);

	cSource = "SELECT e.Emp_Id, e.Emp_Name AS Ա������, ISNULL(v.ZtEva,'') AS ��������, ISNULL(v.jlReason,'') AS ��������,";
	cSource += " ISNULL(v.jlAmount,0) AS �������, ISNULL(v.cfReason,'') AS ��������, ISNULL(v.cfAmount,0) AS �������,";
	cSource += " ISNULL(v.Memo,'') AS ��ע��Ϣ FROM Employees e, Evaluation v WHERE e.Emp_Id*=v.Emp_Id";
	cSource += " AND v.EvaMonth='" + cYear + "-" + cMonth + "' AND Dep_Id=" + cDepId;

	m_adodc.SetRecordSource(cSource);
	m_adodc.Refresh();

	//�����п���
	_variant_t vIndex;
	vIndex = long(0);
	m_datagrid.GetColumns().GetItem(vIndex).SetWidth(0);
}

BOOL CEvaManDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	//Ȩ�޿��ƣ��������ϵͳ����Ա�������û�
	if (curUser.GetUser_type() != 1)
		GetDlgItem(IDC_SET_BUTTON)->EnableWindow(FALSE);

	CTime t = CTime::GetCurrentTime();  //��ȡ��ǰϵͳ����
	int iYear, iMonth;
	iYear = t.GetYear();	
	iMonth = t.GetMonth();

	m_year.SetCurSel(iYear - 2000);
	m_month.SetCurSel(iMonth - 1);
	
	UpdateData(FALSE);
	Refresh_Data();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CEvaManDlg::OnSetButton() 
{
	// TODO: Add your control notification handler code here
	if (m_adodc.GetRecordset().GetEof())
	{
		MessageBox("��ѡ��Ա����¼");
		return;
	}

	//��ȡ�·���Ϣ
	CString cYear, cMonth;
	int index;
	index = m_year.GetCurSel();
	m_year.GetLBText(index, cYear);
	index = m_month.GetCurSel();
	m_month.GetLBText(index, cMonth);

	CEvaEditDlg dlg;
	dlg.m_Month = cYear + "-" + cMonth;  //�����·�
	dlg.iEmpId = atoi(m_datagrid.GetItem(0)); //����Ա�����
	dlg.m_EmpName = m_datagrid.GetItem(1);  //����Ա������
	dlg.m_Zt = m_datagrid.GetItem(2);  //��������
	dlg.m_jlReason = m_datagrid.GetItem(3);  //��������
	dlg.m_jlAmount = atoi(m_datagrid.GetItem(4));  //�������
	dlg.m_cfReason = m_datagrid.GetItem(5);  //��������
	dlg.m_cfAmount = atoi(m_datagrid.GetItem(6));  //�������
	dlg.m_Memo = m_datagrid.GetItem(7);  //��ע
	if (dlg.DoModal() == IDOK)
		Refresh_Data();	
}

void CEvaManDlg::OnSetdepButton() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	//��ѡ���ŶԻ���
	CDepSelDlg dlg;
	dlg.DoModal();
	//�ӶԻ����ж�ȡѡ���ŵ���Ϣ
	iDepId = dlg.DepId;
	m_DepName = dlg.DepName;
	UpdateData(FALSE);
	//����ѡ��Ĳ�����Ϣ��ˢ�±�������
	Refresh_Data();	
}

void CEvaManDlg::OnSelchangeMonthCombo() 
{
	// TODO: Add your control notification handler code here
	Refresh_Data();
}

void CEvaManDlg::OnSelchangeYearCombo() 
{
	// TODO: Add your control notification handler code here
	Refresh_Data();	
}
