// UserManDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HrSys.h"
#include "UserManDlg.h"
#include "UserEditDlg.h"

extern CUsers curUser;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUserManDlg dialog


CUserManDlg::CUserManDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUserManDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUserManDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CUserManDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUserManDlg)
	DDX_Control(pDX, IDC_DATALIST1, m_datalist);
	DDX_Control(pDX, IDC_ADODC1, m_adodc);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUserManDlg, CDialog)
	//{{AFX_MSG_MAP(CUserManDlg)
	ON_BN_CLICKED(IDC_ADD_BUTTON, OnAddButton)
	ON_BN_CLICKED(IDC_MODI_BUTTON, OnModiButton)
	ON_BN_CLICKED(IDC_DEL_BUTTON, OnDelButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUserManDlg message handlers

void CUserManDlg::OnAddButton() 
{
	// TODO: Add your control notification handler code here
	CUserEditDlg dlg;
	dlg.iUserType = 2;
	if (dlg.DoModal() == IDOK)
		m_adodc.Refresh(); 
}

void CUserManDlg::OnModiButton() 
{
	// TODO: Add your control notification handler code here
	if (m_datalist.GetText() == "")
	{
		MessageBox("��ѡ���û�");
		return;
	}
	if (curUser.GetUserName() != "Admin" && curUser.GetUserName() != m_datalist.GetText()
		&& m_datalist.GetBoundText() == "1")
	{	//��Admin�⣬��������Աֻ���޸���ͨ�û���Ϣ
		MessageBox("ֻ�ܶ���ͨ�û��������븴λ");
		return;
	}
	if (MessageBox("�Ƿ�Ե�ǰ�û��������븴λ","��ȷ��", MB_YESNO) == IDYES)
	{
		CUsers usr;
		usr.SetPwd("888888"); //����Ĭ������
		usr.sql_updatePwd(m_datalist.GetText());
		MessageBox("�����Ѿ���λ");
	}
}

void CUserManDlg::OnDelButton() 
{
	// TODO: Add your control notification handler code here
	if (m_datalist.GetText() == "")
	{
		MessageBox("��ѡ���û�");
		return;
	}
	if (curUser.GetUserName() != "Admin" && m_datalist.GetBoundText() == "1")
	{	//��Admin�⣬��������Աֻ��ɾ����ͨ�û�
		MessageBox("ֻ��ɾ����ͨ�û�");
		return;
	}
	if (m_datalist.GetText() == "Admin")
	{
		MessageBox("����ɾ��Admin�û�");
		return;
	}
	if (MessageBox("�Ƿ�ɾ����ǰ�û�","��ȷ��", MB_YESNO) == IDYES)
	{
		CUsers usr;
		usr.sql_delete(m_datalist.GetText());
		m_adodc.Refresh();
	}
}
