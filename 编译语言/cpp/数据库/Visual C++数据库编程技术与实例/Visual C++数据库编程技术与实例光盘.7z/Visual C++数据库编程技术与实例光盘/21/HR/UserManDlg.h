//{{AFX_INCLUDES()
#include "datalist.h"
#include "adodc.h"
//}}AFX_INCLUDES
#if !defined(AFX_USERMANDLG_H__21E906A9_61B5_41CE_8B22_29D93FC9AFAA__INCLUDED_)
#define AFX_USERMANDLG_H__21E906A9_61B5_41CE_8B22_29D93FC9AFAA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UserManDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUserManDlg dialog

class CUserManDlg : public CDialog
{
// Construction
public:
	CUserManDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUserManDlg)
	enum { IDD = IDD_USERMAN_DIALOG };
	CDataList	m_datalist;
	CAdodc	m_adodc;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUserManDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUserManDlg)
	afx_msg void OnAddButton();
	afx_msg void OnModiButton();
	afx_msg void OnDelButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USERMANDLG_H__21E906A9_61B5_41CE_8B22_29D93FC9AFAA__INCLUDED_)
