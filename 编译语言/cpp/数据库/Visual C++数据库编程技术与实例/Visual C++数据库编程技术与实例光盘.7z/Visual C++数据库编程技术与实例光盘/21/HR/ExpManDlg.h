//{{AFX_INCLUDES()
#include "adodc.h"
#include "datagrid.h"
//}}AFX_INCLUDES
#if !defined(AFX_EXPMANDLG_H__20B75B50_85E1_4EAD_99DA_D04202F0E189__INCLUDED_)
#define AFX_EXPMANDLG_H__20B75B50_85E1_4EAD_99DA_D04202F0E189__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ExpManDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CExpManDlg dialog

class CExpManDlg : public CDialog
{
public:
	int iEmpId;  //���ڱ��浱ǰԱ�����
// Construction
public:
	CExpManDlg(CWnd* pParent = NULL);   // standard constructor
	void Refresh_Data();

// Dialog Data
	//{{AFX_DATA(CExpManDlg)
	enum { IDD = IDD_EXPMAN_DIALOG };
	CAdodc	m_adodc;
	CDataGrid	m_datagrid;
	CString	m_EmpName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExpManDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CExpManDlg)
	afx_msg void OnAddButton();
	virtual BOOL OnInitDialog();
	afx_msg void OnModiButton();
	afx_msg void OnDelButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXPMANDLG_H__20B75B50_85E1_4EAD_99DA_D04202F0E189__INCLUDED_)
