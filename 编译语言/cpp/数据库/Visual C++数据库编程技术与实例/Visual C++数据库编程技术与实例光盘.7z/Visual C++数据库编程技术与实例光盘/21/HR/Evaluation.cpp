// Evaluation.cpp: implementation of the CEvaluation class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HrSys.h"
#include "Evaluation.h"
#include "ADOConn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEvaluation::CEvaluation()
{
	EvaMonth = "";
	Emp_Id = 0;
	ztEva = "";
	jlReason = "";
	jlAmount = 0;
	cfReason = "";
	cfAmount = 0;
	Memo = "";
}

CEvaluation::~CEvaluation()
{

}

CString CEvaluation::GetEvaMonth()
{
	return EvaMonth;
}

void CEvaluation::SetEvaMonth(CString cEvaMonth)
{
	EvaMonth = cEvaMonth;
}

int CEvaluation::GetEmp_Id()
{
	return Emp_Id;
}

void CEvaluation::SetEmp_Id(int iEmp_Id)
{
	Emp_Id = iEmp_Id;
}

CString CEvaluation::GetztEva()
{
	return ztEva;
}

void CEvaluation::SetztEva(CString cztEva)
{
	ztEva = cztEva;
}

CString CEvaluation::GetjlReason()
{
	return jlReason;
}

void CEvaluation::SetjlReason(CString cjlReason)
{
	jlReason = cjlReason;
}

int CEvaluation::GetjlAmount()
{
	return jlAmount;
}

void CEvaluation::SetjlAmount(int ijlAmount)
{
	jlAmount = ijlAmount;
}

CString CEvaluation::GetcfReason()
{
	return cfReason;
}

void CEvaluation::SetcfReason(CString ccfReason)
{
	cfReason = ccfReason;
}

int CEvaluation::GetcfAmount()
{
	return cfAmount;
}

void CEvaluation::SetcfAmount(int icfAmount)
{
	cfAmount = icfAmount;
}

CString CEvaluation::GetMemo()
{
	return Memo;
}

void CEvaluation::SetMemo(CString cMemo)
{
	Memo = cMemo;
}
	
//���ݿ����
int CEvaluation::HaveRecord(CString cEvaMonth, CString cEmp_Id)
{	
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����SELECT���
	_bstr_t vSQL;
	vSQL = "SELECT * FROM Evaluation WHERE EvaMonth='" + cEvaMonth 
		+ "' AND Emp_Id=" + cEmp_Id;
	
	//ִ��SELECT���
	_RecordsetPtr m_pRecordset;
	m_pRecordset = m_AdoConn.GetRecordSet(vSQL);
	if (m_pRecordset->adoEOF)
		return -1;
	else
		return 1;

	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

	
void CEvaluation::sql_insert()
{	
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����INSERT���
	CString strEmp_Id;
	strEmp_Id.Format("%d", Emp_Id);
	CString strjlAmount;
	strjlAmount.Format("%d", jlAmount);
	CString strcfAmount;
	strcfAmount.Format("%d", cfAmount);

	_bstr_t vSQL;
	vSQL = "INSERT INTO Evaluation VALUES('" + EvaMonth + "'," + strEmp_Id + ",'" 
		+ ztEva + "','" + jlReason + "'," + strjlAmount + ",'" + cfReason + "'," 
		+ strcfAmount + ",'" + Memo + "')";	
	//ִ��INSERT���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CEvaluation::sql_update(CString cEvaMonth, CString cEmp_Id)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����UPDATE���
	CString strEmp_Id;
	strEmp_Id.Format("%d", Emp_Id);
	CString strjlAmount;
	strjlAmount.Format("%d", jlAmount);
	CString strcfAmount;
	strcfAmount.Format("%d", cfAmount);

	_bstr_t vSQL;
	vSQL = "UPDATE Evaluation SET ztEva='" + ztEva + "', jlReason='" + jlReason 
		+ "', jlAmount=" + strjlAmount + ", cfReason='" + cfReason +"', cfAmount=" 
		+ strcfAmount + ", Memo='" + Memo + "' WHERE EvaMonth='" + cEvaMonth
		+ "' AND Emp_Id=" + cEmp_Id;
	//ִ��UPDATE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CEvaluation::sql_delete(CString cEvaMonth, CString cEmp_Id)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����DELETE���
	_bstr_t vSQL;
	vSQL = "DELETE FROM Evaluation WHERE EvaMonth='" + cEvaMonth
		+ "' AND Emp_Id=" + cEmp_Id;
	//ִ��DELETE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}

void CEvaluation::sql_deleteByEmp(CString cEmp_Id)
{
	//�������ݿ�
	ADOConn m_AdoConn;
	m_AdoConn.OnInitADOConn();
	//����DELETE���
	_bstr_t vSQL;
	vSQL = "DELETE FROM Evaluation WHERE Emp_Id=" + cEmp_Id;
	//ִ��DELETE���
	m_AdoConn.ExecuteSQL(vSQL);	
	//�Ͽ������ݿ������
	m_AdoConn.ExitConnect();
}
