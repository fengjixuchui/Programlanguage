// HrSys.h : main header file for the HRSYS application
//

#if !defined(AFX_HRSYS_H__03CCFCF4_BD32_4531_85DD_0FA7239C5CCF__INCLUDED_)
#define AFX_HRSYS_H__03CCFCF4_BD32_4531_85DD_0FA7239C5CCF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CHrSysApp:
// See HrSys.cpp for the implementation of this class
//

class CHrSysApp : public CWinApp
{
public:
	CHrSysApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHrSysApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CHrSysApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HRSYS_H__03CCFCF4_BD32_4531_85DD_0FA7239C5CCF__INCLUDED_)
