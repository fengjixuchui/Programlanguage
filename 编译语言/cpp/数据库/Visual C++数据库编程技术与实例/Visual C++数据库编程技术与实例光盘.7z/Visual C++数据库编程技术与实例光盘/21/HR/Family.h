// Family.h: interface for the CFamily class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FAMILY_H__B39AA80E_3A15_4F8C_AD17_CAB4D422EB9C__INCLUDED_)
#define AFX_FAMILY_H__B39AA80E_3A15_4F8C_AD17_CAB4D422EB9C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFamily  
{
private:
	int Id;
	int Emp_Id;
	CString Name;
	CString Sex;
	int Age;
	CString Relationship;
	CString WorkingOrg;
public:
	CFamily();
	virtual ~CFamily();

	int GetId();
	void SetId(int iId);
	int GetEmp_Id();
	void SetEmp_Id(int iEmp_Id);
	CString GetName();
	void SetName(CString cName);
	CString GetSex();
	void SetSex(CString cSex);
	int GetAge();
	void SetAge(int iAge);
	CString GetRelationship();
	void SetRelationship(CString cRelationship);
	CString GetWorkingOrg();
	void SetWorkingOrg(CString cWorkingOrg);

	//���ݿ����
	void sql_insert();
	void sql_update(CString cId);
	void sql_delete(CString cId);
	void sql_deleteByEmp(CString cEmp_Id);
};

#endif // !defined(AFX_FAMILY_H__B39AA80E_3A15_4F8C_AD17_CAB4D422EB9C__INCLUDED_)
