USE HR
GO
CREATE VIEW dbo.v_SumCheck
AS
SELECT LEFT(dbo.Checkin.CheckDate, 7) AS CheckMonth, dbo.Employees.Emp_NAME, 
      SUM(dbo.Checkin.qqDays) AS Sumqq, SUM(dbo.Checkin.ccDays) AS SumCc, 
      SUM(dbo.Checkin.bjDays) AS SumBj, SUM(dbo.Checkin.sjDays) AS SumSj, 
      SUM(dbo.Checkin.kgDays) AS SumKg, SUM(dbo.Checkin.fdxjDays) AS SumFdxj, 
      SUM(dbo.Checkin.nxjDays) AS SumNxj, SUM(dbo.Checkin.dxjDays) AS SumDxj, 
      SUM(dbo.Checkin.cdMinutes) AS SumCd, SUM(dbo.Checkin.ztMinutes) AS SumZt, 
      SUM(dbo.Checkin.ot1Days) AS SumOt1, SUM(dbo.Checkin.ot2Days) AS SumOt2, 
      SUM(dbo.Checkin.ot3Days) AS SumOt3, dbo.Employees.Dep_Id
FROM dbo.Checkin INNER JOIN
      dbo.Employees ON dbo.Checkin.Emp_Id = dbo.Employees.Emp_Id
GROUP BY LEFT(dbo.Checkin.CheckDate, 7), dbo.Employees.Emp_NAME, 
      dbo.Checkin.Emp_Id, dbo.Employees.Dep_Id