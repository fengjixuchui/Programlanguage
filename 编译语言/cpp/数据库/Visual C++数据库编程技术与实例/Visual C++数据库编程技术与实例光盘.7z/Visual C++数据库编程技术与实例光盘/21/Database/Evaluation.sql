USE HR
GO
CREATE TABLE Evaluation
  (EvaMonth	char(10) NOT NULL,
   Emp_Id 	int NOT NULL,
   ztEva	varchar(200),
   jlReason    	varchar(200),
   jlAmount	smallint,
   cfReason	varchar(200),
   cfAmount	smallint,
   Memo	varchar(200)
  )
GO
