USE HR
GO
CREATE TABLE Employees
  (Emp_Id	int PRIMARY KEY IDENTITY,
   Emp_NAME    	varchar(50) NOT NULL,
   Photo	image,
   Sex	char(2),
   Nationality	varchar(40),
   Birth	varchar(20),
   Political_Party	varchar(40),
   Culture_Level	varchar(40),
   Marital_Condition	varchar(20),
   Family_Place	varchar(60),
   Id_Card	varchar(20),
   BadgeID	varchar(40),
   Office_phone	varchar(30),
   Mobile	varchar(30),
   Files_Keep_Org	varchar(100),
   Hukou	varchar(100),
   HireDate	varchar(20),
   Dep_Id	int,
   Position	varchar(40),
   Title	varchar(20),
   State	tinyint,
   UpperId	int,
   Contract_Duration	varchar(20),
   Memo	varchar(200),
   Fillin_Person	varchar(30),
   Fillin_Time	varchar(20)
  )
GO
