USE HR
GO
CREATE TABLE Users
  (UserName  		varchar(40) PRIMARY KEY,
   Pwd		varchar(40) NOT NULL,
   User_Type  		tinyint NOT NULL
  )
GO
INSERT INTO Users Values('Admin', '888888', 1)
GO
