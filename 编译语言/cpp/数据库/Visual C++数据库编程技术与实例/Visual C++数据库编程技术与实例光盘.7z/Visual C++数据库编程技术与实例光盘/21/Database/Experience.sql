USE HR
GO
CREATE TABLE Experience
  (Id	tinyint PRIMARY KEY IDENTITY,
   Emp_Id 	int NOT NULL,
   Start_Date 	char(10),
   End_Date    	char(10),
   School_Org	varchar(50),
   Title	varchar(20)
  )
GO
