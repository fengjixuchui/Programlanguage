USE HR
GO
CREATE TABLE Family
  (Id	tinyint PRIMARY KEY IDENTITY,
   Emp_Id 	int NOT NULL,
   Name	varchar(50) NOT NULL,
   Sex    	char(2),
   Age	tinyint,
   Relationship	varchar(20),
   WorkingOrg	varchar(40)
  )
GO
