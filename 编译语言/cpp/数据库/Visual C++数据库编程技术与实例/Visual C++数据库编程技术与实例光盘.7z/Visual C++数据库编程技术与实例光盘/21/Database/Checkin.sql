USE HR
GO
CREATE TABLE Checkin
  (CheckDate	char(10) NOT NULL,
   Emp_Id 	int NOT NULL,
   qqDays    	decimal(4,1),
   ccDays	decimal(4,1),
   bjDays	decimal(4,1),
   sjDays	decimal(4,1),
   kgDays	decimal(4,1),
   fdxjDays	decimal(4,1),
   nxjDays	decimal(4,1),
   dxjDays	decimal(4,1),
   cdMinutes	tinyint,
   ztMinutes	tinyint,
   ot1Days	decimal(4,1),
   ot2Days	decimal(4,1),
   ot3Days 	decimal(4,1),
   Memo	varchar(200)
  )
GO
