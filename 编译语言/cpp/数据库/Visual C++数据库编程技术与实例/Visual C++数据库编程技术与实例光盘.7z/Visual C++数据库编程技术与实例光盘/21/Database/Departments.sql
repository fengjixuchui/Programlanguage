USE HR
GO
CREATE TABLE Departments
  (Dep_id       	int PRIMARY KEY IDENTITY,
   Dep_name	varchar(40) NOT NULL,
   Describe 	varchar(400),
   UpperId	int NOT NULL
  )
GO