/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Jul 06 12:13:11 2004
 */
/* Compiler settings for F:\Visual C++ 6.0���ݿ�ϵͳ����ʵ������\source code\DHTML Grades\DHTML Grades.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IDHTMLControl = {0x83C4494B,0xD5D4,0x4B68,{0xA0,0x14,0x59,0x90,0x9F,0x0F,0x0B,0xCE}};


const IID IID_IDHTMLControlUI = {0x2B51680E,0x4144,0x436B,{0x98,0xA0,0x23,0xFB,0x79,0xC3,0xEA,0x7D}};


const IID LIBID_DHTMLGRADESLib = {0xD84844A5,0x4107,0x417A,{0x82,0x78,0x0C,0x2B,0xB1,0x5A,0x36,0xA5}};


const CLSID CLSID_DHTMLControl = {0x8A5E8C14,0xD74F,0x45B5,{0x8F,0x3F,0x58,0x41,0x7E,0x1C,0xD4,0x9F}};


#ifdef __cplusplus
}
#endif

