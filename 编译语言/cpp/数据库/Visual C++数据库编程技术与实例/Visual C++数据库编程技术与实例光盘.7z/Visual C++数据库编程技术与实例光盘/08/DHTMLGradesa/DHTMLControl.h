// DHTMLControl.h : Declaration of the CDHTMLControl

#ifndef __DHTMLCONTROL_H_
#define __DHTMLCONTROL_H_

#include "resource.h"       // main symbols
#include <atlctl.h>


/////////////////////////////////////////////////////////////////////////////
// CDHTMLControl
class ATL_NO_VTABLE CDHTMLControl : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IDispatchImpl<IDHTMLControl, &IID_IDHTMLControl, &LIBID_DHTMLGRADESLib>,
	public IDispatchImpl<IDHTMLControlUI, &IID_IDHTMLControlUI, &LIBID_DHTMLGRADESLib>,
	public CComControl<CDHTMLControl>,
	public IPersistStreamInitImpl<CDHTMLControl>,
	public IOleControlImpl<CDHTMLControl>,
	public IOleObjectImpl<CDHTMLControl>,
	public IOleInPlaceActiveObjectImpl<CDHTMLControl>,
	public IViewObjectExImpl<CDHTMLControl>,
	public IOleInPlaceObjectWindowlessImpl<CDHTMLControl>,
	public IPersistStorageImpl<CDHTMLControl>,
	public ISpecifyPropertyPagesImpl<CDHTMLControl>,
	public IQuickActivateImpl<CDHTMLControl>,
	public IDataObjectImpl<CDHTMLControl>,
	public IProvideClassInfo2Impl<&CLSID_DHTMLControl, NULL, &LIBID_DHTMLGRADESLib>,
	public CComCoClass<CDHTMLControl, &CLSID_DHTMLControl>
{
public:
	CDHTMLControl()
	{
		m_bWindowOnly = TRUE;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DHTMLCONTROL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDHTMLControl)
	COM_INTERFACE_ENTRY(IDHTMLControl)
	COM_INTERFACE_ENTRY(IDHTMLControlUI)
	COM_INTERFACE_ENTRY2(IDispatch, IDHTMLControl)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
END_COM_MAP()

BEGIN_PROP_MAP(CDHTMLControl)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()

BEGIN_MSG_MAP(CDHTMLControl)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	CHAIN_MSG_MAP(CComControl<CDHTMLControl>)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);



// IViewObjectEx
	DECLARE_VIEW_STATUS(0)

// IDHTMLControl
public:

// IDHTMLControlUI
public:
	// Example method called by the HTML to change the <BODY> background color
	STDMETHOD(OnClick)(IDispatch* pdispBody, VARIANT varColor)
	{
		CComQIPtr<IHTMLBodyElement> spBody(pdispBody);
		if (spBody != NULL)
			spBody->put_bgColor(varColor);
		return S_OK;
	}

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CAxWindow wnd(m_hWnd);
		HRESULT hr = wnd.CreateControl(IDH_DHTMLCONTROL);
		if (SUCCEEDED(hr))
			hr = wnd.SetExternalDispatch(static_cast<IDHTMLControlUI*>(this));
		if (SUCCEEDED(hr))
			hr = wnd.QueryControl(IID_IWebBrowser2, (void**)&m_spBrowser);
		return SUCCEEDED(hr) ? 0 : -1;
	}

	CComPtr<IWebBrowser2> m_spBrowser;
};

#endif //__DHTMLCONTROL_H_
