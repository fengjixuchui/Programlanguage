/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Mar 21 06:42:30 1999
 */
/* Compiler settings for C:\My Documents\Visual C++\DHTMLGrades\DHTMLGrades.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __DHTMLGrades_h__
#define __DHTMLGrades_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IDHTMLControl_FWD_DEFINED__
#define __IDHTMLControl_FWD_DEFINED__
typedef interface IDHTMLControl IDHTMLControl;
#endif 	/* __IDHTMLControl_FWD_DEFINED__ */


#ifndef __IDHTMLControlUI_FWD_DEFINED__
#define __IDHTMLControlUI_FWD_DEFINED__
typedef interface IDHTMLControlUI IDHTMLControlUI;
#endif 	/* __IDHTMLControlUI_FWD_DEFINED__ */


#ifndef __DHTMLControl_FWD_DEFINED__
#define __DHTMLControl_FWD_DEFINED__

#ifdef __cplusplus
typedef class DHTMLControl DHTMLControl;
#else
typedef struct DHTMLControl DHTMLControl;
#endif /* __cplusplus */

#endif 	/* __DHTMLControl_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IDHTMLControl_INTERFACE_DEFINED__
#define __IDHTMLControl_INTERFACE_DEFINED__

/* interface IDHTMLControl */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IDHTMLControl;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4BA7268D-AB73-11D2-9949-C45224D15E47")
    IDHTMLControl : public IDispatch
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IDHTMLControlVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDHTMLControl __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDHTMLControl __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDHTMLControl __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IDHTMLControl __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IDHTMLControl __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IDHTMLControl __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IDHTMLControl __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IDHTMLControlVtbl;

    interface IDHTMLControl
    {
        CONST_VTBL struct IDHTMLControlVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDHTMLControl_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDHTMLControl_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDHTMLControl_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDHTMLControl_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDHTMLControl_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDHTMLControl_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDHTMLControl_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IDHTMLControl_INTERFACE_DEFINED__ */


#ifndef __IDHTMLControlUI_INTERFACE_DEFINED__
#define __IDHTMLControlUI_INTERFACE_DEFINED__

/* interface IDHTMLControlUI */
/* [unique][helpstring][uuid][dual][object] */ 


EXTERN_C const IID IID_IDHTMLControlUI;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4BA7268E-AB73-11D2-9949-C45224D15E47")
    IDHTMLControlUI : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Lookup( 
            /* [in] */ IDispatch __RPC_FAR *pdispForm,
            /* [in] */ IDispatch __RPC_FAR *pdispTable) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDHTMLControlUIVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDHTMLControlUI __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDHTMLControlUI __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDHTMLControlUI __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IDHTMLControlUI __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IDHTMLControlUI __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IDHTMLControlUI __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IDHTMLControlUI __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Lookup )( 
            IDHTMLControlUI __RPC_FAR * This,
            /* [in] */ IDispatch __RPC_FAR *pdispForm,
            /* [in] */ IDispatch __RPC_FAR *pdispTable);
        
        END_INTERFACE
    } IDHTMLControlUIVtbl;

    interface IDHTMLControlUI
    {
        CONST_VTBL struct IDHTMLControlUIVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDHTMLControlUI_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDHTMLControlUI_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDHTMLControlUI_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDHTMLControlUI_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDHTMLControlUI_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDHTMLControlUI_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDHTMLControlUI_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDHTMLControlUI_Lookup(This,pdispForm,pdispTable)	\
    (This)->lpVtbl -> Lookup(This,pdispForm,pdispTable)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IDHTMLControlUI_Lookup_Proxy( 
    IDHTMLControlUI __RPC_FAR * This,
    /* [in] */ IDispatch __RPC_FAR *pdispForm,
    /* [in] */ IDispatch __RPC_FAR *pdispTable);


void __RPC_STUB IDHTMLControlUI_Lookup_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDHTMLControlUI_INTERFACE_DEFINED__ */



#ifndef __DHTMLGRADESLib_LIBRARY_DEFINED__
#define __DHTMLGRADESLib_LIBRARY_DEFINED__

/* library DHTMLGRADESLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_DHTMLGRADESLib;

EXTERN_C const CLSID CLSID_DHTMLControl;

#ifdef __cplusplus

class DECLSPEC_UUID("E40A11EE-AA4B-11D2-9949-C4CF5F772B46")
DHTMLControl;
#endif
#endif /* __DHTMLGRADESLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
