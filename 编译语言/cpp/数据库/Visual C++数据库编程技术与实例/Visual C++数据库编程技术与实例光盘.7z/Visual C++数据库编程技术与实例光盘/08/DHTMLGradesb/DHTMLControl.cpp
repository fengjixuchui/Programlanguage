// DHTMLControl.cpp : Implementation of CDHTMLControl

#include "stdafx.h"
#include "DHTMLGrades.h"
#include "DHTMLControl.h"
//Added by Chuck Wood for error checking
#include "..\OLEDBErrorChecking\OLEDBErrorChecking.h"
/////////////////////////////////////////////////////////////////////////////
// CDHTMLControl

void CDHTMLControl::fillGrades(
		CComQIPtr<IHTMLFormElement> &spForm,
		CComQIPtr<IHTMLElement> &spTableElement) {
	HRESULT hr;
    char strHTML[1500];    //String to hold the new HTML
    char description[51]; //Current Class Description
//Variants that contain zero and the current column name
	CComVariant vZero(0); // Variant set to zero
	CComVariant vColumnName;

//Start new HTML table
    strcpy(strHTML, "<TABLE length=\"80%\" id=theTable>\n");

//Get the UserID 
	CComBSTR strUser;  //Will contain the user ID value
	CComPtr<IDispatch> spUserDisp;
	CComQIPtr<IHTMLInputTextElement> spUserBox;
	hr = spForm->item(vColumnName = "UserID", vZero, &spUserDisp);
	if (SUCCEEDED(hr)) {
		hr = spUserDisp->QueryInterface(&spUserBox);
	}
	if (SUCCEEDED(hr)) {
		hr = spUserBox->get_value(&strUser);
	}
//Get the password
	CComBSTR strPassword;  //Will contain the password value
	CComPtr<IDispatch> spPasswordDisp;
	CComQIPtr<IHTMLInputTextElement> spPasswordBox;
	if (SUCCEEDED(hr)) {
		hr = spForm->item(vColumnName = "Password", vZero, &spPasswordDisp);
	}
	if (SUCCEEDED(hr)) {
		hr = spPasswordDisp->QueryInterface(&spPasswordBox);
	}
	if (SUCCEEDED(hr)) {
		hr = spPasswordBox->get_value(&strPassword);
	}
//Continue if everything worked.
	if (SUCCEEDED(hr)) {
		CLookup *pSet = new CLookup();
		if (SUCCEEDED(hr)) {
			hr = pSet->findUser(strUser, strPassword);
		}
		if (SUCCEEDED(hr)) {
			hr = pSet->MoveFirst();
		}
		if (SUCCEEDED(hr)) {
			//If everything is still OK, continue forming HTML
			//First add a table title (<CAPTION>) containing the name
			strcat(strHTML, "<CAPTION><EM>Name: <STRONG>");
			strcat(strHTML, pSet->m_Name);
			strcat(strHTML, "</STRONG></EM></CAPTION>\n");
			//Next add CLASS, ASSIGNMENT, and GRADE column headings
			strcat(strHTML,"<TR><TH ALIGN=LEFT><STRONG>Class</STRONG>\n");
			strcat(strHTML,"<TH ALIGN=LEFT><STRONG>Assignment</STRONG>");
			strcat(strHTML,"<TH ALIGN=RIGHT><STRONG>Grade</STRONG>\n");
			//Initialize Class Description
			strcpy (description, "");
			do {
	//Start new row and a new cell
				strcat(strHTML, "<TR><TD>");
	//If new class, display it
				if (strcmp(description, pSet->m_Description)){
	//New description
					strcpy (description, pSet->m_Description);
					strcat(strHTML, "<EM>");
					strcat(strHTML, description);
					strcat(strHTML, "</EM>");
				}
	//Add the assignment cell and the score cell
				sprintf(strHTML, 
			   "%s<TD>%s<TD ALIGN=RIGHT>%2.0f%%\n",
			   strHTML, pSet->m_Assignment,pSet->m_Score);
	//Continue loop if there are more records to process
			} while (pSet->MoveNext() == S_OK);
		}
		else {
			COLEDBErrorChecking::DisplaySingleError(hr, "fillGrades");
		}
	//End new table
		strcat(strHTML, "</TABLE>");
	//Messagebox containing the HTML you're getting, for debugging
	//    ::MessageBox(NULL, strHTML, "DHTMLGrades", MB_OK);
	//Now  put the new HTML onto the web page
		CComBSTR html = strHTML;
		spTableElement->put_outerHTML(html.Copy());
	//Clean up or report errors
		if (hr == S_OK) 
			pSet->Close();    //Close the current row set
		else                    //Some database option failed
			::MessageBox(NULL, "Could not open rowset", "DHTMLGrades", MB_OK);
	}
}
