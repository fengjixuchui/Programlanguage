/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Mar 21 06:42:30 1999
 */
/* Compiler settings for C:\My Documents\Visual C++\DHTMLGrades\DHTMLGrades.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IDHTMLControl = {0x4BA7268D,0xAB73,0x11D2,{0x99,0x49,0xC4,0x52,0x24,0xD1,0x5E,0x47}};


const IID IID_IDHTMLControlUI = {0x4BA7268E,0xAB73,0x11D2,{0x99,0x49,0xC4,0x52,0x24,0xD1,0x5E,0x47}};


const IID LIBID_DHTMLGRADESLib = {0x4BA72681,0xAB73,0x11D2,{0x99,0x49,0xC4,0x52,0x24,0xD1,0x5E,0x47}};


const CLSID CLSID_DHTMLControl = {0xE40A11EE,0xAA4B,0x11D2,{0x99,0x49,0xC4,0xCF,0x5F,0x77,0x2B,0x46}};


#ifdef __cplusplus
}
#endif

