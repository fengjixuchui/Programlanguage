// DAODepartmentDoc.cpp : implementation of the CDAODepartmentDoc class
//

#include "stdafx.h"
#include "DAODepartment.h"

#include "DAODepartmentSet.h"
#include "DAODepartmentDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentDoc

IMPLEMENT_DYNCREATE(CDAODepartmentDoc, CDocument)

BEGIN_MESSAGE_MAP(CDAODepartmentDoc, CDocument)
	//{{AFX_MSG_MAP(CDAODepartmentDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentDoc construction/destruction

CDAODepartmentDoc::CDAODepartmentDoc()
{
	// TODO: add one-time construction code here

}

CDAODepartmentDoc::~CDAODepartmentDoc()
{
}

BOOL CDAODepartmentDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentDoc diagnostics

#ifdef _DEBUG
void CDAODepartmentDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDAODepartmentDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentDoc commands
