// DAODepartmentView.cpp : implementation of the CDAODepartmentView class
//

#include "stdafx.h"
#include "DAODepartment.h"

#include "DAODepartmentSet.h"
#include "DAODepartmentDoc.h"
#include "DAODepartmentView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView

IMPLEMENT_DYNCREATE(CDAODepartmentView, CDaoRecordView)

BEGIN_MESSAGE_MAP(CDAODepartmentView, CDaoRecordView)
	//{{AFX_MSG_MAP(CDAODepartmentView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView construction/destruction

CDAODepartmentView::CDAODepartmentView()
	: CDaoRecordView(CDAODepartmentView::IDD)
{
	//{{AFX_DATA_INIT(CDAODepartmentView)
	m_pSet = NULL;
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CDAODepartmentView::~CDAODepartmentView()
{
}

void CDAODepartmentView::DoDataExchange(CDataExchange* pDX)
{
	CDaoRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDAODepartmentView)
	DDX_FieldText(pDX, IDC_DEPARTMENTCODE, m_pSet->m_DepartmentCode, m_pSet);
	DDX_FieldText(pDX, IDC_DEPARTMENTNAME, m_pSet->m_DepartmentName, m_pSet);
	//}}AFX_DATA_MAP
}

BOOL CDAODepartmentView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CDaoRecordView::PreCreateWindow(cs);
}

void CDAODepartmentView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_dAODepartmentSet;
	CDaoRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView diagnostics

#ifdef _DEBUG
void CDAODepartmentView::AssertValid() const
{
	CDaoRecordView::AssertValid();
}

void CDAODepartmentView::Dump(CDumpContext& dc) const
{
	CDaoRecordView::Dump(dc);
}

CDAODepartmentDoc* CDAODepartmentView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDAODepartmentDoc)));
	return (CDAODepartmentDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView database support
CDaoRecordset* CDAODepartmentView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView message handlers
