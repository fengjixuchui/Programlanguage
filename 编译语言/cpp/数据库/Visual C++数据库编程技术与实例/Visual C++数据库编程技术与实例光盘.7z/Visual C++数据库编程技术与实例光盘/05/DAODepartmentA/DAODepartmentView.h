// DAODepartmentView.h : interface of the CDAODepartmentView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DAODEPARTMENTVIEW_H__F860D039_5C02_49F4_AE06_7A208CF585B1__INCLUDED_)
#define AFX_DAODEPARTMENTVIEW_H__F860D039_5C02_49F4_AE06_7A208CF585B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDAODepartmentSet;

class CDAODepartmentView : public CDaoRecordView
{
protected: // create from serialization only
	CDAODepartmentView();
	DECLARE_DYNCREATE(CDAODepartmentView)

public:
	//{{AFX_DATA(CDAODepartmentView)
	enum { IDD = IDD_DAODEPARTMENT_FORM };
	CDAODepartmentSet* m_pSet;
	//}}AFX_DATA

// Attributes
public:
	CDAODepartmentDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDAODepartmentView)
	public:
	virtual CDaoRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDAODepartmentView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDAODepartmentView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DAODepartmentView.cpp
inline CDAODepartmentDoc* CDAODepartmentView::GetDocument()
   { return (CDAODepartmentDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAODEPARTMENTVIEW_H__F860D039_5C02_49F4_AE06_7A208CF585B1__INCLUDED_)
