// DAODeptInstDoc.cpp : implementation of the CDAODeptInstDoc class
//

#include "stdafx.h"
#include "DAODeptInst.h"

#include "DAODeptInstSet.h"
#include "DAODeptInstDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstDoc

IMPLEMENT_DYNCREATE(CDAODeptInstDoc, CDocument)

BEGIN_MESSAGE_MAP(CDAODeptInstDoc, CDocument)
	//{{AFX_MSG_MAP(CDAODeptInstDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstDoc construction/destruction

CDAODeptInstDoc::CDAODeptInstDoc()
{
	// TODO: add one-time construction code here

}

CDAODeptInstDoc::~CDAODeptInstDoc()
{
}

BOOL CDAODeptInstDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstDoc diagnostics

#ifdef _DEBUG
void CDAODeptInstDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDAODeptInstDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstDoc commands
