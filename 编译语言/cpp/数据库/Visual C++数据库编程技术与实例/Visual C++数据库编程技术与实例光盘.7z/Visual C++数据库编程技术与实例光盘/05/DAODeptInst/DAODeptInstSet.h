// DAODeptInstSet.h : interface of the CDAODeptInstSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DAODEPTINSTSET_H__D7B46FAF_9504_11D2_9949_983981A5C342__INCLUDED_)
#define AFX_DAODEPTINSTSET_H__D7B46FAF_9504_11D2_9949_983981A5C342__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDAODeptInstSet : public CDaoRecordset
{
public:
	CDAODeptInstSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDAODeptInstSet)

// Field/Param Data
	//{{AFX_FIELD(CDAODeptInstSet, CDaoRecordset)
	CString	m_DepartmentCode;
	CString	m_DepartmentName;
	long	m_InstructorID;
	CString	m_Name;
	CString	m_DepartmentCode2;
	CString	m_EMAIL;
	CString	m_Notes;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDAODeptInstSet)
	public:
	virtual CString GetDefaultDBName();		// REVIEW:  Get a comment here
	virtual CString GetDefaultSQL(); 	// default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);	// RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAODEPTINSTSET_H__D7B46FAF_9504_11D2_9949_983981A5C342__INCLUDED_)

