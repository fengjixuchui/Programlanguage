// DAODeptInstSet.cpp : implementation of the CDAODeptInstSet class
//

#include "stdafx.h"
#include "DAODeptInst.h"
#include "DAODeptInstSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstSet implementation

IMPLEMENT_DYNAMIC(CDAODeptInstSet, CDaoRecordset)

CDAODeptInstSet::CDAODeptInstSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDAODeptInstSet)
	m_DepartmentCode = _T("");
	m_DepartmentName = _T("");
	m_InstructorID = 0;
	m_Name = _T("");
	m_DepartmentCode2 = _T("");
	m_EMAIL = _T("");
	m_Notes = _T("");
	m_nFields = 7;
	//}}AFX_FIELD_INIT
	m_strFilter = 
"Instructor.DepartmentCode = Department.DepartmentCode";
	m_nDefaultType = dbOpenDynaset;
}

CString CDAODeptInstSet::GetDefaultDBName()
{
	return _T("C:\\Classes.mdb");
}


CString CDAODeptInstSet::GetDefaultSQL()
{
	return _T("[Department],[Instructor]");
}

void CDAODeptInstSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDAODeptInstSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[Department].[DepartmentCode]"), m_DepartmentCode);
	DFX_Text(pFX, _T("[DepartmentName]"), m_DepartmentName);
	DFX_Long(pFX, _T("[InstructorID]"), m_InstructorID);
	DFX_Text(pFX, _T("[Name]"), m_Name);
	DFX_Text(pFX, _T("[Instructor].[DepartmentCode]"), m_DepartmentCode2);
	DFX_Text(pFX, _T("[EMAIL]"), m_EMAIL);
	DFX_Text(pFX, _T("[Notes]"), m_Notes);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstSet diagnostics

#ifdef _DEBUG
void CDAODeptInstSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDAODeptInstSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
