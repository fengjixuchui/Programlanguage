// DAODeptInstView.cpp : implementation of the CDAODeptInstView class
//

#include "stdafx.h"
#include "DAODeptInst.h"

#include "DAODeptInstSet.h"
#include "DAODeptInstDoc.h"
#include "DAODeptInstView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstView

IMPLEMENT_DYNCREATE(CDAODeptInstView, CDaoRecordView)

BEGIN_MESSAGE_MAP(CDAODeptInstView, CDaoRecordView)
	//{{AFX_MSG_MAP(CDAODeptInstView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CDaoRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CDaoRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CDaoRecordView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstView construction/destruction

CDAODeptInstView::CDAODeptInstView()
	: CDaoRecordView(CDAODeptInstView::IDD)
{
	//{{AFX_DATA_INIT(CDAODeptInstView)
	m_pSet = NULL;
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CDAODeptInstView::~CDAODeptInstView()
{
}

void CDAODeptInstView::DoDataExchange(CDataExchange* pDX)
{
	CDaoRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDAODeptInstView)
	DDX_FieldText(pDX, IDC_DEPARTMENTCODE, m_pSet->m_DepartmentCode, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentCode, 4);
	DDX_FieldText(pDX, IDC_DEPARTMENTNAME, m_pSet->m_DepartmentName, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentName, 50);
	DDX_FieldText(pDX, IDC_EMAIL, m_pSet->m_EMAIL, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_EMAIL, 50);
	DDX_FieldText(pDX, IDC_INSTRUCTORNAME, m_pSet->m_Name, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_Name, 50);
	DDX_FieldText(pDX, IDC_NOTES, m_pSet->m_Notes, m_pSet);
	//}}AFX_DATA_MAP
}

BOOL CDAODeptInstView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CDaoRecordView::PreCreateWindow(cs);
}

void CDAODeptInstView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_dAODeptInstSet;
	CDaoRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstView printing

BOOL CDAODeptInstView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CDAODeptInstView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CDAODeptInstView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstView diagnostics

#ifdef _DEBUG
void CDAODeptInstView::AssertValid() const
{
	CDaoRecordView::AssertValid();
}

void CDAODeptInstView::Dump(CDumpContext& dc) const
{
	CDaoRecordView::Dump(dc);
}

CDAODeptInstDoc* CDAODeptInstView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDAODeptInstDoc)));
	return (CDAODeptInstDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstView database support
CDaoRecordset* CDAODeptInstView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstView message handlers
