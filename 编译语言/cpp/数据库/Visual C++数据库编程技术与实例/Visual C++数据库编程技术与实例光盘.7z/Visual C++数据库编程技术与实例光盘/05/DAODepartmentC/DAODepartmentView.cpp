// DAODepartmentView.cpp : implementation of the CDAODepartmentView class
//

#include "stdafx.h"
#include "DAODepartment.h"

#include "DAODepartmentSet.h"
#include "DAODepartmentDoc.h"
#include "DAODepartmentView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView

IMPLEMENT_DYNCREATE(CDAODepartmentView, CDaoRecordView)

BEGIN_MESSAGE_MAP(CDAODepartmentView, CDaoRecordView)
	//{{AFX_MSG_MAP(CDAODepartmentView)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_RECORD_DELETERECORD, OnRecordDeleterecord)
	ON_UPDATE_COMMAND_UI(ID_RECORD_DELETERECORD, OnUpdateRecordDeleterecord)
	ON_COMMAND(ID_RECORD_QUERYRECORD, OnRecordQueryrecord)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
	ON_EN_CHANGE(IDC_DEPARTMENTCODE, OnChangeDepartmentcode)
	ON_EN_CHANGE(IDC_DEPARTMENTNAME, OnChangeDepartmentname)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CDaoRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CDaoRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CDaoRecordView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView construction/destruction

CDAODepartmentView::CDAODepartmentView()
	: CDaoRecordView(CDAODepartmentView::IDD)
{
	//{{AFX_DATA_INIT(CDAODepartmentView)
	m_pSet = NULL;
	m_FindDeptCode = _T("");
	//}}AFX_DATA_INIT
	m_bChangesMade = FALSE;
}

CDAODepartmentView::~CDAODepartmentView()
{
}

void CDAODepartmentView::DoDataExchange(CDataExchange* pDX)
{
	CDaoRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDAODepartmentView)
	DDX_FieldText(pDX, IDC_DEPARTMENTCODE, m_pSet->m_DepartmentCode, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentCode, 4);
	DDX_FieldText(pDX, IDC_DEPARTMENTNAME, m_pSet->m_DepartmentName, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentName, 50);
	DDX_Text(pDX, IDC_FINDCODE, m_FindDeptCode);
	DDV_MaxChars(pDX, m_FindDeptCode, 4);
	//}}AFX_DATA_MAP
}

BOOL CDAODepartmentView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CDaoRecordView::PreCreateWindow(cs);
}

void CDAODepartmentView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_dAODepartmentSet;
	CDaoRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
	if (m_pSet->m_pDatabase->CanTransact()) {
		m_pSet->Close();	//Close to start transaction
		m_pSet->m_pDatabase->m_pWorkspace->BeginTrans();
		m_pSet->Open();	//Open after starting transaction
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView printing

BOOL CDAODepartmentView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CDAODepartmentView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CDAODepartmentView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView diagnostics

#ifdef _DEBUG
void CDAODepartmentView::AssertValid() const
{
	CDaoRecordView::AssertValid();
}

void CDAODepartmentView::Dump(CDumpContext& dc) const
{
	CDaoRecordView::Dump(dc);
}

CDAODepartmentDoc* CDAODepartmentView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDAODepartmentDoc)));
	return (CDAODepartmentDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView database support
CDaoRecordset* CDAODepartmentView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView message handlers

//********* ADDED FOR DAODepartmentViewB ****************//
BOOL CDAODepartmentView::OnMove(UINT nIDMoveCommand) 
{
	SaveData();
	return CDaoRecordView::OnMove(nIDMoveCommand);
}

void CDAODepartmentView::OnFileNew() 
{
	if (!m_pSet->IsBOF() 
					&& !m_pSet->IsDeleted()
					&& !m_pSet->IsEOF()) {
		//On a valid record
		UpdateData(TRUE);	//Get data from dialog box
		if (m_pSet->GetEditMode() != dbEditAdd) {
			//Not currently adding a record
			m_pSet->Edit();	//Set for edit mode
		}
		m_pSet->Update();	//Update data if needed
		m_pSet->MoveLast();	//Get off record 1
	}
	m_pSet->SetFieldNull(NULL);	//Clear all fields
	m_pSet->AddNew();	//Set database in AddNew mode
	UpdateData(FALSE);	//Update dialog box fields
}

void CDAODepartmentView::OnRecordDeleterecord() 
{
	if (AfxMessageBox(	//Be sure to verify your deletes
			"Are you sure you want to delete?",
			MB_YESNO)
		!= IDYES) {
		return;
	}
	if (m_pSet->GetEditMode() == dbEditAdd) {
	//Currently adding so don't delete, just cancel add.
		m_pSet->CancelUpdate();
		m_pSet->MovePrev();
		return;
	}
	try {
		m_pSet->Delete();	//Delete record
	}
	catch(CDaoException* e1) {	//Failed
		TCHAR message[200];
		TCHAR display[255];
		e1->GetErrorMessage(message, 200);
		strcpy (display, "Delete Failed:\n");
		strcat (display, message);
		AfxMessageBox( display, MB_ICONEXCLAMATION);
		m_pSet->MoveFirst();	//We lost our place.
		e1->Delete();		//Delete Error Message
		UpdateData(FALSE);	//Update dialog box fields
		return;
	}
	m_pSet->MoveNext();			//Go to next record
	if (m_pSet->IsBOF() 
				|| m_pSet->IsDeleted()
				|| m_pSet->IsEOF()) {
		//Was there a next record?
		m_pSet->Requery();		//Reretrieve
		m_pSet->MoveFirst();	//Deleted last record
	}
	try {
		if (m_pSet->IsBOF() 
					|| m_pSet->IsDeleted()
					|| m_pSet->IsEOF()) {
			//Can't find a record
			AfxThrowDaoException();   
		}
		UpdateData(FALSE);	//Update dialog box fields
	}
	catch(CDaoException* e2) {	//No records exist
		AfxMessageBox("No more records",
			MB_ICONEXCLAMATION);
		e2->Delete();		//Delete Error Message
		//Close and Open to get rid of the Deleted record
		m_pSet->Close();
		m_pSet->Open();
		//No records, so set up an add record
		OnFileNew();
	}
}

void CDAODepartmentView::OnUpdateRecordDeleterecord(CCmdUI* pCmdUI) 
{
	//Disable delete functionality if no record is found
	pCmdUI->Enable(		//Enable delete if there's a record
		!m_pSet->IsBOF() &&
		!m_pSet->IsDeleted() &&
		!m_pSet->IsEOF());
}

void CDAODepartmentView::OnRecordQueryrecord() 
{
	CString newFilter = "";	//Default is no filter
	UpdateData(TRUE);	//Get data from dialog box
	if (m_pSet->GetEditMode() != dbEditAdd) {
		//Not currently adding, so set to update
		m_pSet->Edit();		
	}
	m_pSet->Update();	//Update data if needed
	if (m_FindDeptCode != "") {
		//Setup new filter
		newFilter = "DepartmentCode = '" + m_FindDeptCode + "'";
	}
	if (newFilter != m_pSet->m_strFilter) {
		//Filter has changed
		m_pSet->m_strFilter = newFilter;	//Assign new filter
		try {
			m_pSet->Requery();			//Requery
		}
		catch(CDaoException* e1)    {
			AfxMessageBox("Requery has failed");
			m_pSet->m_strFilter = "";		//Try to get back
			m_pSet->Requery();			//Requery again
			e1->Delete();		//Delete Error Message
		}
		try {
		//Go to the first record of the new filtered recordset
			m_pSet->MoveFirst();
		}
		catch(CDaoException* e2)    {
			//Move failed because there are no records
			AfxMessageBox("No records were found", MB_ICONEXCLAMATION );
			e2->Delete();		//Delete Error Message
			//No records, so set up an add record
			OnFileNew();
		}
	}
	UpdateData(FALSE);	//Update dialog box fields
}

//********* ADDED FOR DAODepartmentViewC ****************//
void CDAODepartmentView::OnChangeDepartmentcode() 
{
	m_bChangesMade = TRUE;
}

void CDAODepartmentView::OnChangeDepartmentname() 
{
	m_bChangesMade = TRUE;
}

void CDAODepartmentView::OnFileSave() 
{
	SaveData();
	if (m_pSet->m_pDatabase->CanTransact() 
			&& m_bChangesMade) {
		m_pSet->m_pDatabase->m_pWorkspace->CommitTrans();
		m_pSet->m_pDatabase->m_pWorkspace->BeginTrans();
	}
	m_bChangesMade = FALSE;
}

void CDAODepartmentView::OnUpdateFileSave(CCmdUI* pCmdUI) 
{
	//Enable save if records have been changed
	pCmdUI->Enable(m_bChangesMade && 
		m_pSet->m_pDatabase->CanTransact());
}


void CDAODepartmentView::OnDestroy() 
{
//Check for changed fields and transaciton ability
	if (m_pSet->m_pDatabase->CanTransact() 
			&& m_bChangesMade) {
		if (AfxMessageBox (
			"Records have been changed.  Do you want to save?", 
			MB_YESNO) == IDYES) {
			SaveData();
			OnFileSave();
		}
	}
	//Roll back last transaction
	m_pSet->m_pDatabase->m_pWorkspace->Rollback();
	CDaoRecordView::OnDestroy();
}

void CDAODepartmentView::SaveData() 
{
	if (m_pSet->GetEditMode() != dbEditAdd) {
		//Currently not adding a record, so set edit mode
		m_pSet->Edit();
	}
	UpdateData(TRUE);	//Get data from dialog box
	m_pSet->Update();	//Update data if needed
}
