// DAODepartmentDoc.cpp : implementation of the CDAODepartmentDoc class
//

#include "stdafx.h"
#include "DAODepartment.h"

#include "DAODepartmentSet.h"
#include "DAODepartmentDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentDoc

IMPLEMENT_DYNCREATE(CDAODepartmentDoc, CDocument)

BEGIN_MESSAGE_MAP(CDAODepartmentDoc, CDocument)
	//{{AFX_MSG_MAP(CDAODepartmentDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentDoc construction/destruction

CDAODepartmentDoc::CDAODepartmentDoc()
{
}

CDAODepartmentDoc::~CDAODepartmentDoc()
{
}

BOOL CDAODepartmentDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentDoc serialization

void CDAODepartmentDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentDoc diagnostics

#ifdef _DEBUG
void CDAODepartmentDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDAODepartmentDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentDoc commands
