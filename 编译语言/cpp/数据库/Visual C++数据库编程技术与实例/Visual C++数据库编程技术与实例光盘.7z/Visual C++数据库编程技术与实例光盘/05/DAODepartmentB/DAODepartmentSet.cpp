// DAODepartmentSet.cpp : implementation of the CDAODepartmentSet class
//

#include "stdafx.h"
#include "DAODepartment.h"
#include "DAODepartmentSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentSet implementation

IMPLEMENT_DYNAMIC(CDAODepartmentSet, CDaoRecordset)

CDAODepartmentSet::CDAODepartmentSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDAODepartmentSet)
	m_DepartmentCode = _T("");
	m_DepartmentName = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}

CString CDAODepartmentSet::GetDefaultDBName()
{
	return _T("C:\\Classes.mdb");
}


CString CDAODepartmentSet::GetDefaultSQL()
{
	return _T("[Department]");
}

void CDAODepartmentSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDAODepartmentSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Text(pFX, _T("[DepartmentCode]"), m_DepartmentCode);
	DFX_Text(pFX, _T("[DepartmentName]"), m_DepartmentName);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentSet diagnostics

#ifdef _DEBUG
void CDAODepartmentSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDAODepartmentSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
