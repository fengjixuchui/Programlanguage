//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by StudentScore.rc
//
#define IDR_MANIFEST                    1
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_STUDENTSCORE_FORM           101
#define IDD_LOGINFRM                    103
#define IDD_EXAMVIEW                    106
#define IDD_BMDIALOG                    107
#define IDD_SELEXAMNODIALOG             108
#define IDD_ADDCLASSDIALOG              109
#define IDD_EXAMSTUDENTVIEW             110
#define IDD_ADDSTUDENTDIALOG            111
#define IDD_EXAMSUBJECTVIEW             112
#define IDD_ADDSUBJECTDIALOG            113
#define IDR_MAINFRAME                   128
#define IDR_StudentScoreTYPE            129
#define IDI_ICON1                       131
#define IDI_ICON2                       132
#define IDI_ICON3                       133
#define IDR_MENU1                       137
#define ID_138                          138
#define ID_139                          139
#define ID_Menu                         140
#define ID_141                          141
#define ID_LIST142                      142
#define ID_143                          143
#define ID_144                          144
#define ID_145                          145
#define ID_146                          146
#define IDB_IL_CLASS                    147
#define ID_148                          148
#define ID_149                          149
#define ID_150                          150
#define ID_151                          151
#define IDR_MENU2                       152
#define ID_153                          153
#define ID_154                          154
#define ID_155                          155
#define ID_156                          156
#define ID_157                          157
#define IDR_MENU3                       158
#define ID_159                          159
#define ID_190                          160
#define ID__161                         161
#define IDR_MENU4                       162
#define ID__163                         163
#define ID__                            164
#define IDC_COMBO1                      1000
#define IDC_EDIT1                       1001
#define IDC_BUTTON1                     1002
#define IDC_LIST1                       1004
#define IDC_TREE1                       1005
#define IDC_EDIT2                       1009
#define IDC_DATETIMEPICKER1             1010
#define IDC_BUTTON2                     1011
#define IDC_BUTTON3                     1012
#define IDC_BUTTON4                     1013
#define IDC_STATIC1                     1014
#define IDC_STATIC2                     1015
#define IDC_STATIC3                     1016
#define IDC_COMBO2                      1018
#define ID_INDICATOR_USERNAME           1204
#define ID_INDICATOR_SYSTIME            1205
#define ID_BUTTON32771                  32771
#define ID_BUTTON32772                  32772
#define ID_BUTTON32776                  32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        167
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           114
#endif
#endif
