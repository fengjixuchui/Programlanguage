#if !defined(AFX_RSTCLASS1_H__89712896_992D_4D4E_BA7A_CC14F0D8D124__INCLUDED_)
#define AFX_RSTCLASS1_H__89712896_992D_4D4E_BA7A_CC14F0D8D124__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RstClass1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRstClass1 recordset

class CRstClass1 : public CRecordset
{
public:
	CRstClass1(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRstClass1)

// Field/Param Data
	//{{AFX_FIELD(CRstClass1, CRecordset)
	long	m_F_ID;
	CString	m_F_AutoNo;
	CString	m_F_Teacher;
	CTime	m_F_Date;
	long	m_F_Noon;
	CString	m_F_Remark;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRstClass1)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RSTCLASS1_H__89712896_992D_4D4E_BA7A_CC14F0D8D124__INCLUDED_)
