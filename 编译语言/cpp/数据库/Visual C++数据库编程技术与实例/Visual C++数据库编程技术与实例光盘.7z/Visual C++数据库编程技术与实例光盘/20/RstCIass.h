#if !defined(AFX_RSTCIASS_H__E2C74A54_7A15_4B9B_A22A_1B1544D05837__INCLUDED_)
#define AFX_RSTCIASS_H__E2C74A54_7A15_4B9B_A22A_1B1544D05837__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RstCIass.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRstCIass recordset

class CRstCIass : public CRecordset
{
public:
	CRstCIass(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CRstCIass)

// Field/Param Data
	//{{AFX_FIELD(CRstCIass, CRecordset)
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRstCIass)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RSTCIASS_H__E2C74A54_7A15_4B9B_A22A_1B1544D05837__INCLUDED_)
