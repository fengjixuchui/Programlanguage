// sdfsdf.cpp : implementation file
//

#include "stdafx.h"
#include "AutoStuMis.h"
#include "sdfsdf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// sdfsdf

IMPLEMENT_DYNAMIC(sdfsdf, CRecordset)

sdfsdf::sdfsdf(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(sdfsdf)
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}


CString sdfsdf::GetDefaultConnect()
{
	return _T("ODBC;DSN=automis");
}

CString sdfsdf::GetDefaultSQL()
{
	return _T("");
}

void sdfsdf::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(sdfsdf)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// sdfsdf diagnostics

#ifdef _DEBUG
void sdfsdf::AssertValid() const
{
	CRecordset::AssertValid();
}

void sdfsdf::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
