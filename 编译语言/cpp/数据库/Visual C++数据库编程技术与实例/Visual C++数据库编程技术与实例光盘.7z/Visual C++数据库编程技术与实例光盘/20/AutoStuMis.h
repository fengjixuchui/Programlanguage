// AutoStuMis.h : main header file for the AUTOSTUMIS application
//

#if !defined(AFX_AUTOSTUMIS_H__D2236A44_193F_11D8_8C25_000AEB143A3A__INCLUDED_)
#define AFX_AUTOSTUMIS_H__D2236A44_193F_11D8_8C25_000AEB143A3A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

enum OpenType
	{
		dynaset,        // uses SQLExtendedFetch, keyset driven cursor
		snapshot,       // uses SQLExtendedFetch, static cursor
		forwardOnly,    // uses SQLFetch
		dynamic         // uses SQLExtendedFetch, dynamic cursor
	};
enum DataType
{
	dtStudent,
	dtClass
};

/////////////////////////////////////////////////////////////////////////////
// CAutoStuMisApp:
// See AutoStuMis.cpp for the implementation of this class
//
class CAutoStuMisDoc;
class CAutoStuMisApp : public CWinApp
{
public:
	long GetCurMaxKeyID(CString sTableName, BOOL bUpdateNow);
	CAutoStuMisDoc * m_pDoc;
	CString GetStrFromMyIni(CString sAppName, CString sKey, CString sDefault);
	int m_nDBType;
	CString m_sPassword;
	CString m_sUID;
	CString m_sDBN;
	CString m_sDBServer;
	char m_chrCommChar;
	char m_chrDateSplit;
	int m_nOpenType;
	CString m_sSystemSetupFile;
	CString m_sAppPath;
	CDatabase m_db;
	CAutoStuMisApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAutoStuMisApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CAutoStuMisApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AUTOSTUMIS_H__D2236A44_193F_11D8_8C25_000AEB143A3A__INCLUDED_)
