//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AutoStuMis.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_AUTOSTTYPE                  129
#define IDD_DIALOG_STUDENTEDIT          134
#define IDD_DIALOG_CLASSEDIT            139
#define IDD_DIALOG_SELECTSTUDENT        141
#define IDD_DIALOG_STUDENTINFOR         143
#define IDD_DIALOG_FILTERCLASS          144
#define IDD_DIALOG_FINDSTUDENT          146
#define IDC_EDIT_NAME                   1000
#define IDC_COMBO_SEX                   1001
#define IDC_EDIT_SN                     1002
#define IDC_EDIT_ADDRESS                1003
#define IDC_EDIT_TEL                    1004
#define IDC_DATETIMEPICKER1             1005
#define IDC_EDIT_AUTONO                 1006
#define IDC_DATETIMEPICKER_EXAMFIELD    1006
#define IDC_DATETIMEPICKER2             1006
#define IDC_COMBO_TYPE                  1007
#define IDC_DATETIMEPICKER_EXAMROAD     1007
#define IDC_EDIT_REMARK                 1008
#define IDC_DATETIMEPICKER_END          1008
#define ID_BUTTON_SAVE                  1009
#define IDC_COMBO1                      1010
#define IDC_EDIT_TEACHER                1012
#define IDC_LIST1                       1013
#define IDC_BUTTON_ADDSTUDENT           1014
#define IDC_BUTTON_REMOVESTUDENT        1015
#define IDC_EDIT1                       1015
#define ID_BUTTON_SELECT                1016
#define IDC_BUTTON_MODIFYSTUDENT        1016
#define IDC_DATETIMEPICKER_UPAUTO       1017
#define IDC_EDIT2                       1019
#define ID_DATA_STUDENT                 32773
#define ID_EDIT_ADDNEW                  32774
#define ID_VIEW_REFRESH                 32775
#define ID_DATA_CLASS                   32777
#define ID_EDIT_MODIFY                  32778
#define ID_EDIT_DELETE                  32779
#define ID_EDIT_SEARCH                  32781
#define ID_VIEW_CLEARDATA               32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
