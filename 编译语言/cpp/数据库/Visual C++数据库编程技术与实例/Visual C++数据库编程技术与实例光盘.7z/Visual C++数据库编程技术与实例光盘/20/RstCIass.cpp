// RstCIass.cpp : implementation file
//

#include "stdafx.h"
#include "AutoStuMis.h"
#include "RstCIass.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRstCIass

IMPLEMENT_DYNAMIC(CRstCIass, CRecordset)

CRstCIass::CRstCIass(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRstCIass)
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CRstCIass::GetDefaultConnect()
{
	return _T("ODBC;DSN=");
}

CString CRstCIass::GetDefaultSQL()
{
	return _T("");
}

void CRstCIass::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRstCIass)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CRstCIass diagnostics

#ifdef _DEBUG
void CRstCIass::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRstCIass::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
