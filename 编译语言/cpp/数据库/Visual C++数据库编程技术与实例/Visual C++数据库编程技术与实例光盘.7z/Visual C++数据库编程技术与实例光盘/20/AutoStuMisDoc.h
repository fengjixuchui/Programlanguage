// AutoStuMisDoc.h : interface of the CAutoStuMisDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_AUTOSTUMISDOC_H__D2236A4A_193F_11D8_8C25_000AEB143A3A__INCLUDED_)
#define AFX_AUTOSTUMISDOC_H__D2236A4A_193F_11D8_8C25_000AEB143A3A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



class CAutoStuMisDoc : public CDocument
{
protected: // create from serialization only
	CAutoStuMisDoc();
	DECLARE_DYNCREATE(CAutoStuMisDoc)

// Attributes
public:
	CTypedPtrArray <CObArray,CItem*> m_arrExamType;
	CTypedPtrArray <CObArray,CItem*> m_arrStudentType;
	CTypedPtrArray <CObArray,CStudent*> m_arrStudent;
	CTypedPtrArray <CObArray,CClass*> m_arrClass;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAutoStuMisDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	void FreeAllClass();
	int ReadClasss(CTime tmStart, CTime tmEnd,CString sAutoNo,CString sTeacher);
	int FillStudentsToListctrl(CListCtrl *pListCtrl,CString sSex,CString sName);
	void FreeAllData();
	int FillItemsToComboBox(CComboBox *pcbo,CObArray *pArr);
	CItem* GetItemByID(CObArray *pArr,long nID);
	void ReadInitData();
	virtual ~CAutoStuMisDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CAutoStuMisDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AUTOSTUMISDOC_H__D2236A4A_193F_11D8_8C25_000AEB143A3A__INCLUDED_)
