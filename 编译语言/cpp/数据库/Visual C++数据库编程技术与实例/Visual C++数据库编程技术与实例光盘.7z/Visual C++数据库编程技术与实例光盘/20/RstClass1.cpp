// RstClass1.cpp : implementation file
//

#include "stdafx.h"
#include "AutoStuMis.h"
#include "RstClass1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRstClass1

IMPLEMENT_DYNAMIC(CRstClass1, CRecordset)

CRstClass1::CRstClass1(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CRstClass1)
	m_F_ID = 0;
	m_F_AutoNo = _T("");
	m_F_Teacher = _T("");
	m_F_Noon = 0;
	m_F_Remark = _T("");
	m_nFields = 6;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}


CString CRstClass1::GetDefaultConnect()
{
	return _T("ODBC;DSN=automis");
}

CString CRstClass1::GetDefaultSQL()
{
	return _T("[T_Class]");
}

void CRstClass1::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CRstClass1)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[F_ID]"), m_F_ID);
	RFX_Text(pFX, _T("[F_AutoNo]"), m_F_AutoNo);
	RFX_Text(pFX, _T("[F_Teacher]"), m_F_Teacher);
	RFX_Date(pFX, _T("[F_Date]"), m_F_Date);
	RFX_Long(pFX, _T("[F_Noon]"), m_F_Noon);
	RFX_Text(pFX, _T("[F_Remark]"), m_F_Remark);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CRstClass1 diagnostics

#ifdef _DEBUG
void CRstClass1::AssertValid() const
{
	CRecordset::AssertValid();
}

void CRstClass1::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
