// AutoStuMis.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "AutoStuMis.h"

#include "MainFrm.h"
#include "AutoStuMisDoc.h"
#include "AutoStuMisView.h"
#include "RstKeyID.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAutoStuMisApp

BEGIN_MESSAGE_MAP(CAutoStuMisApp, CWinApp)
	//{{AFX_MSG_MAP(CAutoStuMisApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAutoStuMisApp construction

CAutoStuMisApp::CAutoStuMisApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CAutoStuMisApp object

CAutoStuMisApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CAutoStuMisApp initialization

BOOL CAutoStuMisApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	LoadStdProfileSettings(0);  // Load standard INI file options (including MRU)


	//��ȡ����������·��,����sPath��
	GetModuleFileName(NULL,m_sAppPath.GetBufferSetLength(MAX_PATH+1),MAX_PATH);
	m_sAppPath.ReleaseBuffer ();
    int nPos;
	nPos=m_sAppPath.ReverseFind ('\\');
	m_sAppPath=m_sAppPath.Left(nPos);
	m_sSystemSetupFile = m_sAppPath + "\\HyConfig.dat";
	
	try
	{
		if(!m_db.IsOpen())
		{
			//��ȡʹ�õ����ݿ�����
			m_nDBType = atoi(GetStrFromMyIni("NetWork","DBDriver","0"));
			
			m_sDBServer = GetStrFromMyIni("NetWork","DBServer",m_sDBServer);
			m_sDBN = GetStrFromMyIni("NetWork","DBN",m_sDBN);
			m_sUID = GetStrFromMyIni("NetWork","UID",m_sUID);
			m_sPassword = GetStrFromMyIni("NetWork","PSW",m_sPassword);

			CString strCon;			
			switch(m_nDBType)
			{
			case 0://Access
				strCon.Format("DSN=MS Access 97 Database;DBQ=%s;DefaultDir=%s;DriverId=281;FIL=MS Access;MaxBufferSize=2048;PageTimeout=5;UID=admin;",
					m_sDBN,
					m_sAppPath);
				m_nOpenType = dynaset;
				m_chrDateSplit = '#';
				m_chrCommChar = '*';
				break;
			case 1://SQL SERVER 7.0
				strCon.Format("PROVIDER=MSDASQL;driver={SQL Server};server=%s;uid=sa;pwd=;database=%s;",
					m_sDBServer,
					m_sDBN);
				m_nOpenType = dynamic;
				m_chrDateSplit = '\'';
				m_chrCommChar = '%';
				break;
			case 2:
				strCon.Format("DSN=MS Access Database;DBQ=%s;DefaultDir=%s;DriverId=281;FIL=MS Access;MaxBufferSize=2048;PageTimeout=5;UID=admin;",
					m_sDBN,
					m_sAppPath);
				m_nOpenType = dynaset;
				m_chrDateSplit = '#';
				m_chrCommChar = '*';
				break;
			default:
				return false;
			}
			m_db.OpenEx(strCon,CDatabase::noOdbcDialog);				
		}
	}
	catch(CException e)
	{
		e.ReportError();
		e.Delete();
	}

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CAutoStuMisDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CAutoStuMisView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The one and only window has been initialized, so show and update it.
	m_pMainWnd->ShowWindow(SW_SHOWMAXIMIZED);
	m_pMainWnd->UpdateWindow();

	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CAutoStuMisApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CAutoStuMisApp message handlers


CString CAutoStuMisApp::GetStrFromMyIni(CString sAppName, CString sKey, CString sDefault)
{
	char ss[MAX_PATH]; 
	DWORD dwLen=GetPrivateProfileString(sAppName,sKey,
		"",
		ss,
		MAX_PATH,
		m_sSystemSetupFile);
	CString sR(ss);
	sR.TrimLeft();
	sR.TrimRight();
	return sR;

}

long CAutoStuMisApp::GetCurMaxKeyID(CString sTableName, BOOL bUpdateNow)
{
	CRstKeyID rst;
	long ID=1;
	CString sql;
	rst.m_strFilter.Format("F_TableName='%s'",sTableName);
	rst.Open();
	if(rst.GetRecordCount()>0)
	{
        ID = rst.m_F_CurMaxID;
        if(bUpdateNow)
		{
            rst.Edit();
            rst.m_F_CurMaxID = ID + 1;
            rst.Update();
        }
    }
	else
	{
        rst.AddNew();
        rst.m_F_TableName = sTableName;
        rst.m_F_CurMaxID = ID + 1;
        rst.Update();
    }
    rst.Close();
	return ID;
}

HBRUSH CAboutDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}
