// OLEDBReportMFCView.h : interface of the COLEDBReportMFCView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBREPORTMFCVIEW_H__52C04160_4E05_11D2_9949_F7F727FAE648__INCLUDED_)
#define AFX_OLEDBREPORTMFCVIEW_H__52C04160_4E05_11D2_9949_F7F727FAE648__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "StudentsPerClass.h"

class COLEDBReportMFCView : public CScrollView
{
protected: // create from serialization only
	COLEDBReportMFCView();
	void OutputReport(CDC* pDC, CPrintInfo* pInfo = NULL);
	DECLARE_DYNCREATE(COLEDBReportMFCView)
// Attributes
public:
	COLEDBReportMFCDoc* GetDocument();
	CStudentsPerClass* m_pSet;

// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBReportMFCView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLEDBReportMFCView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COLEDBReportMFCView)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in OLEDBReportMFCView.cpp
inline COLEDBReportMFCDoc* COLEDBReportMFCView::GetDocument()
   { return (COLEDBReportMFCDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBREPORTMFCVIEW_H__52C04160_4E05_11D2_9949_F7F727FAE648__INCLUDED_)
