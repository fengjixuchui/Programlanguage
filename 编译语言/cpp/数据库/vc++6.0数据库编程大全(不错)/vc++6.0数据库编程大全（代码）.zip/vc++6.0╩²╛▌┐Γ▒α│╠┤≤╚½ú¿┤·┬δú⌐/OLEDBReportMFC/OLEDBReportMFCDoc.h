// OLEDBReportMFCDoc.h : interface of the COLEDBReportMFCDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBREPORTMFCDOC_H__52C0415E_4E05_11D2_9949_F7F727FAE648__INCLUDED_)
#define AFX_OLEDBREPORTMFCDOC_H__52C0415E_4E05_11D2_9949_F7F727FAE648__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "StudentsPerClass.h"

class COLEDBReportMFCDoc : public CDocument
{
protected: // create from serialization only
	COLEDBReportMFCDoc();
	DECLARE_DYNCREATE(COLEDBReportMFCDoc)

// Attributes
public:
	CStudentsPerClass m_StudentsPerClass;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBReportMFCDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLEDBReportMFCDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COLEDBReportMFCDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBREPORTMFCDOC_H__52C0415E_4E05_11D2_9949_F7F727FAE648__INCLUDED_)
