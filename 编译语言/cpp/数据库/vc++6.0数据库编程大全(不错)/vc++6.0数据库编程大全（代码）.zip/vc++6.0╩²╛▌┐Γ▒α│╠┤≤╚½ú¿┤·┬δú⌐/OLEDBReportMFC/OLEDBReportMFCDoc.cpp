// OLEDBReportMFCDoc.cpp : implementation of the COLEDBReportMFCDoc class
//

#include "stdafx.h"
#include "OLEDBReportMFC.h"

#include "OLEDBReportMFCDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBReportMFCDoc

IMPLEMENT_DYNCREATE(COLEDBReportMFCDoc, CDocument)

BEGIN_MESSAGE_MAP(COLEDBReportMFCDoc, CDocument)
	//{{AFX_MSG_MAP(COLEDBReportMFCDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBReportMFCDoc construction/destruction

COLEDBReportMFCDoc::COLEDBReportMFCDoc()
{
}

COLEDBReportMFCDoc::~COLEDBReportMFCDoc()
{
}

BOOL COLEDBReportMFCDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// COLEDBReportMFCDoc serialization

void COLEDBReportMFCDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// COLEDBReportMFCDoc diagnostics

#ifdef _DEBUG
void COLEDBReportMFCDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void COLEDBReportMFCDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBReportMFCDoc commands
