//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ODBCDepartment.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_ODBCDEPARTMENT_FORM         101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_MAINFRAME                   128
#define IDR_ODBCDETYPE                  129
#define IDC_DEPARTMENTCODE              1000
#define IDC_DEPARTMENTNAME              1001
#define IDC_FINDCODE                    1002
#define IDC_INSTRUCTORNAME              1003
#define IDC_EMAIL                       1004
#define IDC_NOTES                       1005
#define ID_RECORD_DELETERECORD          32772
#define ID_RECORD_QUERYRECORD           32773
#define ID_INSTRUCTOR_FIRSTRECORD       32775
#define ID_INSTRUCTOR_PREVIOUSRECORD    32776
#define ID_INSTRUCTOR_NEXTRECORD        32777
#define ID_INSTRUCTOR_LASTRECORD        32778
#define ID_INSTRUCTOR_ADDINSTRUCTOR     32779
#define ID_INSTRUCTOR_DELETEINSTRUCTOR  32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
