#if !defined(AFX_ODBCINSTRUCTORSET_H__A77F75E1_3B4B_11D2_9949_C17674C3AE46__INCLUDED_)
#define AFX_ODBCINSTRUCTORSET_H__A77F75E1_3B4B_11D2_9949_C17674C3AE46__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ODBCInstructorSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CODBCInstructorSet recordset

class CODBCInstructorSet : public CRecordset
{
public:
	CODBCInstructorSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CODBCInstructorSet)

// Field/Param Data
	//{{AFX_FIELD(CODBCInstructorSet, CRecordset)
	long	m_InstructorID;
	CString	m_Name;
	CString	m_DepartmentCode;
	CString	m_EMAIL;
	CString	m_Notes;
	//}}AFX_FIELD
	//Parameters
	CString *m_pDepartmentCode;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CODBCInstructorSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ODBCINSTRUCTORSET_H__A77F75E1_3B4B_11D2_9949_C17674C3AE46__INCLUDED_)
