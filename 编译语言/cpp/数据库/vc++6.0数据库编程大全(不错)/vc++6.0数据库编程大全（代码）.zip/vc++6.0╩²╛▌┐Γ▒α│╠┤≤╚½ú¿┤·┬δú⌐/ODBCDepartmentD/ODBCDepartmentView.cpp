// ODBCDepartmentView.cpp : implementation of the CODBCDepartmentView class
//

#include "stdafx.h"
#include "ODBCDepartment.h"

#include "ODBCDepartmentSet.h"
#include "ODBCDepartmentDoc.h"
#include "ODBCDepartmentView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView

IMPLEMENT_DYNCREATE(CODBCDepartmentView, CRecordView)

BEGIN_MESSAGE_MAP(CODBCDepartmentView, CRecordView)
	//{{AFX_MSG_MAP(CODBCDepartmentView)
	ON_COMMAND(ID_RECORD_DELETERECORD, OnRecordDeleterecord)
	ON_UPDATE_COMMAND_UI(ID_RECORD_DELETERECORD, OnUpdateRecordDeleterecord)
	ON_COMMAND(ID_RECORD_QUERYRECORD, OnRecordQueryrecord)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_WM_DESTROY()
	ON_EN_CHANGE(IDC_DEPARTMENTCODE, OnChangeDepartmentcode)
	ON_EN_CHANGE(IDC_DEPARTMENTNAME, OnChangeDepartmentname)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
	ON_EN_CHANGE(IDC_EMAIL, OnChangeEmail)
	ON_EN_CHANGE(IDC_INSTRUCTORNAME, OnChangeInstructorname)
	ON_EN_CHANGE(IDC_NOTES, OnChangeNotes)
	ON_COMMAND(ID_INSTRUCTOR_ADDINSTRUCTOR, OnInstructorAddinstructor)
	ON_COMMAND(ID_INSTRUCTOR_DELETEINSTRUCTOR, OnInstructorDeleteinstructor)
	ON_COMMAND(ID_INSTRUCTOR_FIRSTRECORD, OnInstructorFirstrecord)
	ON_COMMAND(ID_INSTRUCTOR_LASTRECORD, OnInstructorLastrecord)
	ON_COMMAND(ID_INSTRUCTOR_NEXTRECORD, OnInstructorNextrecord)
	ON_COMMAND(ID_INSTRUCTOR_PREVIOUSRECORD, OnInstructorPreviousrecord)
	ON_UPDATE_COMMAND_UI(ID_INSTRUCTOR_DELETEINSTRUCTOR, OnUpdateInstructorDeleteinstructor)
	ON_UPDATE_COMMAND_UI(ID_INSTRUCTOR_FIRSTRECORD, OnUpdateInstructorFirstrecord)
	ON_UPDATE_COMMAND_UI(ID_INSTRUCTOR_LASTRECORD, OnUpdateInstructorLastrecord)
	ON_UPDATE_COMMAND_UI(ID_INSTRUCTOR_NEXTRECORD, OnUpdateInstructorNextrecord)
	ON_UPDATE_COMMAND_UI(ID_INSTRUCTOR_PREVIOUSRECORD, OnUpdateInstructorPreviousrecord)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView construction/destruction

CODBCDepartmentView::CODBCDepartmentView()
	: CRecordView(CODBCDepartmentView::IDD)
{
	//{{AFX_DATA_INIT(CODBCDepartmentView)
	m_pSet = NULL;
	m_FindDeptCode = _T("");
	//}}AFX_DATA_INIT
	m_bAddingRecord = FALSE;
	//Next two lines added by Chuck Wood for
	//instructor table support
	m_pInstructorSet = NULL;
	m_bAddingInstructor = FALSE;
	m_bFieldsChanged = FALSE;
}

CODBCDepartmentView::~CODBCDepartmentView()
{
}

void CODBCDepartmentView::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CODBCDepartmentView)
	DDX_Text(pDX, IDC_FINDCODE, m_FindDeptCode);
	DDV_MaxChars(pDX, m_FindDeptCode, 4);
	DDX_FieldText(pDX, IDC_DEPARTMENTCODE, m_pSet->m_DepartmentCode, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentCode, 4);
	DDX_FieldText(pDX, IDC_DEPARTMENTNAME, m_pSet->m_DepartmentName, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentName, 50);
	//}}AFX_DATA_MAP
	//The rest of the lines in this function are added 
	//by Chuck Wood for instructor table support
	DDX_Text(pDX, IDC_EMAIL, m_pInstructorSet->m_EMAIL);
	DDV_MaxChars(pDX, m_pInstructorSet->m_EMAIL, 50);
	DDX_Text(pDX, IDC_INSTRUCTORNAME, m_pInstructorSet->m_Name);
	DDV_MaxChars(pDX, m_pInstructorSet->m_Name, 50);
	DDX_Text(pDX, IDC_NOTES, m_pInstructorSet->m_Notes);
}

BOOL CODBCDepartmentView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CRecordView::PreCreateWindow(cs);
}

void CODBCDepartmentView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_oDBCDepartmentSet;
	m_pInstructorSet = new CODBCInstructorSet(m_pSet->m_pDatabase);
	m_pInstructorSet->m_pDepartmentCode = 
		&GetDocument()->m_oDBCDepartmentSet.m_DepartmentCode;
 	CRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
	m_pSet->Close();	//Close to start transaction
	if (m_pSet->m_pDatabase->CanTransact()) {
		m_pSet->m_pDatabase->BeginTrans();
	}
	m_pSet->Open();	//Open after starting transaction
	m_pSet->MoveFirst();
	OpenInstructorRecordset();	// Display related instructors
	UpdateData(FALSE);	//Update dialog box fields
}

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView diagnostics

#ifdef _DEBUG
void CODBCDepartmentView::AssertValid() const
{
	CRecordView::AssertValid();
}

void CODBCDepartmentView::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CODBCDepartmentDoc* CODBCDepartmentView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CODBCDepartmentDoc)));
	return (CODBCDepartmentDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView database support
CRecordset* CODBCDepartmentView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView message handlers

BOOL CODBCDepartmentView::OnMove(UINT nIDMoveCommand) 
{
	if (m_bAddingRecord) {	//Currently adding?
		//If so, Update the record before the move
		UpdateData(TRUE);	//Get data from dialog box
		m_pSet->Update();	//Update data if needed
		m_pSet->MoveLast();	//Go to the added record
		m_bAddingRecord = FALSE;	//Reset flag
	}
	UpdateInstructor();
	BOOL returnCode = CRecordView::OnMove(nIDMoveCommand);
	m_pInstructorSet->Requery();
	CRecordsetStatus rStatus;		//Status variable
	m_pInstructorSet->GetStatus(rStatus); //Get CRecordset status
	if (rStatus.m_lCurrentRecord < 0) {	//no records Exist?
		//No isntructor records, so add one.
		AddInstructor();
	}
	UpdateData(FALSE);	//Update dialog box fields
	return returnCode;
}

void CODBCDepartmentView::OnRecordDeleterecord() 
{
	if (AfxMessageBox(	//Be sure to verify your deletes
			"Are you sure you want to delete this department?",
			MB_YESNO)
		!= IDYES) {
		return;
	}
	if (m_bAddingRecord) {	//Currently adding?
		//Don't delete, just cancel add.
		m_pSet->CancelUpdate();
		m_bAddingRecord = FALSE;
		OnMove(ID_RECORD_PREV);
		return;
	}
	try {
		m_pSet->Delete();	//Delete record
	}
	catch(CDBException* e1) {	//Failed
		AfxMessageBox("Delete Failed:\n" +
			e1->m_strError,
			MB_ICONEXCLAMATION);
		OnMove(ID_RECORD_FIRST);	//We lost our place.
		e1->Delete();		//Delete Error Message
		UpdateData(FALSE);	//Update dialog box fields
		return;
	}
	try {
		OnMove(ID_RECORD_NEXT);			//Go to next record
		if (m_pSet->IsDeleted()) {	//Was there a next record?
			OnMove(ID_RECORD_FIRST);	//Deleted last record
		}
		if (m_pSet->IsDeleted()) {	//Can't find a record
			AfxThrowDBException(SQL_ERROR, 
				m_pSet->m_pDatabase,
				m_pSet->m_hstmt);   
		}
		UpdateData(FALSE);	//Update dialog box fields
	}
	catch(CDBException* e2) {	//No records exist
		AfxMessageBox("No more records",
			MB_ICONEXCLAMATION);
		e2->Delete();		//Delete Error Message
		//Close and Open to get rid of the Deleted record
		m_pSet->Close();
		m_pSet->Open();
		//No records, so set up an add record
		OnFileNew();
	}
}

void CODBCDepartmentView::OnUpdateRecordDeleterecord(CCmdUI* pCmdUI) 
{
	//Disable delete functionality if no record is found
	pCmdUI->Enable(		//Enable delete if there's a record
		!m_pSet->IsBOF() &&
		!m_pSet->IsDeleted() &&
		!m_pSet->IsEOF());
}

void CODBCDepartmentView::OnRecordQueryrecord() 
{
	CString newFilter = "";	//Default is no filter
	UpdateData(TRUE);	//Get data from dialog box
	if (!m_bAddingRecord) {	//Currently adding?
		//Set to update
		m_pSet->Edit();		
	}
	m_pSet->Update();	//Update data if needed
	m_bAddingRecord = FALSE;	//Reset flag
	if (m_FindDeptCode != "") {
		//Setup new filter
		newFilter = "DepartmentCode = '" + m_FindDeptCode + "'";
	}
	if (newFilter != m_pSet->m_strFilter) {	//Filter has changed
		m_pSet->m_strFilter = newFilter;	//Assign new filter
		if (!m_pSet->Requery()) {			//Requery
			AfxMessageBox("Requery has failed");	//Error occurred
			m_pSet->m_strFilter = "";		//Try to get back
			m_pSet->Requery();				//Requery again
		}
		try {
			//Go to the first record of the new filtered recordset
			OnMove(ID_RECORD_FIRST);
		}
		catch(CDBException* e)    {
			//Move failed because there are no records
			AfxMessageBox("No records were found", MB_ICONEXCLAMATION );
			e->Delete();		//Delete Error Message
			//No records, so set up an add record
			OnFileNew();
		}
	}
	UpdateData(FALSE);	//Update dialog box fields
}

void CODBCDepartmentView::OnFileNew() 
{
	CRecordsetStatus rStatus;		//Status variable
	m_pSet->GetStatus(rStatus);		//Get CRecordset status
	if (rStatus.m_lCurrentRecord >= 0) {	//Records Exist?
		UpdateData(TRUE);	//Get data from dialog box
		if (!m_bAddingRecord) {	//Currently adding?
			//If not, set CRecordset in edit mode for updating
			m_pSet->Edit();		
		}
		m_pSet->Update();	//Update data if needed
		OnMove(ID_RECORD_LAST);	//Get off record 1
	}
	m_bAddingRecord = TRUE;	//Set flag
	m_pSet->SetFieldNull(NULL);	//Clear all fields
	m_pSet->AddNew();	//Set database in AddNew mode
	UpdateData(FALSE);	//Update dialog box fields
	//No isntructor records, so add one.
	AddInstructor();
}

void CODBCDepartmentView::OnFileSave() 
{
	if (m_bFieldsChanged && m_pSet->CanTransact()) {
		if (!m_bAddingRecord) {	//Currently adding?
			m_pSet->Edit();	//If not, set edit mode
		}
		UpdateInstructor();	//Update Instructor too
		UpdateData(TRUE);	//Get data from dialog box
		m_pSet->Update();	//Update data if needed
		m_bAddingRecord = FALSE;	//Reset flag
		m_pSet->m_pDatabase->CommitTrans();	//Commit changes
		CRecordsetStatus rStatus;		//Status variable
		m_pSet->GetStatus(rStatus);		//Get CRecordset status
		m_pSet->Close();	//Close to start transaction
		CRecordsetStatus rStatus2;		//Status variable
		m_pInstructorSet->GetStatus(rStatus2);	//Get CRecordset status
		m_pInstructorSet->Close();	//Close second transaction
		m_pSet->m_pDatabase->BeginTrans();	//Start Transaction
		m_pSet->Open();				//Reopen CRecordset
		//Restore record position
		if (rStatus.m_lCurrentRecord >= 0) {
			m_pSet->SetAbsolutePosition(rStatus.m_lCurrentRecord+1);
		}
		m_bFieldsChanged = FALSE;	//Reset flag
		OpenInstructorRecordset(
			rStatus2.m_lCurrentRecord);	//Reopen second instructor
		UpdateData(FALSE);	//Update dialog box fields
	}
}

void CODBCDepartmentView::OnDestroy() 
{
//Check for changed fields and transaction ability
	if (m_pSet->CanTransact()) {
		if (m_bFieldsChanged) {
			if (AfxMessageBox (
				"Records have been changed.  Do you want to save?", 
				MB_YESNO) == IDNO) {
				m_pSet->m_pDatabase->Rollback();
			}
			else {
				if (!m_bAddingRecord) {	//Currently adding?
				//If not, set edit mode
					m_pSet->Edit();
				}
				UpdateInstructor();
				UpdateData(TRUE);	//Get data from dialog box
				m_pSet->Update();	//Update data if needed
				m_pSet->m_pDatabase->CommitTrans();
			}
		}
		else {
			m_pSet->m_pDatabase->CommitTrans();
		}
	}
	if (m_pInstructorSet != NULL) {
		m_pInstructorSet->Close();
		delete m_pInstructorSet;
	}
	CRecordView::OnDestroy();
}

void CODBCDepartmentView::OnChangeDepartmentcode() 
{
	m_bFieldsChanged = TRUE;
}

void CODBCDepartmentView::OnChangeDepartmentname() 
{
	m_bFieldsChanged = TRUE;
}

void CODBCDepartmentView::OnUpdateFileSave(CCmdUI* pCmdUI) 
{ //Enable save functionality if a record has changed
	pCmdUI->Enable(m_bFieldsChanged);
}

/////////////////////////////////////////////////////////////////////////////
// CODBCInstructorSet functions

void CODBCDepartmentView::AddInstructor() 
{
	m_bAddingInstructor = TRUE;	//Set flag
	m_pInstructorSet->SetFieldNull(NULL);	//Clear all fields
	m_pInstructorSet->AddNew();	//Set database in AddNew mode
	UpdateData(FALSE);	//Update dialog box fields
}

void CODBCDepartmentView::OpenInstructorRecordset(long nRows)
{
	m_pInstructorSet->Open();
	m_pInstructorSet->Requery();
	CRecordsetStatus rStatus;		//Status variable
	m_pInstructorSet->GetStatus(rStatus); //Get CRecordset status
	if (rStatus.m_lCurrentRecord < 0) {	//no records Exist?
		//No isntructor records, so add one.
		AddInstructor();
	}
	else {
		this->m_pInstructorSet->SetAbsolutePosition(nRows+1);
	}
}

void CODBCDepartmentView::UpdateInstructor()
{
	if (!m_bAddingInstructor) {
		if (m_pInstructorSet->IsBOF() ||
			m_pInstructorSet->IsEOF() ||
			m_pInstructorSet->IsDeleted()) {
			return;
		}
		m_pInstructorSet->Edit();
	}
	m_bAddingInstructor = FALSE;
	UpdateData(TRUE);	//Get data from dialog box
	m_pInstructorSet->m_DepartmentCode 
		= *m_pInstructorSet->m_pDepartmentCode;
	m_pInstructorSet->Update();
}

void CODBCDepartmentView::OnChangeEmail() 
{
	m_bFieldsChanged = TRUE;
}

void CODBCDepartmentView::OnChangeInstructorname() 
{
	m_bFieldsChanged = TRUE;
}

void CODBCDepartmentView::OnChangeNotes() 
{
	m_bFieldsChanged = TRUE;
}

void CODBCDepartmentView::OnInstructorAddinstructor() 
{
	UpdateInstructor();
	AddInstructor();
}

void CODBCDepartmentView::OnInstructorDeleteinstructor() 
{
	if (AfxMessageBox(	//Be sure to verify your deletes
			"Are you sure you want to delete this instructor?",
			MB_YESNO)
		!= IDYES) {
		return;
	}
	if (m_bAddingInstructor) {	//Currently adding?
		//Don't delete, just cancel add.
		m_pInstructorSet->CancelUpdate();
		m_bAddingInstructor = FALSE;
		OnInstructorPreviousrecord();
		return;
	}
	try {
		m_pInstructorSet->Delete();	//Delete record
	}
	catch(CDBException* e1) {	//Failed
		AfxMessageBox("Delete Failed:\n" +
			e1->m_strError,
			MB_ICONEXCLAMATION);
		e1->Delete();		//Delete Error Message
		OnInstructorFirstrecord();	//Recapture place
		return;
	}
	try {
		OnInstructorNextrecord();	//Go to the next record
		if (m_pSet->IsDeleted()) {	//Was there a next record?
			OnInstructorFirstrecord();	//Deleted last record
		}
		if (m_pSet->IsDeleted()) {	//Can't find a record
			AfxThrowDBException(SQL_ERROR, 
				m_pInstructorSet->m_pDatabase,
				m_pInstructorSet->m_hstmt);   
		}
		UpdateData(FALSE);	//Update dialog box fields
	}
	catch(CDBException* e2) {	//No records exist
		AfxMessageBox("No more Instructors for this department",
			MB_ICONEXCLAMATION);
		e2->Delete();		//Delete Error Message
		//Close and Open to get rid of the Deleted record
		m_pInstructorSet->Close();
		m_pInstructorSet->Open();
		//No records, so set up an add record
		OnInstructorAddinstructor();
	}
}

void CODBCDepartmentView::OnInstructorFirstrecord() 
{
	UpdateInstructor();
	m_pInstructorSet->MoveFirst();
	UpdateData(FALSE);	//Update dialog from database
}

void CODBCDepartmentView::OnInstructorLastrecord() 
{
	UpdateInstructor();
	m_pInstructorSet->MoveLast();
	UpdateData(FALSE);	//Update dialog from database
}

void CODBCDepartmentView::OnInstructorNextrecord() 
{
	UpdateInstructor();
	m_pInstructorSet->MoveNext();
	if (m_pInstructorSet->IsEOF()) {
		m_pInstructorSet->MoveLast();
	}
	UpdateData(FALSE);	//Update dialog from database
}

void CODBCDepartmentView::OnInstructorPreviousrecord() 
{
	UpdateInstructor();
	m_pInstructorSet->MovePrev();
	if (m_pInstructorSet->IsBOF()) {
		m_pInstructorSet->MoveFirst();
	}
	UpdateData(FALSE);	//Update dialog from database
}

void CODBCDepartmentView::OnUpdateInstructorDeleteinstructor(CCmdUI* pCmdUI) 
{
	//Disable delete functionality if no record is found
	pCmdUI->Enable(		//Enable delete if there's a record
		!m_pInstructorSet->IsBOF() &&
		!m_pInstructorSet->IsDeleted() &&
		!m_pInstructorSet->IsEOF());
}

void CODBCDepartmentView::OnUpdateInstructorFirstrecord(CCmdUI* pCmdUI) 
{
	CRecordsetStatus rStatus;		//Status variable
	m_pInstructorSet->GetStatus(rStatus);		//Get CRecordset status
	pCmdUI->Enable(		//Disable at first record
		rStatus.m_lCurrentRecord > 0);
}

void CODBCDepartmentView::OnUpdateInstructorLastrecord(CCmdUI* pCmdUI) 
{
	CRecordsetStatus rStatus;		//Status variable
	m_pInstructorSet->GetStatus(rStatus);		//Get CRecordset status
	if (rStatus.m_bRecordCountFinal) {
		long recs = m_pInstructorSet->GetRecordCount() - 1;
		pCmdUI->Enable(		//Disable at last record
			rStatus.m_lCurrentRecord < recs);
	}
	else {	//Can't tell if we're at the end
		pCmdUI->Enable(TRUE);
	}
}

void CODBCDepartmentView::OnUpdateInstructorNextrecord(CCmdUI* pCmdUI) 
{
	CRecordsetStatus rStatus;		//Status variable
	m_pInstructorSet->GetStatus(rStatus);		//Get CRecordset status
	if (rStatus.m_bRecordCountFinal) {
		long recs = m_pInstructorSet->GetRecordCount() - 1;
		pCmdUI->Enable(		//Disable at last record
			rStatus.m_lCurrentRecord < recs);
	}
	else {	//Can't tell if we're at the end
		pCmdUI->Enable(TRUE);
	}
}

void CODBCDepartmentView::OnUpdateInstructorPreviousrecord(CCmdUI* pCmdUI) 
{
	CRecordsetStatus rStatus;		//Status variable
	m_pInstructorSet->GetStatus(rStatus);		//Get CRecordset status
	pCmdUI->Enable(		//Disable at first record
		rStatus.m_lCurrentRecord > 0);
}
