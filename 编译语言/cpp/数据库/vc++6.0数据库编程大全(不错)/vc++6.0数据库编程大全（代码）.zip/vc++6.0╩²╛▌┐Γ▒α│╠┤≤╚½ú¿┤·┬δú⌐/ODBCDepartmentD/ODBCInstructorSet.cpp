// ODBCInstructorSet.cpp : implementation file
//

#include "stdafx.h"
#include "ODBCDepartment.h"
#include "ODBCInstructorSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CODBCInstructorSet

IMPLEMENT_DYNAMIC(CODBCInstructorSet, CRecordset)

CODBCInstructorSet::CODBCInstructorSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CODBCInstructorSet)
	m_InstructorID = 0;
	m_Name = _T("");
	m_DepartmentCode = _T("");
	m_EMAIL = _T("");
	m_Notes = _T("");
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nParams = 1;
	m_nDefaultType = dynaset;
}


CString CODBCInstructorSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=Classes");
}

CString CODBCInstructorSet::GetDefaultSQL()
{
	return _T("[Instructor]");
}

void CODBCInstructorSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CODBCInstructorSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[InstructorID]"), m_InstructorID);
	RFX_Text(pFX, _T("[Name]"), m_Name);
	RFX_Text(pFX, _T("[DepartmentCode]"), m_DepartmentCode);
	RFX_Text(pFX, _T("[EMAIL]"), m_EMAIL);
	RFX_Text(pFX, _T("[Notes]"), m_Notes);
	//}}AFX_FIELD_MAP
	m_strFilter = "DepartmentCode = ?";		//Assign a filter
	//Indicate that you're binding parameters
	pFX->SetFieldType(CFieldExchange::param);
	//Now bind the paramter to the m_pDepartmentCode pointer
	//Filter names (i.e. "Parm1") are not important
	RFX_Text(pFX, _T("Parm1"), *m_pDepartmentCode);
}

/////////////////////////////////////////////////////////////////////////////
// CODBCInstructorSet diagnostics

#ifdef _DEBUG
void CODBCInstructorSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CODBCInstructorSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
