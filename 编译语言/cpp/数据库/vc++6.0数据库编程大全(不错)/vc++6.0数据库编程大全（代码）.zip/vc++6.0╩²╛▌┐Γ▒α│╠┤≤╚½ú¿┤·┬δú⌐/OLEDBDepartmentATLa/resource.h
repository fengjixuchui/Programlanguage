//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OLEDBDepartmentATL.rc
//
#define IDS_PROJNAME                    100
#define IDR_OLEDBDepartmentATL          100
#define IDD_DBDIALOG                    101
#define IDC_SAVE                        201
#define IDC_ADD                         202
#define IDC_DELETE                      203
#define IDC_FIRST                       204
#define IDC_PREV                        205
#define IDC_NEXT                        206
#define IDC_LAST                        207
#define IDC_FINDEPARTMENT               208
#define IDC_STATUS                      209
#define IDC_DEPARTMENTCODE              1000
#define IDC_DEPARTMENTNAME              1001
#define IDC_FINDDEPARTMENTEDIT          1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         210
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
