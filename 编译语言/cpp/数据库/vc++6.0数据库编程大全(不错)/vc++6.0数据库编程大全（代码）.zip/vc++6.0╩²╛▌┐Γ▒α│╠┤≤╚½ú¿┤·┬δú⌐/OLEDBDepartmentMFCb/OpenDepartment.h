#if !defined(AFX_OPENDEPARTMENT_H__493EF864_4BF5_11D2_9949_D84454558644__INCLUDED_)
#define AFX_OPENDEPARTMENT_H__493EF864_4BF5_11D2_9949_D84454558644__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OpenDepartment.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COpenDepartment dialog

class COpenDepartment : public CDialog
{
// Construction
public:
	COpenDepartment(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(COpenDepartment)
	enum { IDD = IDD_FINDDEPARTMENT };
	CString	m_strDepartment;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COpenDepartment)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COpenDepartment)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPENDEPARTMENT_H__493EF864_4BF5_11D2_9949_D84454558644__INCLUDED_)
