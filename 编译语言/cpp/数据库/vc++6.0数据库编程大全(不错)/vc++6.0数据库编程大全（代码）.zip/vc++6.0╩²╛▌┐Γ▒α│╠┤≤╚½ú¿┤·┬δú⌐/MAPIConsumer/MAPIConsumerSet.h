// MAPIConsumerSet.h : interface of the CMAPIConsumerSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAPICONSUMERSET_H__1A082C39_C8D8_11D2_9949_D68A87749F4B__INCLUDED_)
#define AFX_MAPICONSUMERSET_H__1A082C39_C8D8_11D2_9949_D68A87749F4B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMy
{
public:
	CMy()
	{
		memset( (void*)this, 0, sizeof(*this) );
	};

	char m_strAuthor[50];
	char m_strSubject[256];
	char m_strDate[20];
	char m_strMessage[1024];

BEGIN_COLUMN_MAP(CMy)
		COLUMN_ENTRY_TYPE(1, DBTYPE_STR, m_strAuthor)
		COLUMN_ENTRY_TYPE(2, DBTYPE_STR, m_strSubject)
		COLUMN_ENTRY_TYPE(3, DBTYPE_STR, m_strDate)
		COLUMN_ENTRY_TYPE(4, DBTYPE_STR, m_strMessage)
END_COLUMN_MAP()

};

class CMAPIConsumerSet : public CCommand<CAccessor<CMy> >
{
public:

	HRESULT Open()
	{
		CDataSource db;
		CSession	session;
		HRESULT		hr;

		CDBPropSet	dbinit(DBPROPSET_DBINIT);
		dbinit.AddProperty(DBPROP_AUTH_PASSWORD, "");
		dbinit.AddProperty(DBPROP_AUTH_PERSIST_SENSITIVE_AUTHINFO, false);
		dbinit.AddProperty(DBPROP_AUTH_USERID, "");
		dbinit.AddProperty(DBPROP_INIT_DATASOURCE, "");
		dbinit.AddProperty(DBPROP_INIT_LCID, (long)0);
		dbinit.AddProperty(DBPROP_INIT_LOCATION, "");
		dbinit.AddProperty(DBPROP_INIT_MODE, (long)0);
		dbinit.AddProperty(DBPROP_INIT_PROMPT, (short)2);
		dbinit.AddProperty(DBPROP_INIT_PROVIDERSTRING, "");
		dbinit.AddProperty(DBPROP_INIT_TIMEOUT, (long)0);

		hr = db.OpenWithServiceComponents("OLEDBMail.MAPIProvider.1", &dbinit);
		if (FAILED(hr))
			return hr;

		hr = session.Open(db);
		if (FAILED(hr))
			return hr;

		CDBPropSet	propset(DBPROPSET_ROWSET);
		propset.AddProperty(DBPROP_CANFETCHBACKWARDS, true);
		propset.AddProperty(DBPROP_IRowsetScroll, true);
		propset.AddProperty(DBPROP_IRowsetChange, true);
		propset.AddProperty(DBPROP_UPDATABILITY, DBPROPVAL_UP_CHANGE | DBPROPVAL_UP_INSERT | DBPROPVAL_UP_DELETE );
//Don't forget at least one character or space in the command
		hr = CCommand<CAccessor<CMy> >::Open(session, " ", &propset);
		if (FAILED(hr))
			return hr;

		return MoveNext();
	}

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAPICONSUMERSET_H__1A082C39_C8D8_11D2_9949_D68A87749F4B__INCLUDED_)

