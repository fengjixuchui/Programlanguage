// MAPIConsumerDoc.cpp : implementation of the CMAPIConsumerDoc class
//

#include "stdafx.h"
#include "MAPIConsumer.h"

#include "MAPIConsumerSet.h"
#include "MAPIConsumerDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMAPIConsumerDoc

IMPLEMENT_DYNCREATE(CMAPIConsumerDoc, CDocument)

BEGIN_MESSAGE_MAP(CMAPIConsumerDoc, CDocument)
	//{{AFX_MSG_MAP(CMAPIConsumerDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMAPIConsumerDoc construction/destruction

CMAPIConsumerDoc::CMAPIConsumerDoc()
{
}

CMAPIConsumerDoc::~CMAPIConsumerDoc()
{
}

BOOL CMAPIConsumerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMAPIConsumerDoc diagnostics

#ifdef _DEBUG
void CMAPIConsumerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMAPIConsumerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMAPIConsumerDoc commands
