// MAPIConsumerDoc.h : interface of the CMAPIConsumerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAPICONSUMERDOC_H__1A082C35_C8D8_11D2_9949_D68A87749F4B__INCLUDED_)
#define AFX_MAPICONSUMERDOC_H__1A082C35_C8D8_11D2_9949_D68A87749F4B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "MAPIConsumerSet.h"


class CMAPIConsumerDoc : public CDocument
{
protected: // create from serialization only
	CMAPIConsumerDoc();
	DECLARE_DYNCREATE(CMAPIConsumerDoc)

// Attributes
public:
	CMAPIConsumerSet m_mAPIConsumerSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMAPIConsumerDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMAPIConsumerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMAPIConsumerDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAPICONSUMERDOC_H__1A082C35_C8D8_11D2_9949_D68A87749F4B__INCLUDED_)
