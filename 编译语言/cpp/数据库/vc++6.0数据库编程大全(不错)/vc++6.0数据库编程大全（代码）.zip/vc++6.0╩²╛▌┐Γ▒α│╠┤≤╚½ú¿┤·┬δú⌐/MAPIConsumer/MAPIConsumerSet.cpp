// MAPIConsumerSet.cpp : implementation of the CMAPIConsumerSet class
//

#include "stdafx.h"
#include "MAPIConsumer.h"
#include "MAPIConsumerSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMAPIConsumerSet implementation

