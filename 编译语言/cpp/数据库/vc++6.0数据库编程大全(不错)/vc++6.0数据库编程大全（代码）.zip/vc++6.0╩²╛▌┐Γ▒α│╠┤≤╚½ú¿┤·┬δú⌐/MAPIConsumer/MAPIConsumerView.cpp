// MAPIConsumerView.cpp : implementation of the CMAPIConsumerView class
//

#include "stdafx.h"
#include "MAPIConsumer.h"

#include "MAPIConsumerSet.h"
#include "MAPIConsumerDoc.h"
#include "MAPIConsumerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMAPIConsumerView

IMPLEMENT_DYNCREATE(CMAPIConsumerView, COleDBRecordView)

BEGIN_MESSAGE_MAP(CMAPIConsumerView, COleDBRecordView)
	//{{AFX_MSG_MAP(CMAPIConsumerView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMAPIConsumerView construction/destruction

CMAPIConsumerView::CMAPIConsumerView()
	: COleDBRecordView(CMAPIConsumerView::IDD)
{
	//{{AFX_DATA_INIT(CMAPIConsumerView)
		// NOTE: the ClassWizard will add member initialization here
	m_pSet = NULL;
	//}}AFX_DATA_INIT
}

CMAPIConsumerView::~CMAPIConsumerView()
{
}

void CMAPIConsumerView::DoDataExchange(CDataExchange* pDX)
{
	COleDBRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMAPIConsumerView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
	//Added by Chuck Wood for data exchange support
	DDX_Text(pDX, IDC_SENDER, m_pSet->m_strAuthor, 50);
	DDX_Text(pDX, IDC_SUBJECT, m_pSet->m_strSubject, 256);
	DDX_Text(pDX, IDC_DATE, m_pSet->m_strDate, 20);
	DDX_Text(pDX, IDC_MESSAGE, m_pSet->m_strMessage, 1024);
	DDV_MaxChars(pDX, m_pSet->m_strAuthor, 50);
	DDV_MaxChars(pDX, m_pSet->m_strSubject, 256);
	DDV_MaxChars(pDX, m_pSet->m_strDate, 20);
	DDV_MaxChars(pDX, m_pSet->m_strMessage, 1024);
}

BOOL CMAPIConsumerView::PreCreateWindow(CREATESTRUCT& cs)
{
	return COleDBRecordView::PreCreateWindow(cs);
}

void CMAPIConsumerView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_mAPIConsumerSet;
	{
		CWaitCursor wait;
		HRESULT hr = m_pSet->Open();
		if (hr != S_OK)
		{
			AfxMessageBox(_T("Record set failed to open."), MB_OK);
			m_bOnFirstRecord = TRUE;
			m_bOnLastRecord = TRUE;
		}				
	}
	COleDBRecordView::OnInitialUpdate();

}

/////////////////////////////////////////////////////////////////////////////
// CMAPIConsumerView diagnostics

#ifdef _DEBUG
void CMAPIConsumerView::AssertValid() const
{
	COleDBRecordView::AssertValid();
}

void CMAPIConsumerView::Dump(CDumpContext& dc) const
{
	COleDBRecordView::Dump(dc);
}

CMAPIConsumerDoc* CMAPIConsumerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMAPIConsumerDoc)));
	return (CMAPIConsumerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMAPIConsumerView database support
CRowset* CMAPIConsumerView::OnGetRowset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CMAPIConsumerView message handlers
