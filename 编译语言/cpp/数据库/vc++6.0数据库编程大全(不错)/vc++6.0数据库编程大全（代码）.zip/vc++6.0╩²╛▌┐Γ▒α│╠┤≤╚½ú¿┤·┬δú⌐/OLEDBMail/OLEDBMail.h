/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sat Feb 20 18:02:47 1999
 */
/* Compiler settings for C:\My Documents\Visual C++\OLEDBMail\OLEDBMail.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __OLEDBMail_h__
#define __OLEDBMail_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __MAPIProvider_FWD_DEFINED__
#define __MAPIProvider_FWD_DEFINED__

#ifdef __cplusplus
typedef class MAPIProvider MAPIProvider;
#else
typedef struct MAPIProvider MAPIProvider;
#endif /* __cplusplus */

#endif 	/* __MAPIProvider_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __OLEDBMAILLib_LIBRARY_DEFINED__
#define __OLEDBMAILLib_LIBRARY_DEFINED__

/* library OLEDBMAILLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_OLEDBMAILLib;

EXTERN_C const CLSID CLSID_MAPIProvider;

#ifdef __cplusplus

class DECLSPEC_UUID("1A082C27-C8D8-11D2-9949-D68A87749F4B")
MAPIProvider;
#endif
#endif /* __OLEDBMAILLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
