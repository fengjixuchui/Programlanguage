// MAPIProviderRS.h : Declaration of the CMAPIProviderRowset
#ifndef __CMAPIProviderRowset_H_
#define __CMAPIProviderRowset_H_
#include "resource.h"       // main symbols
//Added by Chuck Wood -- #include mapi.h for MAPI support
#include <mapi.h>
//Added by Chuck Wood -- Now for a bunch of early '90s C 
//stuff.  No object-oriented here!
typedef ULONG (FAR PASCAL *pMAPILOGON)(HWND, LPSTR, LPSTR, FLAGS, ULONG, LPLHANDLE);
typedef ULONG (FAR PASCAL *pMAPILOGOFF)(LHANDLE, HWND, FLAGS,ULONG);
typedef ULONG (FAR PASCAL *pMAPIFINDNEXT)(LHANDLE, HWND, LPSTR, LPSTR, FLAGS,
                                     ULONG, LPSTR);
typedef ULONG (FAR PASCAL *pMAPIREADMAIL)(LHANDLE, HWND, LPSTR, FLAGS, ULONG,
                                     lpMapiMessage FAR *);
#ifdef MAIN

pMAPILOGON pfnMAPILogon;
pMAPILOGOFF pfnMAPILogoff;
pMAPIFINDNEXT pfnMAPIFindNext;
pMAPIREADMAIL pfnMAPIReadMail;

#else

extern pMAPILOGON pfnMAPILogon;
extern pMAPILOGOFF pfnMAPILogoff;
extern pMAPIFINDNEXT pfnMAPIFindNext;
extern pMAPIREADMAIL pfnMAPIReadMail;

#endif
class CMAPILayout 
{
public:
	char m_strAuthor[50];
	char m_strSubject[256];
	char m_strDate[20];
	char m_strBody[1024];

BEGIN_PROVIDER_COLUMN_MAP(CMAPILayout)
	PROVIDER_COLUMN_ENTRY("Author", 1, m_strAuthor)
	PROVIDER_COLUMN_ENTRY("Subject", 2, m_strSubject)
	PROVIDER_COLUMN_ENTRY("Date", 3, m_strDate)
	PROVIDER_COLUMN_ENTRY("Body", 4, m_strBody)
END_PROVIDER_COLUMN_MAP()
};
// CMAPIProviderCommand
class ATL_NO_VTABLE CMAPIProviderCommand : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IAccessorImpl<CMAPIProviderCommand>,
	public ICommandTextImpl<CMAPIProviderCommand>,
	public ICommandPropertiesImpl<CMAPIProviderCommand>,
	public IObjectWithSiteImpl<CMAPIProviderCommand>,
	public IConvertTypeImpl<CMAPIProviderCommand>,
	public IColumnsInfoImpl<CMAPIProviderCommand>
{
public:
BEGIN_COM_MAP(CMAPIProviderCommand)
	COM_INTERFACE_ENTRY(ICommand)
	COM_INTERFACE_ENTRY(IObjectWithSite)
	COM_INTERFACE_ENTRY(IAccessor)
	COM_INTERFACE_ENTRY(ICommandProperties)
	COM_INTERFACE_ENTRY2(ICommandText, ICommand)
	COM_INTERFACE_ENTRY(IColumnsInfo)
	COM_INTERFACE_ENTRY(IConvertType)
END_COM_MAP()
// ICommand
public:
	HRESULT FinalConstruct()
	{
		HRESULT hr = CConvertHelper::FinalConstruct();
		if (FAILED (hr))
			return hr;
		hr = IAccessorImpl<CMAPIProviderCommand>::FinalConstruct();
		if (FAILED(hr))
			return hr;
		return CUtlProps<CMAPIProviderCommand>::FInit();
	}
	void FinalRelease()
	{
		IAccessorImpl<CMAPIProviderCommand>::FinalRelease();
	}
	HRESULT WINAPI Execute(IUnknown * pUnkOuter, REFIID riid, DBPARAMS * pParams, 
						  LONG * pcRowsAffected, IUnknown ** ppRowset);
	static ATLCOLUMNINFO* GetColumnInfo(CMAPIProviderCommand* pv, ULONG* pcInfo)
	{
		return CMAPILayout::GetColumnInfo(pv,pcInfo);
	}
BEGIN_PROPSET_MAP(CMAPIProviderCommand)
	BEGIN_PROPERTY_SET(DBPROPSET_ROWSET)
		PROPERTY_INFO_ENTRY(IAccessor)
		PROPERTY_INFO_ENTRY(IColumnsInfo)
		PROPERTY_INFO_ENTRY(IConvertType)
		PROPERTY_INFO_ENTRY(IRowset)
		PROPERTY_INFO_ENTRY(IRowsetIdentity)
		PROPERTY_INFO_ENTRY(IRowsetInfo)
		PROPERTY_INFO_ENTRY(IRowsetLocate)
		PROPERTY_INFO_ENTRY(BOOKMARKS)
		PROPERTY_INFO_ENTRY(BOOKMARKSKIPPED)
		PROPERTY_INFO_ENTRY(BOOKMARKTYPE)
		PROPERTY_INFO_ENTRY(CANFETCHBACKWARDS)
		PROPERTY_INFO_ENTRY(CANHOLDROWS)
		PROPERTY_INFO_ENTRY(CANSCROLLBACKWARDS)
		PROPERTY_INFO_ENTRY(LITERALBOOKMARKS)
		PROPERTY_INFO_ENTRY(ORDEREDBOOKMARKS)
	END_PROPERTY_SET(DBPROPSET_ROWSET)
END_PROPSET_MAP()
};
class CMAPIProviderRowset : public CRowsetImpl< CMAPIProviderRowset, CMAPILayout, CMAPIProviderCommand>
{
public:
	HRESULT Execute(DBPARAMS * pParams, LONG* pcRowsAffected)
	{
		USES_CONVERSION;
		LHANDLE hMAPISession;
		CMAPILayout ml;
		lpMapiMessage lppMessage;
		HMODULE hLibrary = LoadLibrary("MAPI32.DLL");
		if (hLibrary < (HANDLE)32)
			return DB_E_INVALID;
//Now to allocate the functions witht the 
//right function address ********************************
		pfnMAPILogon = (pMAPILOGON)GetProcAddress(hLibrary,"MAPILogon");
		if (!pfnMAPILogon) 
			return DB_E_INVALID;
		pfnMAPILogoff = (pMAPILOGOFF)GetProcAddress(hLibrary,"MAPILogoff");
		if (!pfnMAPILogoff)
			return DB_E_INVALID;
		pfnMAPIFindNext= (pMAPIFINDNEXT)GetProcAddress(hLibrary,"MAPIFindNext");
		if (!pfnMAPIFindNext)
			return DB_E_INVALID;
		pfnMAPIReadMail= (pMAPIREADMAIL)GetProcAddress(hLibrary,"MAPIReadMail");
		if (!pfnMAPIReadMail)
			return DB_E_INVALID;
//********************************************
		if ((		(*pfnMAPILogon)(0, NULL, NULL, 
					MAPI_NEW_SESSION | MAPI_LOGON_UI, 0L, 
					&hMAPISession))
				!= SUCCESS_SUCCESS)
			return DB_E_INVALID;
		char lpszMessageID[512];
		strcpy (lpszMessageID, "");
		//Null terminate my strings for later
		ml.m_strAuthor[49] = 0;
		ml.m_strSubject[255] = 0;
		ml.m_strDate[19] = 0;
		ml.m_strBody[1023] = 0;
		while ((*pfnMAPIFindNext)(	hMAPISession, 0, NULL, 
								lpszMessageID,
								MAPI_LONG_MSGID, 0,
								lpszMessageID)
				== SUCCESS_SUCCESS) {
			(*pfnMAPIReadMail)(	hMAPISession, 0, 
								lpszMessageID,
								MAPI_PEEK, 0,
								&lppMessage);
			strncpy(ml.m_strAuthor,
				lppMessage->lpOriginator->lpszName, 49);
			strncpy(ml.m_strSubject,
				lppMessage->lpszSubject,255);
			strncpy(ml.m_strDate,
				lppMessage->lpszDateReceived, 19);
			strncpy(ml.m_strBody,
				lppMessage->lpszNoteText, 1023);
			if (!m_rgRowData.Add(ml))
				return E_OUTOFMEMORY;
			*pcRowsAffected++;
		}
		(*pfnMAPILogoff)(hMAPISession, 0, 0, 0);
		FreeLibrary(hLibrary);	//Close Mail Library
		return S_OK;
	}
};
#endif //__CMAPIProviderRowset_H_
