// Session.h : Declaration of the COLEDBTextProviderSession
#ifndef __COLEDBTextProviderSession_H_
#define __COLEDBTextProviderSession_H_
#include "resource.h"       // main symbols
#include "OLEDBTextProviderRS.h"
class COLEDBTextProviderSessionTRSchemaRowset;
class COLEDBTextProviderSessionColSchemaRowset;
class COLEDBTextProviderSessionPTSchemaRowset;
/////////////////////////////////////////////////////////////////////////////
// COLEDBTextProviderSession
class ATL_NO_VTABLE COLEDBTextProviderSession : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IGetDataSourceImpl<COLEDBTextProviderSession>,
	public IOpenRowsetImpl<COLEDBTextProviderSession>,
	public ISessionPropertiesImpl<COLEDBTextProviderSession>,
	public IObjectWithSiteSessionImpl<COLEDBTextProviderSession>,
	public IDBSchemaRowsetImpl<COLEDBTextProviderSession>,
	public IDBCreateCommandImpl<COLEDBTextProviderSession, COLEDBTextProviderCommand>
{
public:
	COLEDBTextProviderSession()
	{
	}
	HRESULT FinalConstruct()
	{
		return FInit();
	}
	STDMETHOD(OpenRowset)(IUnknown *pUnk, DBID *pTID, DBID *pInID, REFIID riid,
					   ULONG cSets, DBPROPSET rgSets[], IUnknown **ppRowset)
	{
		COLEDBTextProviderRowset* pRowset;
		return CreateRowset(pUnk, pTID, pInID, riid, cSets, rgSets, ppRowset, pRowset);
	}
BEGIN_PROPSET_MAP(COLEDBTextProviderSession)
	BEGIN_PROPERTY_SET(DBPROPSET_SESSION)
		PROPERTY_INFO_ENTRY(SESS_AUTOCOMMITISOLEVELS)
	END_PROPERTY_SET(DBPROPSET_SESSION)
END_PROPSET_MAP()
BEGIN_COM_MAP(COLEDBTextProviderSession)
	COM_INTERFACE_ENTRY(IGetDataSource)
	COM_INTERFACE_ENTRY(IOpenRowset)
	COM_INTERFACE_ENTRY(ISessionProperties)
	COM_INTERFACE_ENTRY(IObjectWithSite)
	COM_INTERFACE_ENTRY(IDBCreateCommand)
	COM_INTERFACE_ENTRY(IDBSchemaRowset)
END_COM_MAP()
BEGIN_SCHEMA_MAP(COLEDBTextProviderSession)
	SCHEMA_ENTRY(DBSCHEMA_TABLES, COLEDBTextProviderSessionTRSchemaRowset)
	SCHEMA_ENTRY(DBSCHEMA_COLUMNS, COLEDBTextProviderSessionColSchemaRowset)
	SCHEMA_ENTRY(DBSCHEMA_PROVIDER_TYPES, COLEDBTextProviderSessionPTSchemaRowset)
END_SCHEMA_MAP()
};
class COLEDBTextProviderSessionTRSchemaRowset : 
	public CRowsetImpl< COLEDBTextProviderSessionTRSchemaRowset, CTABLESRow, COLEDBTextProviderSession>
{
public:
	HRESULT Execute(LONG* pcRowsAffected, ULONG, const VARIANT*)
	{
		USES_CONVERSION;
		CTABLESRow trData;
		lstrcpyW(trData.m_szType, OLESTR("TABLE"));
/* ************************** */
		//Error if file does not exist
		WIN32_FIND_DATA wf;
		HANDLE fileHandle;
		fileHandle = FindFirstFile(
			COLEDBTextProviderRowset::GetFileName(),
			&wf);
		if (fileHandle == INVALID_HANDLE_VALUE)
			return E_FAIL; // The file does not exist
		FindClose(fileHandle);
		lstrcpyW(trData.m_szDesc, 
			T2OLE(COLEDBTextProviderRowset::GetFileName()));
        lstrcpyW(trData.m_szTable, T2OLE("Text File"));
/* ************************** */
		if (!m_rgRowData.Add(trData))
			return E_OUTOFMEMORY;
		*pcRowsAffected = 1;
		return S_OK;
	}
};
class COLEDBTextProviderSessionColSchemaRowset : 
	public CRowsetImpl< COLEDBTextProviderSessionColSchemaRowset, CCOLUMNSRow, COLEDBTextProviderSession>
{
public:
	HRESULT Execute(LONG* pcRowsAffected, ULONG, const VARIANT*)
	{
		USES_CONVERSION;
		//******
		static const struct { char *szName; int maxLength; }
		rgcolumns[] = 
		   {{"Class", 50},
			{"SectionID", 11},
			{"Year", 6},
			{"Term", 30},
			{"Instructor", 50},
			{"Assignment", 255},
			{"Score", 22},
			{"Student", 35}};

		const int NUMBERCOLUMNS = sizeof(rgcolumns) / sizeof(rgcolumns[0]);
		WIN32_FIND_DATA wf;
		HANDLE fileHandle;
		//Error if file does not exist
		fileHandle = FindFirstFile(
			COLEDBTextProviderRowset::GetFileName(),
			&wf);
		if (fileHandle == INVALID_HANDLE_VALUE)
			return E_FAIL; // The file does not exist
		FindClose(fileHandle);

		// Fill out all the CCOLUMNSRow records
		for (int column=0; column<NUMBERCOLUMNS; column++) {
			CCOLUMNSRow crColumnInfo;

			lstrcpyW(crColumnInfo.m_szTableName, 
				T2OLE(COLEDBTextProviderRowset::GetFileName()));
			crColumnInfo.m_ulOrdinalPosition = column+1;
			crColumnInfo.m_bIsNullable = VARIANT_FALSE;
			crColumnInfo.m_bColumnHasDefault = VARIANT_FALSE;
			crColumnInfo.m_ulColumnFlags = 0;
			crColumnInfo.m_nDataType = DBTYPE_STR;

			lstrcpyW(crColumnInfo.m_szColumnName, T2OLE(rgcolumns[column].szName));
			lstrcpyW(crColumnInfo.m_szDescription, T2OLE(rgcolumns[column].szName));
			crColumnInfo.m_ulCharMaxLength = rgcolumns[column].maxLength;

			// Declare new schema row
			m_rgRowData.Add(crColumnInfo);
		}
		*pcRowsAffected = NUMBERCOLUMNS;  // for the four columns
		//******
		return S_OK;
	}
};
class COLEDBTextProviderSessionPTSchemaRowset : 
	public CRowsetImpl< COLEDBTextProviderSessionPTSchemaRowset, CPROVIDER_TYPERow, COLEDBTextProviderSession>
{
public:
	HRESULT Execute(LONG* pcRowsAffected, ULONG, const VARIANT*)
	{
		return S_OK;
	}
};
#endif //__COLEDBTextProviderSession_H_
