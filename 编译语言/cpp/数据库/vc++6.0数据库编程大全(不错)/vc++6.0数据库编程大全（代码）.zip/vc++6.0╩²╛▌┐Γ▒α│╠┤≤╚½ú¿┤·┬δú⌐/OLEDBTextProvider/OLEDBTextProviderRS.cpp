// Implementation of the COLEDBTextProviderCommand
#include "stdafx.h"
#include "OLEDBTextProvider.h"
#include "OLEDBTextProviderRS.h"
/////////////////////////////////////////////////////////////////////////////
// COLEDBTextProviderCommand
HRESULT COLEDBTextProviderCommand::Execute(IUnknown * pUnkOuter, REFIID riid, DBPARAMS * pParams, 
								 LONG * pcRowsAffected, IUnknown ** ppRowset)
{
	COLEDBTextProviderRowset* pRowset;
	return CreateRowset(pUnkOuter, riid, pParams, pcRowsAffected, ppRowset, pRowset);
}
