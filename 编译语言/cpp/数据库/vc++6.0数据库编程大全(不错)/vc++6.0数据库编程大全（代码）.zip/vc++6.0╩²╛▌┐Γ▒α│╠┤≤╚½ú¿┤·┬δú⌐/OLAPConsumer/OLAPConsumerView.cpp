// OLAPConsumerView.cpp : implementation of the COLAPConsumerView class
//

#include "stdafx.h"
#include "OLAPConsumer.h"

#include "OLAPConsumerSet.h"
#include "OLAPConsumerDoc.h"
#include "OLAPConsumerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLAPConsumerView

IMPLEMENT_DYNCREATE(COLAPConsumerView, COleDBRecordView)

BEGIN_MESSAGE_MAP(COLAPConsumerView, COleDBRecordView)
	//{{AFX_MSG_MAP(COLAPConsumerView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLAPConsumerView construction/destruction

COLAPConsumerView::COLAPConsumerView()
	: COleDBRecordView(COLAPConsumerView::IDD)
{
	//{{AFX_DATA_INIT(COLAPConsumerView)
		// NOTE: the ClassWizard will add member initialization here
	m_pSet = NULL;
	//}}AFX_DATA_INIT
}

COLAPConsumerView::~COLAPConsumerView()
{
}

void COLAPConsumerView::DoDataExchange(CDataExchange* pDX)
{
	COleDBRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COLAPConsumerView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BOOL COLAPConsumerView::PreCreateWindow(CREATESTRUCT& cs)
{
	return COleDBRecordView::PreCreateWindow(cs);
}

void COLAPConsumerView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_oLAPConsumerSet;
	{
		CWaitCursor wait;
		HRESULT hr = m_pSet->Open();
		if (hr != S_OK)
		{
			AfxMessageBox(_T("Record set failed to open."), MB_OK);
			m_bOnFirstRecord = TRUE;
			m_bOnLastRecord = TRUE;
		}				
	}
	COleDBRecordView::OnInitialUpdate();

}

/////////////////////////////////////////////////////////////////////////////
// COLAPConsumerView diagnostics

#ifdef _DEBUG
void COLAPConsumerView::AssertValid() const
{
	COleDBRecordView::AssertValid();
}

void COLAPConsumerView::Dump(CDumpContext& dc) const
{
	COleDBRecordView::Dump(dc);
}

COLAPConsumerDoc* COLAPConsumerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(COLAPConsumerDoc)));
	return (COLAPConsumerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLAPConsumerView database support
CRowset* COLAPConsumerView::OnGetRowset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// COLAPConsumerView message handlers
