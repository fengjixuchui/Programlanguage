// OLAPConsumerSet.cpp : implementation of the COLAPConsumerSet class
//

#include "stdafx.h"
#include "OLAPConsumer.h"
#include "OLAPConsumerSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLAPConsumerSet implementation

