// OLAPConsumer.h : main header file for the OLAPCONSUMER application
//

#if !defined(AFX_OLAPCONSUMER_H__FE946BE4_CAEF_11D2_9949_C761AB69F945__INCLUDED_)
#define AFX_OLAPCONSUMER_H__FE946BE4_CAEF_11D2_9949_C761AB69F945__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// COLAPConsumerApp:
// See OLAPConsumer.cpp for the implementation of this class
//

class COLAPConsumerApp : public CWinApp
{
public:
	COLAPConsumerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLAPConsumerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(COLAPConsumerApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLAPCONSUMER_H__FE946BE4_CAEF_11D2_9949_C761AB69F945__INCLUDED_)
