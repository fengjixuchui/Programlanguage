// OLAPConsumerDoc.cpp : implementation of the COLAPConsumerDoc class
//

#include "stdafx.h"
#include "OLAPConsumer.h"

#include "OLAPConsumerSet.h"
#include "OLAPConsumerDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLAPConsumerDoc

IMPLEMENT_DYNCREATE(COLAPConsumerDoc, CDocument)

BEGIN_MESSAGE_MAP(COLAPConsumerDoc, CDocument)
	//{{AFX_MSG_MAP(COLAPConsumerDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLAPConsumerDoc construction/destruction

COLAPConsumerDoc::COLAPConsumerDoc()
{
}

COLAPConsumerDoc::~COLAPConsumerDoc()
{
}

BOOL COLAPConsumerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// COLAPConsumerDoc diagnostics

#ifdef _DEBUG
void COLAPConsumerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void COLAPConsumerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLAPConsumerDoc commands
