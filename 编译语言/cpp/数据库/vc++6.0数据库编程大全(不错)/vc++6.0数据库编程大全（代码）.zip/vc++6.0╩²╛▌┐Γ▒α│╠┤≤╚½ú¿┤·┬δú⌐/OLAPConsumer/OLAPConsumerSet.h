// OLAPConsumerSet.h : interface of the COLAPConsumerSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLAPCONSUMERSET_H__FE946BEE_CAEF_11D2_9949_C761AB69F945__INCLUDED_)
#define AFX_OLAPCONSUMERSET_H__FE946BEE_CAEF_11D2_9949_C761AB69F945__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDepartment
{
public:
	CDepartment()
	{
		memset( (void*)this, 0, sizeof(*this) );
	};

	char m_Student[51];
	char m_DepartmentCode[5];
	int m_Year;
	int m_Average;


BEGIN_COLUMN_MAP(CDepartment)
		COLUMN_ENTRY_TYPE(1, DBTYPE_STR, m_Student)
		COLUMN_ENTRY_TYPE(2, DBTYPE_STR, m_DepartmentCode)
		COLUMN_ENTRY_TYPE(3, DBTYPE_I2, m_Year)
		COLUMN_ENTRY_TYPE(4, DBTYPE_I2, m_Average)
END_COLUMN_MAP()

};

class COLAPConsumerSet : public CCommand<CAccessor<CDepartment> >
{
public:

	HRESULT Open()
	{
		CDataSource db;
		CSession	session;
		HRESULT		hr;

		CDBPropSet	dbinit(DBPROPSET_DBINIT);
		dbinit.AddProperty(DBPROP_AUTH_PERSIST_SENSITIVE_AUTHINFO, false);
		dbinit.AddProperty(DBPROP_INIT_DATASOURCE, "Classes");
		dbinit.AddProperty(DBPROP_INIT_PROMPT, (short)4);
		dbinit.AddProperty(DBPROP_INIT_LCID, (long)1033);

		hr = db.OpenWithServiceComponents("OracleExpressProvider.1", &dbinit);
		if (FAILED(hr))
			return hr;

		hr = session.Open(db);
		if (FAILED(hr))
			return hr;

		CDBPropSet	propset(DBPROPSET_ROWSET);
		propset.AddProperty(DBPROP_CANFETCHBACKWARDS, true);
		propset.AddProperty(DBPROP_IRowsetScroll, true);
		char *oracleExpressSyntax = "\
				LIMIT student TO 'Charles A. Wood' \
				LIMIT section BASED ON Year \
				REPORT DOWN Section.Department, Section.Year";
		hr = CCommand<CAccessor<CDepartment> >::Open(
			session, oracleExpressSyntax, &propset);
		if (FAILED(hr))
			return hr;

		return MoveNext();
	}

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLAPCONSUMERSET_H__FE946BEE_CAEF_11D2_9949_C761AB69F945__INCLUDED_)

