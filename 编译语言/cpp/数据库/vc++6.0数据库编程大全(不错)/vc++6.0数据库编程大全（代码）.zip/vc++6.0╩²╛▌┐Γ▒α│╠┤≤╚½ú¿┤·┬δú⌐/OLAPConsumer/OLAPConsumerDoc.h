// OLAPConsumerDoc.h : interface of the COLAPConsumerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLAPCONSUMERDOC_H__FE946BEA_CAEF_11D2_9949_C761AB69F945__INCLUDED_)
#define AFX_OLAPCONSUMERDOC_H__FE946BEA_CAEF_11D2_9949_C761AB69F945__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "OLAPConsumerSet.h"


class COLAPConsumerDoc : public CDocument
{
protected: // create from serialization only
	COLAPConsumerDoc();
	DECLARE_DYNCREATE(COLAPConsumerDoc)

// Attributes
public:
	COLAPConsumerSet m_oLAPConsumerSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLAPConsumerDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLAPConsumerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COLAPConsumerDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLAPCONSUMERDOC_H__FE946BEA_CAEF_11D2_9949_C761AB69F945__INCLUDED_)
