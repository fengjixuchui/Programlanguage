// OLAPConsumerView.h : interface of the COLAPConsumerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLAPCONSUMERVIEW_H__FE946BEC_CAEF_11D2_9949_C761AB69F945__INCLUDED_)
#define AFX_OLAPCONSUMERVIEW_H__FE946BEC_CAEF_11D2_9949_C761AB69F945__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class COLAPConsumerSet;

class COLAPConsumerView : public COleDBRecordView
{
protected: // create from serialization only
	COLAPConsumerView();
	DECLARE_DYNCREATE(COLAPConsumerView)

public:
	//{{AFX_DATA(COLAPConsumerView)
	enum{ IDD = IDD_OLAPCONSUMER_FORM };
	COLAPConsumerSet* m_pSet;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	COLAPConsumerDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLAPConsumerView)
	public:
	virtual CRowset* OnGetRowset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLAPConsumerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COLAPConsumerView)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in OLAPConsumerView.cpp
inline COLAPConsumerDoc* COLAPConsumerView::GetDocument()
   { return (COLAPConsumerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLAPCONSUMERVIEW_H__FE946BEC_CAEF_11D2_9949_C761AB69F945__INCLUDED_)
