// DAODeptInstView.cpp : implementation of the CDAODeptInstView class
//

#include "stdafx.h"
#include "DAODeptInst.h"

#include "DAODeptInstSet.h"
#include "DAODeptInstDoc.h"
#include "DAODeptInstView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstView

IMPLEMENT_DYNCREATE(CDAODeptInstView, CDaoRecordView)

BEGIN_MESSAGE_MAP(CDAODeptInstView, CDaoRecordView)
	//{{AFX_MSG_MAP(CDAODeptInstView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CDaoRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CDaoRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CDaoRecordView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstView construction/destruction

CDAODeptInstView::CDAODeptInstView()
	: CDaoRecordView(CDAODeptInstView::IDD)
{
	//{{AFX_DATA_INIT(CDAODeptInstView)
	m_pSet = NULL;
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CDAODeptInstView::~CDAODeptInstView()
{
}

void CDAODeptInstView::DoDataExchange(CDataExchange* pDX)
{
	CDaoRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDAODeptInstView)
	DDX_FieldText(pDX, IDC_DEPARTMENTCODE, m_pSet->m_DepartmentCode, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentCode, 4);
	DDX_FieldText(pDX, IDC_DEPARTMENTNAME, m_pSet->m_DepartmentName, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentName, 50);
	DDX_FieldText(pDX, IDC_EMAIL, m_pSet->m_EMAIL, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_EMAIL, 50);
	DDX_FieldText(pDX, IDC_INSTRUCTORNAME, m_pSet->m_Name, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_Name, 50);
	DDX_FieldText(pDX, IDC_NOTES, m_pSet->m_Notes, m_pSet);
	//}}AFX_DATA_MAP
}

BOOL CDAODeptInstView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CDaoRecordView::PreCreateWindow(cs);
}

void CDAODeptInstView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_dAODeptInstSet;
	CDaoRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
	//Limit size to 8" x 20"
	CSize sizeTotal(800, 2000);
	//Because of MM_LOENGLISH, Sizes are in .01 of an inch
	SetScrollSizes(MM_LOENGLISH, sizeTotal);
}

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstView printing

BOOL CDAODeptInstView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CDAODeptInstView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CDAODeptInstView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstView diagnostics

#ifdef _DEBUG
void CDAODeptInstView::AssertValid() const
{
	CDaoRecordView::AssertValid();
}

void CDAODeptInstView::Dump(CDumpContext& dc) const
{
	CDaoRecordView::Dump(dc);
}

CDAODeptInstDoc* CDAODeptInstView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDAODeptInstDoc)));
	return (CDAODeptInstDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstView database support
CDaoRecordset* CDAODeptInstView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstView message handlers

void CDAODeptInstView::OnPrint(CDC* pDC, CPrintInfo* pInfo) 
{
    CString line;    //This is the print line
    TEXTMETRIC metrics;    //Font measurements
    int y = 0;        //Current y position on report
    CFont TitleFont;    //Font for Title
    CFont HeadingFont;    //Font for headings
    CFont DetailFont;    //Font for detail lines
    CFont FooterFont;    //Font for footer
    //Tab stops at 1 inch, 2.5 inches, and 6 inches
    int TabStops[] = {250, 600};
    //Tab stops at 3.5 inches and 6.5 inches
    int FooterTabStops[] = {350, 650};
	//Limit size to 8" x 20"
	CSize sizeTotal(800, 2000);
	//Because of MM_LOENGLISH, Sizes are in .01 of an inch
	SetScrollSizes(MM_LOENGLISH, sizeTotal);
    if (!pInfo || pInfo->m_nCurPage == 1) {
        //Set the recordset at the beginning
        m_pSet->Requery();
        //Detect empty recordset
        if (m_pSet->IsBOF()) {
            return;
        }
    }
    //Bold font for Title
    TitleFont.CreateFont(44, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0,
        ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_ROMAN, 
        "Times New Roman");
    //Bold and underlined font for headings
    HeadingFont.CreateFont(36, 0, 0, 0, FW_BOLD, FALSE, TRUE, 0,
        ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_ROMAN, 
        "Times New Roman");
    //Normal font for detail
    DetailFont.CreateFont(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
        ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_ROMAN, 
        "Times New Roman");
    //Small font for footer
    FooterFont.CreateFont(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
        ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_ROMAN, 
        "Times New Roman");
    //Capture default settings when setting the title font
    CFont* OldFont = (CFont*) pDC->SelectObject(&TitleFont);
    //Retrieve the heading font measurements
    pDC->GetTextMetrics(&metrics);
    //Compute the heading line height
    int LineHeight = metrics.tmHeight + metrics.tmExternalLeading;
    //Set Y to the line height.
    y -= LineHeight;    
    pDC->TextOut(200, 0, "DAO Student Report");
/*
 Y must be set to negative numbers because MM_LOENGLISH was used
*/
    //Set the Heading font
    pDC->SelectObject(&HeadingFont);
    //Format the heading
    line.Format("%s \t%s \t%s ","Dept Code", "Department", "Instructor");
    //Output the heading at (0, y) using 3 tabs
    pDC->TabbedTextOut(0, y, line, 2, TabStops, 0);
    //Compute the detail line height
    LineHeight = metrics.tmHeight + metrics.tmExternalLeading;
    y -= LineHeight;    //Adjust y position
    //Set the detail font
    pDC->SelectObject(&DetailFont);
    //Retrieve detail font measurements
    pDC->GetTextMetrics(&metrics);
    //Compute the detail line height
    LineHeight = metrics.tmHeight + metrics.tmExternalLeading;
    //Scroll through the recordset
    while (!m_pSet->IsEOF()) {
        if (pInfo && abs(y) > 1000) {
            pInfo->SetMaxPage(pInfo->m_nCurPage + 1);
            break;
        }
        //Format the detail line
        line.Format("%s \t%s \t%s",
            m_pSet->m_DepartmentCode,
            m_pSet->m_DepartmentName,
            m_pSet->m_Name);
        //Output the print line at (0, y) using 3 tabs
        pDC->TabbedTextOut(0, y, line, 2, TabStops, 0);
        //Get the next recordset number
        y -= LineHeight;    //Adjust y position
        m_pSet->MoveNext();
    }
    if (pInfo) {
        //Set the footer font
        pDC->SelectObject(&FooterFont);
        //Format the footer
        line.Format(
            "DAO Report \tPage %d \tVisual C++ DB Guide",
            pInfo->m_nCurPage);
        //Output the footer at the bottom using tabs
        pDC->TabbedTextOut(0, -1025, line, 2, FooterTabStops, 0);
    }
    //Restore default settings
    pDC->SelectObject(OldFont);
}
