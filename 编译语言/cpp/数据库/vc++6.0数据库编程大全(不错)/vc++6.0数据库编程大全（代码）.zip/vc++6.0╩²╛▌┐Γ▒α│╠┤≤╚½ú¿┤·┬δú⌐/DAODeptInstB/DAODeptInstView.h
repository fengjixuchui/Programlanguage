// DAODeptInstView.h : interface of the CDAODeptInstView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DAODEPTINSTVIEW_H__D7B46FAD_9504_11D2_9949_983981A5C342__INCLUDED_)
#define AFX_DAODEPTINSTVIEW_H__D7B46FAD_9504_11D2_9949_983981A5C342__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDAODeptInstSet;

class CDAODeptInstView : public CDaoRecordView
{
protected: // create from serialization only
	CDAODeptInstView();
	DECLARE_DYNCREATE(CDAODeptInstView)

public:
	//{{AFX_DATA(CDAODeptInstView)
	enum { IDD = IDD_DAODEPTINST_FORM };
	CDAODeptInstSet* m_pSet;
	//}}AFX_DATA

// Attributes
public:
	CDAODeptInstDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDAODeptInstView)
	public:
	virtual CDaoRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDAODeptInstView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDAODeptInstView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DAODeptInstView.cpp
inline CDAODeptInstDoc* CDAODeptInstView::GetDocument()
   { return (CDAODeptInstDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAODEPTINSTVIEW_H__D7B46FAD_9504_11D2_9949_983981A5C342__INCLUDED_)
