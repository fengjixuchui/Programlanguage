// OLEDBTextConsumerSet.cpp : implementation of the COLEDBTextConsumerSet class
//

#include "stdafx.h"
#include "OLEDBTextConsumer.h"
#include "OLEDBTextConsumerSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBTextConsumerSet implementation

