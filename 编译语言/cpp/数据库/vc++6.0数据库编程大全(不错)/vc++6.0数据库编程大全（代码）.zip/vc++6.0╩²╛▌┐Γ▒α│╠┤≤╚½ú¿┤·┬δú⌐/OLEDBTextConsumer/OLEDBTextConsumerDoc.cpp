// OLEDBTextConsumerDoc.cpp : implementation of the COLEDBTextConsumerDoc class
//

#include "stdafx.h"
#include "OLEDBTextConsumer.h"

#include "OLEDBTextConsumerSet.h"
#include "OLEDBTextConsumerDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBTextConsumerDoc

IMPLEMENT_DYNCREATE(COLEDBTextConsumerDoc, CDocument)

BEGIN_MESSAGE_MAP(COLEDBTextConsumerDoc, CDocument)
	//{{AFX_MSG_MAP(COLEDBTextConsumerDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBTextConsumerDoc construction/destruction

COLEDBTextConsumerDoc::COLEDBTextConsumerDoc()
{
}

COLEDBTextConsumerDoc::~COLEDBTextConsumerDoc()
{
}

BOOL COLEDBTextConsumerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// COLEDBTextConsumerDoc diagnostics

#ifdef _DEBUG
void COLEDBTextConsumerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void COLEDBTextConsumerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBTextConsumerDoc commands
