// OLEDBTextConsumerDoc.h : interface of the COLEDBTextConsumerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBTEXTCONSUMERDOC_H__1A082C0A_C8D8_11D2_9949_D68A87749F4B__INCLUDED_)
#define AFX_OLEDBTEXTCONSUMERDOC_H__1A082C0A_C8D8_11D2_9949_D68A87749F4B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "OLEDBTextConsumerSet.h"


class COLEDBTextConsumerDoc : public CDocument
{
protected: // create from serialization only
	COLEDBTextConsumerDoc();
	DECLARE_DYNCREATE(COLEDBTextConsumerDoc)

// Attributes
public:
	COLEDBTextConsumerSet m_oLEDBTextConsumerSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBTextConsumerDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLEDBTextConsumerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COLEDBTextConsumerDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBTEXTCONSUMERDOC_H__1A082C0A_C8D8_11D2_9949_D68A87749F4B__INCLUDED_)
