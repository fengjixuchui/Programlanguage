#ifndef Chucks_Error_Routine_Included
#define Chucks_Error_Routine_Included
#include <oledberr.h>
#include <atldbcli.h>

class COLEDBErrorChecking {
public:
//Inline functions
	BOOL DBErrorsAreSupported(CComPtr<IUnknown> m_spUnk)
	{
		CComPtr<ISupportErrorInfo> spSupportErrorInfo;
		if (SUCCEEDED(
			m_spUnk->QueryInterface(IID_ISupportErrorInfo,
			(void **) &spSupportErrorInfo))) {
			if (SUCCEEDED(
				spSupportErrorInfo->
					InterfaceSupportsErrorInfo(IID_ICommandPrepare))){
				return TRUE;
			}
		}
		return FALSE;
	}
	void GetDBErrors(CComPtr<IUnknown> m_spUnk, char *msg)
	{
		CDBErrorInfo errInfo;
		IErrorInfo *pErrorInfo = NULL;
		BSTR pErrorDescription = NULL;
		ULONG ulRecords = 0;
		HRESULT hr = 
			errInfo.GetErrorRecords(m_spUnk, 
				IID_ICommandPrepare, &ulRecords);
		if (FAILED(hr) || hr == S_FALSE || ulRecords == 0) {
			//The error info object could not be retrieved
			strcat(msg, "\n\nCould not retrieve an error info object.");
			strcat(msg, "\nTherefore, additional error information is not available.");
		}
		else {
			// Error info object was retrieved successfully
			LCID lcid = GetUserDefaultLCID();
			for (ULONG loop = 0; loop < ulRecords; loop ++) {
				// Get the error information from the source
				hr = errInfo.GetErrorInfo(loop, lcid, &pErrorInfo);
				if (FAILED(hr)) {
					continue;
				}
				//Get the error description
				pErrorInfo->GetDescription(&pErrorDescription);
				//Convert error description to single-width character
				sprintf(msg, "%s\n\n%S", msg, pErrorDescription);
				//Get SQLState and Error Code
				GetSQLCodes(msg, &errInfo, loop);
				//Clean up
				SysFreeString(pErrorDescription);
				pErrorInfo->Release();
			}
		}
	}
	void DisplayDBErrors(CComPtr<IUnknown> m_spUnk, char *msg)
	{
		//Allow 1 k for the error message
		char message[1024];
		if (msg) 
			strcpy(message, msg);
		else
			strcpy (message, "");
		if (m_spUnk) 
			if (DBErrorsAreSupported(m_spUnk)) 
				GetDBErrors(m_spUnk, message);
			else
				DisplaySingleError();
		else
			DisplaySingleError();
	}
	void DisplayAllErrors(CComPtr<IUnknown> m_spUnk, 
		char *msg = NULL, 
		HRESULT hresult = S_OK, 
		char *strFunction = NULL)
	{
		//Allow 1 k for the error message
		char message[1024];
		if (msg) 
			strcpy(message, msg);
		else
			strcpy (message, "");
		if (strFunction) {	//Check for function equal to null
			//Function was passed, so see what function it was
			strcat(message, " in the ");
			strcat(message, strFunction);
			strcat(message, " function ");
		}
		if (FAILED(hresult)) {
			GetHRRESULTMessage(hresult, message);
		}
		DisplayDBErrors(m_spUnk, message);
	}
//Static functions
	static void DisplaySingleError(HRESULT hresult = S_OK, char *strFunction = NULL)
	{
		//Allow 1 k for the error message
		char msg[1024];
		strcpy (msg, "");
		if (strFunction) {	//Check for function equal to null
			//Function was passed, so see what function it was
			strcat(msg, "Error occurred in the ");
			strcat(msg, strFunction);
			strcat(msg, " function \n");
		}
		if (FAILED(hresult)) {
			GetHRRESULTMessage(hresult, msg);
		}
		GetSingleError(msg);
		::MessageBox(NULL, msg, "Error Message", MB_OK);
	}
	static void GetSingleError(char *msg) 
	{
		IErrorInfo *pErrorInfo = NULL;
		BSTR pErrorDescription = NULL;
		if (SUCCEEDED(GetErrorInfo(0, &pErrorInfo))) {
			//Get the error description
			if (SUCCEEDED(pErrorInfo->GetDescription(&pErrorDescription))) {
				//Convert error description to single-width character
				sprintf(msg, "%s\n\n%S", msg, pErrorDescription);
				//Clean up
				SysFreeString(pErrorDescription);
			}
			else {
				strcat(msg, "Could not find the error description");
			}
			pErrorInfo->Release();
		}
		else {
			strcat(msg, "Could not retrieve error information");
		}
	}
	static void GetSQLCodes(char *msg, CDBErrorInfo *errInfo, ULONG errorNum = 0)
	{
		//COM Error Interface to retrieve error codes
		CComPtr<ISQLErrorInfo> spSQLErrorInfo;
		char SQLState[100];	//Buffer for error message
		if (SUCCEEDED(errInfo->GetCustomErrorObject(errorNum, 
					IID_ISQLErrorInfo,
					(IUnknown**) &spSQLErrorInfo))) {
			BSTR bstrSQLState = NULL;	//SQLState that's returned
			LONG errorCode;		//SQL Code that's returned
		//Retrieve the error code and SQLState
			if (SUCCEEDED(spSQLErrorInfo->GetSQLInfo(&bstrSQLState, &errorCode))) {
		//Form an error message
				sprintf(SQLState, 
					"\n\nSQLState is %S\nError code is %ld",
					bstrSQLState, errorCode);
		//Concatenate the error message to the existing message
				strcat(msg, SQLState);
				SysFreeString(bstrSQLState);	//Clean up
			}
			else {
				strcat(msg, 
				   "\n\nCould not get SQL info.");
			}
		}
		else {    //Something went wrong
			strcat(msg, 
			   "\n\nCould not get error or SQLState code.");
		}
	}
	static void DisplayHRRESULTMessage(HRESULT hr, char *strFunction = NULL)
	{
		if (FAILED(hr)) {
			//Allow 1 k for the error message
			char message[1024];
			strcpy (message, "");
			if (strFunction) {	//Check for function equal to null
				//Function was passed, so see what function it was
				strcat(message, "An Error occurred in the ");
				strcat(message, strFunction);
				strcat(message, " function \n\n");
			}
			GetHRRESULTMessage(hr, message);
			::MessageBox(NULL, message, "Database HR Error", MB_OK);
		}
	}
	static void GetHRRESULTMessage(HRESULT hr, char *msg)
	{
		sprintf(msg, "%s\nHRESULT was 0x%X:", msg, hr);
		switch (hr) {
		case DB_E_ABORTLIMITREACHED :
			strcat(msg, "\nYour execution was aborted because a resource limit has been reached. No results are returned when this error occurs.");
			break;
		case DB_E_ALREADYINITIALIZED :
			strcat(msg, "\nYou tried to initialize a data source that has already been initialized.");
			break;
		case DB_E_BADACCESSORFLAGS :
			strcat(msg, "\nInvalid accessor flags");
			break;
		case DB_E_BADACCESSORHANDLE :
			strcat(msg, "\nInvalid accessor handle");
			break;
		case DB_E_BADACCESSORTYPE :
			strcat(msg, "\nThe specified accessor was not a parameter accessor");
			break;
		case DB_E_BADBINDINFO :
			strcat(msg, "\nInvalid binding information");
			break;
		case DB_E_BADBOOKMARK :
			strcat(msg, "\nInvalid bookmark");
			break;
		case DB_E_BADCHAPTER :
			strcat(msg, "\nInvalid chapter");
			break;
		case DB_E_BADCOLUMNID :
			strcat(msg, "\nInvalid column ID");
			break;
		case DB_E_BADCOMPAREOP :
			strcat(msg, "\nThe comparison operator was invalid");
			break;
		case DB_E_BADCONVERTFLAG :
			strcat(msg, "\nInvalid conversion flag");
			break;
		case DB_E_BADCOPY :
			strcat(msg, "\nErrors were detected during a copy");
			break;
		case DB_E_BADDYNAMICERRORID :
			strcat(msg, "\nThe supplied DynamicErrorID was invalid");
			break;
		case DB_E_BADHRESULT :
			strcat(msg, "\nThe supplied HRESULT was invalid");
			break;
//		case DB_E_BADID :
//			DB_E_BADID is deprecated. 
//			Use DB_E_BADTABLEID instead.
//			break;
		case DB_E_BADLOCKMODE :
			strcat(msg, "\nInvalid lock mode");
			break;
		case DB_E_BADLOOKUPID :
			strcat(msg, "\nInvalid LookupID");
			break;
		case DB_E_BADORDINAL :
			strcat(msg, "\nThe specified column number does not exist.");
			break;
		case DB_E_BADPARAMETERNAME :
			strcat(msg, "\nThe given parameter name is not recognized.");
			break;
		case DB_E_BADPRECISION :
			strcat(msg, "\nA specified precision is invalid");
			break;
		case DB_E_BADPROPERTYVALUE :
			strcat(msg, "\nThe value of a property is invalid");
			break;
		case DB_E_BADRATIO :
			strcat(msg, "\nInvalid ratio");
			break;
		case DB_E_BADRECORDNUM :
			strcat(msg, "\nThe specified record number is invalid");
			break;
		case DB_E_BADROWHANDLE :
			strcat(msg, "\nInvalid row handle.  This error often occurs when you are at BOF or EOF of a rowset and you try to update your data set.");
			break;
		case DB_E_BADSCALE :
			strcat(msg, "\nA specified scale was invalid");
			break;
		case DB_E_BADSOURCEHANDLE :
			strcat(msg, "\nInvalid source handle");
			break;
		case DB_E_BADSTARTPOSITION :
			strcat(msg, "\nThe rows offset specified would position you before the beginning or past the end of the rowset.");
			break;
		case DB_E_BADSTATUSVALUE :
			strcat(msg, "\nThe specified status flag was neither DBCOLUMNSTATUS_OK nor DBCOLUMNSTATUS_ISNULL");
			break;
		case DB_E_BADSTORAGEFLAG :
			strcat(msg, "\nOne of the specified storage flags was not supported");
			break;
		case DB_E_BADSTORAGEFLAGS :
			strcat(msg, "\nInvalid storage flags");
			break;
		case DB_E_BADTABLEID :
			strcat(msg, "\nInvalid table ID");
			break;
		case DB_E_BADTYPE :
			strcat(msg, "\nA specified type was invalid");
			break;
		case DB_E_BADTYPENAME :
			strcat(msg, "\nThe given type name was unrecognized");
			break;
		case DB_E_BADVALUES :
			strcat(msg, "\nInvalid value");
			break;
		case DB_E_BOOKMARKSKIPPED :
			strcat(msg, "\nAlthough the bookmark was validly formed, no row could be found to match it");
			break;
		case DB_E_BYREFACCESSORNOTSUPPORTED :
			strcat(msg, "\nBy reference accessors are not supported by this provider");
			break;
		case DB_E_CANCELED :
			strcat(msg, "\nThe change was canceled during notification; no columns are changed");
			break;
		case DB_E_CANNOTRESTART :
			strcat(msg, "\nThe rowset was built over a live data feed and cannot be restarted.");
			break;
		case DB_E_CANTCANCEL :
			strcat(msg, "\nThe executing command cannot be canceled.");
			break;
		case DB_E_CANTCONVERTVALUE :
			strcat(msg, "\nA literal value in the command could not be converted to the correct type due to a reason other than data overflow.");
			break;
		case DB_E_CANTFETCHBACKWARDS :
			strcat(msg, "\nThe rowset does not support backward scrolling.");
			break;
		case DB_E_CANTFILTER :
			strcat(msg, "\nThe requested filter could not be opened.");
			break;
		case DB_E_CANTORDER :
			strcat(msg, "\nThe requested order could not be opened.");
			break;
		case DB_E_CANTSCROLLBACKWARDS :
			strcat(msg, "\nThe rowset cannot scroll backwards.");
			break;
		case DB_E_CANTTRANSLATE :
			strcat(msg, "\nCannot represent the current tree as text.");
			break;
		case DB_E_CHAPTERNOTRELEASED :
			strcat(msg, "\nThe rowset was single-chaptered and the chapter was not released when a new chapter formation is attempted.");
			break;
		case DB_E_CONCURRENCYVIOLATION :
			strcat(msg, "\nThe rowset was using optimistic concurrency and the value of a column has been changed since it was last read.");
			break;
		case DB_E_DATAOVERFLOW :
			strcat(msg, "\nA literal value in the command overflowed the range of the type of the associated column");
			break;
		case DB_E_DELETEDROW :
			strcat(msg, "\nThe row that is referred to has been deleted.");
			break;
		case DB_E_DIALECTNOTSUPPORTED :
			strcat(msg, "\nThe provider does not support the specified dialect");
			break;
		case DB_E_DUPLICATECOLUMNID :
			strcat(msg, "\nA column ID was occurred more than once in the specification");
			break;
		case DB_E_DUPLICATEDATASOURCE :
			strcat(msg, "\nA new data source is trying to be formed when a data source with that specified name already exists.");
			break;
		case DB_E_DUPLICATEINDEXID :
			strcat(msg, "\nThe specified index already exists.");
			break;
		case DB_E_DUPLICATETABLEID :
			strcat(msg, "\nThe specified table already exists.");
			break;
		case DB_E_ERRORSINCOMMAND :
			strcat(msg, "\nThe command contained one or more errors.");
			break;
		case DB_E_ERRORSOCCURRED :
			strcat(msg, "\nErrors occurred.  This message is thrown when an error occurs that is not captured by one of the other error messages.");
			break;
		case DB_E_INDEXINUSE :
			strcat(msg, "\nThe specified index was in use.");
			break;
		case DB_E_INTEGRITYVIOLATION :
			strcat(msg, "\nA specified value violated the referential integrity constraints for a column or table.");
			break;
		case DB_E_INVALID :
			strcat(msg, "\nThe rowset is invalide.");
			break;
		case DB_E_MAXPENDCHANGESEXCEEDED :
			strcat(msg, "\nThe number of rows with pending changes has exceeded the set limit.");
			break;
		case DB_E_MULTIPLESTATEMENTS :
			strcat(msg, "\nThe provider does not support multi-statement commands.");
			break;
		case DB_E_MULTIPLESTORAGE :
			strcat(msg, "\nMultiple storage objects can not be open simultaneously.");
			break;
		case DB_E_NEWLYINSERTED :
			strcat(msg, "\nThe provider is unable to determine identity for newly inserted rows.");
			break;
		case DB_E_NOAGGREGATION :
			strcat(msg, "\nA non-NULL controlling IUnknown was specified and the object being created does not support aggregation.");
			break;
		case DB_E_NOCOMMAND :
			strcat(msg, "\nNo command has been set for the command object.");
			break;
		case DB_E_NOINDEX :
			strcat(msg, "\nThe specified index does not exist.");
			break;
		case DB_E_NOLOCALE :
			strcat(msg, "\nThe specified locale ID was not supported.");
			break;
		case DB_E_NOQUERY :
			strcat(msg, "\nInformation was requested for a query, and the query was not set.");
			break;
		case DB_E_NOTABLE :
			strcat(msg, "\nThe specified table does not exist.");
			break;
		case DB_E_NOTAREFERENCECOLUMN :
			strcat(msg, "\nSpecified column does not contain bookmarks or chapters.");
			break;
		case DB_E_NOTFOUND :
			strcat(msg, "\nNo key matching the described characteristics could be found within the current range.");
			break;
		case DB_E_NOTPREPARED :
			strcat(msg, "\nThe command was not prepared.");
			break;
		case DB_E_NOTREENTRANT :
			strcat(msg, "\nProvider called a method from IRowsetNotify in the consumer and the method has not yet returned.");
			break;
		case DB_E_NOTSUPPORTED :
			strcat(msg, "\nThe provider does not support this method.");
			break;
		case DB_E_NULLACCESSORNOTSUPPORTED :
			strcat(msg, "\nNull accessors are not supported by this provider.");
			break;
		case DB_E_OBJECTOPEN :
			strcat(msg, "\nAn object was open.");
			break;
		case DB_E_PARAMNOTOPTIONAL :
			strcat(msg, "\nNo value given for one or more required parameters.");
			break;
		case DB_E_PARAMUNAVAILABLE :
			strcat(msg, "\nThe provider cannot derive parameter info and SetParameterInfo has not been called.");
			break;
		case DB_E_PENDINGCHANGES :
			strcat(msg, "\nThere are pending changes on a row with a reference count of zero.");
			break;
		case DB_E_PENDINGINSERT :
			strcat(msg, "\nUnable to get visible data for a newly-inserted row that has not yet been updated.");
			break;
		case DB_E_READONLYACCESSOR :
			strcat(msg, "\nUnable to write with a read-only accessor.");
			break;
		case DB_E_ROWLIMITEXCEEDED :
			strcat(msg, "\nCreating another row would have exceeded the total number of active rows supported by the rowset.");
			break;
		case DB_E_ROWSETINCOMMAND :
			strcat(msg, "\nCannot clone a command object whose command tree contains a rowset or rowsets.");
			break;
		case DB_E_ROWSNOTRELEASED :
			strcat(msg, "\nAll HROWs must be released before new ones can be obtained.");
			break;
		case DB_E_SCHEMAVIOLATION :
			strcat(msg, "\nGiven values violate the database schema.");
			break;
		case DB_E_TABLEINUSE :
			strcat(msg, "\nThe specified table was in use.");
			break;
		case DB_E_UNSUPPORTEDCONVERSION :
			strcat(msg, "\nRequested conversion is not supported.");
			break;
		case DB_E_WRITEONLYACCESSOR :
			strcat(msg, "\nThe given accessor was write-only.");
			break;
		case DB_S_ASYNCHRONOUS :
			strcat(msg, "\nThe operation is being processed asynchronously.");
			break;
		case DB_S_BADROWHANDLE :
			strcat(msg, "\nInvalid row handle. This error often occurs when you are at BOF or EOF of a rowset and you try to update your data set.");
			break;
		case DB_S_BOOKMARKSKIPPED :
			strcat(msg, "\nSkipped bookmark for deleted or non-member row.");
			break;
		case DB_S_BUFFERFULL :
			strcat(msg, "\nVariable data buffer full.  Increase system memory, commit open transactions, free more system memory, or declare larger buffers in you database setup.");
			break;
		case DB_S_CANTRELEASE :
			strcat(msg, "\nServer cannot release or \
				downgrade a lock until the end of the transaction.");
			break;
		case DB_S_COLUMNSCHANGED :
			strcat(msg, "\nIn order to reposition to the start of the rowset, the provider had to reexecute the query; either the order of the columns changed or columns were added to or removed from the rowset.");
			break;
		case DB_S_COLUMNTYPEMISMATCH :
			strcat(msg, "\nOne or more column types are incompatible. Conversion errors will occur during copying.");
			break;
		case DB_S_COMMANDREEXECUTED :
			strcat(msg, "\nThe provider re-executed the command.");
			break;
		case DB_S_DELETEDROW :
			strcat(msg, "\nA given HROW referred to a hard-deleted row.");
			break;
		case DB_S_DIALECTIGNORED :
			strcat(msg, "\nInput dialect was ignored and text was returned in different dialect.");
			break;
		case DB_S_ENDOFROWSET :
			strcat(msg, "\nReached start or end of rowset or chapter.");
			break;
		case DB_S_ERRORSOCCURRED :
			strcat(msg, "\nErrors occurred. DB_S_ERRORSOCCURRED flag was set.");
			break;
		case DB_S_ERRORSRETURNED :
			strcat(msg, "\nThe method had some errors; errors have been returned in the error array.");
			break;
		case DB_S_LOCKUPGRADED :
			strcat(msg, "\nA lock was upgraded from the value specified.");
			break;
		case DB_S_MULTIPLECHANGES :
			strcat(msg, "\nUpdating this row caused more than one row to be updated in the data source.");
			break;
		case DB_S_NONEXTROWSET :
			strcat(msg, "\nThere are no more rowsets.");
			break;
		case DB_S_NORESULT :
			strcat(msg, "\nThere are no more results.");
			break;
		case DB_S_PARAMUNAVAILABLE :
			strcat(msg, "\nA specified parameter was invalid.");
			break;
		case DB_S_PROPERTIESCHANGED :
			strcat(msg, "\nOne or more properties were changed as allowed by provider.");
			break;
		case DB_S_ROWLIMITEXCEEDED :
			strcat(msg, "\nFetching requested number of rows would have exceeded total number of active rows supported by the rowset.");
			break;
		case DB_S_STOPLIMITREACHED :
			strcat(msg, "\nExecution stopped because a resource limit has been reached. Results obtained so far have been returned but execution cannot be resumed.");
			break;
		case DB_S_TYPEINFOOVERRIDDEN :
			strcat(msg, "\nCaller has overridden parameter type information.");
			break;
		case DB_S_UNWANTEDOPERATION :
			strcat(msg, "\nConsumer is uninterested in receiving further notification calls for this reason");
			break;
		case DB_S_UNWANTEDPHASE :
			strcat(msg, "\nConsumer is uninterested in receiving further notification calls for this phase");
			break;
		case DB_S_UNWANTEDREASON :
			strcat(msg, "\nConsumer is uninterested in receiving further notification calls for this reason.");
			break;
		case DB_SEC_E_AUTH_FAILED :
			strcat(msg, "\nAuthentication failed");
			break;
		case DB_SEC_E_PERMISSIONDENIED :
			strcat(msg, "\nPermission denied");
			break;
		case MD_E_BADCOORDINATE :
			strcat(msg, "\nBad coordinate for the OLAP dataset.");
			break;
		case MD_E_BADTUPLE :
			strcat(msg, "\nBad tuple for the OLAP dataset");
			break;
		case MD_E_INVALIDAXIS :
			strcat(msg, "\nThe given axis was not valid for this OLAP dataset.");
			break;
		case MD_E_INVALIDCELLRANGE :
			strcat(msg, "\nOne or more of the given cell ordinals was invalid for this OLAP dataset.");
			break;
#if(OLEDBVER >= 0x0250)	
		//Errors if OLE DB version is greater than 2.5
		case DB_E_BADREGIONHANDLE :
			strcat(msg, "\nInvalid region handle");
			break;
		case DB_E_CANNOTFREE :
			strcat(msg, "\nOwnership of this tree has been given to the provider.  You cannot free the tree.");
			break;
		case DB_E_COSTLIMIT :
			strcat(msg, "\nUnable to find a query plan within the given cost limit");
			break;
		case DB_E_GOALREJECTED :
			strcat(msg, "\nNo nonzero weights specified for any goals supported, so goal was rejected; current goal was not changed.");
			break;
		case DB_E_INVALIDTRANSITION :
			strcat(msg, "\nA transition from ALL* to MOVE* or EXTEND* was specified.");
			break;
		case DB_E_LIMITREJECTED :
			strcat(msg, "\nSome cost limits were rejected.");
			break;
		case DB_E_NONCONTIGUOUSRANGE :
			strcat(msg, "\nThe specified set of rows was not contiguous to or overlapping the rows in the specified watch region.");
			break;
		case DB_S_ERRORSINTREE :
			strcat(msg, "\nErrors found in validating tree.");
			break;
		case DB_S_GOALCHANGED :
			strcat(msg, "\nSpecified weight was not supported or exceeded the supported limit and was set to 0 or the supported limit.");
			break;
		case DB_S_TOOMANYCHANGES :
			strcat(msg, "\nThe provider was unable to keep track of all the changes. You must refetch the data associated with the watch region using another method.");
			break;
#endif	//OLEDBVER >= 0x0250
// BLOB ISequentialStream errors
		case STG_E_INVALIDFUNCTION :
			strcat(msg, "\nYou tried an invalid function.");
			break;
		case S_FALSE :
			strcat(msg, "\nS_FALSE was returned.  The ISequentialStream data could not be read from the stream object.");
			break;
		case E_PENDING :
			strcat(msg, "\nAsynchronous Storage only: Part or all of the data to be written is currently unavailable. For more information, see IFillLockBytes and Asynchronous Storage in MSDN.");
			break;
		case STG_E_MEDIUMFULL :
			strcat(msg, "\nThe write operation was not completed because there is no space left on the storage device.");
			break;
		case STG_E_ACCESSDENIED :
			strcat(msg, "\nThe caller does not have sufficient permissions for writing this stream object.");
			break;
		case STG_E_CANTSAVE :
			strcat(msg, "\nData cannot be written for reasons other than lack of access or space.");
			break;
		case STG_E_INVALIDPOINTER :
			strcat(msg, "\nOne of the pointer values is invalid.");
			break;
		case STG_E_REVERTED :
			strcat(msg, "\nThe object has been invalidated by a revert operation above it in the transaction tree.");
			break;
		case STG_E_WRITEFAULT :
			strcat(msg, "\nThe write operation was not completed due to a disk error.");
			break;
// Unknown error
		default :
			strcat(msg, "\nHRESULT returned an unknown error.");
			break;
		}
	}
};
#endif // !defined(Chucks_Error_Routine_Included)
