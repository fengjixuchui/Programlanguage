// ODBCDepartmentView.h : interface of the CODBCDepartmentView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ODBCDEPARTMENTVIEW_H__2A271D2C_38DD_11D2_9949_87AD526EFE4A__INCLUDED_)
#define AFX_ODBCDEPARTMENTVIEW_H__2A271D2C_38DD_11D2_9949_87AD526EFE4A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CODBCDepartmentSet;

class CODBCDepartmentView : public CRecordView
{
protected: // create from serialization only
	CODBCDepartmentView();
	DECLARE_DYNCREATE(CODBCDepartmentView)

public:
	//{{AFX_DATA(CODBCDepartmentView)
	enum { IDD = IDD_ODBCDEPARTMENT_FORM };
	CODBCDepartmentSet* m_pSet;
	//}}AFX_DATA

// Attributes
public:
	CODBCDepartmentDoc* GetDocument();
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CODBCDepartmentView)
	public:
	virtual CRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CODBCDepartmentView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CODBCDepartmentView)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ODBCDepartmentView.cpp
inline CODBCDepartmentDoc* CODBCDepartmentView::GetDocument()
   { return (CODBCDepartmentDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ODBCDEPARTMENTVIEW_H__2A271D2C_38DD_11D2_9949_87AD526EFE4A__INCLUDED_)
