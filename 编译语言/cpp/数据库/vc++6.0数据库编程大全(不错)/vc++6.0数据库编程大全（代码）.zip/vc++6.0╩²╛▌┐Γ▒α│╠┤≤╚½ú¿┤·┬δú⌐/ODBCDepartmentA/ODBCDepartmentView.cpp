// ODBCDepartmentView.cpp : implementation of the CODBCDepartmentView class
//

#include "stdafx.h"
#include "ODBCDepartment.h"

#include "ODBCDepartmentSet.h"
#include "ODBCDepartmentDoc.h"
#include "ODBCDepartmentView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView

IMPLEMENT_DYNCREATE(CODBCDepartmentView, CRecordView)

BEGIN_MESSAGE_MAP(CODBCDepartmentView, CRecordView)
	//{{AFX_MSG_MAP(CODBCDepartmentView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView construction/destruction

CODBCDepartmentView::CODBCDepartmentView()
	: CRecordView(CODBCDepartmentView::IDD)
{
	//{{AFX_DATA_INIT(CODBCDepartmentView)
	m_pSet = NULL;
	//}}AFX_DATA_INIT
}

CODBCDepartmentView::~CODBCDepartmentView()
{
}

void CODBCDepartmentView::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CODBCDepartmentView)
	DDX_FieldText(pDX, IDC_DEPARTMENTCODE, m_pSet->m_DepartmentCode, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentCode, 4);
	DDX_FieldText(pDX, IDC_DEPARTMENTNAME, m_pSet->m_DepartmentName, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentName, 50);
	//}}AFX_DATA_MAP
}

BOOL CODBCDepartmentView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CRecordView::PreCreateWindow(cs);
}

void CODBCDepartmentView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_oDBCDepartmentSet;
	CRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView diagnostics

#ifdef _DEBUG
void CODBCDepartmentView::AssertValid() const
{
	CRecordView::AssertValid();
}

void CODBCDepartmentView::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CODBCDepartmentDoc* CODBCDepartmentView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CODBCDepartmentDoc)));
	return (CODBCDepartmentDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView database support
CRecordset* CODBCDepartmentView::OnGetRecordset()
{
	return m_pSet;
}

