// ODBCDepartmentSet.cpp : implementation of the CODBCDepartmentSet class
//

#include "stdafx.h"
#include "ODBCDepartment.h"
#include "ODBCDepartmentSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentSet implementation

IMPLEMENT_DYNAMIC(CODBCDepartmentSet, CRecordset)

CODBCDepartmentSet::CODBCDepartmentSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CODBCDepartmentSet)
	m_DepartmentCode = _T("");
	m_DepartmentName = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}

CString CODBCDepartmentSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=Classes");
}

CString CODBCDepartmentSet::GetDefaultSQL()
{
	return _T("[Department]");
}

void CODBCDepartmentSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CODBCDepartmentSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[DepartmentCode]"), m_DepartmentCode);
	RFX_Text(pFX, _T("[DepartmentName]"), m_DepartmentName);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentSet diagnostics

#ifdef _DEBUG
void CODBCDepartmentSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CODBCDepartmentSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
