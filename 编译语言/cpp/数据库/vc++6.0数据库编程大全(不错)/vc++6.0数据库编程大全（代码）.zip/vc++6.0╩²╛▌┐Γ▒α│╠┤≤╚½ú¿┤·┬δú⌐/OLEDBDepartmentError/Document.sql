Create Trigger DELETEDEPARTMENT
On DEPARTMENT
For DELETE
As

DECLARE @count tinyint,
        @errors tinyint
SET @errors = 0
SELECT @count = COUNT(*) 
FROM Instructor e INNER JOIN deleted d ON e.DepartmentCode = d.DepartmentCode 
IF (@count > 0)
BEGIN
    RAISERROR ('Instructor has related records so this department cannot be deleted', 16, 1)
	SET @errors = @errors + 1
END
SELECT @count = COUNT(*) 
FROM Class c INNER JOIN deleted d ON c.DepartmentCode = d.DepartmentCode 
IF (@count > 0)
BEGIN
    RAISERROR ('Class has related records so this department cannot be deleted', 16, 1)
	SET @errors = @errors + 1
END
IF (@errors > 0)
	ROLLBACK TRANSACTION
