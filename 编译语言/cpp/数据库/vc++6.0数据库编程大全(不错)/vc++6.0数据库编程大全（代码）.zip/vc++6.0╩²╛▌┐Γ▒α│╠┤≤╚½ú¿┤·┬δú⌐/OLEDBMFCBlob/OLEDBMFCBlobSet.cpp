// OLEDBMFCBlobSet.cpp : implementation of the COLEDBMFCBlobSet class
//

#include "stdafx.h"
#include "OLEDBMFCBlob.h"
#include "OLEDBMFCBlobSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCBlobSet implementation

