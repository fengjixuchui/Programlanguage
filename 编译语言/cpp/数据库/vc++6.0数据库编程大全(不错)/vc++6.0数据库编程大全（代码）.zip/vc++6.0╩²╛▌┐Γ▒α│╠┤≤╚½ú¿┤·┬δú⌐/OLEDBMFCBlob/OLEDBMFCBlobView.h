// OLEDBMFCBlobView.h : interface of the COLEDBMFCBlobView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBMFCBLOBVIEW_H__2126A6EC_B381_11D2_9949_AF1E89DECD4A__INCLUDED_)
#define AFX_OLEDBMFCBLOBVIEW_H__2126A6EC_B381_11D2_9949_AF1E89DECD4A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class COLEDBMFCBlobSet;

class COLEDBMFCBlobView : public COleDBRecordView
{
protected: // create from serialization only
	COLEDBMFCBlobView();
	DECLARE_DYNCREATE(COLEDBMFCBlobView)

public:
	//{{AFX_DATA(COLEDBMFCBlobView)
	enum { IDD = IDD_OLEDBMFCBLOB_FORM };
	COLEDBMFCBlobSet* m_pSet;
	//}}AFX_DATA

// Attributes
public:
	BOOL UpdateData(BOOL bSaveAndValidate=TRUE);
	COLEDBMFCBlobDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBMFCBlobView)
	public:
	virtual CRowset* OnGetRowset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnMove(UINT nIDMoveCommand);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLEDBMFCBlobView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	BOOL m_bCommentChange;

// Generated message map functions
protected:
	//{{AFX_MSG(COLEDBMFCBlobView)
	afx_msg void OnChangeComment();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in OLEDBMFCBlobView.cpp
inline COLEDBMFCBlobDoc* COLEDBMFCBlobView::GetDocument()
   { return (COLEDBMFCBlobDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBMFCBLOBVIEW_H__2126A6EC_B381_11D2_9949_AF1E89DECD4A__INCLUDED_)
