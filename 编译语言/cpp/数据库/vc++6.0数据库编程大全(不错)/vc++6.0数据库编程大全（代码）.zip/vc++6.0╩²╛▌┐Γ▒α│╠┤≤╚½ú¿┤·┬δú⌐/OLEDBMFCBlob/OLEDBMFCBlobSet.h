// OLEDBMFCBlobSet.h : interface of the COLEDBMFCBlobSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBMFCBLOBSET_H__2126A6EE_B381_11D2_9949_AF1E89DECD4A__INCLUDED_)
#define AFX_OLEDBMFCBLOBSET_H__2126A6EE_B381_11D2_9949_AF1E89DECD4A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
class CStudent
{
public:
	CStudent()
	{
		memset( (void*)this, 0, sizeof(*this) );
	};
	char m_FirstName[31];
	char m_MidName[31];
	char m_LastName[31];
	char m_UserID[51];
	char m_Password[51];
	char m_Address[31];
	char m_City[51];
	char m_StateOrProvince[21];
	char m_PostalCode[21];
	char m_PhoneNumber[16];
	char m_EMAIL[51];
	char m_Major[51];
	char m_StudentSSN[31];
	ISequentialStream *m_Comments;


BEGIN_COLUMN_MAP(CStudent)
	COLUMN_ENTRY_TYPE(1, DBTYPE_STR, m_FirstName)
	COLUMN_ENTRY_TYPE(2, DBTYPE_STR, m_MidName)
	COLUMN_ENTRY_TYPE(3, DBTYPE_STR, m_LastName)
	COLUMN_ENTRY_TYPE(4, DBTYPE_STR, m_UserID)
	COLUMN_ENTRY_TYPE(5, DBTYPE_STR, m_Password)
	COLUMN_ENTRY_TYPE(6, DBTYPE_STR, m_Address)
	COLUMN_ENTRY_TYPE(7, DBTYPE_STR, m_City)
	COLUMN_ENTRY_TYPE(8, DBTYPE_STR, m_StateOrProvince)
	COLUMN_ENTRY_TYPE(9, DBTYPE_STR, m_PostalCode)
	COLUMN_ENTRY_TYPE(10, DBTYPE_STR, m_PhoneNumber)
	COLUMN_ENTRY_TYPE(11, DBTYPE_STR, m_EMAIL)
	COLUMN_ENTRY_TYPE(12, DBTYPE_STR, m_Major)
	COLUMN_ENTRY_TYPE(13, DBTYPE_STR, m_StudentSSN)
	BLOB_ENTRY(14, IID_ISequentialStream, 
		STGM_READWRITE, 
		m_Comments)
END_COLUMN_MAP()

};

class COLEDBMFCBlobSet : public CCommand<CAccessor<CStudent> >
{
public:

	HRESULT Open()
	{
		CDataSource db;
		CSession	session;
		HRESULT		hr;

		CDBPropSet	dbinit(DBPROPSET_DBINIT);
		dbinit.AddProperty(DBPROP_AUTH_PERSIST_SENSITIVE_AUTHINFO, false);
		dbinit.AddProperty(DBPROP_INIT_DATASOURCE, "Classes");
		dbinit.AddProperty(DBPROP_INIT_PROMPT, (short)4);
		dbinit.AddProperty(DBPROP_INIT_LCID, (long)1033);

		hr = db.OpenWithServiceComponents("MSDASQL.1", &dbinit);
		if (FAILED(hr))
			return hr;

		hr = session.Open(db);
		if (FAILED(hr))
			return hr;

		CDBPropSet	propset(DBPROPSET_ROWSET);
		propset.AddProperty(DBPROP_CANFETCHBACKWARDS, true);
		propset.AddProperty(DBPROP_IRowsetScroll, true);
		propset.AddProperty(DBPROP_IRowsetChange, true);
		propset.AddProperty(DBPROP_UPDATABILITY, DBPROPVAL_UP_CHANGE | DBPROPVAL_UP_INSERT | DBPROPVAL_UP_DELETE );

		hr = CCommand<CAccessor<CStudent> >::Open(session, 
					"SELECT FirstName, \
							MidName, \
							LastName, \
							UserID, \
							Password, \
							Address, \
							City, \
							StateOrProvince, \
							PostalCode, \
							PhoneNumber, \
							EMAIL, \
							Major, \
							StudentSSN,\
							Comments \
					   FROM Student",
					&propset);
		if (FAILED(hr))
			return hr;

		return MoveNext();
	}

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBMFCBLOBSET_H__2126A6EE_B381_11D2_9949_AF1E89DECD4A__INCLUDED_)

