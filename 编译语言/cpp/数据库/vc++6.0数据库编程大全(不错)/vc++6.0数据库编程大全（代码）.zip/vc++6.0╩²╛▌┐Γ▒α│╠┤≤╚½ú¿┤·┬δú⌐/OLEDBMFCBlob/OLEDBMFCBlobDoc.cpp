// OLEDBMFCBlobDoc.cpp : implementation of the COLEDBMFCBlobDoc class
//

#include "stdafx.h"
#include "OLEDBMFCBlob.h"

#include "OLEDBMFCBlobSet.h"
#include "OLEDBMFCBlobDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCBlobDoc

IMPLEMENT_DYNCREATE(COLEDBMFCBlobDoc, CDocument)

BEGIN_MESSAGE_MAP(COLEDBMFCBlobDoc, CDocument)
	//{{AFX_MSG_MAP(COLEDBMFCBlobDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCBlobDoc construction/destruction

COLEDBMFCBlobDoc::COLEDBMFCBlobDoc()
{
}

COLEDBMFCBlobDoc::~COLEDBMFCBlobDoc()
{
}

BOOL COLEDBMFCBlobDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCBlobDoc diagnostics

#ifdef _DEBUG
void COLEDBMFCBlobDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void COLEDBMFCBlobDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCBlobDoc commands
