// OLEDBMFCBlobView.cpp : implementation of the COLEDBMFCBlobView class
//

#include "stdafx.h"
#include "OLEDBMFCBlob.h"

#include "OLEDBMFCBlobSet.h"
#include "OLEDBMFCBlobDoc.h"
#include "OLEDBMFCBlobView.h"
//Added by Chuck Wood for Error Checking
#include "..\OLEDBErrorChecking\OLEDBErrorChecking.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCBlobView

IMPLEMENT_DYNCREATE(COLEDBMFCBlobView, COleDBRecordView)

BEGIN_MESSAGE_MAP(COLEDBMFCBlobView, COleDBRecordView)
	//{{AFX_MSG_MAP(COLEDBMFCBlobView)
	ON_EN_CHANGE(IDC_COMMENT, OnChangeComment)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCBlobView construction/destruction

COLEDBMFCBlobView::COLEDBMFCBlobView()
	: COleDBRecordView(COLEDBMFCBlobView::IDD)
{
	//{{AFX_DATA_INIT(COLEDBMFCBlobView)
	m_pSet = NULL;
	//}}AFX_DATA_INIT
	m_bCommentChange = FALSE;
}

COLEDBMFCBlobView::~COLEDBMFCBlobView()
{
}

void COLEDBMFCBlobView::DoDataExchange(CDataExchange* pDX)
{
	COleDBRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COLEDBMFCBlobView)
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_FIRSTNAME, m_pSet->m_FirstName,31);
	DDX_Text(pDX, IDC_MIDDLENAME, m_pSet->m_MidName,31);
	DDX_Text(pDX, IDC_LASTNAME, m_pSet->m_LastName,31);
	DDX_Text(pDX, IDC_USERID, m_pSet->m_UserID,51);
	DDX_Text(pDX, IDC_PASSWORD, m_pSet->m_Password,51);
	DDX_Text(pDX, IDC_ADDRESS, m_pSet->m_Address,31);
	DDX_Text(pDX, IDC_CITY, m_pSet->m_City,51);
	DDX_Text(pDX, IDC_STOTEORPROVINCE, m_pSet->m_StateOrProvince,21);
	DDX_Text(pDX, IDC_POSTALCODE, m_pSet->m_PostalCode,21);
	DDX_Text(pDX, IDC_PHONENUMBER, m_pSet->m_PhoneNumber,16);
	DDX_Text(pDX, IDC_EMAIL, m_pSet->m_EMAIL,51);
	DDX_Text(pDX, IDC_MAJOR, m_pSet->m_Major,51);
	DDX_Text(pDX, IDC_SSN, m_pSet->m_StudentSSN,31);
}

BOOL COLEDBMFCBlobView::PreCreateWindow(CREATESTRUCT& cs)
{
	return COleDBRecordView::PreCreateWindow(cs);
}

void COLEDBMFCBlobView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_oLEDBMFCBlobSet;
	{
		CWaitCursor wait;
		HRESULT hr = m_pSet->Open();
		if (hr != S_OK)
		{
			AfxMessageBox(_T("Record set failed to open."), MB_OK);
			m_bOnFirstRecord = TRUE;
			m_bOnLastRecord = TRUE;
		}				
	}
	COleDBRecordView::OnInitialUpdate();

}

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCBlobView diagnostics

#ifdef _DEBUG
void COLEDBMFCBlobView::AssertValid() const
{
	COleDBRecordView::AssertValid();
}

void COLEDBMFCBlobView::Dump(CDumpContext& dc) const
{
	COleDBRecordView::Dump(dc);
}

COLEDBMFCBlobDoc* COLEDBMFCBlobView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(COLEDBMFCBlobDoc)));
	return (COLEDBMFCBlobDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCBlobView database support
CRowset* COLEDBMFCBlobView::OnGetRowset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCBlobView message handlers

BOOL COLEDBMFCBlobView::OnMove(UINT nIDMoveCommand) 
{
	UpdateData(TRUE);
	BOOL returnValue = COleDBRecordView::OnMove(nIDMoveCommand);
	UpdateData(FALSE);
	return returnValue;
}
BOOL COLEDBMFCBlobView::UpdateData(BOOL bSaveAndValidate) {
	//Use SteveMcQueen to get the BLOB
	CString SteveMcQueen = "";
	const int BUFFER_SIZE = 1000;	//Size of the buffer
	ULONG ulIOBytes;
	HRESULT hr;
	if (bSaveAndValidate && m_bCommentChange) {
		//Get Text for BLOB
		GetDlgItemText(IDC_COMMENT, SteveMcQueen);
		//Use SteveMcQueen to put it to the BLOB
		long bufferSize = SteveMcQueen.GetLength();
		if (bufferSize) {
			hr = m_pSet->m_Comments->Write(
				SteveMcQueen.GetBuffer(bufferSize), 
				bufferSize, &ulIOBytes);
			if (FAILED(hr)) {
				COLEDBErrorChecking::DisplayHRRESULTMessage(
					hr, "Write in UpdateData");
			}
			else {
				hr = m_pSet->SetData();
				if (FAILED(hr)) {
					COLEDBErrorChecking::DisplaySingleError(
						hr, "SetData in UpdateData");
				}
			}
		}
		else {
			m_pSet->m_Comments = NULL;
		}
	}
	else{
		//Test to see if comments exist
		if (m_pSet->m_Comments) {
			char bBuffer[BUFFER_SIZE];	//Allocate buffer
			do {
				hr = m_pSet->m_Comments->Read(
					bBuffer, BUFFER_SIZE-1, &ulIOBytes);
				if (FAILED(hr)) {
					COLEDBErrorChecking::DisplayHRRESULTMessage(hr, "Read in UpdateData");
					break; //out of loop
				}
				bBuffer[ulIOBytes] = 0; //Null terminate
				SteveMcQueen = SteveMcQueen + bBuffer;
			} while (ulIOBytes > 0);
		}
		if (SUCCEEDED(hr)) {
			SetDlgItemText(IDC_COMMENT, (LPCTSTR) SteveMcQueen);
		}
	}
	m_bCommentChange = FALSE;	//Set update flag
//Update the normal, non-BLOB fields
	return CWnd::UpdateData(bSaveAndValidate);
}

void COLEDBMFCBlobView::OnChangeComment() 
{
	m_bCommentChange = TRUE;
}
