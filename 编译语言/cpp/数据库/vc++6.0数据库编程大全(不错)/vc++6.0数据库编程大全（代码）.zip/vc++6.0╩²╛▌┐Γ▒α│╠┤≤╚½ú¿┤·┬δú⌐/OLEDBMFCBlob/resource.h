//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OLEDBMFCBlob.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_OLEDBMFCBLOB_FORM           101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_MAINFRAME                   128
#define IDR_OLEDBMTYPE                  129
#define IDC_STUDENTID                   1000
#define IDC_FIRSTNAME                   1001
#define IDC_MIDDLENAME                  1002
#define IDC_LASTNAME                    1003
#define IDC_PASSWORD                    1004
#define IDC_ADDRESS                     1005
#define IDC_CITY                        1006
#define IDC_STOTEORPROVINCE             1007
#define IDC_POSTALCODE                  1008
#define IDC_PHONENUMBER                 1009
#define IDC_EMAIL                       1010
#define IDC_MAJOR                       1011
#define IDC_SSN                         1012
#define IDC_COMMENT                     1013
#define IDC_USERID                      1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
