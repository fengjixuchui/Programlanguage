// OLEDBMFCBlob.h : main header file for the OLEDBMFCBLOB application
//

#if !defined(AFX_OLEDBMFCBLOB_H__2126A6E4_B381_11D2_9949_AF1E89DECD4A__INCLUDED_)
#define AFX_OLEDBMFCBLOB_H__2126A6E4_B381_11D2_9949_AF1E89DECD4A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCBlobApp:
// See OLEDBMFCBlob.cpp for the implementation of this class
//

class COLEDBMFCBlobApp : public CWinApp
{
public:
	COLEDBMFCBlobApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBMFCBlobApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(COLEDBMFCBlobApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBMFCBLOB_H__2126A6E4_B381_11D2_9949_AF1E89DECD4A__INCLUDED_)
