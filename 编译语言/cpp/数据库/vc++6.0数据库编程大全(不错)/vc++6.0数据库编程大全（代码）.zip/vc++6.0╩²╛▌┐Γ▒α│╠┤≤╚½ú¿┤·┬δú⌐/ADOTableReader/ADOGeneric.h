// ADOGeneric.h: interface for the ADOGeneric class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ADOGENERIC_H__3CADFD81_C319_11D2_9949_AE4C5BF4C84A__INCLUDED_)
#define AFX_ADOGENERIC_H__3CADFD81_C319_11D2_9949_AE4C5BF4C84A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ADOGeneric  
{
public:
	ADOGeneric();
	virtual ~ADOGeneric();

};

#endif // !defined(AFX_ADOGENERIC_H__3CADFD81_C319_11D2_9949_AE4C5BF4C84A__INCLUDED_)
