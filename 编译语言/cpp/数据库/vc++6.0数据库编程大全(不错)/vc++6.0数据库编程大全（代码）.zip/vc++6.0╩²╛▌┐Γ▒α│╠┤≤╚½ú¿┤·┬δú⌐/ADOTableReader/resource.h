//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ADOTableReader.rc
//
#define IDS_PROJNAME                    100
#define IDR_ADOTableReader              100
#define IDD_ADODIALOG                   101
#define IDR_MENU1                       201
#define IDC_STATUS                      201
#define IDC_CODE                        202
#define IDC_NAME                        203
#define ID_RECORDSET_FIRST              32775
#define ID_RECORDSET_PREV               32776
#define ID_RECORDSET_NEXT               32777
#define ID_RECORDSET_LAST               32778
#define ID_RECORDSET_INSERT             32779
#define ID_RECORDSET_DELETE             32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        209
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         206
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
