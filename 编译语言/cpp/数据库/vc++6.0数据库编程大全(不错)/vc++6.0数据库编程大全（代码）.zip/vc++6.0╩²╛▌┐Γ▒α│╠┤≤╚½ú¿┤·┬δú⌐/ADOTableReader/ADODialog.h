// ADODialog.h : Declaration of the CADODialog

#ifndef __ADODIALOG_H_
#define __ADODIALOG_H_

#include "resource.h"       // main symbols
#include <atlhost.h>
//The next two were added by Chuck Wood for ADO Support
#include <adoid.h>			// ADO header file
#include <adoint.h>			// ADO header file
//Added by Chuck Wood for OLE DB Error support
#include "..\OLEDBErrorChecking\OLEDBErrorChecking.h"

/////////////////////////////////////////////////////////////////////////////
// CADODialog
class CADODialog : 
	public CAxDialogImpl<CADODialog>
{
private :
	//Database Fields 
	char m_DepartmentCode[5];
	char m_DepartmentName[51];
	//ADO Connection and Recordset variables
	CComPtr<ADOConnection> m_ADOConn;
	CComPtr<ADORecordset> m_pSet;
	//Variant for null VARIANT parameters
	VARIANT m_varNoVariant;
	//Name of database fields
	char *m_strODBCDatabase;	//Database Name
	char *m_strUserID;			//User ID
	char *m_strPassword;		//Password
	char *m_strDBTable;			//Table for data source
	void StartDatabaseAccess();	//Begin program	
	void StopDatabaseAccess();	//End program
	//Show a status message on the dialog box
	void DisplayStatus(char *strMessage);
	//Take data to and from the dialog box
	void UpdateData(BOOL bSaveChangesToSet = TRUE);
	//Take data from database fields
	HRESULT GetFields();		
	//Take data to database fields
	HRESULT SetFields();
	HRESULT OpenConnection();	//Connect
	HRESULT OpenRecordset();	//Form Recordset
	HRESULT SaveChanges();		//Save Changes
	void CloseConnection();		//End Connection
	void CloseRecordset();		//End Recordset
public:
	//enum for ADOMove function
	enum ADOMoveEnum {FIRST, PREV, NEXT, LAST, SAME};
	//Move recordset pointer around
	void ADOMove(ADOMoveEnum p, BOOL SaveFirst = TRUE);
	void ExecuteSQL(char *SQL);	//Execute some SQL
	CADODialog()
	{
		//Initialize a variant for inserting and updating
		m_varNoVariant.vt = VT_ERROR;
		m_varNoVariant.scode = DISP_E_PARAMNOTFOUND;
		//Set up your ADO database access
		m_strODBCDatabase = strdup("Classes");
		m_strUserID = strdup("");
		m_strPassword = strdup("");
		m_strDBTable = strdup("Department");
		m_ADOConn = NULL;	//Initialize connection
		m_pSet = NULL;		//Initialize recordset
		DoModal();			//Open this dialog box
	}

	~CADODialog()
	{
		CloseRecordset();	//Close the crecord set
		CloseConnection();	//Close a connection
		delete m_strODBCDatabase;	//Clean up strings
		delete m_strUserID;
		delete m_strPassword;
		delete m_strDBTable;
	}

	enum { IDD = IDD_ADODIALOG };

BEGIN_MSG_MAP(CADODialog)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	COMMAND_ID_HANDLER(ID_RECORDSET_FIRST, OnMoveFirst)
	COMMAND_ID_HANDLER(ID_RECORDSET_LAST, OnMoveLast)
	COMMAND_ID_HANDLER(ID_RECORDSET_PREV, OnMovePrev)
	COMMAND_ID_HANDLER(ID_RECORDSET_NEXT, OnMoveNext)
	COMMAND_ID_HANDLER(ID_RECORDSET_INSERT, OnInsert)
	COMMAND_ID_HANDLER(ID_RECORDSET_DELETE, OnDelete)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		DisplayStatus("Opening Connection.  Please Wait.");
		//Open a connection
		if (SUCCEEDED(OpenConnection())) {
			DisplayStatus("Now Opening RecordSet.  Please Wait.");
			//Open a Recordset
			if (SUCCEEDED(OpenRecordset())) {
				DisplayStatus("");
			}
		}
		return 1;  // Let the system set the focus
	}

	LRESULT OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		SaveChanges();
		EndDialog(wID);	//End Program
		return 0;
	}

	LRESULT OnMoveFirst(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		ADOMove(FIRST);	//Move to first record
		return 0;
	}

	LRESULT OnMoveNext(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		ADOMove(NEXT);	//Move to next record
		return 0;
	}

	LRESULT OnMovePrev(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		ADOMove(PREV);	//Move to previous record
		return 0;
	}

	LRESULT OnMoveLast(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		ADOMove(LAST);	//Move to last record
		return 0;
	}

	LRESULT OnInsert(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		ADOMove(SAME);		//Don't move, just do the updating
		//Place the recordset in addnew mode
		HRESULT hr = m_pSet->AddNew(m_varNoVariant, m_varNoVariant);
		if (FAILED(hr)) {
			COLEDBErrorChecking::DisplaySingleError(hr, "Can't set addnew mode");
			DisplayStatus("Cannot add.");
			return 0;
		}
		//Clear Record
		SetDlgItemText(IDC_CODE, "");
		SetDlgItemText(IDC_NAME, "");
		return 0;
	}

	LRESULT OnDelete(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		if (MessageBox(	//Be sure to verify your deletes
				"Are you sure you want to delete?",
				"Delete this record?",
				MB_YESNO)
			!= IDYES) {
			DisplayStatus("Delete aborted");
			return 0;
		}
		//Delete record and test
		EditModeEnum eme;	//Edit Mode variable
		//Get Edit Mode to test for currently adding
		HRESULT hr = m_pSet->get_EditMode(&eme);
		if (FAILED(hr)) {
			COLEDBErrorChecking::DisplaySingleError(hr, "OnDelete get_EditMode");
			DisplayStatus("Cannot determine edit mode. Delete aborted");
			return 0;
		}
		if (eme == adEditAdd) {	//In add mode?
			//Just abort the add
			m_pSet->CancelUpdate();
			ADOMove(NEXT, FALSE);
			DisplayStatus("Add aborted");
			return 0;
		}
		//Ready to delete current record
		hr = m_pSet->Delete(adAffectCurrent);	
		if (FAILED(hr)) {
			COLEDBErrorChecking::DisplaySingleError(hr, "OnDelete Delete");
			DisplayStatus("Delete had failed.");
			return 0;
		}
		ADOMove(NEXT, FALSE);	//Reposition record
		return 0;
	}

};

#endif //__ADODIALOG_H_
