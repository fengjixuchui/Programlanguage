// ADODialog.cpp : Implementtion of CADODialog
#include "stdafx.h"
#include "ADODialog.h"
/////////////////////////////////////////////////////////////////////////////
// CADODialog

HRESULT CADODialog::OpenConnection() {
    CComBSTR bstrODBCDatabase = m_strODBCDatabase;
	CComBSTR bstrUserId = m_strUserID;
	CComBSTR bstrPassword = m_strPassword;

	//Create new connection
	CoCreateInstance(CLSID_CADOConnection, NULL, 
		CLSCTX_INPROC_SERVER, IID_IADOConnection, 
		(LPVOID *)&m_ADOConn);
	//Use the connection to open a link to database
	HRESULT hr = m_ADOConn->Open(
		bstrODBCDatabase, 
		bstrUserId,
		bstrPassword,
		adOpenUnspecified);
	if (FAILED(hr)) {
		COLEDBErrorChecking::DisplaySingleError(hr, 
			"OpenConnection");
		m_ADOConn = NULL;
	}
	return hr;
}

void CADODialog::CloseConnection() {
	if (m_ADOConn != NULL ) {
		//Close the connection
		m_ADOConn->Close();
		m_ADOConn = NULL;
	}
}

HRESULT CADODialog::OpenRecordset() {
//Form an SQL statement from the table
	CComBSTR bstrSQL = "SELECT * FROM ";
	bstrSQL += m_strDBTable;
//Allocate a new ADORecordset variable
	CoCreateInstance(CLSID_CADORecordset, NULL, 
		CLSCTX_INPROC_SERVER, IID_IADORecordset, 
		(LPVOID *)&m_pSet);
//Open the newly formed recordset with the SQL
//and the connection
	HRESULT hr = m_pSet->Open(
		CComVariant(bstrSQL),
		CComVariant(m_ADOConn), 
		adOpenKeyset, adLockOptimistic, adCmdText);
	if (FAILED(hr)) {
		COLEDBErrorChecking::DisplaySingleError(hr, 
			"OpenRecordset");
		m_pSet = NULL;
	}
	else {
		//Everything worked.  Move to the first record.
		ADOMove(FIRST, FALSE);
	}
	return hr;
}

void CADODialog::CloseRecordset() {
	if (m_pSet != NULL ) {
		//Close recordset 
		m_pSet->Close();
		m_pSet = NULL;
	}
}

void CADODialog::ExecuteSQL(char *SQL) {
	CComBSTR bstrSQL = SQL;
	//Execute an SQL string
	HRESULT hr = m_ADOConn->Execute(
		bstrSQL,	//Source statement
		NULL,		//VARIANT records Affected
        adOptionUnspecified, //Options -- Usually leave unspecified
		NULL);		//ADORecordset results;
	if (FAILED(hr)) {
		COLEDBErrorChecking::DisplaySingleError(hr, 
			"Execute SQL");
	}
}

void CADODialog::UpdateData(BOOL bSaveChangesToSet) {
	HRESULT hr;
	if (bSaveChangesToSet) {
		//Read From Screen
		GetDlgItemText(IDC_CODE, m_DepartmentCode, 5);
		GetDlgItemText(IDC_NAME, m_DepartmentName, 51);
		//Place data in database fields
		hr = SetFields();
		if (FAILED(hr)) {
			COLEDBErrorChecking::DisplaySingleError(hr, "SaveDepartment SetFields");
		}
	}
	else {
		//Write to Screen
		//Take data from database fields
		hr = GetFields();	
		if (FAILED(hr)) {
			COLEDBErrorChecking::DisplaySingleError(hr, "OnMove GetFields");
			DisplayStatus("No records found.");
		}
		SetDlgItemText(IDC_CODE, m_DepartmentCode);
		SetDlgItemText(IDC_NAME, m_DepartmentName);
	}
}

HRESULT CADODialog::SaveChanges() {
	UpdateData(TRUE);	//Read from screen
	//Update database from fields
	HRESULT hr = m_pSet->Update(m_varNoVariant, m_varNoVariant);
	if (FAILED(hr)) {
		COLEDBErrorChecking::DisplaySingleError(hr, "SaveDepartment Update");
	}
	return hr;
}

void CADODialog::DisplayStatus(char *strMessage)
{
	//Send a message to the status line in the dialog box
	SetDlgItemText(IDC_STATUS, strMessage);
}

void CADODialog::ADOMove(ADOMoveEnum position, BOOL SaveFirst) {
	//This function is called by other move functions
	HRESULT hr;
	VARIANT_BOOL vb;
	if (SaveFirst) {
//Don't save deleted records or on your first time through
		hr = SaveChanges();	//Save changes
		if (FAILED(hr)) {
			DisplayStatus("Save failed.  Can't move off this record.");
			return;		//End if save did not work.
		}
	}
	DisplayStatus("");
	switch (position) {
		case (FIRST) :	//first record
			hr = m_pSet->MoveFirst();
			break;
		case (NEXT) :	//next record
			hr = m_pSet->MoveNext();
			m_pSet->get_EOF(&vb);
			if (vb) {
				//EOF.  No more records
				DisplayStatus("Last record reached.");
				hr = m_pSet->MoveLast();
			}
			break;
		case (LAST) :	//last record
			hr = m_pSet->MoveLast();
			break;
		case (PREV) :	//previous record
			hr = m_pSet->MovePrevious();
			m_pSet->get_BOF(&vb);
			if (vb) {
				//BOF.  No previous records
				DisplayStatus("First record reached.");
				hr = m_pSet->MoveFirst();
			}
			break;
	}
	if (FAILED(hr)) {
		COLEDBErrorChecking::DisplaySingleError(hr, "OnMove Move");
		DisplayStatus("No records found.");
		return;
	}
	UpdateData(FALSE);	//Update Screen
}

HRESULT CADODialog::GetFields() {
	CComPtr<ADOFields> pFields = NULL;	//Fields Container
	CComPtr<ADOField> pDeptCode = NULL;	//Individual Field
	CComPtr<ADOField> pDeptName = NULL;	//Individual Field
	CComVariant varValue; // Variant set to zero
//Get all the fields in the Fields container
	HRESULT hr = m_pSet->get_Fields(&pFields);
	if (FAILED(hr)) return hr;
//Get the DepartmentCode Field (Field 0)
	hr = pFields->get_Item(CComVariant(0), &pDeptCode);
	if (FAILED(hr)) return hr;
//Get the value of the DepartmentCode field
	hr = pDeptCode->get_Value(&varValue);
	if (FAILED(hr)) return hr;
//Assign Variant to Department Code
	sprintf(m_DepartmentCode, "%S", varValue.bstrVal);
//Get the DepartmentName Field (Field 1)
	hr = pFields->get_Item(CComVariant(1), &pDeptName);
	if (FAILED(hr)) return hr;
//Get the value of the DepartmentName field
	hr = pDeptName->get_Value(&varValue);
	if (FAILED(hr)) return hr;
//Assign Variant to Department Name
	sprintf(m_DepartmentName, "%S", varValue.bstrVal);
	return hr;
}

HRESULT CADODialog::SetFields() {
	CComPtr<ADOFields> pFields = NULL;
	CComPtr<ADOField> pDeptCode = NULL;	//Individual Field
	CComPtr<ADOField> pDeptName = NULL;	//Individual Field

//Get all the fields
	HRESULT hr = m_pSet->get_Fields(&pFields);
	if (FAILED(hr)) return hr;

//Get the DepartmentCode Field (Field 0)
	hr = pFields->get_Item(CComVariant(0), &pDeptCode);
	if (FAILED(hr)) return hr;
//Set the value of the DepartmentCode field
	hr = pDeptCode->put_Value(CComVariant(m_DepartmentCode));
	if (FAILED(hr)) return hr;

//Get the DepartmentName Field (Field 1)
	hr = pFields->get_Item(CComVariant(1), &pDeptName);
	if (FAILED(hr)) return hr;
//Set the value of the DepartmentName field
	return pDeptName->put_Value(CComVariant(m_DepartmentName));
}

