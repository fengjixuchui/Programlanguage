// OLEDBMFCMiscSet.cpp : implementation of the COLEDBMFCMiscSet class
//

#include "stdafx.h"
#include "OLEDBMFCMisc.h"
#include "OLEDBMFCMiscSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMiscSet implementation

HRESULT COLEDBMFCMiscSet::MoveNext(){
/*
	if (m_nCurrentRow >= 0 && m_nCurrentRow+1 < m_nCurrentRows) {
		// Get the data for the next row
		m_nCurrentRow++;
		m_hRow = m_phRow[m_nCurrentRow];
		return GetData();
	}
//	HRESULT HR = CTable<CAccessor<CRowDefinition>, CRowset >
*/
	HRESULT HR = CTable<CAccessor<CRowDefinition>, CBulkRowset >
		::MoveNext();
	return HR;
}

void COLEDBMFCMiscSet::DisplayColumnInfo(){
	ULONG ulColumns;			//Number of columns
	DBCOLUMNINFO *pColumnInfo;	//Arrow of column information
	LPOLESTR pColumnNames;		//Array of column names
	char strDisplay[500];		//String to display

	GetColumnInfo(&ulColumns,&pColumnInfo, &pColumnNames);
	sprintf(strDisplay, "The number of columns is %d\n\n", ulColumns-1);
	strcat(strDisplay, "The columns are:");
	for (ULONG loop = 1; loop < ulColumns; loop++) {
	char mbstr[50];		//String for w_str conversion
		char strType[50];
		strcpy(mbstr, "");	//Initialize string		
		if (pColumnInfo[loop].pwszName) {
			wcstombs(mbstr, pColumnInfo[loop].pwszName, 50);
		}
		sprintf(strDisplay, "%s\n  %d) %-30s %s [%d]",
			strDisplay, loop, 
			mbstr,
			getType(pColumnInfo[loop].wType, strType),
			pColumnInfo[loop].ulColumnSize);
		if (pColumnInfo[loop].bPrecision != 255) {
			if (pColumnInfo[loop].bScale != 255) {
				sprintf (strDisplay, "%s(%d.%d)",
					strDisplay,
					pColumnInfo[loop].bPrecision,
					pColumnInfo[loop].bScale);
			}
			else {
				sprintf (strDisplay, "%s(%d)",
					strDisplay,
					pColumnInfo[loop].bPrecision);
			}
		}
	}
	::MessageBox(NULL, strDisplay, "Column Information", MB_OK);
}

char *COLEDBMFCMiscSet::getType(DBTYPE wType, char *strType) {
	strcpy(strType, "");
    //Test for type without reference, array, or vector
    switch (wType& ~(DBTYPE_BYREF | DBTYPE_ARRAY | DBTYPE_VECTOR)){
		case DBTYPE_BOOL:
			strcpy(strType, "boolean ");
			break;
		case DBTYPE_BSTR:
			strcpy(strType, "wide-character string (BSTR)");
			break;
		case DBTYPE_BYTES:
			strcpy(strType, "byte array ");
			break;
		case DBTYPE_CY:
			strcpy(strType, "currency ");
			break;
		case DBTYPE_DATE:
			strcpy(strType, "date ");
			break;
		case DBTYPE_DBDATE:
			strcpy(strType, "DBDATE ");
			break;
		case DBTYPE_DBTIME:
			strcpy(strType, "DBTIME ");
			break;
		case DBTYPE_DBTIMESTAMP:
			strcpy(strType, "DBTIMESTAMP ");
			break;
		case DBTYPE_DECIMAL:
			strcpy(strType, "Decimal ");
			break;
		case DBTYPE_ERROR:
			strcpy(strType, "32-bit error code ");
			break;
		case DBTYPE_FILETIME:
			strcpy(strType, "FILETIME (100-nanoseconds since 1/1/1601 ");
			break;
		case DBTYPE_GUID:
			strcpy(strType, "GUID (globally unique identifier)");
			break;
		case DBTYPE_HCHAPTER:
			strcpy(strType, "4-byte chapter ");
			break;
		case DBTYPE_I1:
			strcpy(strType, "one-byte signed integer ");
			break;
		case DBTYPE_I2:
			strcpy(strType, "2-byte integer ");
			break;
		case DBTYPE_I4:
			strcpy(strType, "4-byte integer ");
			break;
		case DBTYPE_I8:
			strcpy(strType, "eight byte signed integer ");
			break;
		case DBTYPE_IDISPATCH:
			strcpy(strType, "OLE  IDispatch interface pointer ");
			break;
		case DBTYPE_IUNKNOWN:
			strcpy(strType, " OLE  IUnknown interface pointer  ");
			break;
		case DBTYPE_NULL:
			strcpy(strType, "null ");
			break;
		case DBTYPE_NUMERIC:
			strcpy(strType, "numeric ");
			break;
		case DBTYPE_PROPVARIANT:
			strcpy(strType, "PROPVARIANT ");
			break;
		case DBTYPE_R4:
			strcpy(strType, "single-precision floating point ");
			break;
		case DBTYPE_R8:
			strcpy(strType, "double-precision floating point ");
			break;
		case DBTYPE_RESERVED:
			strcpy(strType, "reserved (unknown)");
			break;
		case DBTYPE_STR:
			strcpy(strType, "char * ");
			break;
		case DBTYPE_UDT:
			strcpy(strType, "user-defined data type ");
			break;
		case DBTYPE_UI1:
			strcpy(strType, "one-byte unsigned integer ");
			break;
		case DBTYPE_UI2:
			strcpy(strType, "two-byte unsigned integer ");
			break;
		case DBTYPE_UI4:
			strcpy(strType, "four byte unsigned integer ");
			break;
		case DBTYPE_UI8:
			strcpy(strType, "eight byte unsigned integer ");
			break;
		case DBTYPE_VARIANT:
			strcpy(strType, "VARIANT ");
			break;
		case DBTYPE_VARNUMERIC:
			strcpy(strType, "DB_VARNUMERIC ");
			break;
		case DBTYPE_WSTR:
			strcpy(strType, "unicode string (wchar_t)");
	} //End Switch
	if (wType & DBTYPE_ARRAY)
		strcat (strType, "SAFEARRAY pointer ");
	if (wType & DBTYPE_BYREF)
		strcat (strType, "(by reference)");
	if (wType & DBTYPE_VECTOR)
		strcat (strType, "DBVECTOR structure ");
	return strType;
}
