// OLEDBMFCMiscDoc.cpp : implementation of the COLEDBMFCMiscDoc class
//

#include "stdafx.h"
#include "OLEDBMFCMisc.h"

#include "OLEDBMFCMiscSet.h"
#include "OLEDBMFCMiscDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMiscDoc

IMPLEMENT_DYNCREATE(COLEDBMFCMiscDoc, CDocument)

BEGIN_MESSAGE_MAP(COLEDBMFCMiscDoc, CDocument)
	//{{AFX_MSG_MAP(COLEDBMFCMiscDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMiscDoc construction/destruction

COLEDBMFCMiscDoc::COLEDBMFCMiscDoc()
{
}

COLEDBMFCMiscDoc::~COLEDBMFCMiscDoc()
{
}

BOOL COLEDBMFCMiscDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMiscDoc diagnostics

#ifdef _DEBUG
void COLEDBMFCMiscDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void COLEDBMFCMiscDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMiscDoc commands
