// OLEDBMFCMiscView.h : interface of the COLEDBMFCMiscView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBMFCMISCVIEW_H__7DEAF56C_AEF0_11D2_9949_C0D1E9AACF44__INCLUDED_)
#define AFX_OLEDBMFCMISCVIEW_H__7DEAF56C_AEF0_11D2_9949_C0D1E9AACF44__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class COLEDBMFCMiscSet;

class COLEDBMFCMiscView : public COleDBRecordView
{
protected: // create from serialization only
	COLEDBMFCMiscView();
	DECLARE_DYNCREATE(COLEDBMFCMiscView)

public:
	//{{AFX_DATA(COLEDBMFCMiscView)
	enum{ IDD = IDD_OLEDBMFCMISC_FORM };
	COLEDBMFCMiscSet* m_pSet;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	COLEDBMFCMiscDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBMFCMiscView)
	public:
	virtual CRowset* OnGetRowset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnMove(UINT nIDMoveCommand);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLEDBMFCMiscView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CBookmark<4> m_ViewBookmark;
// Generated message map functions
protected:
	//{{AFX_MSG(COLEDBMFCMiscView)
	afx_msg void OnRecordSetbookmark();
	afx_msg void OnRecordGotobookmark();
	afx_msg void OnRecordDisplayposition();
	afx_msg void OnRecordChangeaccessor();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in OLEDBMFCMiscView.cpp
inline COLEDBMFCMiscDoc* COLEDBMFCMiscView::GetDocument()
   { return (COLEDBMFCMiscDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBMFCMISCVIEW_H__7DEAF56C_AEF0_11D2_9949_C0D1E9AACF44__INCLUDED_)
