// OLEDBMFCMiscSet.h : interface of the COLEDBMFCMiscSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBMFCMISCSET_H__7DEAF56E_AEF0_11D2_9949_C0D1E9AACF44__INCLUDED_)
#define AFX_OLEDBMFCMISCSET_H__7DEAF56E_AEF0_11D2_9949_C0D1E9AACF44__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "..\OLEDBErrorChecking\OLEDBErrorChecking.h"

class CRowDefinition
{
public:
	CRowDefinition()
	{
		memset( (void*)this, 0, sizeof(*this) );
	};

	CBookmark<4> m_RowsetBookmark;   // Added by CW for bookmarks
	char m_strDepartmentCode[5];
	char m_strDepartmentName[51];


BEGIN_COLUMN_MAP(CRowDefinition)
        BOOKMARK_ENTRY(m_RowsetBookmark)   // Added by CW for bookmarks
		COLUMN_ENTRY_TYPE(1, DBTYPE_STR, m_strDepartmentCode)
		COLUMN_ENTRY_TYPE(2, DBTYPE_STR, m_strDepartmentName)
END_COLUMN_MAP()
};

//class COLEDBMFCMiscSet : public CTable<CAccessor<CRowDefinition>, CRowset >
class COLEDBMFCMiscSet : public CTable<CAccessor<CRowDefinition>, CBulkRowset>
{
public:
	ULONG m_lRecordInAccessor;
	HRESULT MoveNext();
	void DisplayColumnInfo();
	char *getType(DBTYPE wType, char* strType);
	HRESULT Open()
	{
		CDataSource db;
		CSession	session;
		HRESULT		hr;

		m_lRecordInAccessor = 0;
		CDBPropSet	dbinit(DBPROPSET_DBINIT);
		dbinit.AddProperty(DBPROP_AUTH_PERSIST_SENSITIVE_AUTHINFO, false);
		dbinit.AddProperty(DBPROP_INIT_DATASOURCE, "Classes");
		dbinit.AddProperty(DBPROP_INIT_PROMPT, (short)4);
		dbinit.AddProperty(DBPROP_INIT_LCID, (long)1033);
		hr = db.OpenWithServiceComponents("MSDASQL.1", &dbinit);
		if (FAILED(hr))
			return hr;

		hr = session.Open(db);
		if (FAILED(hr))
			return hr;

		CDBPropSet	propset(DBPROPSET_ROWSET);
		propset.AddProperty(DBPROP_CANFETCHBACKWARDS, true);
		propset.AddProperty(DBPROP_IRowsetScroll, true);
		propset.AddProperty(DBPROP_IRowsetChange, true);
		propset.AddProperty(DBPROP_UPDATABILITY, DBPROPVAL_UP_CHANGE | DBPROPVAL_UP_INSERT | DBPROPVAL_UP_DELETE );
//Added by Chuck Wood for bookmark support
        propset.AddProperty(DBPROP_BOOKMARKS, true);

		//Set the number of records in the CBulkRowset
		SetRows(3);
//		hr = CTable<CAccessor<CRowDefinition>, CBulkRowset >::Open(session, "Grades", &propset);
		hr = CTable<CAccessor<CRowDefinition>, CBulkRowset >::Open(session, "Department", &propset);
//		hr = CTable<CAccessor<CRowDefinition>, CRowset>::Open(session, "Department", &propset);
		if (FAILED(hr))
			return hr;

		return MoveNext();
	}
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBMFCMISCSET_H__7DEAF56E_AEF0_11D2_9949_C0D1E9AACF44__INCLUDED_)

