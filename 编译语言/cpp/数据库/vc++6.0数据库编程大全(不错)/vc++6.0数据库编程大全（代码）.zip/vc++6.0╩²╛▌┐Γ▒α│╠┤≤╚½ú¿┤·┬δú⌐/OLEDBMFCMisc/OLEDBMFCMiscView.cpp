// OLEDBMFCMiscView.cpp : implementation of the COLEDBMFCMiscView class
//

#include "stdafx.h"
#include "OLEDBMFCMisc.h"

#include "OLEDBMFCMiscSet.h"
#include "OLEDBMFCMiscDoc.h"
#include "OLEDBMFCMiscView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMiscView

IMPLEMENT_DYNCREATE(COLEDBMFCMiscView, COleDBRecordView)

BEGIN_MESSAGE_MAP(COLEDBMFCMiscView, COleDBRecordView)
	//{{AFX_MSG_MAP(COLEDBMFCMiscView)
	ON_COMMAND(ID_RECORD_SETBOOKMARK, OnRecordSetbookmark)
	ON_COMMAND(ID_RECORD_GOTOBOOKMARK, OnRecordGotobookmark)
	ON_COMMAND(ID_RECORD_DISPLAYPOSITION, OnRecordDisplayposition)
	ON_COMMAND(ID_RECORD_CHANGEACCESSOR, OnRecordChangeaccessor)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMiscView construction/destruction

COLEDBMFCMiscView::COLEDBMFCMiscView()
	: COleDBRecordView(COLEDBMFCMiscView::IDD)
{
	//{{AFX_DATA_INIT(COLEDBMFCMiscView)
		// NOTE: the ClassWizard will add member initialization here
	m_pSet = NULL;
	//}}AFX_DATA_INIT
}

COLEDBMFCMiscView::~COLEDBMFCMiscView()
{
}

void COLEDBMFCMiscView::DoDataExchange(CDataExchange* pDX)
{
	COleDBRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COLEDBMFCMiscView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_COLUMN1, m_pSet->m_strDepartmentCode, 51);
	DDX_Text(pDX, IDC_COLUMN2, m_pSet->m_strDepartmentName, 51);
}

BOOL COLEDBMFCMiscView::PreCreateWindow(CREATESTRUCT& cs)
{
	return COleDBRecordView::PreCreateWindow(cs);
}

void COLEDBMFCMiscView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_oLEDBMFCMiscSet;
	{
		CWaitCursor wait;
		HRESULT hr = m_pSet->Open();
		if (hr != S_OK)
		{

			COLEDBErrorChecking::DisplayHRRESULTMessage(hr, "Open");
//			AfxMessageBox(_T("Record set failed to open."), MB_OK);
			m_bOnFirstRecord = TRUE;
			m_bOnLastRecord = TRUE;
		}				
	}
	COleDBRecordView::OnInitialUpdate();

}

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMiscView diagnostics

#ifdef _DEBUG
void COLEDBMFCMiscView::AssertValid() const
{
	COleDBRecordView::AssertValid();
}

void COLEDBMFCMiscView::Dump(CDumpContext& dc) const
{
	COleDBRecordView::Dump(dc);
}

COLEDBMFCMiscDoc* COLEDBMFCMiscView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(COLEDBMFCMiscDoc)));
	return (COLEDBMFCMiscDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMiscView database support
CRowset* COLEDBMFCMiscView::OnGetRowset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMiscView message handlers

//Added by Chuck Wood
//I had to capture the OnMove for the bulk processing
BOOL COLEDBMFCMiscView::OnMove(UINT nIDMoveCommand) 
{
	if (nIDMoveCommand == ID_RECORD_NEXT) {
		UpdateData(TRUE);
		m_pSet->MoveNext();
		UpdateData(FALSE);
		return TRUE;
	}
	else 
		return COleDBRecordView::OnMove(nIDMoveCommand);
}
//Bookmark processing added by Chuck Wood
void COLEDBMFCMiscView::OnRecordSetbookmark() 
{
	//Assign the current row's bookmark to the 
	//view bookmark
	m_ViewBookmark = m_pSet->m_RowsetBookmark;
}

void COLEDBMFCMiscView::OnRecordGotobookmark() 
{
	//Go to the view bookmark and update the window
	m_pSet->MoveToBookmark(m_ViewBookmark);
	UpdateData(FALSE);
}

void COLEDBMFCMiscView::OnRecordDisplayposition() 
{
	//Display the current record
	CBookmark<4> tempBookmark;
	ULONG ulCurrentRow;
	ULONG ulTotalRows;
	char strDisplay[50];		//String to display
	
	tempBookmark = m_pSet->m_RowsetBookmark;
	m_pSet->GetApproximatePosition(&tempBookmark, 
		&ulCurrentRow, &ulTotalRows);
	sprintf(strDisplay, "You are at row %d out of %d total rows",
		ulCurrentRow, ulTotalRows);
	MessageBox(strDisplay, "Column Information");
}

void COLEDBMFCMiscView::OnRecordChangeaccessor() 
{
/*
	ULONG numAccessors = GetNumAccessors();
	if (m_lRecordInAccessor < 1 &&
		numAccessors <= m_lRecordInAccessor) {
		m_lRecordInAccessor = 1;
		return CCommand<CAccessor<CRowDefinition>, CRowset, CMultipleReoords >
			::MoveNext();
	}
	else {
		m_lRecordInAccessor++;
		return GetDataHere(m_lRecordInAccessor, this);
	}
*/
}
