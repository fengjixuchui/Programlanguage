// OLEDBMFCMisc.h : main header file for the OLEDBMFCMISC application
//

#if !defined(AFX_OLEDBMFCMISC_H__7DEAF564_AEF0_11D2_9949_C0D1E9AACF44__INCLUDED_)
#define AFX_OLEDBMFCMISC_H__7DEAF564_AEF0_11D2_9949_C0D1E9AACF44__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMiscApp:
// See OLEDBMFCMisc.cpp for the implementation of this class
//

class COLEDBMFCMiscApp : public CWinApp
{
public:
	COLEDBMFCMiscApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBMFCMiscApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(COLEDBMFCMiscApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBMFCMISC_H__7DEAF564_AEF0_11D2_9949_C0D1E9AACF44__INCLUDED_)
