// OLEDBMFCMiscDoc.h : interface of the COLEDBMFCMiscDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBMFCMISCDOC_H__7DEAF56A_AEF0_11D2_9949_C0D1E9AACF44__INCLUDED_)
#define AFX_OLEDBMFCMISCDOC_H__7DEAF56A_AEF0_11D2_9949_C0D1E9AACF44__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "OLEDBMFCMiscSet.h"


class COLEDBMFCMiscDoc : public CDocument
{
protected: // create from serialization only
	COLEDBMFCMiscDoc();
	DECLARE_DYNCREATE(COLEDBMFCMiscDoc)

// Attributes
public:
	COLEDBMFCMiscSet m_oLEDBMFCMiscSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBMFCMiscDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLEDBMFCMiscDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COLEDBMFCMiscDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBMFCMISCDOC_H__7DEAF56A_AEF0_11D2_9949_C0D1E9AACF44__INCLUDED_)
