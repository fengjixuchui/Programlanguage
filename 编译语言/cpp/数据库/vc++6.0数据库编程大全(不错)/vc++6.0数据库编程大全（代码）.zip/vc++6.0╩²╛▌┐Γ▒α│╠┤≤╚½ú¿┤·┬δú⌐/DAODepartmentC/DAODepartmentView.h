// DAODepartmentView.h : interface of the CDAODepartmentView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DAODEPARTMENTVIEW_H__C75F6EEC_943A_11D2_9949_E8E2006C6048__INCLUDED_)
#define AFX_DAODEPARTMENTVIEW_H__C75F6EEC_943A_11D2_9949_E8E2006C6048__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDAODepartmentSet;

class CDAODepartmentView : public CDaoRecordView
{
protected: // create from serialization only
	BOOL m_bChangesMade;
	CDAODepartmentView();
	DECLARE_DYNCREATE(CDAODepartmentView)

public:
	//{{AFX_DATA(CDAODepartmentView)
	enum { IDD = IDD_DAODEPARTMENT_FORM };
	CDAODepartmentSet* m_pSet;
	CString	m_FindDeptCode;
	//}}AFX_DATA

// Attributes
public:
	CDAODepartmentDoc* GetDocument();
// Operations
public:
	void SaveData();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDAODepartmentView)
	public:
	virtual CDaoRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnMove(UINT nIDMoveCommand);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDAODepartmentView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDAODepartmentView)
	afx_msg void OnFileNew();
	afx_msg void OnRecordDeleterecord();
	afx_msg void OnUpdateRecordDeleterecord(CCmdUI* pCmdUI);
	afx_msg void OnRecordQueryrecord();
	afx_msg void OnFileSave();
	afx_msg void OnUpdateFileSave(CCmdUI* pCmdUI);
	afx_msg void OnChangeDepartmentcode();
	afx_msg void OnChangeDepartmentname();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DAODepartmentView.cpp
inline CDAODepartmentDoc* CDAODepartmentView::GetDocument()
   { return (CDAODepartmentDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAODEPARTMENTVIEW_H__C75F6EEC_943A_11D2_9949_E8E2006C6048__INCLUDED_)
