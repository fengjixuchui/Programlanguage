// OLEDBDepartmentMFCDoc.cpp : implementation of the COLEDBDepartmentMFCDoc class
//

#include "stdafx.h"
#include "OLEDBDepartmentMFC.h"

#include "OLEDBDepartmentMFCSet.h"
#include "OLEDBDepartmentMFCDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCDoc

IMPLEMENT_DYNCREATE(COLEDBDepartmentMFCDoc, CDocument)

BEGIN_MESSAGE_MAP(COLEDBDepartmentMFCDoc, CDocument)
	//{{AFX_MSG_MAP(COLEDBDepartmentMFCDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCDoc construction/destruction

COLEDBDepartmentMFCDoc::COLEDBDepartmentMFCDoc()
{
}

COLEDBDepartmentMFCDoc::~COLEDBDepartmentMFCDoc()
{
}

BOOL COLEDBDepartmentMFCDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCDoc diagnostics

#ifdef _DEBUG
void COLEDBDepartmentMFCDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void COLEDBDepartmentMFCDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCDoc commands
