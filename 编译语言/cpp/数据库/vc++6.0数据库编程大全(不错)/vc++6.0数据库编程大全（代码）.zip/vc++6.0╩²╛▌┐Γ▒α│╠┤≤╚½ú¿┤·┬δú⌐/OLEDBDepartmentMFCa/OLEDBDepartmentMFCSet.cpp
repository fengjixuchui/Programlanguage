// OLEDBDepartmentMFCSet.cpp : implementation of the COLEDBDepartmentMFCSet class
//

#include "stdafx.h"
#include "OLEDBDepartmentMFC.h"
#include "OLEDBDepartmentMFCSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCSet implementation

