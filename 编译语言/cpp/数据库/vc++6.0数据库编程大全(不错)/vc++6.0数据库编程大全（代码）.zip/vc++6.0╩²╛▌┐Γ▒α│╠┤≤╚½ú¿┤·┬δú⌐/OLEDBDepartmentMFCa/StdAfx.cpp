// stdafx.cpp : source file that includes just the standard includes
//	OLEDBDepartmentMFC.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


CComModule _Module;
#include <atlimpl.cpp>

