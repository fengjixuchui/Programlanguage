// OLEDBDepartmentMFCView.cpp : implementation of the COLEDBDepartmentMFCView class
//

#include "stdafx.h"
#include "OLEDBDepartmentMFC.h"

#include "OLEDBDepartmentMFCSet.h"
#include "OLEDBDepartmentMFCDoc.h"
#include "OLEDBDepartmentMFCView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCView

IMPLEMENT_DYNCREATE(COLEDBDepartmentMFCView, COleDBRecordView)

BEGIN_MESSAGE_MAP(COLEDBDepartmentMFCView, COleDBRecordView)
	//{{AFX_MSG_MAP(COLEDBDepartmentMFCView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCView construction/destruction

COLEDBDepartmentMFCView::COLEDBDepartmentMFCView()
	: COleDBRecordView(COLEDBDepartmentMFCView::IDD)
{
	//{{AFX_DATA_INIT(COLEDBDepartmentMFCView)
		// NOTE: the ClassWizard will add member initialization here
	m_pSet = NULL;
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

COLEDBDepartmentMFCView::~COLEDBDepartmentMFCView()
{
}

void COLEDBDepartmentMFCView::DoDataExchange(CDataExchange* pDX)
{
	COleDBRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COLEDBDepartmentMFCView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_DEPARTMENTCODE, m_pSet->m_DepartmentCode, 5);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentCode, 4);
	DDX_Text(pDX, IDC_DEPARTMENTNAME, m_pSet->m_DepartmentName, 51);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentName, 51);
}

BOOL COLEDBDepartmentMFCView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return COleDBRecordView::PreCreateWindow(cs);
}

void COLEDBDepartmentMFCView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_oLEDBDepartmentMFCSet;
	{
		CWaitCursor wait;
		HRESULT hr = m_pSet->Open();
		if (hr != S_OK)
		{
			AfxMessageBox(_T("Record set failed to open."), MB_OK);
			// Disable the Next and Previous record commands,
			// since attempting to change the current record without an
			// open RecordSet will cause a crash.
			m_bOnFirstRecord = TRUE;
			m_bOnLastRecord = TRUE;
		}				
	}
	COleDBRecordView::OnInitialUpdate();

}

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCView diagnostics

#ifdef _DEBUG
void COLEDBDepartmentMFCView::AssertValid() const
{
	COleDBRecordView::AssertValid();
}

void COLEDBDepartmentMFCView::Dump(CDumpContext& dc) const
{
	COleDBRecordView::Dump(dc);
}

COLEDBDepartmentMFCDoc* COLEDBDepartmentMFCView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(COLEDBDepartmentMFCDoc)));
	return (COLEDBDepartmentMFCDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCView database support
CRowset* COLEDBDepartmentMFCView::OnGetRowset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// COLEDBDepartmentMFCView message handlers
