// OLEDBDepartmentMFCSet.h : interface of the COLEDBDepartmentMFCSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBDEPARTMENTMFCSET_H__3D2A236F_4C1D_11D2_9949_D84454558644__INCLUDED_)
#define AFX_OLEDBDEPARTMENTMFCSET_H__3D2A236F_4C1D_11D2_9949_D84454558644__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDepartment
{
public:
	CDepartment()
	{
		memset( (void*)this, 0, sizeof(*this) );
	};

	char m_DepartmentCode[5];
	char m_DepartmentName[51];


BEGIN_COLUMN_MAP(CDepartment)
		COLUMN_ENTRY_TYPE(1, DBTYPE_STR, m_DepartmentCode)
		COLUMN_ENTRY_TYPE(2, DBTYPE_STR, m_DepartmentName)
END_COLUMN_MAP()

};

class COLEDBDepartmentMFCSet : public CCommand<CAccessor<CDepartment> >
{
public:

	HRESULT Open()
	{
		CDataSource db;
		CSession	session;
		HRESULT		hr;

		CDBPropSet	dbinit(DBPROPSET_DBINIT);
		dbinit.AddProperty(DBPROP_AUTH_CACHE_AUTHINFO, true);
		dbinit.AddProperty(DBPROP_AUTH_ENCRYPT_PASSWORD, false);
		dbinit.AddProperty(DBPROP_AUTH_MASK_PASSWORD, false);
		dbinit.AddProperty(DBPROP_AUTH_PASSWORD, "");
		dbinit.AddProperty(DBPROP_AUTH_PERSIST_ENCRYPTED, false);
		dbinit.AddProperty(DBPROP_AUTH_PERSIST_SENSITIVE_AUTHINFO, false);
		dbinit.AddProperty(DBPROP_AUTH_USERID, "Admin");
		dbinit.AddProperty(DBPROP_INIT_DATASOURCE, "C:\\My Documents\\Visual C++\\Classes.mdb");
		dbinit.AddProperty(DBPROP_INIT_MODE, (long)16);
		dbinit.AddProperty(DBPROP_INIT_PROMPT, (short)4);
		dbinit.AddProperty(DBPROP_INIT_PROVIDERSTRING, ";COUNTRY=0;CP=1252;LANGID=0x0409");
		dbinit.AddProperty(DBPROP_INIT_LCID, (long)1033);

		hr = db.OpenWithServiceComponents("Microsoft.Jet.OLEDB.3.51", &dbinit);
		if (FAILED(hr))
			return hr;

		hr = session.Open(db);
		if (FAILED(hr))
			return hr;

		CDBPropSet	propset(DBPROPSET_ROWSET);
		propset.AddProperty(DBPROP_CANFETCHBACKWARDS, true);
		propset.AddProperty(DBPROP_IRowsetScroll, true);
		propset.AddProperty(DBPROP_IRowsetChange, true);
		propset.AddProperty(DBPROP_UPDATABILITY, DBPROPVAL_UP_CHANGE | DBPROPVAL_UP_INSERT | DBPROPVAL_UP_DELETE );

		hr = CCommand<CAccessor<CDepartment> >::Open(session, "SELECT * FROM Department", &propset);
		if (FAILED(hr))
			return hr;

		return MoveNext();
	}

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBDEPARTMENTMFCSET_H__3D2A236F_4C1D_11D2_9949_D84454558644__INCLUDED_)

