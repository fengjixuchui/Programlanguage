// DAODeptInst.h : main header file for the DAODEPTINST application
//

#if !defined(AFX_DAODEPTINST_H__D7B46FA5_9504_11D2_9949_983981A5C342__INCLUDED_)
#define AFX_DAODEPTINST_H__D7B46FA5_9504_11D2_9949_983981A5C342__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDAODeptInstApp:
// See DAODeptInst.cpp for the implementation of this class
//

class CDAODeptInstApp : public CWinApp
{
public:
	CDAODeptInstApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDAODeptInstApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CDAODeptInstApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAODEPTINST_H__D7B46FA5_9504_11D2_9949_983981A5C342__INCLUDED_)
