// DAODeptInstDoc.h : interface of the CDAODeptInstDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DAODEPTINSTDOC_H__D7B46FAB_9504_11D2_9949_983981A5C342__INCLUDED_)
#define AFX_DAODEPTINSTDOC_H__D7B46FAB_9504_11D2_9949_983981A5C342__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "DAODeptInstSet.h"


class CDAODeptInstDoc : public CDocument
{
protected: // create from serialization only
	CDAODeptInstDoc();
	DECLARE_DYNCREATE(CDAODeptInstDoc)

// Attributes
public:
	CDAODeptInstSet m_dAODeptInstSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDAODeptInstDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDAODeptInstDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDAODeptInstDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAODEPTINSTDOC_H__D7B46FAB_9504_11D2_9949_983981A5C342__INCLUDED_)
