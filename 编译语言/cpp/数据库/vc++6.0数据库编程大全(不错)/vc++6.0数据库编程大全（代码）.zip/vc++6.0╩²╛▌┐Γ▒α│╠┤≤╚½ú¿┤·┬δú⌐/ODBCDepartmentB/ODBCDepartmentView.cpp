// ODBCDepartmentView.cpp : implementation of the CODBCDepartmentView class
//

#include "stdafx.h"
#include "ODBCDepartment.h"

#include "ODBCDepartmentSet.h"
#include "ODBCDepartmentDoc.h"
#include "ODBCDepartmentView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView

IMPLEMENT_DYNCREATE(CODBCDepartmentView, CRecordView)

BEGIN_MESSAGE_MAP(CODBCDepartmentView, CRecordView)
	//{{AFX_MSG_MAP(CODBCDepartmentView)
	ON_COMMAND(ID_RECORD_ADDRECORD, OnRecordAddrecord)
	ON_COMMAND(ID_RECORD_DELETERECORD, OnRecordDeleterecord)
	ON_COMMAND(ID_RECORD_QUERYRECORD, OnRecordQueryrecord)
	ON_UPDATE_COMMAND_UI(ID_RECORD_DELETERECORD, OnUpdateRecordDeleterecord)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView construction/destruction

CODBCDepartmentView::CODBCDepartmentView()
	: CRecordView(CODBCDepartmentView::IDD)
{
	//{{AFX_DATA_INIT(CODBCDepartmentView)
	m_pSet = NULL;
	m_FindDeptCode = _T("");
	//}}AFX_DATA_INIT
	m_bAddingRecord = FALSE;
}

CODBCDepartmentView::~CODBCDepartmentView()
{
}

void CODBCDepartmentView::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CODBCDepartmentView)
	DDX_FieldText(pDX, IDC_DEPARTMENTCODE, m_pSet->m_DepartmentCode, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentCode, 4);
	DDX_FieldText(pDX, IDC_DEPARTMENTNAME, m_pSet->m_DepartmentName, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentName, 50);
	DDX_Text(pDX, IDC_FINDCODE, m_FindDeptCode);
	DDV_MaxChars(pDX, m_FindDeptCode, 4);
	//}}AFX_DATA_MAP
}

BOOL CODBCDepartmentView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CRecordView::PreCreateWindow(cs);
}

void CODBCDepartmentView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_oDBCDepartmentSet;
	CRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView diagnostics

#ifdef _DEBUG
void CODBCDepartmentView::AssertValid() const
{
	CRecordView::AssertValid();
}

void CODBCDepartmentView::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CODBCDepartmentDoc* CODBCDepartmentView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CODBCDepartmentDoc)));
	return (CODBCDepartmentDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView database support
CRecordset* CODBCDepartmentView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentView message handlers

BOOL CODBCDepartmentView::OnMove(UINT nIDMoveCommand) 
{
	if (m_bAddingRecord) {	//Currently adding?
		//If so, Update the record before the move
		UpdateData(TRUE);	//Get data from dialog box
		m_pSet->Update();	//Update data if needed
		m_pSet->MoveLast();	//Go to the added record
		m_bAddingRecord = FALSE;	//Reset flag
	}
	//Continue with normal processing
	return CRecordView::OnMove(nIDMoveCommand);
}

void CODBCDepartmentView::OnRecordAddrecord() 
{
	CRecordsetStatus rStatus;		//Status variable
	m_pSet->GetStatus(rStatus);		//Get CRecordset status
	if (rStatus.m_lCurrentRecord >= 0) {	//Records Exist?
		UpdateData(TRUE);	//Get data from dialog box
		if (!m_bAddingRecord) {	//Currently adding?
			//If not, set CRecordset in edit mode for updating
			m_pSet->Edit();		
		}
		m_pSet->Update();	//Update data if needed
		m_pSet->MoveLast();	//Get off record 1
	}
	m_bAddingRecord = TRUE;	//Set flag
	m_pSet->SetFieldNull(NULL);	//Clear all fields
	m_pSet->AddNew();	//Set database in AddNew mode
	UpdateData(FALSE);	//Update dialog box fields
}

void CODBCDepartmentView::OnRecordDeleterecord() 
{
	if (AfxMessageBox(	//Be sure to verify your deletes
			"Are you sure you want to delete?",
			MB_YESNO)
		!= IDYES) {
		return;
	}
	if (m_bAddingRecord) {	//Currently adding?
		//Don't delete, just cancel add.
		m_pSet->CancelUpdate();
		m_bAddingRecord = FALSE;
		m_pSet->MovePrev();
		return;
	}
	try {
		m_pSet->Delete();	//Delete record
	}
	catch(CDBException* e1) {	//Failed
		AfxMessageBox("Delete Failed:\n" +
			e1->m_strError,
			MB_ICONEXCLAMATION);
		m_pSet->MoveFirst();	//We lost our place.
		e1->Delete();		//Delete Error Message
		UpdateData(FALSE);	//Update dialog box fields
		return;
	}
	CRecordsetStatus rStatus;		//Status variable
	m_pSet->GetStatus(rStatus);		//Get CRecordset status
	try {
		m_pSet->MoveNext();			//Go to next record
		if (m_pSet->IsDeleted()) {	//Was there a next record?
			m_pSet->MoveFirst();	//Deleted last record
		}
		if (m_pSet->IsDeleted()) {	//Can't find a record
			AfxThrowDBException(SQL_ERROR, 
				m_pSet->m_pDatabase,
				m_pSet->m_hstmt);   
		}
		UpdateData(FALSE);	//Update dialog box fields
	}
	catch(CDBException* e2) {	//No records exist
		AfxMessageBox("No more records",
			MB_ICONEXCLAMATION);
		e2->Delete();		//Delete Error Message
		//Close and Open to get rid of the Deleted record
		m_pSet->Close();
		m_pSet->Open();
		//No records, so set up an add record
		OnRecordAddrecord();
	}
}

void CODBCDepartmentView::OnUpdateRecordDeleterecord(CCmdUI* pCmdUI) 
{
	//Disable delete functionality if no record is found
	pCmdUI->Enable(		//Enable delete if there's a record
		!m_pSet->IsBOF() &&
		!m_pSet->IsDeleted() &&
		!m_pSet->IsEOF());
}

void CODBCDepartmentView::OnRecordQueryrecord() 
{
	CString newFilter = "";	//Default is no filter
	UpdateData(TRUE);	//Get data from dialog box
	if (!m_bAddingRecord) {	//Currently adding?
		//Set to update
		m_pSet->Edit();		
	}
	m_pSet->Update();	//Update data if needed
	m_bAddingRecord = FALSE;	//Reset flag
	if (m_FindDeptCode != "") {
		//Setup new filter
		newFilter = "DepartmentCode = '" + m_FindDeptCode + "'";
	}
	if (newFilter != m_pSet->m_strFilter) {	//Filter has changed
		m_pSet->m_strFilter = newFilter;	//Assign new filter
		if (!m_pSet->Requery()) {			//Requery
			AfxMessageBox("Requery has failed");	//Error occurred
			m_pSet->m_strFilter = "";		//Try to get back
			m_pSet->Requery();				//Requery again
		}
		try {
			//Go to the first record of the new filtered recordset
			m_pSet->MoveFirst();
		}
		catch(CDBException* e)    {
			//Move failed because there are no records
			AfxMessageBox("No records were found", MB_ICONEXCLAMATION );
			e->Delete();		//Delete Error Message
			//No records, so set up an add record
			OnRecordAddrecord();
		}
	}
	UpdateData(FALSE);	//Update dialog box fields
}

