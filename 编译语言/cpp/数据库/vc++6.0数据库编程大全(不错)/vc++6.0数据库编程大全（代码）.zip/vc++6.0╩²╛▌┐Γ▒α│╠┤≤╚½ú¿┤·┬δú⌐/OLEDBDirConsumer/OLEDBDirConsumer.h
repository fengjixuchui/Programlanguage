// OLEDBDirConsumer.h : main header file for the OLEDBDIRCONSUMER application
//

#if !defined(AFX_OLEDBDIRCONSUMER_H__76BD4169_A1B6_11D2_9949_A3461EC15C47__INCLUDED_)
#define AFX_OLEDBDIRCONSUMER_H__76BD4169_A1B6_11D2_9949_A3461EC15C47__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// COLEDBDirConsumerApp:
// See OLEDBDirConsumer.cpp for the implementation of this class
//

class COLEDBDirConsumerApp : public CWinApp
{
public:
	COLEDBDirConsumerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBDirConsumerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(COLEDBDirConsumerApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBDIRCONSUMER_H__76BD4169_A1B6_11D2_9949_A3461EC15C47__INCLUDED_)
