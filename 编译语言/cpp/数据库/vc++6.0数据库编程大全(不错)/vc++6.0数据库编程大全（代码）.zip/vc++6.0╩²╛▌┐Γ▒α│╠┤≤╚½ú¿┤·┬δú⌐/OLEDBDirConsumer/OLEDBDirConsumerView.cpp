// OLEDBDirConsumerView.cpp : implementation of the COLEDBDirConsumerView class
//

#include "stdafx.h"
#include "OLEDBDirConsumer.h"

#include "OLEDBDirConsumerSet.h"
#include "OLEDBDirConsumerDoc.h"
#include "OLEDBDirConsumerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBDirConsumerView

IMPLEMENT_DYNCREATE(COLEDBDirConsumerView, COleDBRecordView)

BEGIN_MESSAGE_MAP(COLEDBDirConsumerView, COleDBRecordView)
	//{{AFX_MSG_MAP(COLEDBDirConsumerView)
	ON_EN_KILLFOCUS(IDC_DIRECTORY, OnKillfocusDirectory)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBDirConsumerView construction/destruction

COLEDBDirConsumerView::COLEDBDirConsumerView()
	: COleDBRecordView(COLEDBDirConsumerView::IDD)
{
	//{{AFX_DATA_INIT(COLEDBDirConsumerView)
	m_pSet = NULL;
	m_strDirectory = _T("");
	//}}AFX_DATA_INIT
}

COLEDBDirConsumerView::~COLEDBDirConsumerView()
{
}

void COLEDBDirConsumerView::DoDataExchange(CDataExchange* pDX)
{
	COleDBRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COLEDBDirConsumerView)
	DDX_Text(pDX, IDC_DIRECTORY, m_strDirectory);
	DDV_MaxChars(pDX, m_strDirectory, 260);
	//}}AFX_DATA_MAP
	//Added by Chuck Wood to link OLE DB Variables to text boxes
	DDX_Text(pDX, IDC_FILEATTRIBUTES, m_pSet->m_strFileAttributes, 7);
	DDX_Text(pDX, IDC_FILESIZE, m_pSet->m_nFileSize);
	DDX_Text(pDX, IDC_FILENAME, m_pSet->m_strFileName, 260);
	DDX_Text(pDX, IDC_SHORTFILENAME, m_pSet->m_strShortFileName, 14);
}

BOOL COLEDBDirConsumerView::PreCreateWindow(CREATESTRUCT& cs)
{
	return COleDBRecordView::PreCreateWindow(cs);
}

void COLEDBDirConsumerView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_oLEDBDirConsumerSet;
	{
		CWaitCursor wait;
		HRESULT hr = m_pSet->Open();
		if (hr != S_OK)
		{
			AfxMessageBox(_T("Record set failed to open."), MB_OK);
			m_bOnFirstRecord = TRUE;
			m_bOnLastRecord = TRUE;
		}				
	}
	//Added by Chuck Wood to initialize the directory
	m_strDirectory = m_pSet->GetDir();
	COleDBRecordView::OnInitialUpdate();

}

/////////////////////////////////////////////////////////////////////////////
// COLEDBDirConsumerView diagnostics

#ifdef _DEBUG
void COLEDBDirConsumerView::AssertValid() const
{
	COleDBRecordView::AssertValid();
}

void COLEDBDirConsumerView::Dump(CDumpContext& dc) const
{
	COleDBRecordView::Dump(dc);
}

COLEDBDirConsumerDoc* COLEDBDirConsumerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(COLEDBDirConsumerDoc)));
	return (COLEDBDirConsumerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBDirConsumerView database support
CRowset* COLEDBDirConsumerView::OnGetRowset()
{
	return m_pSet;
}

void COLEDBDirConsumerView::OnKillfocusDirectory() 
{
	UpdateData(TRUE);
	m_pSet->SetDir(m_strDirectory);
	UpdateData(FALSE);
}
