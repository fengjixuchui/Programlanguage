// OLEDBDirConsumerSet.h : interface of the COLEDBDirConsumerSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBDIRCONSUMERSET_H__76BD4173_A1B6_11D2_9949_A3461EC15C47__INCLUDED_)
#define AFX_OLEDBDIRCONSUMERSET_H__76BD4173_A1B6_11D2_9949_A3461EC15C47__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMy
{
public:
    CMy() 
    {
        memset( (void*)this, 0, sizeof(*this) );
    };
/*  Old Structure
    char m_column0[261];
    char m_column1[15];
    unsigned int m_column2;
    char m_column3[8];
*/
    char m_strFileName[261];
    char m_strShortFileName[15];
    unsigned int m_nFileSize;
    char m_strFileAttributes[8];

BEGIN_COLUMN_MAP(CMy)
/* Old map
    COLUMN_ENTRY_TYPE(1, DBTYPE_STR, m_column0)
    COLUMN_ENTRY_TYPE(2, DBTYPE_STR, m_column1)
    COLUMN_ENTRY_TYPE(3, DBTYPE_UI4, m_column2)
    COLUMN_ENTRY_TYPE(4, DBTYPE_STR, m_column3)
*/    
    COLUMN_ENTRY_TYPE(1, DBTYPE_STR, m_strFileName)
    COLUMN_ENTRY_TYPE(2, DBTYPE_STR, m_strShortFileName)
    COLUMN_ENTRY_TYPE(3, DBTYPE_UI4, m_nFileSize)
    COLUMN_ENTRY_TYPE(4, DBTYPE_STR, m_strFileAttributes)
END_COLUMN_MAP()
};

class COLEDBDirConsumerSet : public CCommand<CAccessor<CMy> >
{
protected:
	CString m_strDirectory;
public:
	COLEDBDirConsumerSet() {
		//Initialize directory
		m_strDirectory = _T("C:\\*.*");
	}
	void SetDir(CString dirName) {
		//Reset Directory
		if (dirName != GetDir()) {
			Close();
			m_strDirectory = dirName;
			Open();
		}
	}
	CString GetDir() {
		return m_strDirectory;
	}
	HRESULT Open()
	{
		CDataSource db;
		CSession	session;
		HRESULT		hr;

		CDBPropSet	dbinit(DBPROPSET_DBINIT);
		dbinit.AddProperty(DBPROP_AUTH_PASSWORD, "");
		dbinit.AddProperty(DBPROP_AUTH_PERSIST_SENSITIVE_AUTHINFO, false);
		dbinit.AddProperty(DBPROP_AUTH_USERID, "");
		dbinit.AddProperty(DBPROP_INIT_DATASOURCE, "");
		dbinit.AddProperty(DBPROP_INIT_LCID, (long)0);
		dbinit.AddProperty(DBPROP_INIT_LOCATION, "");
		dbinit.AddProperty(DBPROP_INIT_MODE, (long)0);
		dbinit.AddProperty(DBPROP_INIT_PROMPT, (short)2);
		dbinit.AddProperty(DBPROP_INIT_PROVIDERSTRING, "");
		dbinit.AddProperty(DBPROP_INIT_TIMEOUT, (long)0);

		hr = db.OpenWithServiceComponents("OLEDBDirProvider.DirProvider.1", &dbinit);
		if (FAILED(hr))
			return hr;

		hr = session.Open(db);
		if (FAILED(hr))
			return hr;

		CDBPropSet	propset(DBPROPSET_ROWSET);
		propset.AddProperty(DBPROP_CANFETCHBACKWARDS, true);
		propset.AddProperty(DBPROP_IRowsetScroll, true);
		propset.AddProperty(DBPROP_IRowsetChange, true);
//		propset.AddProperty(DBPROP_UPDATABILITY, DBPROPVAL_UP_CHANGE | DBPROPVAL_UP_INSERT | DBPROPVAL_UP_DELETE );
		hr = CCommand<CAccessor<CMy> >::Open(session, m_strDirectory, &propset);
		if (FAILED(hr))
			return hr;

		return MoveNext();
	}

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBDIRCONSUMERSET_H__76BD4173_A1B6_11D2_9949_A3461EC15C47__INCLUDED_)

