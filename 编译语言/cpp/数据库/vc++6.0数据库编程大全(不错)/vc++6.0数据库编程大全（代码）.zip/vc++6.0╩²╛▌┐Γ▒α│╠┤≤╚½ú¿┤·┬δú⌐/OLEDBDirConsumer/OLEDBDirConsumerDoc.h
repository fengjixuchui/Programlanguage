// OLEDBDirConsumerDoc.h : interface of the COLEDBDirConsumerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBDIRCONSUMERDOC_H__76BD416F_A1B6_11D2_9949_A3461EC15C47__INCLUDED_)
#define AFX_OLEDBDIRCONSUMERDOC_H__76BD416F_A1B6_11D2_9949_A3461EC15C47__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "OLEDBDirConsumerSet.h"


class COLEDBDirConsumerDoc : public CDocument
{
protected: // create from serialization only
	COLEDBDirConsumerDoc();
	DECLARE_DYNCREATE(COLEDBDirConsumerDoc)

// Attributes
public:
	COLEDBDirConsumerSet m_oLEDBDirConsumerSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBDirConsumerDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLEDBDirConsumerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COLEDBDirConsumerDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBDIRCONSUMERDOC_H__76BD416F_A1B6_11D2_9949_A3461EC15C47__INCLUDED_)
