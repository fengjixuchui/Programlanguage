// OLEDBDirConsumerDoc.cpp : implementation of the COLEDBDirConsumerDoc class
//

#include "stdafx.h"
#include "OLEDBDirConsumer.h"

#include "OLEDBDirConsumerSet.h"
#include "OLEDBDirConsumerDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBDirConsumerDoc

IMPLEMENT_DYNCREATE(COLEDBDirConsumerDoc, CDocument)

BEGIN_MESSAGE_MAP(COLEDBDirConsumerDoc, CDocument)
	//{{AFX_MSG_MAP(COLEDBDirConsumerDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBDirConsumerDoc construction/destruction

COLEDBDirConsumerDoc::COLEDBDirConsumerDoc()
{
}

COLEDBDirConsumerDoc::~COLEDBDirConsumerDoc()
{
}

BOOL COLEDBDirConsumerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// COLEDBDirConsumerDoc diagnostics

#ifdef _DEBUG
void COLEDBDirConsumerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void COLEDBDirConsumerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBDirConsumerDoc commands
