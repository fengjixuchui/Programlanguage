// OLEDBDirConsumerSet.cpp : implementation of the COLEDBDirConsumerSet class
//

#include "stdafx.h"
#include "OLEDBDirConsumer.h"
#include "OLEDBDirConsumerSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBDirConsumerSet implementation

