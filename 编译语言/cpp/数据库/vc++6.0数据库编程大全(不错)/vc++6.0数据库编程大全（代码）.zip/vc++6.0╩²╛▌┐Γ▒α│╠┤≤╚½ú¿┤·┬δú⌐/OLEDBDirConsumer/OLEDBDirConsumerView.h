// OLEDBDirConsumerView.h : interface of the COLEDBDirConsumerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBDIRCONSUMERVIEW_H__76BD4171_A1B6_11D2_9949_A3461EC15C47__INCLUDED_)
#define AFX_OLEDBDIRCONSUMERVIEW_H__76BD4171_A1B6_11D2_9949_A3461EC15C47__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class COLEDBDirConsumerSet;

class COLEDBDirConsumerView : public COleDBRecordView
{
protected: // create from serialization only
	COLEDBDirConsumerView();
	DECLARE_DYNCREATE(COLEDBDirConsumerView)

public:
	//{{AFX_DATA(COLEDBDirConsumerView)
	enum { IDD = IDD_OLEDBDIRCONSUMER_FORM };
	COLEDBDirConsumerSet* m_pSet;
	CString	m_strDirectory;
	//}}AFX_DATA

// Attributes
public:
	COLEDBDirConsumerDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBDirConsumerView)
	public:
	virtual CRowset* OnGetRowset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLEDBDirConsumerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COLEDBDirConsumerView)
	afx_msg void OnKillfocusDirectory();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in OLEDBDirConsumerView.cpp
inline COLEDBDirConsumerDoc* COLEDBDirConsumerView::GetDocument()
   { return (COLEDBDirConsumerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBDIRCONSUMERVIEW_H__76BD4171_A1B6_11D2_9949_A3461EC15C47__INCLUDED_)
