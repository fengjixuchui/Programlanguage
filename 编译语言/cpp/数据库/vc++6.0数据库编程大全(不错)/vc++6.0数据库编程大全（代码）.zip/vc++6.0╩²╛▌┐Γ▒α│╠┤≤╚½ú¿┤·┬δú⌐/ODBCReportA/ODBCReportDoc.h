// ODBCReportDoc.h : interface of the CODBCReportDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ODBCREPORTDOC_H__FA789B99_4121_11D2_9949_B5757778F646__INCLUDED_)
#define AFX_ODBCREPORTDOC_H__FA789B99_4121_11D2_9949_B5757778F646__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ODBCReportSet.h"

class CODBCReportDoc : public CDocument
{
protected: // create from serialization only
	CODBCReportDoc();
	DECLARE_DYNCREATE(CODBCReportDoc)

// Attributes
public:
	CODBCReportSet m_dbSet;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CODBCReportDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CODBCReportDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CODBCReportDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ODBCREPORTDOC_H__FA789B99_4121_11D2_9949_B5757778F646__INCLUDED_)
