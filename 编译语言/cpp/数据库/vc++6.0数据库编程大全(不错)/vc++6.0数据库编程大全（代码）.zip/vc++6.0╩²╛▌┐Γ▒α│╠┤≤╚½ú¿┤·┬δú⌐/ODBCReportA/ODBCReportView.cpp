// ODBCReportView.cpp : implementation of the CODBCReportView class
//

#include "stdafx.h"
#include "ODBCReport.h"

#include "ODBCReportDoc.h"
#include "ODBCReportView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CODBCReportView

IMPLEMENT_DYNCREATE(CODBCReportView, CScrollView)

BEGIN_MESSAGE_MAP(CODBCReportView, CScrollView)
	//{{AFX_MSG_MAP(CODBCReportView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CODBCReportView construction/destruction

CODBCReportView::CODBCReportView()
{
}

CODBCReportView::~CODBCReportView()
{
	m_pSet->Close();	//Close the recordset
}

BOOL CODBCReportView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CODBCReportView drawing

void CODBCReportView::OnDraw(CDC* pDC)
{
	CString line;	//This is the print line
	TEXTMETRIC metrics;	//Font measurements
	int y = 0;		//Current y position on report
	CFont TitleFont;	//Font for Title
	CFont HeadingFont;	//Font for headings
	CFont DetailFont;	//Font for detail lines
	//Tab stops at 1 inch, 2.5 inches, and 6.5 inches
	int TabStops[] = {100, 275, 650};

	//Set the recordset at the beginning
	m_pSet->Requery();
	//Bold font for Title
	TitleFont.CreateFont(44, 0, 0, 0, FW_BOLD, FALSE, FALSE, 0,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY, DEFAULT_PITCH | FF_ROMAN, 
		"Times New Roman");
	//Bold and underlined font for headings
	HeadingFont.CreateFont(36, 0, 0, 0, FW_BOLD, FALSE, TRUE, 0,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY, DEFAULT_PITCH | FF_ROMAN, 
		"Times New Roman");
	//Normal font for detail
	DetailFont.CreateFont(18, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY, DEFAULT_PITCH | FF_ROMAN, 
		"Times New Roman");
	//Capture default settings when setting the title font
	CFont* OldFont = pDC->SelectObject(&TitleFont);
	//Retrieve the heading font measurements
	pDC->GetTextMetrics(&metrics);
	//Compute the heading line height
	int LineHeight = metrics.tmHeight + metrics.tmExternalLeading;
	//Set Y to the line height.
	y -= LineHeight;	
	pDC->TextOut(200, 0, "ODBC Student Report");
/*
	Y must be set to negative numbers because MM_LOENGLISH was
	used in the CODBCReportView::OnInitialUpdate funciton.
*/
	//Set the Heading font
	pDC->SelectObject(&HeadingFont);
	//Format the heading
	line.Format("%s\t%s\t%s\t%s","Dept","Instructor","Class", "Student");
	//Output the heading using tabs
	pDC->TabbedTextOut(0, y, line, 3, TabStops, 0);
	//Detect empty recordset
	if (m_pSet->IsBOF()) {
		return;
	}
	//Compute the detail line height
	LineHeight = metrics.tmHeight + metrics.tmExternalLeading;
	y -= LineHeight;	//Adjust y position
	//Set the detail font
	pDC->SelectObject(&DetailFont);
	//Retrieve detail font measurements
	pDC->GetTextMetrics(&metrics);
	//Compute the detail line height
	LineHeight = metrics.tmHeight + metrics.tmExternalLeading;
	//Scroll through the recordset
	while (!m_pSet->IsEOF()) {
		//Format the detail line
		line.Format("%s\t%s\t%s\t%s %s",
			m_pSet->m_DepartmentCode,
			m_pSet->m_Name,
			m_pSet->m_Description,
			m_pSet->m_FirstName,
			m_pSet->m_LastName);
		//Output the detail line using tabs
		pDC->TabbedTextOut(0, y, line, 3, TabStops, 0);
		//Get the next recordset number
		y -= LineHeight;	//Adjust y position
		m_pSet->MoveNext();
	}
	//Restore default settings
	pDC->SelectObject(OldFont);
}

void CODBCReportView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
	//Limit size to 8" x 20"
	CSize sizeTotal(800, 2000);
	//Because of MM_LOENGLISH, Sizes are in .01 of an inch
	SetScrollSizes(MM_LOENGLISH, sizeTotal);
	//Retrieve the document	
	CODBCReportDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);	//Make sure it's valid
	//Set the window title
	pDoc->SetTitle("ODBC Student Report");
	//Set the m_pSet pointer to the m_dbSet recordset
	m_pSet = &pDoc->m_dbSet;
	//Open the recordset
	m_pSet->Open();
}

/////////////////////////////////////////////////////////////////////////////
// CODBCReportView printing

BOOL CODBCReportView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CODBCReportView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CODBCReportView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

/////////////////////////////////////////////////////////////////////////////
// CODBCReportView diagnostics

#ifdef _DEBUG
void CODBCReportView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CODBCReportView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CODBCReportDoc* CODBCReportView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CODBCReportDoc)));
	return (CODBCReportDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CODBCReportView message handlers



