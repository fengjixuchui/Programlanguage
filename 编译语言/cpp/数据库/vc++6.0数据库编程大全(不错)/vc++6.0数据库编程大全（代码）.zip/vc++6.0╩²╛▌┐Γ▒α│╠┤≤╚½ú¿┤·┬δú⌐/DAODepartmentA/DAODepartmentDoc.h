// DAODepartmentDoc.h : interface of the CDAODepartmentDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DAODEPARTMENTDOC_H__C75F6EEA_943A_11D2_9949_E8E2006C6048__INCLUDED_)
#define AFX_DAODEPARTMENTDOC_H__C75F6EEA_943A_11D2_9949_E8E2006C6048__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "DAODepartmentSet.h"


class CDAODepartmentDoc : public CDocument
{
protected: // create from serialization only
	CDAODepartmentDoc();
	DECLARE_DYNCREATE(CDAODepartmentDoc)

// Attributes
public:
	CDAODepartmentSet m_dAODepartmentSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDAODepartmentDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDAODepartmentDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDAODepartmentDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAODEPARTMENTDOC_H__C75F6EEA_943A_11D2_9949_E8E2006C6048__INCLUDED_)
