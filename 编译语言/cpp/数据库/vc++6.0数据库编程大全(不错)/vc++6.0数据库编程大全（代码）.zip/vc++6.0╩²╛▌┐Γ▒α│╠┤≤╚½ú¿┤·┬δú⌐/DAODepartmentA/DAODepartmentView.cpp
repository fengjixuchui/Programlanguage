// DAODepartmentView.cpp : implementation of the CDAODepartmentView class
//

#include "stdafx.h"
#include "DAODepartment.h"

#include "DAODepartmentSet.h"
#include "DAODepartmentDoc.h"
#include "DAODepartmentView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView

IMPLEMENT_DYNCREATE(CDAODepartmentView, CDaoRecordView)

BEGIN_MESSAGE_MAP(CDAODepartmentView, CDaoRecordView)
	//{{AFX_MSG_MAP(CDAODepartmentView)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CDaoRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CDaoRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CDaoRecordView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView construction/destruction

CDAODepartmentView::CDAODepartmentView()
	: CDaoRecordView(CDAODepartmentView::IDD)
{
	//{{AFX_DATA_INIT(CDAODepartmentView)
	m_pSet = NULL;
	//}}AFX_DATA_INIT
}

CDAODepartmentView::~CDAODepartmentView()
{
}

void CDAODepartmentView::DoDataExchange(CDataExchange* pDX)
{
	CDaoRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDAODepartmentView)
	DDX_FieldText(pDX, IDC_DEPARTMENTCODE, m_pSet->m_DepartmentCode, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentCode, 4);
	DDX_FieldText(pDX, IDC_DEPARTMENTNAME, m_pSet->m_DepartmentName, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_DepartmentName, 50);
	//}}AFX_DATA_MAP
}

BOOL CDAODepartmentView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CDaoRecordView::PreCreateWindow(cs);
}

void CDAODepartmentView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_dAODepartmentSet;
	CDaoRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView printing

BOOL CDAODepartmentView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CDAODepartmentView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CDAODepartmentView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView diagnostics

#ifdef _DEBUG
void CDAODepartmentView::AssertValid() const
{
	CDaoRecordView::AssertValid();
}

void CDAODepartmentView::Dump(CDumpContext& dc) const
{
	CDaoRecordView::Dump(dc);
}

CDAODepartmentDoc* CDAODepartmentView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDAODepartmentDoc)));
	return (CDAODepartmentDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView database support
CDaoRecordset* CDAODepartmentView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CDAODepartmentView message handlers
