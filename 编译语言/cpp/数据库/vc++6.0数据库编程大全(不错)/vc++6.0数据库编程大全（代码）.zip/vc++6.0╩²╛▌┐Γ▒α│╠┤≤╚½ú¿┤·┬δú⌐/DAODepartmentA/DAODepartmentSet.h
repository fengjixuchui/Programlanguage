// DAODepartmentSet.h : interface of the CDAODepartmentSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DAODEPARTMENTSET_H__C75F6EEE_943A_11D2_9949_E8E2006C6048__INCLUDED_)
#define AFX_DAODEPARTMENTSET_H__C75F6EEE_943A_11D2_9949_E8E2006C6048__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDAODepartmentSet : public CDaoRecordset
{
public:
	CDAODepartmentSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDAODepartmentSet)

// Field/Param Data
	//{{AFX_FIELD(CDAODepartmentSet, CDaoRecordset)
	CString	m_DepartmentCode;
	CString	m_DepartmentName;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDAODepartmentSet)
	public:
	virtual CString GetDefaultDBName();		// REVIEW:  Get a comment here
	virtual CString GetDefaultSQL(); 	// default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);	// RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAODEPARTMENTSET_H__C75F6EEE_943A_11D2_9949_E8E2006C6048__INCLUDED_)

