// ODBCDepartmentDoc.cpp : implementation of the CODBCDepartmentDoc class
//

#include "stdafx.h"
#include "ODBCDepartment.h"

#include "ODBCDepartmentSet.h"
#include "ODBCDepartmentDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentDoc

IMPLEMENT_DYNCREATE(CODBCDepartmentDoc, CDocument)

BEGIN_MESSAGE_MAP(CODBCDepartmentDoc, CDocument)
	//{{AFX_MSG_MAP(CODBCDepartmentDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentDoc construction/destruction

CODBCDepartmentDoc::CODBCDepartmentDoc()
{
}

CODBCDepartmentDoc::~CODBCDepartmentDoc()
{
}

BOOL CODBCDepartmentDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentDoc serialization

void CODBCDepartmentDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentDoc diagnostics

#ifdef _DEBUG
void CODBCDepartmentDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CODBCDepartmentDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CODBCDepartmentDoc commands
