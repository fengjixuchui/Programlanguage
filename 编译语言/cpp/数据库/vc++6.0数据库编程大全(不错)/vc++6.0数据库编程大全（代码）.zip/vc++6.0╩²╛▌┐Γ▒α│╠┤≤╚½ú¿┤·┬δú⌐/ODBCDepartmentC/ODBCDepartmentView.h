// ODBCDepartmentView.h : interface of the CODBCDepartmentView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ODBCDEPARTMENTVIEW_H__4C511D25_3A73_11D2_9949_CA74FE5E5648__INCLUDED_)
#define AFX_ODBCDEPARTMENTVIEW_H__4C511D25_3A73_11D2_9949_CA74FE5E5648__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CODBCDepartmentSet;

class CODBCDepartmentView : public CRecordView
{
protected: // create from serialization only
	CODBCDepartmentView();
	DECLARE_DYNCREATE(CODBCDepartmentView)

public:
	//{{AFX_DATA(CODBCDepartmentView)
	enum { IDD = IDD_ODBCDEPARTMENT_FORM };
	CODBCDepartmentSet* m_pSet;
	CString	m_FindDeptCode;
	//}}AFX_DATA

// Attributes
public:
	CODBCDepartmentDoc* GetDocument();
	BOOL m_bAddingRecord;
	BOOL m_bFieldsChanged;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CODBCDepartmentView)
	public:
	virtual CRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnMove(UINT nIDMoveCommand);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CODBCDepartmentView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CODBCDepartmentView)
	afx_msg void OnRecordDeleterecord();
	afx_msg void OnUpdateRecordDeleterecord(CCmdUI* pCmdUI);
	afx_msg void OnRecordQueryrecord();
	afx_msg void OnFileNew();
	afx_msg void OnFileSave();
	afx_msg void OnDestroy();
	afx_msg void OnChangeDepartmentcode();
	afx_msg void OnChangeDepartmentname();
	afx_msg void OnUpdateFileSave(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ODBCDepartmentView.cpp
inline CODBCDepartmentDoc* CODBCDepartmentView::GetDocument()
   { return (CODBCDepartmentDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ODBCDEPARTMENTVIEW_H__4C511D25_3A73_11D2_9949_CA74FE5E5648__INCLUDED_)
