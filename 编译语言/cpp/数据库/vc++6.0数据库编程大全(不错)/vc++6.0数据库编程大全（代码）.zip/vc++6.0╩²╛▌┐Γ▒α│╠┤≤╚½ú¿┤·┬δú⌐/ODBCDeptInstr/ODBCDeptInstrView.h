// ODBCDeptInstrView.h : interface of the CODBCDeptInstrView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ODBCDEPTINSTRVIEW_H__E41EC1C1_3EFB_11D2_9949_8B1DD78D9246__INCLUDED_)
#define AFX_ODBCDEPTINSTRVIEW_H__E41EC1C1_3EFB_11D2_9949_8B1DD78D9246__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CODBCDeptInstrSet;

class CODBCDeptInstrView : public CRecordView
{
protected: // create from serialization only
	CODBCDeptInstrView();
	DECLARE_DYNCREATE(CODBCDeptInstrView)

public:
	//{{AFX_DATA(CODBCDeptInstrView)
	enum { IDD = IDD_ODBCDEPTINSTR_FORM };
	CODBCDeptInstrSet* m_pSet;
	//}}AFX_DATA

// Attributes
public:
	CODBCDeptInstrDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CODBCDeptInstrView)
	public:
	virtual CRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CODBCDeptInstrView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CODBCDeptInstrView)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ODBCDeptInstrView.cpp
inline CODBCDeptInstrDoc* CODBCDeptInstrView::GetDocument()
   { return (CODBCDeptInstrDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ODBCDEPTINSTRVIEW_H__E41EC1C1_3EFB_11D2_9949_8B1DD78D9246__INCLUDED_)
