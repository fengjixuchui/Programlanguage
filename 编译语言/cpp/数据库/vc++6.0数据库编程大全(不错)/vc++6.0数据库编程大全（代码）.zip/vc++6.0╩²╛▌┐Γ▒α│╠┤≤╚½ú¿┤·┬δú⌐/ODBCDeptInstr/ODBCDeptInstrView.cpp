// ODBCDeptInstrView.cpp : implementation of the CODBCDeptInstrView class
//

#include "stdafx.h"
#include "ODBCDeptInstr.h"

#include "ODBCDeptInstrSet.h"
#include "ODBCDeptInstrDoc.h"
#include "ODBCDeptInstrView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CODBCDeptInstrView

IMPLEMENT_DYNCREATE(CODBCDeptInstrView, CRecordView)

BEGIN_MESSAGE_MAP(CODBCDeptInstrView, CRecordView)
	//{{AFX_MSG_MAP(CODBCDeptInstrView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CODBCDeptInstrView construction/destruction

CODBCDeptInstrView::CODBCDeptInstrView()
	: CRecordView(CODBCDeptInstrView::IDD)
{
	//{{AFX_DATA_INIT(CODBCDeptInstrView)
	m_pSet = NULL;
	//}}AFX_DATA_INIT
}

CODBCDeptInstrView::~CODBCDeptInstrView()
{
}

void CODBCDeptInstrView::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CODBCDeptInstrView)
	DDX_FieldText(pDX, IDC_DEPARTMENTCODE, m_pSet->m_DepartmentCode, m_pSet);
	DDX_FieldText(pDX, IDC_DEPARTMENTNAME, m_pSet->m_DepartmentName, m_pSet);
	DDX_FieldText(pDX, IDC_EMAIL, m_pSet->m_EMAIL, m_pSet);
	DDX_FieldText(pDX, IDC_INSTRUCTORNAME, m_pSet->m_Name, m_pSet);
	DDX_FieldText(pDX, IDC_NOTES, m_pSet->m_Notes, m_pSet);
	//}}AFX_DATA_MAP
}

BOOL CODBCDeptInstrView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CRecordView::PreCreateWindow(cs);
}

void CODBCDeptInstrView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_oDBCDeptInstrSet;
	CRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CODBCDeptInstrView diagnostics

#ifdef _DEBUG
void CODBCDeptInstrView::AssertValid() const
{
	CRecordView::AssertValid();
}

void CODBCDeptInstrView::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CODBCDeptInstrDoc* CODBCDeptInstrView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CODBCDeptInstrDoc)));
	return (CODBCDeptInstrDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CODBCDeptInstrView database support
CRecordset* CODBCDeptInstrView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CODBCDeptInstrView message handlers
