// ODBCDeptInstrSet.cpp : implementation of the CODBCDeptInstrSet class
//

#include "stdafx.h"
#include "ODBCDeptInstr.h"
#include "ODBCDeptInstrSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CODBCDeptInstrSet implementation

IMPLEMENT_DYNAMIC(CODBCDeptInstrSet, CRecordset)

CODBCDeptInstrSet::CODBCDeptInstrSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CODBCDeptInstrSet)
	m_DepartmentCode = _T("");
	m_DepartmentName = _T("");
	m_InstructorID = 0;
	m_Name = _T("");
	m_DepartmentCode2 = _T("");
	m_EMAIL = _T("");
	m_Notes = _T("");
	m_nFields = 7;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
	m_strFilter = "Instructor.DepartmentCode = Department.DepartmentCode";
}

CString CODBCDeptInstrSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=Classes");
}

CString CODBCDeptInstrSet::GetDefaultSQL()
{
	return _T("[Department],[Instructor]");
}

void CODBCDeptInstrSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CODBCDeptInstrSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[Department].[DepartmentCode]"), m_DepartmentCode);
	RFX_Text(pFX, _T("[DepartmentName]"), m_DepartmentName);
	RFX_Long(pFX, _T("[InstructorID]"), m_InstructorID);
	RFX_Text(pFX, _T("[Name]"), m_Name);
	RFX_Text(pFX, _T("[Instructor].[DepartmentCode]"), m_DepartmentCode2);
	RFX_Text(pFX, _T("[EMAIL]"), m_EMAIL);
	RFX_Text(pFX, _T("[Notes]"), m_Notes);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CODBCDeptInstrSet diagnostics

#ifdef _DEBUG
void CODBCDeptInstrSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CODBCDeptInstrSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
