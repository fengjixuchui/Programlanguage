// ODBCDeptInstr.h : main header file for the ODBCDEPTINSTR application
//

#if !defined(AFX_ODBCDEPTINSTR_H__E41EC1B9_3EFB_11D2_9949_8B1DD78D9246__INCLUDED_)
#define AFX_ODBCDEPTINSTR_H__E41EC1B9_3EFB_11D2_9949_8B1DD78D9246__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CODBCDeptInstrApp:
// See ODBCDeptInstr.cpp for the implementation of this class
//

class CODBCDeptInstrApp : public CWinApp
{
public:
	CODBCDeptInstrApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CODBCDeptInstrApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CODBCDeptInstrApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ODBCDEPTINSTR_H__E41EC1B9_3EFB_11D2_9949_8B1DD78D9246__INCLUDED_)
