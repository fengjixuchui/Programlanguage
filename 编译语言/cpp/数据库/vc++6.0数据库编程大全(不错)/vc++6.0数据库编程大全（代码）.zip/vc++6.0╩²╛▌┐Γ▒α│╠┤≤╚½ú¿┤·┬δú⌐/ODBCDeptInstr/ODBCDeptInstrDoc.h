// ODBCDeptInstrDoc.h : interface of the CODBCDeptInstrDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ODBCDEPTINSTRDOC_H__E41EC1BF_3EFB_11D2_9949_8B1DD78D9246__INCLUDED_)
#define AFX_ODBCDEPTINSTRDOC_H__E41EC1BF_3EFB_11D2_9949_8B1DD78D9246__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ODBCDeptInstrSet.h"


class CODBCDeptInstrDoc : public CDocument
{
protected: // create from serialization only
	CODBCDeptInstrDoc();
	DECLARE_DYNCREATE(CODBCDeptInstrDoc)

// Attributes
public:
	CODBCDeptInstrSet m_oDBCDeptInstrSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CODBCDeptInstrDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CODBCDeptInstrDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CODBCDeptInstrDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ODBCDEPTINSTRDOC_H__E41EC1BF_3EFB_11D2_9949_8B1DD78D9246__INCLUDED_)
