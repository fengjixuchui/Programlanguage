// ODBCDeptInstrDoc.cpp : implementation of the CODBCDeptInstrDoc class
//

#include "stdafx.h"
#include "ODBCDeptInstr.h"

#include "ODBCDeptInstrSet.h"
#include "ODBCDeptInstrDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CODBCDeptInstrDoc

IMPLEMENT_DYNCREATE(CODBCDeptInstrDoc, CDocument)

BEGIN_MESSAGE_MAP(CODBCDeptInstrDoc, CDocument)
	//{{AFX_MSG_MAP(CODBCDeptInstrDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CODBCDeptInstrDoc construction/destruction

CODBCDeptInstrDoc::CODBCDeptInstrDoc()
{
}

CODBCDeptInstrDoc::~CODBCDeptInstrDoc()
{
}

BOOL CODBCDeptInstrDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CODBCDeptInstrDoc diagnostics

#ifdef _DEBUG
void CODBCDeptInstrDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CODBCDeptInstrDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CODBCDeptInstrDoc commands
