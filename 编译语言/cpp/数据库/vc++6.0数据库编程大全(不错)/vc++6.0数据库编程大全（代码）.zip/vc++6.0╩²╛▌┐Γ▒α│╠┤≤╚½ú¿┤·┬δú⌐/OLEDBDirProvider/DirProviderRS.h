// DirProviderRS.h : Declaration of the CDirProviderRowset
#ifndef __CDirProviderRowset_H_
#define __CDirProviderRowset_H_
#include "resource.h"       // main symbols
class CDirProviderWindowsFile
{
public:
    TCHAR    cFileName[ MAX_PATH ];
    TCHAR    cShortFileName[ 14 ]; 
    DWORD    nFileSize;
    TCHAR    strFileAttributes[7]; 
BEGIN_PROVIDER_COLUMN_MAP(CDirProviderWindowsFile)
    PROVIDER_COLUMN_ENTRY("FileName",       1, cFileName)
    PROVIDER_COLUMN_ENTRY("AltFileName",    2, cShortFileName)
    PROVIDER_COLUMN_ENTRY("FileSize",       3, nFileSize)
    PROVIDER_COLUMN_ENTRY("FileAttributes", 4, strFileAttributes)
END_PROVIDER_COLUMN_MAP()
};
// CDirProviderCommand
class ATL_NO_VTABLE CDirProviderCommand : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IAccessorImpl<CDirProviderCommand>,
	public ICommandTextImpl<CDirProviderCommand>,
	public ICommandPropertiesImpl<CDirProviderCommand>,
	public IObjectWithSiteImpl<CDirProviderCommand>,
	public IConvertTypeImpl<CDirProviderCommand>,
	public IColumnsInfoImpl<CDirProviderCommand>
{
public:
BEGIN_COM_MAP(CDirProviderCommand)
	COM_INTERFACE_ENTRY(ICommand)
	COM_INTERFACE_ENTRY(IObjectWithSite)
	COM_INTERFACE_ENTRY(IAccessor)
	COM_INTERFACE_ENTRY(ICommandProperties)
	COM_INTERFACE_ENTRY2(ICommandText, ICommand)
	COM_INTERFACE_ENTRY(IColumnsInfo)
	COM_INTERFACE_ENTRY(IConvertType)
END_COM_MAP()
// ICommand
public:
	HRESULT FinalConstruct()
	{
		HRESULT hr = CConvertHelper::FinalConstruct();
		if (FAILED (hr))
			return hr;
		hr = IAccessorImpl<CDirProviderCommand>::FinalConstruct();
		if (FAILED(hr))
			return hr;
		return CUtlProps<CDirProviderCommand>::FInit();
	}
	void FinalRelease()
	{
		IAccessorImpl<CDirProviderCommand>::FinalRelease();
	}
	HRESULT WINAPI Execute(IUnknown * pUnkOuter, REFIID riid, DBPARAMS * pParams, 
						  LONG * pcRowsAffected, IUnknown ** ppRowset);
	static ATLCOLUMNINFO* GetColumnInfo(CDirProviderCommand* pv, ULONG* pcInfo)
	{
		return CDirProviderWindowsFile::GetColumnInfo(pv,pcInfo);
	}
BEGIN_PROPSET_MAP(CDirProviderCommand)
	BEGIN_PROPERTY_SET(DBPROPSET_ROWSET)
		PROPERTY_INFO_ENTRY(IAccessor)
		PROPERTY_INFO_ENTRY(IColumnsInfo)
		PROPERTY_INFO_ENTRY(IConvertType)
		PROPERTY_INFO_ENTRY(IRowset)
		PROPERTY_INFO_ENTRY(IRowsetIdentity)
		PROPERTY_INFO_ENTRY(IRowsetInfo)
		PROPERTY_INFO_ENTRY(IRowsetLocate)
		PROPERTY_INFO_ENTRY(BOOKMARKS)
		PROPERTY_INFO_ENTRY(BOOKMARKSKIPPED)
		PROPERTY_INFO_ENTRY(BOOKMARKTYPE)
		PROPERTY_INFO_ENTRY(CANFETCHBACKWARDS)
		PROPERTY_INFO_ENTRY(CANHOLDROWS)
		PROPERTY_INFO_ENTRY(CANSCROLLBACKWARDS)
		PROPERTY_INFO_ENTRY(LITERALBOOKMARKS)
		PROPERTY_INFO_ENTRY(ORDEREDBOOKMARKS)
	END_PROPERTY_SET(DBPROPSET_ROWSET)
END_PROPSET_MAP()
};
class CDirProviderRowset : public CRowsetImpl< CDirProviderRowset, CDirProviderWindowsFile, CDirProviderCommand>
{
public:
	HRESULT Execute(DBPARAMS * pParams, LONG* pcRowsAffected)
	{
		USES_CONVERSION;
		BOOL bFound = FALSE;
		HANDLE hFile;
		LPTSTR  szDir = (m_strCommandText == _T("")) ? _T("*.*") : OLE2T(m_strCommandText);
		CDirProviderWindowsFile wf;
		WIN32_FIND_DATA fileInfo;
		hFile = FindFirstFile(szDir, &fileInfo);
		if (hFile == INVALID_HANDLE_VALUE)
			return DB_E_ERRORSINCOMMAND;
		LONG cFiles = 1;
		BOOL bMoreFiles = TRUE;
		while (bMoreFiles)
		{
			wf.nFileSize = fileInfo.nFileSizeLow;
			strcpy(wf.cFileName, fileInfo.cFileName);
			strcpy(wf.cShortFileName, fileInfo.cAlternateFileName);
			strcpy (wf.strFileAttributes, "");
			if (fileInfo.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
				strcat(wf.strFileAttributes, "D");
			}
			if (fileInfo.dwFileAttributes &  FILE_ATTRIBUTE_READONLY) {
				strcat(wf.strFileAttributes, "R");
			}
			if (fileInfo.dwFileAttributes & FILE_ATTRIBUTE_SYSTEM) {
				strcat(wf.strFileAttributes, "S");
			}
			if (fileInfo.dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE) {
				strcat(wf.strFileAttributes, "A");
			}
			if (fileInfo.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN) {
				strcat(wf.strFileAttributes, "H");
			} 
			if (fileInfo.dwFileAttributes & FILE_ATTRIBUTE_TEMPORARY) {
				strcat(wf.strFileAttributes, "T");
			} 
			if (!m_rgRowData.Add(wf))
				return E_OUTOFMEMORY;
			bMoreFiles = FindNextFile(hFile, &fileInfo);
			cFiles++;
		}
		FindClose(hFile);
		if (pcRowsAffected != NULL)
			*pcRowsAffected = cFiles;
		return S_OK;
	}
};
#endif //__CDirProviderRowset_H_
