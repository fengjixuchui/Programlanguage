// Implementation of the CDirProviderCommand
#include "stdafx.h"
#include "OLEDBDirProvider.h"
#include "DirProviderRS.h"
/////////////////////////////////////////////////////////////////////////////
// CDirProviderCommand
HRESULT CDirProviderCommand::Execute(IUnknown * pUnkOuter, REFIID riid, DBPARAMS * pParams, 
								 LONG * pcRowsAffected, IUnknown ** ppRowset)
{
	CDirProviderRowset* pRowset;
	return CreateRowset(pUnkOuter, riid, pParams, pcRowsAffected, ppRowset, pRowset);
}
