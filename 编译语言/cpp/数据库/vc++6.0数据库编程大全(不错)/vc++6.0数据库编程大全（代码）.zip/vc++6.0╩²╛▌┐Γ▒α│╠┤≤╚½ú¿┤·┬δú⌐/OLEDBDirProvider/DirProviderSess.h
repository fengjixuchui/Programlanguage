// Session.h : Declaration of the CDirProviderSession
#ifndef __CDirProviderSession_H_
#define __CDirProviderSession_H_
#include "resource.h"       // main symbols
#include "DirProviderRS.h"
class CDirProviderSessionTRSchemaRowset;
class CDirProviderSessionColSchemaRowset;
class CDirProviderSessionPTSchemaRowset;
/////////////////////////////////////////////////////////////////////////////
// CDirProviderSession
class ATL_NO_VTABLE CDirProviderSession : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IGetDataSourceImpl<CDirProviderSession>,
	public IOpenRowsetImpl<CDirProviderSession>,
	public ISessionPropertiesImpl<CDirProviderSession>,
	public IObjectWithSiteSessionImpl<CDirProviderSession>,
	public IDBSchemaRowsetImpl<CDirProviderSession>,
	public IDBCreateCommandImpl<CDirProviderSession, CDirProviderCommand>
{
public:
	CDirProviderSession()
	{
	}
	HRESULT FinalConstruct()
	{
		return FInit();
	}
	STDMETHOD(OpenRowset)(IUnknown *pUnk, DBID *pTID, DBID *pInID, REFIID riid,
					   ULONG cSets, DBPROPSET rgSets[], IUnknown **ppRowset)
	{
		CDirProviderRowset* pRowset;
		return CreateRowset(pUnk, pTID, pInID, riid, cSets, rgSets, ppRowset, pRowset);
	}
BEGIN_PROPSET_MAP(CDirProviderSession)
	BEGIN_PROPERTY_SET(DBPROPSET_SESSION)
		PROPERTY_INFO_ENTRY(SESS_AUTOCOMMITISOLEVELS)
	END_PROPERTY_SET(DBPROPSET_SESSION)
END_PROPSET_MAP()
BEGIN_COM_MAP(CDirProviderSession)
	COM_INTERFACE_ENTRY(IGetDataSource)
	COM_INTERFACE_ENTRY(IOpenRowset)
	COM_INTERFACE_ENTRY(ISessionProperties)
	COM_INTERFACE_ENTRY(IObjectWithSite)
	COM_INTERFACE_ENTRY(IDBCreateCommand)
	COM_INTERFACE_ENTRY(IDBSchemaRowset)
END_COM_MAP()
BEGIN_SCHEMA_MAP(CDirProviderSession)
	SCHEMA_ENTRY(DBSCHEMA_TABLES, CDirProviderSessionTRSchemaRowset)
	SCHEMA_ENTRY(DBSCHEMA_COLUMNS, CDirProviderSessionColSchemaRowset)
	SCHEMA_ENTRY(DBSCHEMA_PROVIDER_TYPES, CDirProviderSessionPTSchemaRowset)
END_SCHEMA_MAP()
};
class CDirProviderSessionTRSchemaRowset : 
	public CRowsetImpl< CDirProviderSessionTRSchemaRowset, CTABLESRow, CDirProviderSession>
{
public:
	HRESULT Execute(LONG* pcRowsAffected, ULONG, const VARIANT*)
	{
		USES_CONVERSION;
		//Changed session to not rely on recordset
//		CDirProviderWindowsFile wf;
		WIN32_FIND_DATA wf;
		CTABLESRow trData;
		lstrcpyW(trData.m_szType, OLESTR("TABLE"));
		lstrcpyW(trData.m_szDesc, OLESTR("The Directory Table"));
		HANDLE hFile = INVALID_HANDLE_VALUE;
		TCHAR szDir[MAX_PATH + 1];
		DWORD cbCurDir = GetCurrentDirectory(MAX_PATH, szDir);
		lstrcat(szDir, _T("\\*.*"));
		hFile = FindFirstFile(szDir, &wf);
		if (hFile == INVALID_HANDLE_VALUE)
			return E_FAIL; // User doesn't have a c:\ drive
		FindClose(hFile);
		lstrcpynW(trData.m_szTable, T2OLE(szDir), SIZEOF_MEMBER(CTABLESRow, m_szTable));
		if (!m_rgRowData.Add(trData))
			return E_OUTOFMEMORY;
		*pcRowsAffected = 1;
		return S_OK;
	}
};
class CDirProviderSessionColSchemaRowset : 
	public CRowsetImpl< CDirProviderSessionColSchemaRowset, CCOLUMNSRow, CDirProviderSession>
{
public:
	HRESULT Execute(LONG* pcRowsAffected, ULONG, const VARIANT*)
	{
		USES_CONVERSION;
		//Changed session to not rely on recordset
//		CDirProviderWindowsFile wf;
		WIN32_FIND_DATA wf;
		HANDLE hFile = INVALID_HANDLE_VALUE;
		TCHAR szDir[MAX_PATH + 1];
		DWORD cbCurDir = GetCurrentDirectory(MAX_PATH, szDir);
		lstrcat(szDir, _T("\\*.*"));
		hFile = FindFirstFile(szDir, &wf);
		if (hFile == INVALID_HANDLE_VALUE)
			return E_FAIL; // User doesn't have a c:\ drive
		FindClose(hFile);// szDir has got the tablename
		DBID dbid;
		memset(&dbid, 0, sizeof(DBID));
		dbid.uName.pwszName = T2OLE(szDir);
		dbid.eKind = DBKIND_NAME;
		return InitFromRowset < _RowsetArrayType > (m_rgRowData, &dbid, NULL, m_spUnkSite, pcRowsAffected);
	}
};
class CDirProviderSessionPTSchemaRowset : 
	public CRowsetImpl< CDirProviderSessionPTSchemaRowset, CPROVIDER_TYPERow, CDirProviderSession>
{
public:
	HRESULT Execute(LONG* pcRowsAffected, ULONG, const VARIANT*)
	{
		return S_OK;
	}
};
#endif //__CDirProviderSession_H_
