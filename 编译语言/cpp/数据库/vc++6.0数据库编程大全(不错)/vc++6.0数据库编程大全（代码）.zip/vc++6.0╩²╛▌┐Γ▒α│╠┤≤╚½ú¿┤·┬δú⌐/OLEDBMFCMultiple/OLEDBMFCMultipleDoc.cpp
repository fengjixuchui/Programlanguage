// OLEDBMFCMultipleDoc.cpp : implementation of the COLEDBMFCMultipleDoc class
//

#include "stdafx.h"
#include "OLEDBMFCMultiple.h"

#include "OLEDBMFCMultipleSet.h"
#include "OLEDBMFCMultipleDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMultipleDoc

IMPLEMENT_DYNCREATE(COLEDBMFCMultipleDoc, CDocument)

BEGIN_MESSAGE_MAP(COLEDBMFCMultipleDoc, CDocument)
	//{{AFX_MSG_MAP(COLEDBMFCMultipleDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMultipleDoc construction/destruction

COLEDBMFCMultipleDoc::COLEDBMFCMultipleDoc()
{
}

COLEDBMFCMultipleDoc::~COLEDBMFCMultipleDoc()
{
}

BOOL COLEDBMFCMultipleDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMultipleDoc diagnostics

#ifdef _DEBUG
void COLEDBMFCMultipleDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void COLEDBMFCMultipleDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMultipleDoc commands
