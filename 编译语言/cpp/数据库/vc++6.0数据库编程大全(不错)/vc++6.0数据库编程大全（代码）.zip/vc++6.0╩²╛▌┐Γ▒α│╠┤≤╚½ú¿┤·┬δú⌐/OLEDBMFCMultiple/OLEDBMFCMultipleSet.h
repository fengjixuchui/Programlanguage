// OLEDBMFCMultipleSet.h : interface of the COLEDBMFCMultipleSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBMFCMULTIPLESET_H__61B08419_B233_11D2_9949_A7BC39D74A45__INCLUDED_)
#define AFX_OLEDBMFCMULTIPLESET_H__61B08419_B233_11D2_9949_A7BC39D74A45__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRowDefinition
{
public:
	CRowDefinition()
	{
		memset( (void*)this, 0, sizeof(*this) );
	};
	char    column1[62];
	char    column2[51];
};

class COLEDBMFCMultipleSet : public CCommand<CManualAccessor, CRowset, CMultipleResults>
{
public:
    CRowDefinition m_Rows;      //Row Definition
    int m_iResultNumber;        //Current result
    char m_columnName1[17];     //Name of the first column
    char m_columnName2[17];     //Name of the second column
//The open function was moved to the .CPP file since.
    COLEDBMFCMultipleSet() {    //Constructor
        m_iResultNumber = 0;    //Initialize the result number
    };
	HRESULT Open() {
//For the original Open function, 
//view the OpenSession function
		HRESULT	hr;
		if (m_iResultNumber == 0) {
			hr = OpenSession();
			if (hr != S_OK) 
				return hr;
		}
//Open the rowset to get the information 
//so we can then bind the columns
		hr = CCommand<CManualAccessor, CRowset, CMultipleResults>::
			Open(NULL, NULL, false);
		if (hr != S_OK)
			return hr;
		if (m_iResultNumber == 1) {
			m_iResultNumber = 2;
//Get the next result set, but don't bind it.
			GetNextResult(NULL, false);
			strcpy(m_columnName1, "Student Name:");
			strcpy(m_columnName2, "Student EMAIL:");
		}
		else {
//First result set.  No extra code needed
			m_iResultNumber = 1;
			strcpy(m_columnName1, "Department Code:");
			strcpy(m_columnName2, "Department Name:");
		}
		CreateAccessor(2, &m_Rows, sizeof(CRowDefinition));
		AddBindEntry(1, DBTYPE_STR, 
				sizeof(m_Rows.column1), 
				&m_Rows.column1);
		AddBindEntry(2, DBTYPE_STR, 
				sizeof(m_Rows.column2), 
				&m_Rows.column2);
		Bind();
		return MoveNext();
	}
	HRESULT OpenSession() {  //Used to be HRESULT Open()
		CDataSource db;
		CSession	session;
		HRESULT		hr;
		CDBPropSet	dbinit(DBPROPSET_DBINIT);
		dbinit.AddProperty(DBPROP_AUTH_PASSWORD, "");
		dbinit.AddProperty(DBPROP_AUTH_PERSIST_SENSITIVE_AUTHINFO, false);
		dbinit.AddProperty(DBPROP_AUTH_USERID, "sa");
		dbinit.AddProperty(DBPROP_INIT_CATALOG,  "Classes");
		dbinit.AddProperty(DBPROP_INIT_DATASOURCE, "(local)");
		dbinit.AddProperty(DBPROP_INIT_LCID, (long)1033);
		dbinit.AddProperty(DBPROP_INIT_PROMPT, (short)4);
		hr = db.OpenWithServiceComponents("SQLOLEDB.1", &dbinit);
		if (FAILED(hr))
			return hr;
		hr = session.Open(db);
		if (FAILED(hr))
			return hr;
//Create a new SQL statement
        hr = Create(session, "EXEC TestMultipleRowset");
        if (FAILED(hr))
            return hr;
//Prepare the statement to be executed once
        return Prepare(1);
//The rest of this functionality has been moved 
//to the Open function
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBMFCMULTIPLESET_H__61B08419_B233_11D2_9949_A7BC39D74A45__INCLUDED_)

