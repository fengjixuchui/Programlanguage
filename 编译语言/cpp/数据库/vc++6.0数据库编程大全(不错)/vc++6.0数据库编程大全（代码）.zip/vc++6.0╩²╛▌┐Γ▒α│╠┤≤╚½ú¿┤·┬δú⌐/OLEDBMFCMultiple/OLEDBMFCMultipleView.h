// OLEDBMFCMultipleView.h : interface of the COLEDBMFCMultipleView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBMFCMULTIPLEVIEW_H__61B08417_B233_11D2_9949_A7BC39D74A45__INCLUDED_)
#define AFX_OLEDBMFCMULTIPLEVIEW_H__61B08417_B233_11D2_9949_A7BC39D74A45__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class COLEDBMFCMultipleSet;

class COLEDBMFCMultipleView : public COleDBRecordView
{
protected: // create from serialization only
	COLEDBMFCMultipleView();
	DECLARE_DYNCREATE(COLEDBMFCMultipleView)

public:
	//{{AFX_DATA(COLEDBMFCMultipleView)
	enum{ IDD = IDD_OLEDBMFCMULTIPLE_FORM };
	COLEDBMFCMultipleSet* m_pSet;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	COLEDBMFCMultipleDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBMFCMultipleView)
	public:
	virtual CRowset* OnGetRowset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLEDBMFCMultipleView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COLEDBMFCMultipleView)
	afx_msg void OnRecordChangerowset();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in OLEDBMFCMultipleView.cpp
inline COLEDBMFCMultipleDoc* COLEDBMFCMultipleView::GetDocument()
   { return (COLEDBMFCMultipleDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBMFCMULTIPLEVIEW_H__61B08417_B233_11D2_9949_A7BC39D74A45__INCLUDED_)
