// OLEDBMFCMultipleView.cpp : implementation of the COLEDBMFCMultipleView class
//

#include "stdafx.h"
#include "OLEDBMFCMultiple.h"

#include "OLEDBMFCMultipleSet.h"
#include "OLEDBMFCMultipleDoc.h"
#include "OLEDBMFCMultipleView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMultipleView

IMPLEMENT_DYNCREATE(COLEDBMFCMultipleView, COleDBRecordView)

BEGIN_MESSAGE_MAP(COLEDBMFCMultipleView, COleDBRecordView)
	//{{AFX_MSG_MAP(COLEDBMFCMultipleView)
	ON_COMMAND(ID_RECORD_CHANGEROWSET, OnRecordChangerowset)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMultipleView construction/destruction

COLEDBMFCMultipleView::COLEDBMFCMultipleView()
	: COleDBRecordView(COLEDBMFCMultipleView::IDD)
{
	//{{AFX_DATA_INIT(COLEDBMFCMultipleView)
		// NOTE: the ClassWizard will add member initialization here
	m_pSet = NULL;
	//}}AFX_DATA_INIT
}

COLEDBMFCMultipleView::~COLEDBMFCMultipleView()
{
}

void COLEDBMFCMultipleView::DoDataExchange(CDataExchange* pDX)
{
	COleDBRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COLEDBMFCMultipleView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_COLUMN1, m_pSet->m_Rows.column1, 62);
	DDX_Text(pDX, IDC_COLUMN2, m_pSet->m_Rows.column2, 51);
	DDX_Text(pDX, IDC_STATIC1, m_pSet->m_columnName1, 17);
	DDX_Text(pDX, IDC_STATIC2, m_pSet->m_columnName2, 17);
}

BOOL COLEDBMFCMultipleView::PreCreateWindow(CREATESTRUCT& cs)
{
	return COleDBRecordView::PreCreateWindow(cs);
}

void COLEDBMFCMultipleView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_oLEDBMFCMultipleSet;
	{
		CWaitCursor wait;
		HRESULT hr = m_pSet->Open();
		if (hr != S_OK)
		{
			AfxMessageBox(_T("Record set failed to open."), MB_OK);
			m_bOnFirstRecord = TRUE;
			m_bOnLastRecord = TRUE;
		}				
	}
	COleDBRecordView::OnInitialUpdate();

}

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMultipleView diagnostics

#ifdef _DEBUG
void COLEDBMFCMultipleView::AssertValid() const
{
	COleDBRecordView::AssertValid();
}

void COLEDBMFCMultipleView::Dump(CDumpContext& dc) const
{
	COleDBRecordView::Dump(dc);
}

COLEDBMFCMultipleDoc* COLEDBMFCMultipleView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(COLEDBMFCMultipleDoc)));
	return (COLEDBMFCMultipleDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMultipleView database support
CRowset* COLEDBMFCMultipleView::OnGetRowset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMultipleView message handlers

void COLEDBMFCMultipleView::OnRecordChangerowset() 
{
    UpdateData(TRUE);    // Update from Window
    m_pSet->Close();     // Close the last rowset
    m_pSet->Open();      // Toggle to the new rowset
    UpdateData(FALSE);   // Update to Window
}
