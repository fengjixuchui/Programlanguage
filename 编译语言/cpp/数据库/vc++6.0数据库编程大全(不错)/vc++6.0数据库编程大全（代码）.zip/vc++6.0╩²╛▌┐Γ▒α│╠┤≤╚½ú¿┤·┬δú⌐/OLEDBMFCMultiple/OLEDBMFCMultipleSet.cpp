// OLEDBMFCMultipleSet.cpp : implementation of the COLEDBMFCMultipleSet class
//

#include "stdafx.h"
#include "OLEDBMFCMultiple.h"
#include "OLEDBMFCMultipleSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMultipleSet implementation

