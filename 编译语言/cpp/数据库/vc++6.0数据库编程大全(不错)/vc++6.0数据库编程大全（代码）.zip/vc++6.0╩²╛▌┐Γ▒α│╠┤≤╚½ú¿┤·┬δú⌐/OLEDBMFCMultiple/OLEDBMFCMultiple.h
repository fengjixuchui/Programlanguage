// OLEDBMFCMultiple.h : main header file for the OLEDBMFCMULTIPLE application
//

#if !defined(AFX_OLEDBMFCMULTIPLE_H__61B0840F_B233_11D2_9949_A7BC39D74A45__INCLUDED_)
#define AFX_OLEDBMFCMULTIPLE_H__61B0840F_B233_11D2_9949_A7BC39D74A45__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// COLEDBMFCMultipleApp:
// See OLEDBMFCMultiple.cpp for the implementation of this class
//

class COLEDBMFCMultipleApp : public CWinApp
{
public:
	COLEDBMFCMultipleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBMFCMultipleApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(COLEDBMFCMultipleApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBMFCMULTIPLE_H__61B0840F_B233_11D2_9949_A7BC39D74A45__INCLUDED_)
