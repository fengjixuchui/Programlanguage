// OLEDBDepartmentMFCView.h : interface of the COLEDBDepartmentMFCView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OLEDBDEPARTMENTMFCVIEW_H__C270A612_4B8D_11D2_9949_D84454558644__INCLUDED_)
#define AFX_OLEDBDEPARTMENTMFCVIEW_H__C270A612_4B8D_11D2_9949_D84454558644__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class COLEDBDepartmentMFCSet;

class COLEDBDepartmentMFCView : public COleDBRecordView
{
protected: // create from serialization only
	COLEDBDepartmentMFCView();
	BOOL SaveRecord();
	void AddRecord();
	void ResetRowSet();
	BOOL m_bAddingRecord;
	BOOL m_bChangesMade;
	DECLARE_DYNCREATE(COLEDBDepartmentMFCView)

public:
	//{{AFX_DATA(COLEDBDepartmentMFCView)
	enum{ IDD = IDD_OLEDBDEPARTMENTMFC_FORM };
	COLEDBDepartmentMFCSet* m_pSet;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:
	COLEDBDepartmentMFCDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COLEDBDepartmentMFCView)
	public:
	virtual CRowset* OnGetRowset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnMove(UINT nIDMoveCommand);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COLEDBDepartmentMFCView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(COLEDBDepartmentMFCView)
	afx_msg void OnDestroy();
	afx_msg void OnEditDeletetctrldel();
	afx_msg void OnFileNew();
	afx_msg void OnFileOpen();
	afx_msg void OnFileSave();
	afx_msg void OnChangeDepartmentcode();
	afx_msg void OnChangeDepartmentname();
	afx_msg void OnChangeEmail();
	afx_msg void OnChangeInstructorname();
	afx_msg void OnChangeNotes();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in OLEDBDepartmentMFCView.cpp
inline COLEDBDepartmentMFCDoc* COLEDBDepartmentMFCView::GetDocument()
   { return (COLEDBDepartmentMFCDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OLEDBDEPARTMENTMFCVIEW_H__C270A612_4B8D_11D2_9949_D84454558644__INCLUDED_)
