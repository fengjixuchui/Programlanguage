// DeptDialog.h : Declaration of the CDeptDialog

#ifndef __DEPTDIALOG_H_
#define __DEPTDIALOG_H_

#include "resource.h"       // main symbols
#include <atlhost.h>
//Added by Chuck Wood. Included for error checking
#include "..\OLEDBErrorChecking\OLEDBErrorChecking.h"
//Added by Chuck Wood. Included for database support
#include "Department.H"

/////////////////////////////////////////////////////////////////////////////
// CDeptDialog
class CDeptDialog : 
	public CAxDialogImpl<CDeptDialog>
{
public:
	CDepartment* m_pSet;
	int m_nCurrentRow;
	int m_nMaxRows;
	enum CPosition{	FIRST = 0,
			LAST = 1,
			NEXT = 2,
			PREV = 3 };
	HRESULT SaveDepartment();
	void UpdateData(BOOL bSaveChangesToSet = TRUE);
	void DisplayStatus(char *strMessage);
	void OnMove(CPosition position);
	CDeptDialog()
	{
		m_pSet = new CDepartment();
		DoModal();
	}

	~CDeptDialog()
	{
		m_pSet->Close();
		delete m_pSet;
	}

	enum { IDD = IDD_DEPTDIALOG };

BEGIN_MSG_MAP(CDeptDialog)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(ID_FIRST, OnFirst)
	COMMAND_ID_HANDLER(ID_PREV, OnPrev)
	COMMAND_ID_HANDLER(ID_NEXT, OnNext)
	COMMAND_ID_HANDLER(ID_LAST, OnLast)
	COMMAND_ID_HANDLER(IDOK, OnExit)
	COMMAND_ID_HANDLER(IDCANCEL, OnExit)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		HRESULT hr = m_pSet->Open();
		if (FAILED(hr)) {
			COLEDBErrorChecking::DisplayHRRESULTMessage(hr, "OnInitDialog");
			exit(1);	//Better not start
		}
	//Added by Chuck Wood to set array bounds
		m_nCurrentRow = 0;
		m_nMaxRows = 8;
		UpdateData(FALSE);	//Write Values to Window
		return 1;  // Let the system set the focus
	}
	LRESULT OnFirst(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		OnMove(FIRST);
		return 0;
	}

	LRESULT OnPrev(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		OnMove(PREV);
		return 0;
	}

	LRESULT OnNext(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		OnMove(NEXT);
		return 0;
	}

	LRESULT OnLast(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		OnMove(LAST);
		return 0;
	}

	LRESULT OnExit(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}
};

#endif //__DEPTDIALOG_H_
