// DeptDialog.cpp : Implementation of CDeptDialog
#include "stdafx.h"
#include "DeptDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CDeptDialog
void CDeptDialog::UpdateData(BOOL bSaveChangesToSet)
{
	if (bSaveChangesToSet) {
		//Read From Screen
		GetDlgItemText(IDC_CODE,
			(char *) m_pSet[0][m_nCurrentRow].m_DepartmentCode, 5);
		GetDlgItemText(IDC_NAME,
			(char *) m_pSet[0][m_nCurrentRow].m_DepartmentName, 51);
	}
	else {
		//Write to Screen
		SetDlgItemText(IDC_CODE,
			(char *) m_pSet[0][m_nCurrentRow].m_DepartmentCode);
		SetDlgItemText(IDC_NAME,
			(char *) m_pSet[0][m_nCurrentRow].m_DepartmentName);
	}
}
void CDeptDialog::OnMove(CPosition position)
{
	UpdateData(TRUE);	//Read from screen
	DisplayStatus("");
	switch (position) {
	case (FIRST) :
		m_nCurrentRow = 0;
		break;
	case (NEXT) :
		m_nCurrentRow++;
		if (m_nCurrentRow > m_nMaxRows) {	//EOF
			m_nCurrentRow = m_nMaxRows;
			DisplayStatus("Last record reached.");
		}
		break;
	case (LAST) :
		m_nCurrentRow = m_nMaxRows;
		break;
	case (PREV) :
		m_nCurrentRow--;
		if (m_nCurrentRow < 0) {	//BOF
			m_nCurrentRow = 0;
			DisplayStatus("First record reached.");
		}
		break;
	}
	UpdateData(FALSE);	//Update Screen
}
void CDeptDialog::DisplayStatus(char *strMessage)
{
	SetDlgItemText(IDC_STATUS, strMessage);
}

