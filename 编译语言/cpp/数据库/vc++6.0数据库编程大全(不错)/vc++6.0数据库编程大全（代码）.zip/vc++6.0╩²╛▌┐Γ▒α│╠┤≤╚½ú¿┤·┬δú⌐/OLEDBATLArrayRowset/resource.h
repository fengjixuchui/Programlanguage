//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OLEDBATLArrayRowset.rc
//
#define IDS_PROJNAME                    100
#define IDR_OLEDBATLArrayRowset         100
#define IDD_DEPTDIALOG                  101
#define IDC_CODE                        201
#define IDC_NAME                        202
#define IDC_STATUS                      203
#define ID_NEXT                         204
#define ID_PREV                         205
#define ID_FIRST                        206
#define ID_LAST                         207

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
