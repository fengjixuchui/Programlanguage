// EnumDialog.h : Declaration of the CEnumDialog

#ifndef __ENUMDIALOG_H_
#define __ENUMDIALOG_H_

#include "resource.h"       // main symbols
#include <atlhost.h>
//Added by Chuck Wood -- #include for CEnumerator support
#include <atldbcli.h>
//Added by Chuck Wood -- #include for ListBox_AddString support
#include <WindowsX.h>
//Added by Chuck Wood -- #include for sprintf support
#include <stdio.h>
/////////////////////////////////////////////////////////////////////////////
// CEnumDialog
class CEnumDialog : 
	public CAxDialogImpl<CEnumDialog>
{
public:
	CEnumDialog()
	{
		//Added by Chuck Wood to automatically go modal
		DoModal();
	}

	~CEnumDialog()
	{
	}

	enum { IDD = IDD_ENUMDIALOG };

BEGIN_MSG_MAP(CEnumDialog)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(IDOK, OnOK)
	COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
//This function was written by Chuck Wood to show an enumerator
		CEnumerator cenum;	//Declare an enumerator
// String for building the list
		char strProviderList[255];	
		cenum.Open();	//Open a class enumerator
//Go to the first provider in the rowset
		HRESULT hr = cenum.MoveFirst();
//Retrieve the list box control
		HWND hwndCtl = GetDlgItem(IDC_PROVIDERLIST);
//Go until the end of the rowset
		while (hr == S_OK) {
//Build a string with the name and parse name of the
//Enumerator
			sprintf(strProviderList, "%-60S %S",
				cenum.m_szName, cenum.m_szDescription);
//Use the ListBox_AddString function to add the string
//to the list box
			ListBox_AddString(hwndCtl, strProviderList);
//Get the next provider in the rowset
			hr = cenum.MoveNext();
		}
//Close your rowset
		cenum.Close();	//Close the enumerator
		return 1;  // Let the system set the focus
	}

	LRESULT OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}

	LRESULT OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}
};

#endif //__ENUMDIALOG_H_
