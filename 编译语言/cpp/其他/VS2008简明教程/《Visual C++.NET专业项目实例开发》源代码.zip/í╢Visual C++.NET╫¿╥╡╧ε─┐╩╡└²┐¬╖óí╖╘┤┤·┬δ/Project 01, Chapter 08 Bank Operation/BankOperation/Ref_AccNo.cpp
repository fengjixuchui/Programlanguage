// Ref_AccNo.cpp : implementation file
//

#include "stdafx.h"
#include "BankOperation.h"
#include "Ref_AccNo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Ref_AccNo
IMPLEMENT_DYNAMIC(Ref_AccNo, CRecordset)

Ref_AccNo::Ref_AccNo(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(Ref_AccNo)
	m_First_Name = _T("");
	m_Last_Name = _T("");
	m_date_birth = _T("");
	m_Permanent_Addr = _T("");
	m_Mailing_Addr = _T("");
	m_Phone_Number = _T("");
	m_eMailID = _T("");
	m_Type_account = _T("");
	m_Balance = 0.0;
	m_Valid_Acc = _T("");
	m_Account_Number = 0;
	m_Ref_Acc_No = 0;
	//m_curr_date = _T("");
	m_nFields = 12;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}


CString Ref_AccNo::GetDefaultConnect()
{
	return _T("ODBC;DSN=Bank;UID=sa;PWD=");
}

CString Ref_AccNo::GetDefaultSQL()
{
	return _T("[dbo].[Account_Detail]");
}

void Ref_AccNo::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(Ref_AccNo)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[First_Name]"), m_First_Name);
	RFX_Text(pFX, _T("[Last_Name]"), m_Last_Name);
	RFX_Text(pFX, _T("[date_birth]"), m_date_birth);
	RFX_Text(pFX, _T("[Permanent_Addr]"), m_Permanent_Addr);
	RFX_Text(pFX, _T("[Mailing_Addr]"), m_Mailing_Addr);
	RFX_Text(pFX, _T("[Phone_Number]"), m_Phone_Number);
	RFX_Text(pFX, _T("[eMailID]"), m_eMailID);
	RFX_Text(pFX, _T("[Type_account]"), m_Type_account);
	RFX_Double(pFX, _T("[Balance]"), m_Balance);
	RFX_Text(pFX, _T("[Valid_Acc]"), m_Valid_Acc);
	RFX_Long(pFX, _T("[Account_Number]"), m_Account_Number);
	RFX_Long(pFX, _T("[Ref_Acc_No]"), m_Ref_Acc_No);
	//RFX_Text(pFX, _T("[curr_date]"), m_curr_date);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Ref_AccNo diagnostics

#ifdef _DEBUG
void Ref_AccNo::AssertValid() const
{
	CRecordset::AssertValid();
}

void Ref_AccNo::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG

long Ref_AccNo::GetCurrentRecord() const
{
	return 0;
	//CRecordsetStatus oRecStatus;
	//GetStatus(oRecStatus);
	//return oRecStatus.m_lCurrentRecord;
}
long Ref_AccNo::GetTotalCount() const
{
	return GetRecordCount();
	//CRecordsetStatus oRecStatus;
	//GetStatus(oRecStatus);
	//return oRecStatus.m_lCurrentRecord;
}

