// Transfer.cpp : implementation file
//

#include "stdafx.h"
#include "BankOperation.h"
#include "Transfer.h"
#include "Ref_AccNo.h"
#include "Transfer.h"
#include "Tran_DW.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CTransfer dialog


CTransfer::CTransfer(CWnd* pParent /*=NULL*/)
	: CDialog(CTransfer::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTransfer)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTransfer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTransfer)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTransfer, CDialog)
	//{{AFX_MSG_MAP(CTransfer)
	ON_BN_CLICKED(IDC_INTERNAL, OnInternal)
	ON_BN_CLICKED(IDC_External, OnExternal)
	//ON_EN_KILLFOCUS(IDC_CAMT, OnKillfocusCamt)
	ON_BN_CLICKED(IDC_CSAVE, OnCsave)
	ON_BN_CLICKED(IDC_CCANCEL, OnCcancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTransfer message handlers
void CTransfer::OnInternal() 
{
	((CEdit*)GetDlgItem(IDC_TACCNO))->EnableWindow(true);
	((CEdit*)GetDlgItem(IDC_CNAME))->EnableWindow(true);
	((CEdit*)GetDlgItem(IDC_CAMT))->EnableWindow(true);
	((CEdit*)GetDlgItem(IDC_CBANKNAME))->EnableWindow(false);
	((CEdit*)GetDlgItem(IDC_CBANKADDR))->EnableWindow(false);
}

void CTransfer::OnExternal() 
{
	((CEdit*)GetDlgItem(IDC_TACCNO))->EnableWindow(true);
	((CEdit*)GetDlgItem(IDC_CNAME))->EnableWindow(true);
	((CEdit*)GetDlgItem(IDC_CAMT))->EnableWindow(true);
	((CEdit*)GetDlgItem(IDC_CBANKNAME))->EnableWindow(true);
	((CEdit*)GetDlgItem(IDC_CBANKADDR))->EnableWindow(true);
}

void CTransfer::CheckForBalance() 
{
	Ref_AccNo *m_ptr1;
	m_ptr1=new Ref_AccNo;
	if(!m_ptr1->IsOpen ())
		m_ptr1->Open();
	if(!m_ptr1->IsBOF() && m_ptr1->IsEOF())
		m_ptr1->MoveFirst();

	long tamt=GetDlgItemInt(IDC_CAMT,NULL,true);
	long acc=GetDlgItemInt(IDC_TACCNO,NULL,true);
	while(!m_ptr1->IsEOF())
	{
		if(m_ptr1->m_Account_Number==acc)
			break;
		m_ptr1->MoveNext();
	}
	m_ptr1->MoveFirst();
	acc=GetDlgItemInt(IDC_FRMACCNO,NULL,true);
	while(!m_ptr1->IsEOF())
	{
		if(m_ptr1->m_Account_Number==acc)
		{
			double WAmt=m_ptr1->m_Balance-tamt;
			if(WAmt<500)
			{
				AfxMessageBox("You do not have Sufficient Balance in your Account");
				((CEdit*)GetDlgItem(IDC_CAMT))->SetFocus();
				return;
			}
			else
				break;
		}
		m_ptr1->MoveNext();
	}
}

void CTransfer::OnCsave() 
{
	if (!VerifyAccountNumber())
		return;

	//Check for the avilable balance
	CheckForBalance();

	Tran_DW *ptr1;
	ptr1=new Tran_DW;
	if(!ptr1->IsOpen ())
		ptr1->Open();
	if(!ptr1->IsBOF() && ptr1->IsEOF())
		ptr1->MoveLast();
	ptr1->AddNew();
		
	CButton *pExternal, *pInternal;
	pExternal=(CButton*)GetDlgItem(IDC_External);
	pInternal=(CButton*)GetDlgItem(IDC_INTERNAL);
	
	ptr1->m_Account_Number=GetDlgItemInt(IDC_FRMACCNO, NULL, true);
	ptr1->m_To_Account=GetDlgItemInt(IDC_TACCNO,NULL,true);
	GetDlgItemText(IDC_CNAME,ptr1->m_Creditor_Name);
	ptr1->m_Transaction_Amount=GetDlgItemInt(IDC_CAMT,NULL,true);
	GetDlgItemText(IDC_CCDT,ptr1->m_Transaction_Date);
	ptr1->m_Transaction_Status="P";

	ptr1->m_Transaction_Mode="TRF";	
	if(pExternal->GetCheck()==BST_CHECKED)
	{
		GetDlgItemText(IDC_CBANKNAME,ptr1->m_Creditor_BankName);
		GetDlgItemText(IDC_CBANKADDR,ptr1->m_Creditor_BankAddr);
		ptr1->m_Transaction_Type="ETF";	
	}
	if(pExternal->GetCheck()==BST_CHECKED)
		ptr1->m_Transaction_Type="ETF";	
	if(pInternal->GetCheck()==BST_CHECKED)
		ptr1->m_Transaction_Type="ITF";	
	
	if(!ptr1->Update())
		AfxMessageBox("Unable to Save....");
	
	AfxMessageBox("Transaction is successful");
	if(ptr1->Requery()==0)
		return;

	CDialog::OnOK();
}

void CTransfer::OnCcancel() 
{
	CDialog::OnCancel();	
}

BOOL CTransfer::OnInitDialog()
{
	CComboBox *cmb;
	cmb=(CComboBox*)GetDlgItem(IDC_FRMACCNO);
	
	CTime t1=CTime::GetCurrentTime();
	int dd=t1.GetDay();
	int mm=t1.GetMonth();
	int yy=t1.GetYear();
	char str[30];
	sprintf(str,"%2d/%2d/%2d",dd,mm,yy);
	SetDlgItemText(IDC_CCDT,str);
	
	if(cmb->GetCount()>0)
		cmb->Clear();

	Ref_AccNo *m_pGet=new Ref_AccNo;
	if(!m_pGet->IsOpen ())
		m_pGet->Open();
	if(!m_pGet->IsBOF() && m_pGet->IsEOF())
		m_pGet->MoveFirst();
	char str1[30];
	while(!m_pGet->IsEOF())
	{
		if(m_pGet->m_Valid_Acc.CompareNoCase("VA") == 0)
		{
			sprintf(str1,"%d",m_pGet->m_Account_Number);
			cmb->AddString(str1);
		}
		m_pGet->MoveNext();
	}

	GetDlgItem(IDC_FRMACCNO)->SetFocus();
	return FALSE;
}

BOOL CTransfer::VerifyAccountNumber()
{
	Ref_AccNo *m_ptr1;
	m_ptr1=new Ref_AccNo;
	if(!m_ptr1->IsOpen ())
		m_ptr1->Open();
	if(m_ptr1->IsBOF() && m_ptr1->IsEOF ())
		AfxMessageBox("No Records in the Database...");
	m_ptr1->MoveFirst();

	bool flag=false;
	long acc=GetDlgItemInt(IDC_TACCNO,NULL,true);

	CButton* pRadioExternal = (CButton*) GetDlgItem(IDC_External);
	if (pRadioExternal->GetState() & 0x0003)
	{
		// We won't check the validity of extrnal checks
		return TRUE;
	}

	while(!m_ptr1->IsEOF())
	{
		if(acc==m_ptr1->m_Account_Number)
		{
			if(m_ptr1->m_Valid_Acc=="CA")
			{
				AfxMessageBox("UnOperational Account - Check Account Number");
				flag=false;
				((CEdit*)GetDlgItem(IDC_TACCNO))->SetFocus();
				return flag;
			}
			flag=true;
			break;
		}
		m_ptr1->MoveNext();
	}
	if(m_ptr1->IsEOF() && flag==false)
	{
		AfxMessageBox("Invalid Account Number. Please enter again");
		((CEdit*)GetDlgItem(IDC_TACCNO))->SetFocus();
	}
	return flag;
}
