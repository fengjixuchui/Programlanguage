#if !defined(AFX_REF_ACCNO_H__224FF4E1_9D44_11D5_AC60_00A0C93654A0__INCLUDED_)
#define AFX_REF_ACCNO_H__224FF4E1_9D44_11D5_AC60_00A0C93654A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Ref_AccNo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Ref_AccNo recordset

class Ref_AccNo : public CRecordset
{
public:
	long GetTotalCount() const;
	long GetCurrentRecord()const;
	Ref_AccNo(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(Ref_AccNo)

// Field/Param Data
	//{{AFX_FIELD(Ref_AccNo, CRecordset)
	CString	m_First_Name;
	CString	m_Last_Name;
	CString	m_date_birth;
//	COleDateTime m_date_birth;
	CString	m_Permanent_Addr;
	CString	m_Mailing_Addr;
	CString	m_Phone_Number;
	CString	m_eMailID;
	CString	m_Type_account;
	double	m_Balance;
	CString	m_Valid_Acc;
	long	m_Account_Number;
	long	m_Ref_Acc_No;
	CString	m_curr_date;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Ref_AccNo)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REF_ACCNO_H__224FF4E1_9D44_11D5_AC60_00A0C93654A0__INCLUDED_)
