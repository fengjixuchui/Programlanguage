#if !defined(AFX_TRANSFER_H__0AFD04C3_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_)
#define AFX_TRANSFER_H__0AFD04C3_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Transfer.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTransfer dialog

class CTransfer : public CDialog
{
// Construction
public:
	CTransfer(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTransfer)
	enum { IDD = IDD_TRANSFER };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTransfer)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTransfer)
	afx_msg void OnDropdownFrmaccno();
	afx_msg void OnInternal();
	afx_msg void OnExternal();
	afx_msg void OnKillfocusTaccno();
	//afx_msg void OnKillfocusCamt();
	afx_msg void OnCsave();
	afx_msg void OnCcancel();
	afx_msg BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	BOOL VerifyAccountNumber();
	void CheckForBalance();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRANSFER_H__0AFD04C3_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_)
