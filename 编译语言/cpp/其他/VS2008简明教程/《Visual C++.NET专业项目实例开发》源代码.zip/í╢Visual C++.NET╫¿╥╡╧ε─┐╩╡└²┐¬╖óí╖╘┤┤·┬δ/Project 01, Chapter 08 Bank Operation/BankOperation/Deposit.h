#if !defined(AFX_DEPOSIT_H__0AFD04C1_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_)
#define AFX_DEPOSIT_H__0AFD04C1_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Deposit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDeposit dialog

class CDeposit : public CDialog
{
// Construction
public:
	CDeposit(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDeposit)
	enum { IDD = IDD_DEPWDRL };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDeposit)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDeposit)
	afx_msg void OnRdep();
	afx_msg void OnRwithdraw();
	afx_msg void OnCash();
	afx_msg void OnCheck();
	afx_msg void OnSave();
	afx_msg BOOL OnInitDialog();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEPOSIT_H__0AFD04C1_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_)
