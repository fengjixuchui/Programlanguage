// ChkBook.cpp : implementation file
//

#include "stdafx.h"
#include "BankOperation.h"
#include "ChkBook.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChkBook

IMPLEMENT_DYNAMIC(CChkBook, CRecordset)

CChkBook::CChkBook(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CChkBook)
	m_Number_of_Checks = 0;
	m_Start_Check_Number = 0;
	m_Account_Number = 0;
	m_Date_of_Issue = _T("");
	m_Tran_No = 0;
	m_End_Check_Number = 0;
	m_Hand_Over = _T("");
	m_nFields = 7;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}


CString CChkBook::GetDefaultConnect()
{
	return _T("ODBC;DSN=Bank;UID=sa;PWD=");
}

CString CChkBook::GetDefaultSQL()
{
	return _T("[dbo].[Check_Book]");
}

void CChkBook::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CChkBook)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[Number_of_Checks]"), m_Number_of_Checks);
	RFX_Long(pFX, _T("[Start_Check_Number]"), m_Start_Check_Number);
	RFX_Long(pFX, _T("[Account_Number]"), m_Account_Number);
	RFX_Text(pFX, _T("[Date_of_Issue]"), m_Date_of_Issue);
	RFX_Long(pFX, _T("[Tran_No]"), m_Tran_No);
	RFX_Long(pFX, _T("[End_Check_Number]"), m_End_Check_Number);
	RFX_Text(pFX, _T("[Hand_Over]"), m_Hand_Over);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CChkBook diagnostics

#ifdef _DEBUG
void CChkBook::AssertValid() const
{
	CRecordset::AssertValid();
}

void CChkBook::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
