#if !defined(AFX_TRAN_DW_H__0AFD04C2_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_)
#define AFX_TRAN_DW_H__0AFD04C2_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Tran_DW.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Tran_DW recordset

class Tran_DW : public CRecordset
{
public:
	Tran_DW(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(Tran_DW)

// Field/Param Data
	//{{AFX_FIELD(Tran_DW, CRecordset)
	long	m_Account_Number;
	long	m_Check_Draft_Number;
	CString	m_Creditor_BankAddr;
	CString	m_Creditor_BankName;
	CString	m_Creditor_Name;
	long	m_To_Account;
	long	m_TranId;
	double	m_Transaction_Amount;
	CString	m_Transaction_Date;
	CString	m_Transaction_Mode;
	CString	m_Transaction_Status;
	CString	m_Transaction_Type;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Tran_DW)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRAN_DW_H__0AFD04C2_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_)
