// Clearance.cpp : implementation file
//

#include "stdafx.h"
#include "BankOperation.h"
#include "Clearance.h"
#include "Tran_DW.h"
#include "Ref_AccNo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

Tran_DW *tptr1;
Ref_AccNo *rptr1;
/////////////////////////////////////////////////////////////////////////////
// CClearance dialog


CClearance::CClearance(CWnd* pParent /*=NULL*/)
	: CDialog(CClearance::IDD, pParent)
{
	//{{AFX_DATA_INIT(CClearance)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CClearance::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClearance)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CClearance, CDialog)
	//{{AFX_MSG_MAP(CClearance)
	ON_BN_CLICKED(IDCGENLIST, OnCgenlist)
	ON_BN_CLICKED(IDCSAVE, OnCsave)
	ON_CBN_SELCHANGE(IDC_TRANID, OnSelchangeTranid)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClearance message handlers

void CClearance::OnCgenlist() 
{
	CComboBox *ed1;
	ed1=(CComboBox*)GetDlgItem(IDC_TRANID);
	ed1->EnableWindow(true);

	CButton *b1,*b2;
	b1=(CButton*)GetDlgItem(IDC_CLCHECK);
	b1->EnableWindow(true);
	
	b2=(CButton*)GetDlgItem(IDCSAVE);
	b2->EnableWindow(true);
	
	tptr1=new Tran_DW;
	if(!tptr1->IsOpen())
		tptr1->Open();
	if(!tptr1->IsBOF() && tptr1->IsEOF())
		tptr1->MoveFirst();
	while(!tptr1->IsEOF())
	{
		if(tptr1->m_Transaction_Status=="P" && tptr1->m_Transaction_Type!="STP")
		{
			char str[30];
			sprintf(str,"%d",tptr1->m_TranId);
			ed1->AddString(str);
		}
		tptr1->MoveNext();
	}
}

void CClearance::OnCsave() 
{
	tptr1=new Tran_DW;
	int sel=GetDlgItemInt(IDC_LACCNO,NULL,true);
	
	CComboBox *l1;
	l1=(CComboBox*)GetDlgItem(IDC_TRANID);
	int selected=l1->GetCurSel();
	int tranID;
	tranID=GetDlgItemInt(IDC_TRANID,NULL,true);
	
	CString cmdStr;
	cmdStr.Format("Select * from Transaction_Detail where TranId=%d and Account_Number = %d and Transaction_Type !='STP'",tranID ,sel);
	AfxMessageBox(cmdStr);
	
	tptr1->Open(AFX_DB_USE_DEFAULT_TYPE, cmdStr);
	tptr1->Edit();
	if(tptr1->m_Transaction_Mode=="CHQ")
		if(tptr1->m_Transaction_Type="WTH")
		{
			tptr1->m_Creditor_Name="";
			tptr1->m_Creditor_BankAddr="";
			tptr1->m_Creditor_BankName="";
			tptr1->m_To_Account=-99;
		}
	
	if(tptr1->m_Transaction_Mode=="ITF")
	{
		AfxMessageBox("Init");
		tptr1->m_Creditor_BankAddr="";
		tptr1->m_Creditor_BankName="";
		tptr1->m_Check_Draft_Number=-99;
		AfxMessageBox("Initlized");
	}
	if(tptr1->m_Transaction_Mode=="ETF")
	{
		tptr1->m_Check_Draft_Number=-99;
	}
	
	AfxMessageBox("Checked the mode");
	rptr1=new Ref_AccNo;
	if(!rptr1->IsOpen())
		rptr1->Open();
	if(!rptr1->IsBOF() && rptr1->IsEOF())
		rptr1->MoveFirst();

	while(!rptr1->IsEOF())
	{
		if(rptr1->m_Account_Number==sel)
		{
			double WAmt=rptr1->m_Balance-tptr1->m_Transaction_Amount;
			if(WAmt<500)
			{
				AfxMessageBox("Insufficient Balance Amount - Check/Transfer Cancelled");
				tptr1->m_Transaction_Status="B"; //For Bounced Check
				break;
			}
			else
			{
				AfxMessageBox("Sufficient Balance Amount");
				AfxMessageBox(tptr1->m_Transaction_Type);
				if(tptr1->m_Transaction_Type=="WTH" || tptr1->m_Transaction_Type=="ETF" || tptr1->m_Transaction_Type=="ITF")
				{
					AfxMessageBox("Value is updatable");
					tptr1->m_Transaction_Status="C"; //Check is cleared
					rptr1->Edit();
					rptr1->m_Balance=rptr1->m_Balance-tptr1->m_Transaction_Amount;
					rptr1->m_CIS_LoginID="";
					rptr1->m_CIS_Password="";
					if(!rptr1->Update())
						AfxMessageBox("Unable to update the balance Amount");
					else
						AfxMessageBox("Balance is updated..");
					break;
				}
			}
		}
		rptr1->MoveNext();
	}
	AfxMessageBox(tptr1->m_Transaction_Status);
	AfxMessageBox(tptr1->m_Creditor_BankAddr);
	if(!tptr1->Update())
		AfxMessageBox("Error Updating Database");
	if(tptr1->Requery()==0)
		return;
	AfxMessageBox("Pending Transcation Status Updated in the Database");
}

void CClearance::OnSelchangeTranid() 
{
	tptr1=new Tran_DW;
	if(!tptr1->IsOpen())
		tptr1->Open();
	if(!tptr1->IsBOF() && tptr1->IsEOF())
		tptr1->MoveFirst();
	
	CComboBox *l1;
	l1=(CComboBox*)GetDlgItem(IDC_TRANID);
	int sel=l1->GetCurSel();
	CString str;
	l1->GetLBText(sel,str);
	sel=atoi(str);
	
	while(!tptr1->IsEOF())
	{
		if(tptr1->m_TranId==sel)
		{
			long mAccNo=tptr1->m_Account_Number;
			SetDlgItemInt(IDC_LACCNO,mAccNo,true);
			break;
		}
		tptr1->MoveNext();
	}	
	AfxMessageBox("Please Check the Transaction Number \n Before Updating");
}
