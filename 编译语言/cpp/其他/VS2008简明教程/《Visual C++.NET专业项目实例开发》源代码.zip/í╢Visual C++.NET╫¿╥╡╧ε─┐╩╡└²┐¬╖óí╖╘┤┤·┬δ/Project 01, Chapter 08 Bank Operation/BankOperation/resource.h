//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BankOperation.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_BANKOPERATION_FORM          101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_MAINFRAME                   128
#define IDR_BANKOPTYPE                  129
#define IDD_DIALOG1                     130
#define IDD_DEPWDRL                     130
#define IDD_DIALOG2                     131
#define IDD_TRANSFER                    131
#define IDD_DIALOG5                     134
#define IDD_LOGINDLG                    134
#define ID_REPORTS_DAYENDTRANSACTIONS   135
#define ID_REPORTS_MORE                 136
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_RADIO3                      1002
#define IDC_ACCNO                       1004
#define IDC_FNAME                       1005
#define IDC_LNAME                       1006
#define IDC_DOB                         1007
#define IDC_PADD                        1008
#define IDC_MADD                        1009
#define IDC_PHONE                       1010
#define IDC_EMAIL                       1011
#define IDC_REFACCNO                    1012
#define IDC_AMOUNT                      1013
#define IDC_CISLOGIN                    1014
#define IDC_CISPWD                      1015
#define IDC_SAVE                        1016
#define IDC_MODIFY                      1017
#define IDC_UPD                         1018
#define IDC_DELETE                      1019
#define IDC_CLEAR                       1020
#define IDC_VALID                       1021
#define IDC_MOD                         1022
#define IDC_CHECK1                      1023
#define IDC_CHECK2                      1024
#define IDC_CURRDT                      1025
#define IDC_DEPOSIT                     1026
#define IDC_CASH                        1027
#define IDC_TRANSFER                    1027
#define IDC_FC                          1028
#define IDC_AMTDEPW                     1028
#define IDC_CHECKNO                     1029
#define IDSAVE                          1030
#define IDC_CHECK                       1032
#define IDC_RDEP                        1033
#define IDC_RWITHDRAW                   1034
#define IDC_ACCNUM                      1035
#define IDC_TRANDT                      1036
#define IDC_CALCINT                     1037
#define IDC_GIVECLEAR                   1038
#define IDC_FRMACCNO                    1038
#define IDC_TACCNO                      1039
#define IDC_INTERNAL                    1040
#define IDC_External                    1041
#define IDC_CNAME                       1042
#define IDC_CBANKNAME                   1043
#define IDC_CBANKADDR                   1044
#define IDC_CAMT                        1045
#define IDC_CSAVE                       1046
#define IDC_CCANCEL                     1047
#define IDC_CCDT                        1048
#define IDC_FOLIO_NO                    1050
#define IDC_FFNAME                      1051
#define IDC_FLNAME                      1052
#define IDC_FCDT                        1053
#define IDC_OPPAMT                      1054
#define IDC_TENURE                      1055
#define IDC_MATAMT                      1056
#define IDC_MDT                         1057
#define ID_FSAVE                        1058
#define ID_FCANCEL                      1059
#define ID_FCLEAR                       1060
#define ID_GENINFO                      1061
#define IDC_CLCHECK                     1061
#define IDCSAVE                         1062
#define IDCGENLIST                      1063
#define IDC_LACCNO                      1066
#define IDC_TRANID                      1067
#define IDC_LOGIN                       1068
#define IDC_PASSWORD                    1069
#define IDC_BUTTON1                     1070
#define IDC_BUTTON2                     1071
#define IDC_BUTTON3                     1072
#define IDC_BUTTON4                     1073
#define IDC_BUTTON5                     1076
#define IDC_COMMIT                      1076
#define IDC_BUTTON6                     1077
#define IDC_REACTIVATE                  1077
#define IDC_CANCEL1                     1078
#define IDC_RICHEDIT21                  1082
#define IDC_BUTTON7                     1083

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1084
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
