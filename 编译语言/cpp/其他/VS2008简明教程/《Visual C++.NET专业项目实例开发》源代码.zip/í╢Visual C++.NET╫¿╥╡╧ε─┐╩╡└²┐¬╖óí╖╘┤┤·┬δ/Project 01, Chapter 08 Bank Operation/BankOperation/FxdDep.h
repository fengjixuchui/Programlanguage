#if !defined(AFX_FXDDEP_H__0AFD04C5_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_)
#define AFX_FXDDEP_H__0AFD04C5_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FxdDep.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFxdDep recordset

class CFxdDep : public CRecordset
{
public:
	CFxdDep(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CFxdDep)

// Field/Param Data
	//{{AFX_FIELD(CFxdDep, CRecordset)
	long	m_Folio_Number;
	CString	m_Fname;
	CString	m_Lname;
	long	m_Tenure;
	double	m_Opening_Balance_Amount;
	double	m_Maturity_Amount;
	CString	m_Maturity_Date;
	CString	m_Transaction_Date;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFxdDep)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FXDDEP_H__0AFD04C5_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_)
