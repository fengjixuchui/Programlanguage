// BankOperationDoc.cpp : implementation of the CBankOperationDoc class
//

#include "stdafx.h"
#include "BankOperation.h"

#include "BankOperationSet.h"
#include "BankOperationDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBankOperationDoc

IMPLEMENT_DYNCREATE(CBankOperationDoc, CDocument)

BEGIN_MESSAGE_MAP(CBankOperationDoc, CDocument)
	//{{AFX_MSG_MAP(CBankOperationDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBankOperationDoc construction/destruction

CBankOperationDoc::CBankOperationDoc()
{
	// TODO: add one-time construction code here

}

CBankOperationDoc::~CBankOperationDoc()
{
}

BOOL CBankOperationDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CBankOperationDoc diagnostics

#ifdef _DEBUG
void CBankOperationDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CBankOperationDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBankOperationDoc commands
