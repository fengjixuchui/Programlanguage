// BankOperationView.cpp : implementation of the CBankOperationView class
//

#include "stdafx.h"
#include "BankOperation.h"
#include "Ref_AccNo.h"
#include "ChkBook.h"
#include "Deposit.h"
#include "Transfer.h"

#include "BankOperationSet.h"
#include "BankOperationDoc.h"
#include "BankOperationView.h"
#include "Tran_DW.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

using namespace AUTOGEN_ACCOUNT_NOLib;

Ref_AccNo* m_pRef;
CChkBook *m_pBk;

/////////////////////////////////////////////////////////////////////////////
// CBankOperationView

IMPLEMENT_DYNCREATE(CBankOperationView, CRecordView)

BEGIN_MESSAGE_MAP(CBankOperationView, CRecordView)
	//{{AFX_MSG_MAP(CBankOperationView)
	ON_COMMAND(ID_RECORD_FIRST, OnRecordFirst)
	ON_COMMAND(ID_RECORD_LAST, OnRecordLast)
	ON_COMMAND(ID_RECORD_NEXT, OnRecordNext)
	ON_COMMAND(ID_RECORD_PREV, OnRecordPrev)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	ON_BN_CLICKED(IDC_DELETE, OnDeActivate)
	ON_CBN_SELCHANGE(IDC_ACCNO, OnSelchangeAccno)
	ON_BN_CLICKED(IDC_UPD, OnUpd)
	ON_BN_CLICKED(IDC_MOD, OnMod)
	ON_BN_CLICKED(IDC_CHECK1, OnCheck1)
	ON_BN_CLICKED(IDC_CLEAR, OnClear)
	ON_BN_CLICKED(IDC_DEPOSIT, OnDeposit)
	ON_BN_CLICKED(IDC_TRANSFER, OnTransfer)
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedFirst)
	ON_BN_CLICKED(IDC_BUTTON4, OnBnClickedLast)
	ON_BN_CLICKED(IDC_BUTTON2, OnBnClickedPrev)
	ON_BN_CLICKED(IDC_BUTTON3, OnBnClickedNext)
	ON_BN_CLICKED(IDC_COMMIT, OnBnClickedCommit)
	ON_BN_CLICKED(IDC_REACTIVATE, OnBnClickedReactivate)
	ON_BN_CLICKED(IDC_CANCEL1, OnBnClickedCancel1)
	ON_COMMAND(ID_REPORTS_DAYENDTRANSACTIONS, OnReportsDayendtransactions)
	ON_COMMAND(ID_REPORTS_MORE, OnReportsMore)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBankOperationView construction/destruction

CBankOperationView::CBankOperationView()
	: CRecordView(CBankOperationView::IDD)
{
	//{{AFX_DATA_INIT(CBankOperationView)
	m_pSet = NULL;
	m_pRef = NULL;
	m_pBk=NULL;
	//}}AFX_DATA_INIT
	// TODO: add construction code here
	m_nCurrentRecord = 0;
	m_bAddNewAccount = FALSE;
	m_bFromCancel = FALSE;
	m_bFromCommit = FALSE;
	m_bFromUpdate = FALSE;
}

CBankOperationView::~CBankOperationView()
{
}

void CBankOperationView::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBankOperationView)
	DDX_FieldText(pDX, IDC_ACCNO, m_pSet->m_Account_Number, m_pSet);
	DDX_FieldText(pDX, IDC_AMOUNT, m_pSet->m_Balance, m_pSet);
	DDX_FieldText(pDX, IDC_EMAIL, m_pSet->m_eMailID, m_pSet);
	DDX_FieldText(pDX, IDC_FNAME, m_pSet->m_First_Name, m_pSet);
	DDX_FieldText(pDX, IDC_LNAME, m_pSet->m_Last_Name, m_pSet);
	DDX_FieldText(pDX, IDC_MADD, m_pSet->m_Mailing_Addr, m_pSet);
	DDX_FieldText(pDX, IDC_PADD, m_pSet->m_Permanent_Addr, m_pSet);
	DDX_FieldText(pDX, IDC_PHONE, m_pSet->m_Phone_Number, m_pSet);
	DDX_FieldText(pDX, IDC_DOB, m_pSet->m_date_birth, m_pSet);
	DDX_FieldText(pDX, IDC_REFACCNO, m_pSet->m_Ref_Acc_No, m_pSet);
	//}}AFX_DATA_MAP
}

BOOL CBankOperationView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRecordView::PreCreateWindow(cs);
}

void CBankOperationView::OnInitialUpdate()
{
	CMonthCalCtrl *pDOB;
	pDOB = (CMonthCalCtrl *)GetDlgItem(IDC_DOB);
	
	m_pSet = &GetDocument()->m_bankOperationSet;
	m_pRef = new Ref_AccNo;

	//Set the max limit of the DOB edit box to 10
	((CEdit*)GetDlgItem(IDC_DOB))->SetLimitText(10);

	if(!m_pSet->IsOpen ())
		m_pSet->Open();
	if(!m_pSet->IsBOF() && m_pSet->IsEOF())
		m_pSet->MoveFirst();

	if (m_bFromCancel || m_bFromCommit || m_bFromUpdate)
	{
		m_pSet->MoveFirst();
		m_pSet->MoveLast();
		UpdateData(true);
		m_pSet->Requery();
	}

	CRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	CComboBox* cmb=(CComboBox*)GetDlgItem(IDC_ACCNO);
	
	if (!m_bFromCancel && !m_bFromCommit && !m_bFromUpdate)
	{
		while(!m_pSet->IsEOF())
		{
			char str[30];
			sprintf(str,"%d",m_pSet->m_Account_Number);
			cmb->AddString(str);
			m_pSet->MoveNext();
		}
		m_pSet->MoveFirst();
	}

	//Enable Disable 
	if (m_pSet->m_Valid_Acc.CompareNoCase("CA"))
	{
		((CButton*)GetDlgItem(IDC_REACTIVATE))->EnableWindow(false);
	}
	else
	{
		((CButton*)GetDlgItem(IDC_REACTIVATE))->EnableWindow(true);
	}

	CButton *b1;
	b1=(CButton*)GetDlgItem(IDC_UPD);
	b1->EnableWindow(false);
	CButton *bAdd,*bMod,*bDel,*bUpd, *pCancel;
	if(m_pSet->m_Valid_Acc=="CA")
	{
		SetDlgItemText(IDC_VALID,"UnOperational Account");

		bAdd=(CButton*)GetDlgItem(IDC_SAVE);
		bAdd->EnableWindow(false);
		
		bUpd=(CButton*)GetDlgItem(IDC_UPD);
		bUpd->EnableWindow(false);

		pCancel=(CButton*)GetDlgItem(IDC_CANCEL1);
		pCancel->EnableWindow(false);

		bMod=(CButton*)GetDlgItem(IDC_MOD);
		bMod->EnableWindow(false);
		
		bDel=(CButton*)GetDlgItem(IDC_DELETE);
		bDel->EnableWindow(false);
		
		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);
	}
	else
	{	
		SetDlgItemText(IDC_VALID,"Operational Account");

		bAdd=(CButton*)GetDlgItem(IDC_SAVE);
		bAdd->EnableWindow(true);
		
		bUpd=(CButton*)GetDlgItem(IDC_UPD);
		bUpd->EnableWindow(false);
		
		pCancel=(CButton*)GetDlgItem(IDC_CANCEL1);
		pCancel->EnableWindow(false);
		
		bMod=(CButton*)GetDlgItem(IDC_MOD);
		bMod->EnableWindow(true);
		
		bDel=(CButton*)GetDlgItem(IDC_DELETE);
		bDel->EnableWindow(true);

		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);
	}

	CButton *pSaving,*pCurrent,*pChecking;
	pSaving=(CButton*)GetDlgItem(IDC_RADIO1);
	pCurrent=(CButton*)GetDlgItem(IDC_RADIO2);
	pChecking=(CButton*)GetDlgItem(IDC_RADIO3);

	if(m_pSet->m_Type_account=="S")
	{
		pSaving->SetCheck(true);
		pCurrent->SetCheck(false);
		pChecking->SetCheck(false);
	}
	else if(m_pSet->m_Type_account=="C")
	{
		pSaving->SetCheck(false);
		pCurrent->SetCheck(true);
		pChecking->SetCheck(false);
	}
	else if(m_pSet->m_Type_account=="K")
	{
		pSaving->SetCheck(false);
		pCurrent->SetCheck(false);
		pChecking->SetCheck(true);
	}

	CTime t1=CTime::GetCurrentTime();
	int dd=t1.GetDay();
	int mm=t1.GetMonth();
	int yy=t1.GetYear();
	char str[30];
	sprintf(str,"%2d/%2d/%2d",dd,mm,yy);
	SetDlgItemText(IDC_CURRDT,str);

	EnableDisableNavigationKeys(5);
}

/////////////////////////////////////////////////////////////////////////////
// CBankOperationView diagnostics

#ifdef _DEBUG
void CBankOperationView::AssertValid() const
{
	CRecordView::AssertValid();
}

void CBankOperationView::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CBankOperationDoc* CBankOperationView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CBankOperationDoc)));
	return (CBankOperationDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBankOperationView database support
CRecordset* CBankOperationView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CBankOperationView message handlers
void CBankOperationView::OnRecordFirst() 
{
	m_nCurrentRecord = 1;
	m_pSet->MoveFirst();
	UpdateData(false);

	CButton *bAdd,*bMod,*bDel,*bUpd, *bReac;
	if(m_pSet->m_Valid_Acc=="CA")
	{
		SetDlgItemText(IDC_VALID,"UnOperational Account");

		bAdd=(CButton*)GetDlgItem(IDC_SAVE);
		bAdd->EnableWindow(false);
		
		bUpd=(CButton*)GetDlgItem(IDC_UPD);
		bUpd->EnableWindow(false);
		
		bMod=(CButton*)GetDlgItem(IDC_MOD);
		bMod->EnableWindow(false);

		bDel=(CButton*)GetDlgItem(IDC_DELETE);
		bDel->EnableWindow(false);

		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);
	}
	else
	{	
		SetDlgItemText(IDC_VALID,"Operational Account");
		
		bAdd=(CButton*)GetDlgItem(IDC_SAVE);
		bAdd->EnableWindow(true);
		
		bUpd=(CButton*)GetDlgItem(IDC_UPD);
		bUpd->EnableWindow(false);
		
		bMod=(CButton*)GetDlgItem(IDC_MOD);
		bMod->EnableWindow(true);
		
		bDel=(CButton*)GetDlgItem(IDC_DELETE);
		bDel->EnableWindow(true);

		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);
	}
	CButton *pSaving,*pCurrent,*pChecking;
	pSaving=(CButton*)GetDlgItem(IDC_RADIO1);
	pCurrent=(CButton*)GetDlgItem(IDC_RADIO2);
	pChecking=(CButton*)GetDlgItem(IDC_RADIO3);

	if(m_pSet->m_Type_account=="S")
	{
		pSaving->SetCheck(true);
		pCurrent->SetCheck(false);
		pChecking->SetCheck(false);
	}
	else if(m_pSet->m_Type_account=="C")
	{
		pSaving->SetCheck(false);
		pCurrent->SetCheck(true);
		pChecking->SetCheck(false);
	}
	else if(m_pSet->m_Type_account=="K")
	{
		pSaving->SetCheck(false);
		pCurrent->SetCheck(false);
		pChecking->SetCheck(true);
	}

}

void CBankOperationView::OnRecordLast() 
{
	if(!m_pSet->IsOpen())
		m_pSet->Open();
	if(!m_pSet->IsBOF() && m_pSet->IsEOF ())
	{
		m_pSet->MoveFirst();
	}
	int nTotalRecordCount=0;
	while (!m_pSet->IsEOF())
	{
		nTotalRecordCount++;
		m_pSet->MoveNext();
	}

	m_nCurrentRecord = nTotalRecordCount;

	m_pSet->MoveLast();
	UpdateData(false);

	CButton *bAdd,*bMod,*bDel,*bUpd;
	if(m_pSet->m_Valid_Acc=="CA")
	{
		SetDlgItemText(IDC_VALID,"UnOperational Account");

		bAdd=(CButton*)GetDlgItem(IDC_SAVE);
		bAdd->EnableWindow(false);
		
		bUpd=(CButton*)GetDlgItem(IDC_UPD);
		bUpd->EnableWindow(false);
		
		bMod=(CButton*)GetDlgItem(IDC_MOD);
		bMod->EnableWindow(false);
		
		bDel=(CButton*)GetDlgItem(IDC_DELETE);
		bDel->EnableWindow(false);
		
		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);
	}
	else
	{	
		SetDlgItemText(IDC_VALID,"Operational Account");

		bAdd=(CButton*)GetDlgItem(IDC_SAVE);
		bAdd->EnableWindow(true);
		
		bUpd=(CButton*)GetDlgItem(IDC_UPD);
		bUpd->EnableWindow(false);
		
		bMod=(CButton*)GetDlgItem(IDC_MOD);
		bMod->EnableWindow(true);
		
		bDel=(CButton*)GetDlgItem(IDC_DELETE);
		bDel->EnableWindow(true);

		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);
	}

	CButton *pSaving,*pCurrent,*pChecking;
	pSaving=(CButton*)GetDlgItem(IDC_RADIO1);
	pCurrent=(CButton*)GetDlgItem(IDC_RADIO2);
	pChecking=(CButton*)GetDlgItem(IDC_RADIO3);

	if(m_pSet->m_Type_account=="S")
	{
		pSaving->SetCheck(true);
		pCurrent->SetCheck(false);
		pChecking->SetCheck(false);
	}
	else if(m_pSet->m_Type_account=="C")
	{
		pSaving->SetCheck(false);
		pCurrent->SetCheck(true);
		pChecking->SetCheck(false);
	}
	else if(m_pSet->m_Type_account=="K")
	{
		pSaving->SetCheck(false);
		pCurrent->SetCheck(false);
		pChecking->SetCheck(true);
	}
}

void CBankOperationView::OnRecordNext() 
{
	m_nCurrentRecord++;

	if(m_pSet->IsEOF())
	{
		AfxMessageBox("Attempt to scroll beyond Last Record");
		return;
	}
	m_pSet->MoveNext();
	UpdateData(false);	
	
	CButton *bAdd,*bMod,*bDel,*bUpd;
	if(m_pSet->m_Valid_Acc=="CA")
	{
		SetDlgItemText(IDC_VALID,"UnOperational Account");

		bAdd=(CButton*)GetDlgItem(IDC_SAVE);
		bAdd->EnableWindow(false);
		
		bUpd=(CButton*)GetDlgItem(IDC_UPD);
		bUpd->EnableWindow(false);
		
		bMod=(CButton*)GetDlgItem(IDC_MOD);
		bMod->EnableWindow(false);
		
		bDel=(CButton*)GetDlgItem(IDC_DELETE);
		bDel->EnableWindow(false);
		
		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);
	}
	else
	{	
		SetDlgItemText(IDC_VALID,"Operational Account");

		bAdd=(CButton*)GetDlgItem(IDC_SAVE);
		bAdd->EnableWindow(true);
		
		bUpd=(CButton*)GetDlgItem(IDC_UPD);
		bUpd->EnableWindow(false);
		
		bMod=(CButton*)GetDlgItem(IDC_MOD);
		bMod->EnableWindow(true);
		
		bDel=(CButton*)GetDlgItem(IDC_DELETE);
		bDel->EnableWindow(true);

		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);
	}

	CButton *pSaving,*pCurrent,*pChecking;
	pSaving=(CButton*)GetDlgItem(IDC_RADIO1);
	pCurrent=(CButton*)GetDlgItem(IDC_RADIO2);
	pChecking=(CButton*)GetDlgItem(IDC_RADIO3);
	
	if(m_pSet->m_Type_account=="S")
	{
		pSaving->SetCheck(true);
		pCurrent->SetCheck(false);
		pChecking->SetCheck(false);
	}
	else if(m_pSet->m_Type_account=="C")
	{
		pSaving->SetCheck(false);
		pCurrent->SetCheck(true);
		pChecking->SetCheck(false);
	}
	else if(m_pSet->m_Type_account=="K")
	{
		pSaving->SetCheck(false);
		pCurrent->SetCheck(false);
		pChecking->SetCheck(true);
	}

}

void CBankOperationView::OnRecordPrev() 
{
	m_nCurrentRecord--;

	if(m_pSet->IsBOF())
	{
		AfxMessageBox("Attempt to scroll beyond First Record");
		return;
	}
	m_pSet->MovePrev();
	UpdateData(false);
	
	CButton *bAdd,*bMod,*bDel,*bUpd;
	if(m_pSet->m_Valid_Acc=="CA")
	{
		SetDlgItemText(IDC_VALID,"UnOperational Account");

		bAdd=(CButton*)GetDlgItem(IDC_SAVE);
		bAdd->EnableWindow(false);
		
		bUpd=(CButton*)GetDlgItem(IDC_UPD);
		bUpd->EnableWindow(false);
		
		bMod=(CButton*)GetDlgItem(IDC_MOD);
		bMod->EnableWindow(false);
		
		bDel=(CButton*)GetDlgItem(IDC_DELETE);
		bDel->EnableWindow(false);
		
		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);
	}
	else
	{	
		SetDlgItemText(IDC_VALID,"Operational Account");

		bAdd=(CButton*)GetDlgItem(IDC_SAVE);
		bAdd->EnableWindow(true);
		
		bUpd=(CButton*)GetDlgItem(IDC_UPD);
		bUpd->EnableWindow(false);
		
		bMod=(CButton*)GetDlgItem(IDC_MOD);
		bMod->EnableWindow(true);
		
		bDel=(CButton*)GetDlgItem(IDC_DELETE);
		bDel->EnableWindow(true);
		
		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);
	}

	CButton *pSaving,*pCurrent,*pChecking;
	pSaving=(CButton*)GetDlgItem(IDC_RADIO1);
	pCurrent=(CButton*)GetDlgItem(IDC_RADIO2);
	pChecking=(CButton*)GetDlgItem(IDC_RADIO3);
	
	if(m_pSet->m_Type_account=="S")
	{
		pSaving->SetCheck(true);
		pCurrent->SetCheck(false);
		pChecking->SetCheck(false);
	}
	else if(m_pSet->m_Type_account=="C")
	{
		pSaving->SetCheck(false);
		pCurrent->SetCheck(true);
		pChecking->SetCheck(false);
	}
	else if(m_pSet->m_Type_account=="K")
	{
		pSaving->SetCheck(false);
		pCurrent->SetCheck(false);
		pChecking->SetCheck(true);
	}
}

void CBankOperationView::OnSave() 
{
	CComboBox *cmb=(CComboBox*)GetDlgItem(IDC_ACCNO);
	long lAccountNum = cmb->GetCount();	
	lAccountNum = 10000 + lAccountNum; //10000 is the seed for Account number //Newly created account number
	cmb->EnableWindow(FALSE); //Disable the account num as it will get generated automatically.
	m_bAddNewAccount = TRUE;

	CString strAccNum;
	strAccNum.Format("%ld", lAccountNum);
	SetDlgItemText(IDC_ACCNO, strAccNum);

	CButton* pAdd, *pMod, *pUpd, *pCancel, *pDel, *pReActivate, *pDep, *pTransfer;
	pAdd=(CButton*)GetDlgItem(IDC_SAVE);
	pAdd->EnableWindow(false);
	pMod=(CButton*)GetDlgItem(IDC_MOD);
	pMod->EnableWindow(false);
	pUpd=(CButton*)GetDlgItem(IDC_UPD);
	pUpd->EnableWindow(true);
	pCancel=(CButton*)GetDlgItem(IDC_CANCEL1);
	pCancel->EnableWindow(true);
	pDel=(CButton*)GetDlgItem(IDC_DELETE);
	pDel->EnableWindow(false);
	pReActivate=(CButton*)GetDlgItem(IDC_REACTIVATE);
	pReActivate->EnableWindow(false);
	pDep=(CButton*)GetDlgItem(IDC_DEPOSIT);
	pDep->EnableWindow(false);
	pTransfer=(CButton*)GetDlgItem(IDC_TRANSFER);
	pTransfer->EnableWindow(false);

	SetDlgItemText(IDC_FNAME, "");
	SetDlgItemText(IDC_LNAME, "");
	SetDlgItemText(IDC_DOB, "");
	SetDlgItemText(IDC_PADD, "");
	SetDlgItemText(IDC_MADD, "");
	SetDlgItemText(IDC_PHONE, "");
	SetDlgItemText(IDC_EMAIL, "");
	SetDlgItemInt(IDC_REFACCNO,0,false);
	SetDlgItemInt(IDC_AMOUNT,0,false);

	CButton* pChk1=(CButton*)GetDlgItem(IDC_CHECK1);
	pChk1->SetCheck(0);

	//Rest will be done by Update button
}

//Handles the OnDeActivate button
void CBankOperationView::OnDeActivate() 
{
	if (AfxMessageBox("Are you sure you want to deactivate this account number?", MB_YESNO) == IDNO)
		return;

	m_pSet->Edit();
	long lCurrentAccountNum = m_pSet->m_Account_Number;
	m_pSet->m_Valid_Acc="CA";
	UpdateData(true);
	if(!m_pSet->Update())
		AfxMessageBox("Not Able to delete this account");
	if(m_pSet->Requery()==0)
		return;

	AfxMessageBox("The Account has been marked as Unused Account!!!");

	if(!m_pSet->IsBOF() && m_pSet->IsEOF())
		m_pSet->MoveFirst();
	while( m_pSet->m_Account_Number == lCurrentAccountNum || m_pSet->IsEOF())
	{
		m_pSet->MoveNext();
	}

	CButton *pAdd, *pUpd, *pMod, *pDel, *pReActivate;
	pAdd=(CButton*)GetDlgItem(IDC_SAVE);
	pAdd->EnableWindow(false);
		
	pUpd=(CButton*)GetDlgItem(IDC_UPD);
	pUpd->EnableWindow(false);
	
	pMod=(CButton*)GetDlgItem(IDC_MOD);
	pMod->EnableWindow(false);
	
	pDel=(CButton*)GetDlgItem(IDC_DELETE);
	pDel->EnableWindow(false);
		
	pReActivate=(CButton*)GetDlgItem(IDC_REACTIVATE);
	pReActivate->EnableWindow(true);

	SetDlgItemText(IDC_VALID,"UnOperational Account");
}

//Handles the sel change for Account number Combo
void CBankOperationView::OnSelchangeAccno() 
{
	m_pSet->MoveFirst();
	CComboBox *cmb=(CComboBox*)GetDlgItem(IDC_ACCNO);
	int nCurIndex=cmb->GetCurSel();
	
	CString str;
	cmb->GetLBText(nCurIndex,str);
	int accNo=atoi(str);
	while( m_pSet->m_Account_Number != accNo )
		m_pSet->MoveNext();
	UpdateData(false);		
	
	//CDateTimeCtrl *pDOBCtrl = (CDateTimeCtrl*) GetDlgItem(IDC_DOB);
	//pDOBCtrl->("01/01/1980");

	CButton *pAdd,*pMod,*pDel,*pUpd, *pReActivate;
	if(m_pSet->m_Valid_Acc=="CA")
	{
		SetDlgItemText(IDC_VALID,"UnOperational Account");

		pAdd=(CButton*)GetDlgItem(IDC_SAVE);
		pAdd->EnableWindow(false);
		
		pUpd=(CButton*)GetDlgItem(IDC_UPD);
		pUpd->EnableWindow(false);
		
		pMod=(CButton*)GetDlgItem(IDC_MOD);
		pMod->EnableWindow(false);
		
		pDel=(CButton*)GetDlgItem(IDC_DELETE);
		pDel->EnableWindow(false);

		pReActivate=(CButton*)GetDlgItem(IDC_REACTIVATE);
		pReActivate->EnableWindow(true);

		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);
	}
	else
	{	
		SetDlgItemText(IDC_VALID,"Operational Account");

		pAdd=(CButton*)GetDlgItem(IDC_SAVE);
		pAdd->EnableWindow(true);
			
		pUpd=(CButton*)GetDlgItem(IDC_UPD);
		pUpd->EnableWindow(false);
		
		pMod=(CButton*)GetDlgItem(IDC_MOD);
		pMod->EnableWindow(true);
		
		pDel=(CButton*)GetDlgItem(IDC_DELETE);
		pDel->EnableWindow(true);
		
		pReActivate=(CButton*)GetDlgItem(IDC_REACTIVATE);
		pReActivate->EnableWindow(false);

		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);
	}
	CButton *pSaving,*pCurrent,*pChecking;
	pSaving=(CButton*)GetDlgItem(IDC_RADIO1);
	pCurrent=(CButton*)GetDlgItem(IDC_RADIO2);
	pChecking=(CButton*)GetDlgItem(IDC_RADIO3);
	
	if(m_pSet->m_Type_account=="S")
	{
		pSaving->SetCheck(true);
		pCurrent->SetCheck(false);
		pChecking->SetCheck(false);
	}
	else if(m_pSet->m_Type_account=="C")
	{
		pSaving->SetCheck(false);
		pCurrent->SetCheck(true);
		pChecking->SetCheck(false);
	}
	else if(m_pSet->m_Type_account=="K")
	{
		pSaving->SetCheck(false);
		pCurrent->SetCheck(false);
		pChecking->SetCheck(true);
	}

}

//Handles the case of Update buton
void CBankOperationView::OnUpd() 
{
	if(!m_pRef->IsOpen())
		m_pRef->Open();
	if(m_pRef->IsBOF() && m_pRef->IsEOF ())
		AfxMessageBox("No Records in the Database...");
	m_pRef->MoveFirst();

	//Get the account number to edit
	long lAcctNumToEdit = m_pSet->m_Account_Number;
	if(!m_pSet->IsOpen())
		m_pSet->Open();
	if(m_pSet->IsBOF() && m_pSet->IsEOF ())
		AfxMessageBox("No Records in the Database...");
	m_pSet->MoveFirst();

	bool flag=false;
	
	CString strRefAccNum;
	GetDlgItemText(IDC_REFACCNO, strRefAccNum);
	CEdit *pRefAcc = (CEdit*)GetDlgItem(IDC_REFACCNO);
	if ( atoi(strRefAccNum) != 0 ) 
	{
		while(!m_pRef->IsEOF())
		{
			if(atoi(strRefAccNum) == m_pRef->m_Account_Number)
			{
				if(m_pRef->m_Valid_Acc=="CA")
				{
					AfxMessageBox("UnOperational Account - Give Another Number");
					flag=false;
					pRefAcc->SetFocus();
					return;
				}
				flag=true;
				break;
			}
			m_pRef->MoveNext();
		}
		if(m_pRef->IsEOF() && flag==false)
		{
			AfxMessageBox("Invalid Account Number: Please enter valid account number");
			pRefAcc->SetFocus();
			return;
		}
	}

	CEdit* pAmount=(CEdit*)GetDlgItem(IDC_AMOUNT);
	CString strAmt;
	pAmount->GetWindowText(strAmt);
	long lAmt = atoi(strAmt);
	strAmt.Format("%ld", lAmt);
	pAmount->SetWindowText(strAmt);

	CString strFName, strLName, strDOB, strPADD;
	GetDlgItemText(IDC_FNAME, strFName);
	if (strFName.Trim().IsEmpty())
	{
		AfxMessageBox("Please enter your first name");
		((CEdit*)GetDlgItem(IDC_FNAME))->SetFocus();
		return;
	}
	GetDlgItemText(IDC_LNAME, strLName);
	if (strLName.Trim().IsEmpty())
	{
		AfxMessageBox("Please enter your last name");
		((CEdit*)GetDlgItem(IDC_LNAME))->SetFocus();
		return;
	}

	GetDlgItemText(IDC_DOB, strDOB);
	if (!VerifyDate(strDOB))
	{
		AfxMessageBox("Please enter/correct your DOB");
		((CEdit*)GetDlgItem(IDC_DOB))->SetFocus();
		return;
	}

	GetDlgItemText(IDC_PADD, strPADD);
	if (strPADD.Trim().IsEmpty())
	{
		AfxMessageBox("Please enter your Address");
		((CEdit*)GetDlgItem(IDC_PADD))->SetFocus();
		return;
	}

	CEdit *pAmnt;
	pAmnt=(CEdit*)GetDlgItem(IDC_AMOUNT);

	CButton *pSaveing,*pCurrent,*pChecking;
	pSaveing=(CButton*)GetDlgItem(IDC_RADIO1);
	pCurrent=(CButton*)GetDlgItem(IDC_RADIO2);
	pChecking=(CButton*)GetDlgItem(IDC_RADIO3);

	if(pSaveing->GetCheck()==BST_CHECKED)
	{
		m_pSet->m_Type_account="S";
		if(m_pSet->m_Balance<50)
		{
			AfxMessageBox("Minimum Acceptable Amount is $50");
			pAmnt->SetFocus();
			return;
		}
	}
	else if(pCurrent->GetCheck()==BST_CHECKED)
	{
		m_pSet->m_Type_account="C";
		if(m_pSet->m_Balance<100)
		{
			AfxMessageBox("Minimum Acceptable Amount is $100");
			pAmnt->SetFocus();
			return;
		}
	}
	else if (pChecking->GetCheck()==BST_CHECKED)
	{
		m_pSet->m_Type_account="K";
		if(m_pSet->m_Balance<150)
		{
			AfxMessageBox("Minimum Acceptable Amount is $150");
			pAmnt->SetFocus();
			return;
		}
	}

	CComboBox* cmb=(CComboBox*)GetDlgItem(IDC_ACCNO);
	CButton* pAdd, *pMod, *pDel, *pUpd, *pDep, *pTransfer, *pCancel;
	pAdd=(CButton*)GetDlgItem(IDC_SAVE);
	pAdd->EnableWindow(true);
	pMod=(CButton*)GetDlgItem(IDC_MOD);
	pMod->EnableWindow(true);
	pUpd=(CButton*)GetDlgItem(IDC_UPD);
	pUpd->EnableWindow(false);
	pCancel=(CButton*)GetDlgItem(IDC_CANCEL1);
	pCancel->EnableWindow(false);
	pDel=(CButton*)GetDlgItem(IDC_DELETE);
	pDel->EnableWindow(true);
	//pReActivate=(CButton*)GetDlgItem(IDC_REACTIVATE);
	//pReActivate->EnableWindow(false);
	pDep=(CButton*)GetDlgItem(IDC_DEPOSIT);
	pDep->EnableWindow(true);
	pTransfer=(CButton*)GetDlgItem(IDC_TRANSFER);
	pTransfer->EnableWindow(true);

	if (m_bAddNewAccount)
	{
		cmb->EnableWindow(true);
		pMod=(CButton*)GetDlgItem(IDC_MOD);
		pMod->EnableWindow(true);

		int nNewAccountNum=0;
		if(!m_pSet->IsEOF())
		{
			m_pSet->MoveLast();
			nNewAccountNum = m_pSet->m_Account_Number + 1;
		}

		CString strNewAccountNum;
		strNewAccountNum.Format("%d", nNewAccountNum);

		m_pSet->AddNew();
		UpdateData(true);

		m_pSet->m_Valid_Acc="VA";
		//GetDlgItemText(IDC_CURRDT,m_pSet->m_curr_date);
	
		CButton *pSaveing,*pCurrent,*pChecking;
		pSaveing=(CButton*)GetDlgItem(IDC_RADIO1);
		pCurrent=(CButton*)GetDlgItem(IDC_RADIO2);
		pChecking=(CButton*)GetDlgItem(IDC_RADIO3);

		if(pSaveing->GetCheck()==BST_CHECKED)
			m_pSet->m_Type_account="S";
		else if(pCurrent->GetCheck()==BST_CHECKED)
			m_pSet->m_Type_account="C";
		else if (pChecking->GetCheck()==BST_CHECKED)
			m_pSet->m_Type_account="K";

		if(!m_pSet->Update())
			AfxMessageBox("Unable to Save....");
		if(m_pSet->Requery()==0)
			return;

		cmb->AddString(strNewAccountNum);
		if(!m_pSet->IsBOF() && m_pSet->IsEOF())
			m_pSet->MoveLast();

		AfxMessageBox("Account has been created");		
		
		CButton *chk1; 
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);

		CButton *bMod,*bDel;
		bMod=(CButton*)GetDlgItem(IDC_MOD);
		bMod->EnableWindow(true);
		bDel=(CButton*)GetDlgItem(IDC_DELETE);
		bDel->EnableWindow(true);

		m_bAddNewAccount = FALSE;
	}
	else
	{
		if(!m_pSet->IsOpen())
			m_pSet->Open();
		if(m_pSet->IsBOF() && m_pSet->IsEOF ())
			AfxMessageBox("No Records in the Database...");
		while (!m_pSet->IsEOF())
		{
			if (m_pSet->m_Account_Number == lAcctNumToEdit)
				break;
			m_pSet->MoveNext();
		}

		m_pSet->Edit();
		m_pSet->m_Valid_Acc="VA";
		GetDlgItemText(IDC_MADD,m_pSet->m_Mailing_Addr);
		GetDlgItemText(IDC_PADD,m_pSet->m_Permanent_Addr);
		GetDlgItemText(IDC_EMAIL,m_pSet->m_eMailID);
		GetDlgItemText(IDC_PHONE,m_pSet->m_Phone_Number);

		CButton *pSaveing,*pCurrent,*pChecking;
		pSaveing=(CButton*)GetDlgItem(IDC_RADIO1);
		pCurrent=(CButton*)GetDlgItem(IDC_RADIO2);
		pChecking=(CButton*)GetDlgItem(IDC_RADIO3);

		if(pSaveing->GetCheck()==BST_CHECKED)
			m_pSet->m_Type_account="S";
		else if(pCurrent->GetCheck()==BST_CHECKED)
			m_pSet->m_Type_account="C";
		else if (pChecking->GetCheck()==BST_CHECKED)
			m_pSet->m_Type_account="K";

		if(!m_pSet->Update())
			AfxMessageBox("Updation of Record Failed!!!");
		UpdateData(false);
		if(m_pSet->Requery()==0)
			return;

		if(!m_pSet->IsOpen())
			m_pSet->Open();
		while (!m_pSet->IsEOF())
		{
			if (m_pSet->m_Account_Number == lAcctNumToEdit)
				break;
			m_pSet->MoveNext();
		}

		AfxMessageBox("Record has been updated");

		CButton *chk1;
		chk1=(CButton*)GetDlgItem(IDC_CHECK1);
		chk1->SetCheck(false);

		CEdit *pFName,*pLName,*pDOB,*pRefAcc,*pAmount;

		pFName=(CEdit*)GetDlgItem(IDC_FNAME);
		pFName->EnableWindow(true);

		pLName=(CEdit*)GetDlgItem(IDC_LNAME);
		pLName->EnableWindow(true);

		pDOB=(CEdit*)GetDlgItem(IDC_DOB);
		pDOB->EnableWindow(true);

		pRefAcc=(CEdit*)GetDlgItem(IDC_REFACCNO);
		pRefAcc->EnableWindow(true);
		
		pAmount=(CEdit*)GetDlgItem(IDC_AMOUNT);
		pAmount->EnableWindow(true);
		
		CComboBox *pcmbAcc;
		pcmbAcc=(CComboBox*)GetDlgItem(IDC_ACCNO);
		pcmbAcc->EnableWindow(true);
	}

	m_bFromUpdate = TRUE;
	OnInitialUpdate();
}

//Handles Modfy button
void CBankOperationView::OnMod() 
{
	CButton *b1, *pCancel;
	b1=(CButton*)GetDlgItem(IDC_UPD);
	b1->EnableWindow(true);
	pCancel=(CButton*)GetDlgItem(IDC_CANCEL1);
	pCancel->EnableWindow(true);

	CEdit *pFName,*pLName,*pDOB,*pRefAcc,*pAmount;

	pFName=(CEdit*)GetDlgItem(IDC_FNAME);
	pFName->EnableWindow(false);

	pLName=(CEdit*)GetDlgItem(IDC_LNAME);
	pLName->EnableWindow(false);

	pDOB=(CEdit*)GetDlgItem(IDC_DOB);
	pDOB->EnableWindow(false);

	pRefAcc=(CEdit*)GetDlgItem(IDC_REFACCNO);
	pRefAcc->EnableWindow(false);
	
	pAmount=(CEdit*)GetDlgItem(IDC_AMOUNT);
	pAmount->EnableWindow(false);
	
	CComboBox *pcmbAcc;
	pcmbAcc=(CComboBox*)GetDlgItem(IDC_ACCNO);
	pcmbAcc->EnableWindow(false);

	CButton *pAdd, *pMod, *pDel, *pReActivate, *pDep, *pTransfer;
	pAdd=(CButton*)GetDlgItem(IDC_SAVE);
	pAdd->EnableWindow(false);
	pMod=(CButton*)GetDlgItem(IDC_MOD);
	pMod->EnableWindow(false);
	pDel=(CButton*)GetDlgItem(IDC_DELETE);
	pDel->EnableWindow(false);
	pReActivate=(CButton*)GetDlgItem(IDC_REACTIVATE);
	pReActivate->EnableWindow(false);
	pDep=(CButton*)GetDlgItem(IDC_DEPOSIT);
	pDep->EnableWindow(false);
	pTransfer=(CButton*)GetDlgItem(IDC_TRANSFER);
	pTransfer->EnableWindow(false);
}

//Handles te Check issue check box
void CBankOperationView::OnCheck1() 
{
	CButton* pButton = (CButton*)GetDlgItem(IDC_CHECK1);
	if ( !(pButton->GetState() & 0x0003) )
		return; //Don't do anything if the checkbox is being unchecked
	
	m_pBk=new CChkBook;
	if(!m_pBk->IsOpen())
		m_pBk->Open();
	if(m_pBk->IsBOF() && m_pBk->IsEOF ())
		AfxMessageBox("No Records in the Database...");
	m_pBk->MoveLast();

	int st=m_pBk->m_Start_Check_Number;
	m_pBk->AddNew();
	UpdateData(true);
	m_pBk->m_Account_Number=m_pSet->m_Account_Number;
	GetDlgItemText(IDC_CURRDT,m_pBk->m_Date_of_Issue);
	m_pBk->m_Hand_Over="C";
	
	if(m_pSet->m_Type_account=="S") //saving account
	{
		m_pBk->m_Number_of_Checks=20;
		m_pBk->m_Start_Check_Number=st+1;
		m_pBk->m_End_Check_Number=m_pBk->m_Start_Check_Number + 20;
	}
	if(m_pSet->m_Type_account=="C") //Current account
	{
		m_pBk->m_Number_of_Checks=40;
		m_pBk->m_Start_Check_Number=st+1;
		m_pBk->m_End_Check_Number=m_pBk->m_Start_Check_Number + 40;
	}
	if(m_pSet->m_Type_account=="K") //Checking account
	{
		m_pBk->m_Number_of_Checks=10;
		
		m_pBk->m_Start_Check_Number=st+1;
		m_pBk->m_End_Check_Number=m_pBk->m_Start_Check_Number + 50;
	}
	if(!m_pBk->Update())
		AfxMessageBox("Updation of Record Failed!!!");
	UpdateData(false);

	AfxMessageBox("Check Book has been issued");
	if(m_pBk->Requery()==0)
		return;
}

void CBankOperationView::OnClear() 
{
	CButton *bAdd,*bMod,*bDel,*bUpd;
	SetDlgItemText(IDC_VALID,"");

	bAdd=(CButton*)GetDlgItem(IDC_SAVE);
	bAdd->EnableWindow(true);
	bUpd=(CButton*)GetDlgItem(IDC_UPD);
	bUpd->EnableWindow(false);
	bMod=(CButton*)GetDlgItem(IDC_MOD);
	bMod->EnableWindow(false);
	bDel=(CButton*)GetDlgItem(IDC_DELETE);
	bDel->EnableWindow(false);
	
	SetDlgItemText(IDC_FNAME,"");
	SetDlgItemText(IDC_LNAME,"");
	SetDlgItemInt(IDC_ACCNO,0,false);
	SetDlgItemText(IDC_PADD,"");
	SetDlgItemText(IDC_MADD,"");
	SetDlgItemText(IDC_PHONE,"");
	SetDlgItemText(IDC_EMAIL,"");
	SetDlgItemInt(IDC_REFACCNO,0,false);
	SetDlgItemInt(IDC_AMOUNT,0,false);
	SetDlgItemText(IDC_DOB,"");
	
	CButton *chk1;
	chk1=(CButton*)GetDlgItem(IDC_CHECK1);
	chk1->SetCheck(false);

	CButton *pSaveing,*pCurrent,*pChecking;
	pSaveing=(CButton*)GetDlgItem(IDC_RADIO1);
	pCurrent=(CButton*)GetDlgItem(IDC_RADIO2);
	pChecking=(CButton*)GetDlgItem(IDC_RADIO3);
	
	pSaveing->SetCheck(true);
	pCurrent->SetCheck(false);
	pChecking->SetCheck(false);
}

//Handles Deposit/Wihdrawl to/from an account
void CBankOperationView::OnDeposit() 
{
	CDeposit d1;
	d1.DoModal();
}

//Handles Transfer amount from one account to other
void CBankOperationView::OnTransfer() 
{
	CTransfer d2;
	d2.DoModal();
}

//Handles the "<<" button
void CBankOperationView::OnBnClickedFirst()
{
	OnRecordFirst();
	EnableDisableNavigationKeys(1);
}

//Handles the ">>" button
void CBankOperationView::OnBnClickedLast()
{
	OnRecordLast();
	EnableDisableNavigationKeys(2);
}

//Handles the "<" button
void CBankOperationView::OnBnClickedPrev()
{
	OnRecordPrev();

	EnableDisableNavigationKeys(3);
}
//Handles the ">" button
void CBankOperationView::OnBnClickedNext()
{
	OnRecordNext();
	EnableDisableNavigationKeys(4);
}

//Handles the Commit of transactions
void CBankOperationView::OnBnClickedCommit()
{
	//This will commit Pending "Transfer" operations
	Tran_DW *ptr_Tran=new Tran_DW;		//Contains Transaction Details
	Ref_AccNo *m_pGet=new Ref_AccNo;	//Contains Customer Details
	
	if(!ptr_Tran->IsOpen())
		ptr_Tran->Open();
	if(!ptr_Tran->IsBOF() && ptr_Tran->IsEOF ())
		ptr_Tran->MoveFirst();
	
	if(!m_pGet->IsOpen())
		m_pGet->Open();
	if(!m_pGet->IsBOF() && m_pGet->IsEOF ())
		m_pGet->MoveFirst();

	BOOL bFirstTransactionOver = FALSE;
	//Go through all the transactions in transaction recordset
	while (!ptr_Tran->IsEOF())
	{
		//Choose pending records from the recordset
		if (ptr_Tran->m_Transaction_Status.CompareNoCase("P") == 0)
		{
			//Case of Cheque transactions in Deposit/Withdrawl
			if (ptr_Tran->m_Transaction_Mode.CompareNoCase("CHQ") == 0)
			{
				// Deposit Case
				if (ptr_Tran->m_Transaction_Type.CompareNoCase("DEP") == 0)
				{
					while (!m_pGet->IsEOF())
					{
						if (m_pGet->m_Account_Number == ptr_Tran->m_Account_Number)
						{
							m_pGet->Edit();
							m_pGet->m_Balance=m_pGet->m_Balance + ptr_Tran->m_Transaction_Amount;
							m_pGet->Update();
							m_pGet->Requery();
							ptr_Tran->Edit();
							ptr_Tran->m_Transaction_Status = "C";
							ptr_Tran->Update();
							ptr_Tran->Requery();
							break;
						}
						m_pGet->MoveNext();
					}
					m_pGet->MoveFirst();
				}
				else if (ptr_Tran->m_Transaction_Type.CompareNoCase("WTH") == 0) // Withdrawl Case
				{
					while (!m_pGet->IsEOF())
					{
						if (m_pGet->m_Account_Number == ptr_Tran->m_Account_Number)
						{
							m_pGet->Edit();
							m_pGet->m_Balance=m_pGet->m_Balance - ptr_Tran->m_Transaction_Amount;
							m_pGet->Update();
							m_pGet->Requery();
							ptr_Tran->Edit();
							ptr_Tran->m_Transaction_Status = "C";
							ptr_Tran->Update();
							ptr_Tran->Requery();
							break;
						}
						m_pGet->MoveNext();
					}
					m_pGet->MoveFirst();
				}
			}
			else if(ptr_Tran->m_Transaction_Mode.CompareNoCase("TRF") == 0) //Case of money transfer from one account to another
			{
				//Transfer to an internal account
				if (ptr_Tran->m_Transaction_Type.CompareNoCase("ITF") == 0)
				{
					long lAccNumFrom = ptr_Tran->m_Account_Number;
					while (!m_pGet->IsEOF())
					{
						if (m_pGet->m_Account_Number == ptr_Tran->m_Account_Number)
						{
							m_pGet->Edit();
							m_pGet->m_Balance=m_pGet->m_Balance - ptr_Tran->m_Transaction_Amount;
							m_pGet->Update();
							m_pGet->Requery();
							if (bFirstTransactionOver)
							{
								ptr_Tran->Edit();
								ptr_Tran->m_Transaction_Status = "C";
								ptr_Tran->Update();
								ptr_Tran->Requery();
								break;
							}
							bFirstTransactionOver = TRUE;
						} 
						if (m_pGet->m_Account_Number == ptr_Tran->m_To_Account)
						{
							m_pGet->Edit();
							m_pGet->m_Balance=m_pGet->m_Balance + ptr_Tran->m_Transaction_Amount;
							m_pGet->Update();
							m_pGet->Requery();
							if (bFirstTransactionOver)
							{
								ptr_Tran->Edit();
								ptr_Tran->m_Transaction_Status = "C";
								ptr_Tran->Update();
								ptr_Tran->Requery();
								break;
							}
							bFirstTransactionOver = TRUE;
						}
						m_pGet->MoveNext();
					}
					m_pGet->MoveFirst();
				}
				else if (ptr_Tran->m_Transaction_Type.CompareNoCase("ETF") == 0) 
				{
					//Transfer to an External account
					long lAccNumFrom = ptr_Tran->m_Account_Number;
					while (!m_pGet->IsEOF())
					{
						if (m_pGet->m_Account_Number == ptr_Tran->m_Account_Number)
						{
							m_pGet->Edit();
							m_pGet->m_Balance=m_pGet->m_Balance - ptr_Tran->m_Transaction_Amount;
							m_pGet->Update();
							m_pGet->Requery();
							ptr_Tran->Edit();
							ptr_Tran->m_Transaction_Status = "C";
							ptr_Tran->Update();
							ptr_Tran->Requery();
							break;
						} 
						m_pGet->MoveNext();
					}
					m_pGet->MoveFirst();
				}
			}
			bFirstTransactionOver = FALSE;
		}

		ptr_Tran->MoveNext();
	}

	if (ptr_Tran) //Contains Transaction Details
		delete ptr_Tran;
	if (m_pGet) //Contains Transaction Details
		delete m_pGet;
	
	//Refresh the records
	m_bFromCommit = TRUE;
	OnInitialUpdate();

	//Display the message "Transactions have been commited"
	MessageBox("All pending transactions have been commited");
}

//Handles the reactivate button
void CBankOperationView::OnBnClickedReactivate()
{
	m_pSet->Edit();
	//Get the Account Number to edit
	long lCurrentAccountNum = m_pSet->m_Account_Number;
	m_pSet->m_Valid_Acc="VA";
	UpdateData(true);
	if(!m_pSet->Update())
		AfxMessageBox("Some internal problem. Not Able to reactivate the account");
	if(m_pSet->Requery()==0)
		return;

	if(!m_pSet->IsBOF() && m_pSet->IsEOF())
		m_pSet->MoveFirst();
	while( m_pSet->m_Account_Number == lCurrentAccountNum || m_pSet->IsEOF())
	{
		m_pSet->MoveNext();
	}

	//Update the Operational box
	SetDlgItemText(IDC_VALID,"Operational Account");

	CButton *pAdd, *pUpd, *pMod, *pDel, *pReActivate, *pChk1;

	pAdd=(CButton*)GetDlgItem(IDC_SAVE);
	pAdd->EnableWindow(true);
		
	pUpd=(CButton*)GetDlgItem(IDC_UPD);
	pUpd->EnableWindow(false);
	
	pMod=(CButton*)GetDlgItem(IDC_MOD);
	pMod->EnableWindow(true);
	
	pDel=(CButton*)GetDlgItem(IDC_DELETE);
	pDel->EnableWindow(true);
		
	pReActivate=(CButton*)GetDlgItem(IDC_REACTIVATE);
	pReActivate->EnableWindow(false);

	pChk1=(CButton*)GetDlgItem(IDC_CHECK1);
	pChk1->SetCheck(false);

	AfxMessageBox("The Record has been activated!");
}

//Handles Navigation keys
void CBankOperationView::EnableDisableNavigationKeys(int nFrom)
{
	Ref_AccNo *m_pGet=new Ref_AccNo;
	long lCurrentRecord=0;
	lCurrentRecord = m_pGet->GetCurrentRecord();
	if(!m_pGet->IsOpen())
		m_pGet->Open();
	if(!m_pGet->IsBOF() && m_pGet->IsEOF ())
	{
		m_pGet->MoveFirst();
	}
	int nTotalRecordCount=0;
	while (!m_pGet->IsEOF())
	{
		nTotalRecordCount++;
		m_pGet->MoveNext();
	}

	//nTotalRecordCount = m_pGet->GetTotalCount();
	m_pGet->MoveFirst();

	CButton *pFirst, *pLast, *pNext, *pPrev;
	pFirst = (CButton*)GetDlgItem(IDC_BUTTON1);
	pLast = (CButton*)GetDlgItem(IDC_BUTTON4);
	pPrev = (CButton*)GetDlgItem(IDC_BUTTON2);
	pNext = (CButton*)GetDlgItem(IDC_BUTTON3);

	if (nTotalRecordCount == 0 || nTotalRecordCount == 1) {
		pFirst->EnableWindow(false);
		pLast->EnableWindow(false);
		pPrev->EnableWindow(false);
		pNext->EnableWindow(false);
		return;
	}

	switch(nFrom)
	{
		case 1: //First
			pFirst->EnableWindow(false);
			pLast->EnableWindow(true);
			pPrev->EnableWindow(false);
			pNext->EnableWindow(true);
			break;
		case 2: //Last
			pFirst->EnableWindow(true);
			pLast->EnableWindow(false);
			pPrev->EnableWindow(true);
			pNext->EnableWindow(false);
			break;
		case 3: //Prev 
			//if (m_nCurrentRecord == 1) 
			//{
			//	pFirst->EnableWindow(false);
			//	pLast->EnableWindow(true);
			//	pPrev->EnableWindow(false);
			//	pNext->EnableWindow(true);
			//}
			//else
			//{
				pFirst->EnableWindow(true);
				pLast->EnableWindow(true);
				pPrev->EnableWindow(true);
				pNext->EnableWindow(true);
			//}
			break;
		case 4: //Next
			//if (m_nCurrentRecord == nTotalRecordCount) 
			//{
			//	pFirst->EnableWindow(true);
			//	pLast->EnableWindow(false);
			//	pPrev->EnableWindow(true);
			//	pNext->EnableWindow(false);
			//}
			//else
			//{
				pFirst->EnableWindow(true);
				pLast->EnableWindow(true);
				pPrev->EnableWindow(true);
				pNext->EnableWindow(true);
			//}
			break;
		case 5: //From IniialUpdate
			pFirst->EnableWindow(false);
			pLast->EnableWindow(true);
			pPrev->EnableWindow(false);
			pNext->EnableWindow(true);
			break;
	}
}

//Handles the Cancel button
void CBankOperationView::OnBnClickedCancel1()
{
	// TODO: Add your control notification handler code here
	CComboBox *cmb=(CComboBox*)GetDlgItem(IDC_ACCNO);
	cmb->EnableWindow(TRUE); 

	CEdit *pFName, *pLName, *pDOB, *pRefAcct, *pAmnt;

	pFName=(CEdit*)GetDlgItem(IDC_FNAME);
	pFName->EnableWindow(TRUE);

	pLName=(CEdit*)GetDlgItem(IDC_LNAME);
	pLName->EnableWindow(TRUE);

	pDOB = (CEdit*)GetDlgItem(IDC_DOB);
	pDOB->EnableWindow(TRUE);

	pRefAcct=(CEdit*)GetDlgItem(IDC_REFACCNO);
	pRefAcct->EnableWindow(TRUE);
	
	pAmnt=(CEdit*)GetDlgItem(IDC_AMOUNT);
	pAmnt->EnableWindow(TRUE);

	CButton *pDep, *pTransfer, *pCancel;

	pCancel=(CButton*)GetDlgItem(IDC_CANCEL1);
	pCancel->EnableWindow(FALSE);

	pDep=(CButton*)GetDlgItem(IDC_DEPOSIT);
	pDep->EnableWindow(true);

	pTransfer=(CButton*)GetDlgItem(IDC_TRANSFER);
	pTransfer->EnableWindow(true);

	m_bFromCancel = TRUE;
	//To refresh the records
	OnInitialUpdate();
}

BOOL CBankOperationView::VerifyDate(CString strDate)
{
	BOOL bValidDate = FALSE;
	CString strTemp1, strTemp2, strTemp3;
	for (int i=0; i<10; i++)
	{
		strTemp1 = strDate.Left(2);
		if (atoi(strTemp1)> 0 && atoi(strTemp1)< 13) // 1 to 12
		{
			//Valid Month. Wait till we check the date.
		}
		else
		{
			return FALSE;
		}

		strTemp2 = strDate.Right(4);
		if (atoi(strTemp2)> 1700 && atoi(strTemp2)< 3000)
		{
			//Valid Year. Wait till we check the date.
		}
		else
		{
			return FALSE;
		}
		strTemp3 = strDate.Mid(3, 2);
		if (atoi(strTemp3)> 0 && atoi(strTemp3)< 32)
		{
			//Valid Month
			int iMonth = atoi(strTemp1);
			switch(iMonth)
			{
				case 1:
					bValidDate = TRUE;
					break;
				case 2:
					{
						int nRes = atoi(strTemp2)/4;
						if ( nRes == 0 && (atoi(strTemp3)> 0 && atoi(strTemp3)< 29) )
							bValidDate = TRUE;
						if ( nRes != 0 && atoi(strTemp3)> 0 && atoi(strTemp3)< 30) ////Leap year
							bValidDate = TRUE;
					}
					break;
				case 3:
					bValidDate = TRUE;
					break;
				case 4:
					if (atoi(strTemp3)> 0 && atoi(strTemp3)< 31)
						bValidDate = TRUE;
					break;
				case 5:
					bValidDate = TRUE;
					break;
				case 6:
					if (atoi(strTemp3)> 0 && atoi(strTemp3)< 31)
						bValidDate = TRUE;
					break;
				case 7:
					bValidDate = TRUE;
					break;
				case 8:
					bValidDate = TRUE;
					break;
				case 9:
					if (atoi(strTemp3)> 0 && atoi(strTemp3)< 31)
						bValidDate = TRUE;
					break;
				case 10:
					bValidDate = TRUE;
					break;
				case 11:
					if (atoi(strTemp3)> 0 && atoi(strTemp3)< 31)
						bValidDate = TRUE;
					break;
				case 12:
					bValidDate = TRUE;
					break;
			}
		}
	}
	return bValidDate;
}

//Handles the "Day end transactions" button
void CBankOperationView::OnReportsDayendtransactions()
{
	// TODO: Add your command handler code here
}

//Handles the "reports more..." button
void CBankOperationView::OnReportsMore()
{
	// TODO: Add your command handler code here
}

