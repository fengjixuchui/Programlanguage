// BankOperationSet.h : interface of the CBankOperationSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_BANKOPERATIONSET_H__C5F09D84_9D2C_11D5_AC60_00A0C93654A0__INCLUDED_)
#define AFX_BANKOPERATIONSET_H__C5F09D84_9D2C_11D5_AC60_00A0C93654A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include <ATLComTime.h>

class CBankOperationSet : public CRecordset
{
public:
	long GetCurrentRecord() const;
	CBankOperationSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CBankOperationSet)

// Field/Param Data
	//{{AFX_FIELD(CBankOperationSet, CRecordset)
	double	m_Balance;
	CString	m_eMailID;
	CString	m_First_Name;
	CString	m_Last_Name;
	CString	m_Mailing_Addr;
	CString	m_Permanent_Addr;
	CString	m_Phone_Number;
	CString	m_Type_account;
	CString	m_Valid_Acc;
	CString	m_date_birth;
	//COleDateTime	m_date_birth;
	long	m_Account_Number;
	long	m_Ref_Acc_No;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBankOperationSet)
	public:
	virtual CString GetDefaultConnect();	// Default connection string
	virtual CString GetDefaultSQL(); 	// default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);	// RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BANKOPERATIONSET_H__C5F09D84_9D2C_11D5_AC60_00A0C93654A0__INCLUDED_)

