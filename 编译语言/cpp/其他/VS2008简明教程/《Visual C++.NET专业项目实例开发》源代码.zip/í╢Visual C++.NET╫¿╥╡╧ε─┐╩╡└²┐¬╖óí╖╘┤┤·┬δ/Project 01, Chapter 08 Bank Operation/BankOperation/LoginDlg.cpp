// LoginDlg.cpp : implementation file
//

#include "stdafx.h"
#include "BankOperation.h"
#include "LoginDlg.h"
#include "BankLoginSet.h"

// CLoginDlg dialog

IMPLEMENT_DYNAMIC(CLoginDlg, CDialog)
CLoginDlg::CLoginDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLoginDlg::IDD, pParent)
{
}

CLoginDlg::~CLoginDlg()
{
}

void CLoginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CLoginDlg, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, OnBnClickedCancel)
END_MESSAGE_MAP()

// CLoginDlg message handlers

void CLoginDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CString strLoginID, strPassword;
	CWnd* pWnd = GetDlgItem(IDC_LOGIN);
	pWnd->GetWindowText(strLoginID);
	GetDlgItem(IDC_PASSWORD)->GetWindowText(strPassword);

	CBankLoginSet *m_pGet=new CBankLoginSet;
	if(!m_pGet->IsOpen ())
		m_pGet->Open();
	if(!m_pGet->IsBOF() && m_pGet->IsEOF())
		m_pGet->MoveFirst();

	CString strTemp1, strTemp2;
	while(!m_pGet->IsEOF())
	{
		strTemp1 = m_pGet->m_UserNm;
		strTemp2 = m_pGet->m_Pwd;
		if ( (strLoginID.CompareNoCase(strTemp1) == 0) &&  (strPassword.Compare(strTemp2) == 0) )
		{
			//Success
			((CBankOperationApp*)AfxGetApp())->bLoginCorrect = TRUE;
		}
		else
		{
			//Failure
			((CBankOperationApp*)AfxGetApp())->bLoginCorrect = FALSE;
		}

		m_pGet->MoveNext();
	}	

	CDialog::OnOK();
}

void CLoginDlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	((CBankOperationApp*)AfxGetApp())->bCancelPressed = TRUE;
	CDialog::OnCancel();
}

BOOL CLoginDlg::OnInitDialog()
{
	//GetDlgItem(IDC_LOGIN)->SetWindowText("S103");
	//GetDlgItem(IDC_PASSWORD)->SetWindowText("password");

	GetDlgItem(IDC_LOGIN)->SetFocus();
	return FALSE;
}
