// Deposit.cpp : implementation file
//

#include "stdafx.h"
#include "BankOperation.h"
#include "Deposit.h"
#include "Ref_AccNo.h"
#include "Tran_DW.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDeposit dialog


CDeposit::CDeposit(CWnd* pParent /*=NULL*/)
	: CDialog(CDeposit::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDeposit)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDeposit::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDeposit)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDeposit, CDialog)
	//{{AFX_MSG_MAP(CDeposit)
	ON_BN_CLICKED(IDC_RDEP, OnRdep)
	ON_BN_CLICKED(IDC_RWITHDRAW, OnRwithdraw)
	ON_BN_CLICKED(IDC_CASH, OnCash)
	ON_BN_CLICKED(IDC_CHECK, OnCheck)
	//ON_CBN_DROPDOWN(IDC_ACCNUM, OnDropdownAccnum)
	ON_BN_CLICKED(IDSAVE, OnSave)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDeposit message handlers

void CDeposit::OnRdep() 
{
	CButton *pCash,*pCheck;
	
	pCash=(CButton*)GetDlgItem(IDC_CASH);
	pCheck=(CButton*)GetDlgItem(IDC_CHECK);
	
	pCash->EnableWindow(true);
	pCheck->EnableWindow(true);
}

void CDeposit::OnRwithdraw() 
{
	CButton *pCash,*pCheck;
	
	pCash=(CButton*)GetDlgItem(IDC_CASH);
	pCheck=(CButton*)GetDlgItem(IDC_CHECK);
	
	pCash->EnableWindow(true);
	pCheck->EnableWindow(true);
}


void CDeposit::OnCash() 
{
	((CButton*)GetDlgItem(IDSAVE))->EnableWindow(true);
	((CEdit*)GetDlgItem(IDC_AMTDEPW))->EnableWindow(true);
	((CEdit*)GetDlgItem(IDC_CHECKNO))->EnableWindow(false);
}

void CDeposit::OnCheck() 
{
	((CButton*)GetDlgItem(IDSAVE))->EnableWindow(true);
	((CEdit*)GetDlgItem(IDC_AMTDEPW))->EnableWindow(true);
	((CEdit*)GetDlgItem(IDC_CHECKNO))->EnableWindow(true);
}

BOOL CDeposit::OnInitDialog()
{
	CComboBox *cmb;
	cmb=(CComboBox*)GetDlgItem(IDC_ACCNUM);
	
	CTime t1=CTime::GetCurrentTime();
	int dd=t1.GetDay();
	int mm=t1.GetMonth();
	int yy=t1.GetYear();
	char str[30];
	sprintf(str,"%2d/%2d/%2d",dd,mm,yy);
	SetDlgItemText(IDC_TRANDT,str);
	
	if(cmb->GetCount()>0)
		cmb->Clear();
	Ref_AccNo *m_pGet=new Ref_AccNo;
	if(!m_pGet->IsOpen ())
		m_pGet->Open();
	if(!m_pGet->IsBOF() && m_pGet->IsEOF())
		m_pGet->MoveFirst();
	while(!m_pGet->IsEOF())
	{
		char str[30];
		if(m_pGet->m_Valid_Acc.CompareNoCase("VA") == 0)
		{
			sprintf(str,"%d",m_pGet->m_Account_Number);
			cmb->AddString(str);
		}
		m_pGet->MoveNext();
	}

	return FALSE;
}

void CDeposit::OnSave() 
{
	Tran_DW *ptr;
	Ref_AccNo *m_pGet=new Ref_AccNo;
	ptr=new Tran_DW;
	
	if(!ptr->IsOpen())
		ptr->Open();
	if(!ptr->IsBOF() && ptr->IsEOF ())
		ptr->MoveLast();
	ptr->AddNew();
	ptr->m_Account_Number=GetDlgItemInt(IDC_ACCNUM,NULL,true);
	
	CButton *pradioDep,*pradioWdrl;
	pradioDep=(CButton*)GetDlgItem(IDC_RDEP);
	pradioWdrl=(CButton*)GetDlgItem(IDC_RWITHDRAW);

	if(pradioDep->GetCheck()==BST_CHECKED)
		ptr->m_Transaction_Type="DEP";
	if(pradioWdrl->GetCheck()==BST_CHECKED)
		ptr->m_Transaction_Type="WTH";
	
	CButton *pCash,*pCheck;
	pCash=(CButton*)GetDlgItem(IDC_CASH);
	pCheck=(CButton*)GetDlgItem(IDC_CHECK);

	if(pCash->GetCheck()==BST_CHECKED)
	{
		ptr->m_Transaction_Mode="CAS";
		ptr->m_Transaction_Amount=GetDlgItemInt(IDC_AMTDEPW,NULL,true);
		if(ptr->m_Transaction_Type=="WTH")
		{
			if(!m_pGet->IsOpen ())
				m_pGet->Open();
			if(!m_pGet->IsBOF() && m_pGet->IsEOF())
				m_pGet->MoveFirst();
			while(!m_pGet->IsEOF())
			{
				if(m_pGet->m_Account_Number==ptr->m_Account_Number)
				{
					double WAmt=m_pGet->m_Balance-ptr->m_Transaction_Amount;
					if(WAmt<500)
					{
						AfxMessageBox("Insufficient Balance Amount - Should Deposit Money");
						return;
					}
					else
					{
						ptr->m_Transaction_Status="C";
						m_pGet->Edit();
						m_pGet->m_Balance=m_pGet->m_Balance-ptr->m_Transaction_Amount;
						m_pGet->Update();
						m_pGet->Requery();
						AfxMessageBox("Balance has been Updated");
						break;
					}
				}
				m_pGet->MoveNext();
			}	
		}
		if(ptr->m_Transaction_Type=="DEP")
		{
			if(!m_pGet->IsOpen ())
				m_pGet->Open();
			if(!m_pGet->IsBOF() && m_pGet->IsEOF())
				m_pGet->MoveFirst();
			long lAccountNum = ptr->m_Account_Number;
			while(!m_pGet->IsEOF())
			{
				if( m_pGet->m_Account_Number == lAccountNum )
				{
					m_pGet->Edit();
					m_pGet->m_Balance=m_pGet->m_Balance+ptr->m_Transaction_Amount;
					if(!m_pGet->Update())
					{
						AfxMessageBox("Unable to update Balance");
						return;
					}
					m_pGet->Requery();
					AfxMessageBox("Balance has been Updated");
					ptr->m_Transaction_Status="C";
					break;
				}
				m_pGet->MoveNext();
			}
		}
	}
	if(pCheck->GetCheck()==BST_CHECKED)
	{
		ptr->m_Transaction_Mode="CHQ";
		ptr->m_Transaction_Amount=GetDlgItemInt(IDC_AMTDEPW,NULL,true);
		ptr->m_Check_Draft_Number=GetDlgItemInt(IDC_CHECKNO,NULL,true);
		ptr->m_Transaction_Status="P";
		if(ptr->m_Transaction_Type=="WTH")
		{
			if(!m_pGet->IsOpen ())
				m_pGet->Open();
			if(!m_pGet->IsBOF() && m_pGet->IsEOF())
				m_pGet->MoveFirst();
			while(!m_pGet->IsEOF())
			{
				if(m_pGet->m_Account_Number==ptr->m_Account_Number)
				{
					double WAmt=m_pGet->m_Balance-ptr->m_Transaction_Amount;
					if(WAmt<500)
					{
						AfxMessageBox("Insufficient Balance Amount - Should Deposit Money");
						return;
					}
					else
					{
						ptr->m_Transaction_Status="P";
						break;
					}
				}
				m_pGet->MoveNext();
			}	
		}
		if(ptr->m_Transaction_Type=="DEP")
			ptr->m_Transaction_Status="P";
	}
	GetDlgItemText(IDC_TRANDT,ptr->m_Transaction_Date);

	if(!ptr->Update())
		AfxMessageBox("Unable to Save....");
	if(ptr->Requery()==0)
		return;

	CDialog::OnOK();
}

void CDeposit::OnCancel() 
{
	CDialog::OnCancel();
}
