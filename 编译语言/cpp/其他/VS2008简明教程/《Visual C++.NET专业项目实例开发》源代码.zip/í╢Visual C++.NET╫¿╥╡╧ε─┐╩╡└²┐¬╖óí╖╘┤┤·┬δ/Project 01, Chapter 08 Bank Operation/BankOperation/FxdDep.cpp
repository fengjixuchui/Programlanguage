// FxdDep.cpp : implementation file
//

#include "stdafx.h"
#include "BankOperation.h"
#include "FxdDep.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFxdDep

IMPLEMENT_DYNAMIC(CFxdDep, CRecordset)

CFxdDep::CFxdDep(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CFxdDep)
	m_Folio_Number = 0;
	m_Fname = _T("");
	m_Lname = _T("");
	m_Tenure = 0;
	m_Opening_Balance_Amount = 0.0;
	m_Maturity_Amount = 0.0;
	m_Maturity_Date = _T("");
	m_Transaction_Date = _T("");
	m_nFields = 8;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}


CString CFxdDep::GetDefaultConnect()
{
	return _T("ODBC;DSN=Bank;UID=sa;PWD=");
}

CString CFxdDep::GetDefaultSQL()
{
	return _T("[dbo].[Fixed_Deposit]");
}

void CFxdDep::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CFxdDep)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[Folio_Number]"), m_Folio_Number);
	RFX_Text(pFX, _T("[Fname]"), m_Fname);
	RFX_Text(pFX, _T("[Lname]"), m_Lname);
	RFX_Long(pFX, _T("[Tenure]"), m_Tenure);
	RFX_Double(pFX, _T("[Opening_Balance_Amount]"), m_Opening_Balance_Amount);
	RFX_Double(pFX, _T("[Maturity_Amount]"), m_Maturity_Amount);
	RFX_Text(pFX, _T("[Maturity_Date]"), m_Maturity_Date);
	RFX_Text(pFX, _T("[Transaction_Date]"), m_Transaction_Date);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CFxdDep diagnostics

#ifdef _DEBUG
void CFxdDep::AssertValid() const
{
	CRecordset::AssertValid();
}

void CFxdDep::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
