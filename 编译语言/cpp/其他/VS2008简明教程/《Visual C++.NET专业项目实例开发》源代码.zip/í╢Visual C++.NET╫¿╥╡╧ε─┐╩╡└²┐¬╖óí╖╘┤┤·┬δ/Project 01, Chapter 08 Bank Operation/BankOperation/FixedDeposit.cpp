// FixedDeposit.cpp : implementation file
//

#include "stdafx.h"
#include "BankOperation.h"
#include "FixedDeposit.h"
#include "FxdDep.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CFxdDep *dep;

/////////////////////////////////////////////////////////////////////////////
// CFixedDeposit dialog


CFixedDeposit::CFixedDeposit(CWnd* pParent /*=NULL*/)
	: CDialog(CFixedDeposit::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFixedDeposit)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CFixedDeposit::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFixedDeposit)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFixedDeposit, CDialog)
	//{{AFX_MSG_MAP(CFixedDeposit)
	ON_BN_CLICKED(ID_GENINFO, OnGeninfo)
	ON_BN_CLICKED(ID_FCANCEL, OnFcancel)
	ON_BN_CLICKED(ID_FSAVE, OnFsave)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFixedDeposit message handlers

void CFixedDeposit::OnGeninfo() 
{
	CEdit *ed1,*ed2,*ed3;
	ed1=(CEdit*)GetDlgItem(IDC_FFNAME);
	ed1->EnableWindow(true);

	ed2=(CEdit*)GetDlgItem(IDC_FLNAME);
	ed2->EnableWindow(true);

	ed3=(CEdit*)GetDlgItem(IDC_OPPAMT);
	ed3->EnableWindow(true);

	CButton *b1,*b2,*b3;
	b1=(CButton*)GetDlgItem(ID_FSAVE);
	b1->EnableWindow(true);
	
	CListBox *ls1;
	ls1=(CListBox*)GetDlgItem(IDC_TENURE);
	ls1->AddString("15");
	ls1->AddString("30");
	ls1->AddString("90");
	ls1->AddString("180");
	ls1->AddString("365");
	ls1->AddString("1825");
	ls1->EnableWindow(true);
	b3=(CButton*)GetDlgItem(ID_GENINFO);
	b3->EnableWindow(false);

	CTime t1=CTime::GetCurrentTime();
	int dd=t1.GetDay();
	int mm=t1.GetMonth();
	int yy=t1.GetYear();
	char str[15];
	sprintf(str,"%2d/%2d/%2d",dd,mm,yy);
	SetDlgItemText(IDC_FCDT,str);
}

void CFixedDeposit::OnFcancel() 
{
	EndDialog(true);	
}

void CFixedDeposit::OnFsave() 
{
	CFxdDep *fd;
	fd=new CFxdDep;
	if(!fd->IsOpen ())
		fd->Open();
	if(!fd->IsBOF() && fd->IsEOF())
		fd->MoveLast();
	long fdNo=fd->m_Folio_Number+1;
	fd->AddNew();
	fd->m_Folio_Number=fdNo;
	SetDlgItemInt(IDC_FOLIO_NO,fdNo,true);
	GetDlgItemText(IDC_FFNAME,fd->m_Fname);
	GetDlgItemText(IDC_FLNAME,fd->m_Lname);
	fd->m_Opening_Balance_Amount=GetDlgItemInt(IDC_OPPAMT,NULL,true);
	
	CListBox *l1;
	l1=(CListBox*)GetDlgItem(IDC_TENURE);
	int sel=l1->GetCurSel();
	CString str;
	l1->GetText(sel,str);
	AfxMessageBox(str);
	sel=atoi(str);
	fd->m_Tenure=sel;
	GetDlgItemText(IDC_FCDT,fd->m_Transaction_Date);

	if(sel==15)
	{
		fd->m_Maturity_Amount=(fd->m_Opening_Balance_Amount*0.03)+fd->m_Opening_Balance_Amount;
		fd->m_Maturity_Date="09/09/01";
	}
	if(sel==30)
	{
		fd->m_Maturity_Amount=(fd->m_Opening_Balance_Amount*0.05)+fd->m_Opening_Balance_Amount;
		fd->m_Maturity_Date="09/09/01";
	}
	if(sel==90)
	{
		fd->m_Maturity_Amount=(fd->m_Opening_Balance_Amount*0.07)+fd->m_Opening_Balance_Amount;
		fd->m_Maturity_Date="09/09/01";
	}
	if(sel==180)
	{
		fd->m_Maturity_Amount=(fd->m_Opening_Balance_Amount*0.09)+fd->m_Opening_Balance_Amount;
		fd->m_Maturity_Date="09/09/01";
	}
	if(sel==365)
	{
		fd->m_Maturity_Amount=(fd->m_Opening_Balance_Amount*0.11)+fd->m_Opening_Balance_Amount;
		fd->m_Maturity_Date="09/09/01";
	}
	if(!fd->Update())
		AfxMessageBox("Unable to update database");
	if(fd->Requery()==0)
		return;
	AfxMessageBox("Updated Database");
}

