#if !defined(AFX_CHKBOOK_H__224FF4E2_9D44_11D5_AC60_00A0C93654A0__INCLUDED_)
#define AFX_CHKBOOK_H__224FF4E2_9D44_11D5_AC60_00A0C93654A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ChkBook.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CChkBook recordset

class CChkBook : public CRecordset
{
public:
	CChkBook(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CChkBook)

// Field/Param Data
	//{{AFX_FIELD(CChkBook, CRecordset)
	long	m_Number_of_Checks;
	long	m_Start_Check_Number;
	long	m_Account_Number;
	CString	m_Date_of_Issue;
	long	m_Tran_No;
	long	m_End_Check_Number;
	CString	m_Hand_Over;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChkBook)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHKBOOK_H__224FF4E2_9D44_11D5_AC60_00A0C93654A0__INCLUDED_)
