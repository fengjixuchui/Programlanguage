#if !defined(AFX_CLEARANCE_H__C8A915F0_9E59_11D5_AC60_00A0C93654A0__INCLUDED_)
#define AFX_CLEARANCE_H__C8A915F0_9E59_11D5_AC60_00A0C93654A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Clearance.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CClearance dialog

class CClearance : public CDialog
{
// Construction
public:
	CClearance(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CClearance)
	enum { IDD = IDD_DIALOG4 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClearance)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CClearance)
	afx_msg void OnCgenlist();
	afx_msg void OnCsave();
	afx_msg void OnSelchangeLaccno();
	afx_msg void OnSelchangeTranid();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLEARANCE_H__C8A915F0_9E59_11D5_AC60_00A0C93654A0__INCLUDED_)
