// BankLoginSet.cpp : implementation of the CBankLoginSet class
//

#include "stdafx.h"
#include "BankOperation.h"
#include "BankLoginSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBankLoginSet implementation

IMPLEMENT_DYNAMIC(CBankLoginSet, CRecordset)

CBankLoginSet::CBankLoginSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CBankLoginSet)
	m_UserNm = _T("");
	m_Pwd = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}

CString CBankLoginSet::GetDefaultConnect()
{
	//return _T("ODBC;DSN=Bank;UID=sa;PWD=");
	return _T("ODBC;DSN=Bank");
}

CString CBankLoginSet::GetDefaultSQL()
{
	return _T("[dbo].[BankLogin]");
}

void CBankLoginSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CBankLoginSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[UserNm]"), m_UserNm);
	RFX_Text(pFX, _T("[Pwd]"), m_Pwd);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CBankLoginSet diagnostics

#ifdef _DEBUG
void CBankLoginSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CBankLoginSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
