#if !defined(AFX_FIXEDDEPOSIT_H__0AFD04C4_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_)
#define AFX_FIXEDDEPOSIT_H__0AFD04C4_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FixedDeposit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFixedDeposit dialog

class CFixedDeposit : public CDialog
{
// Construction
public:
	CFixedDeposit(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFixedDeposit)
	enum { IDD = IDD_DIALOG3 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFixedDeposit)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFixedDeposit)
	afx_msg void OnGeninfo();
	afx_msg void OnFcancel();
	afx_msg void OnFsave();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIXEDDEPOSIT_H__0AFD04C4_9DF5_11D5_AC60_00A0C93654A0__INCLUDED_)
