// Tran_DW.cpp : implementation file
//

#include "stdafx.h"
#include "BankOperation.h"
#include "Tran_DW.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Tran_DW

IMPLEMENT_DYNAMIC(Tran_DW, CRecordset)

Tran_DW::Tran_DW(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(Tran_DW)
	m_Account_Number = 0;
	m_Check_Draft_Number = 0;
	m_Creditor_BankAddr = _T("");
	m_Creditor_BankName = _T("");
	m_Creditor_Name = _T("");
	m_To_Account = 0;
	m_TranId = 0;
	m_Transaction_Amount = 0.0;
	m_Transaction_Date = _T("");
	m_Transaction_Mode = _T("");
	m_Transaction_Status = _T("");
	m_Transaction_Type = _T("");
	m_nFields = 12;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dynaset;
}


CString Tran_DW::GetDefaultConnect()
{
	return _T("ODBC;DSN=Bank;UID=sa;PWD=");
}

CString Tran_DW::GetDefaultSQL()
{
	return _T("[dbo].[Transaction_Detail]");
}

void Tran_DW::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(Tran_DW)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[Account_Number]"), m_Account_Number);
	RFX_Long(pFX, _T("[Check_Draft_Number]"), m_Check_Draft_Number);
	RFX_Text(pFX, _T("[Creditor_BankAddr]"), m_Creditor_BankAddr);
	RFX_Text(pFX, _T("[Creditor_BankName]"), m_Creditor_BankName);
	RFX_Text(pFX, _T("[Creditor_Name]"), m_Creditor_Name);
	RFX_Long(pFX, _T("[To_Account]"), m_To_Account);
	RFX_Long(pFX, _T("[TranId]"), m_TranId);
	RFX_Double(pFX, _T("[Transaction_Amount]"), m_Transaction_Amount);
	RFX_Text(pFX, _T("[Transaction_Date]"), m_Transaction_Date);
	RFX_Text(pFX, _T("[Transaction_Mode]"), m_Transaction_Mode);
	RFX_Text(pFX, _T("[Transaction_Status]"), m_Transaction_Status);
	RFX_Text(pFX, _T("[Transaction_Type]"), m_Transaction_Type);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// Tran_DW diagnostics

#ifdef _DEBUG
void Tran_DW::AssertValid() const
{
	CRecordset::AssertValid();
}

void Tran_DW::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
