// BankOperationView.h : interface of the CBankOperationView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_BANKOPERATIONVIEW_H__C5F09D82_9D2C_11D5_AC60_00A0C93654A0__INCLUDED_)
#define AFX_BANKOPERATIONVIEW_H__C5F09D82_9D2C_11D5_AC60_00A0C93654A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CBankOperationSet;
//class Ref_AccNo;

class CBankOperationView : public CRecordView
{
	BOOL m_bAddNewAccount;
	BOOL m_bFromCancel;
	BOOL m_bFromCommit;
	BOOL m_bFromUpdate;
	int m_nCurrentRecord;
private:
	void EnableDisableNavigationKeys(int nFromWhere);

protected: // create from serialization only
	CBankOperationView();
	DECLARE_DYNCREATE(CBankOperationView)

public:
	//{{AFX_DATA(CBankOperationView)
	enum { IDD = IDD_BANKOPERATION_FORM };
	CBankOperationSet* m_pSet;
	//}}AFX_DATA

// Attributes
public:
	CBankOperationDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBankOperationView)
	public:
	virtual CRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	BOOL VerifyDate(CString strDate);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CBankOperationView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CBankOperationView)
	afx_msg void OnRecordFirst();
	afx_msg void OnRecordLast();
	afx_msg void OnRecordNext();
	afx_msg void OnRecordPrev();
	afx_msg void OnSave();
	afx_msg void OnDeActivate();  //Handles deactivate Account
	afx_msg void OnKillfocusRefaccno();
	afx_msg void OnSelchangeAccno();
	afx_msg void OnUpd();
	afx_msg void OnMod();
	afx_msg void OnCheck1();
	afx_msg void OnClear();
	afx_msg void OnDeposit();
	afx_msg void OnTransfer();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	afx_msg void OnBnClickedFirst();
	afx_msg void OnBnClickedLast();
	afx_msg void OnBnClickedNext();
	afx_msg void OnBnClickedPrev();
	afx_msg void OnBnClickedCommit();
	afx_msg void OnBnClickedReactivate();
	afx_msg void OnBnClickedCancel1();

public:
	afx_msg void OnReportsDayendtransactions();
	afx_msg void OnReportsMore();
};

#ifndef _DEBUG  // debug version in BankOperationView.cpp
inline CBankOperationDoc* CBankOperationView::GetDocument()
   { return (CBankOperationDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BANKOPERATIONVIEW_H__C5F09D82_9D2C_11D5_AC60_00A0C93654A0__INCLUDED_)
