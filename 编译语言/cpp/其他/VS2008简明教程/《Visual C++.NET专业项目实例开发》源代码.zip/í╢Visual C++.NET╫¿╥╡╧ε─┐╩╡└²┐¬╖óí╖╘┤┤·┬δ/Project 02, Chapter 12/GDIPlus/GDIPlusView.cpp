#include "GDIPlus.h"
#include "GDIPlusView.h"
#include "GDIPlusDoc.h"

CGDIPlusView:: CGDIPlusView(CGDIPlusDoc* pDoc1, CMainWindow* pParent)
{
	InitializeComponent();
	pDoc  = pDoc1;
	MdiParent = pParent; //PSK
	pMainWin = pParent;
	this->Text = String::Concat(S"GDIPlusDoc", pDoc->nDocID.ToString(), S":", pDoc->viewList->Count.ToString());				
}

CGDIPlusView::~CGDIPlusView()
{		
}

void CGDIPlusView::InitializeComponent()
{
	pComponents = new System::ComponentModel::Container();
	
	AutoScaleBaseSize = System::Drawing::Size(5, 13);
	Text = "GDIPlusDoc";
	BackColor  = Color::White;

	MouseDown += new MouseEventHandler(this, MouseDownHandler);  
	MouseMove += new MouseEventHandler(this, MouseMoveHandler);
	MouseUp += new MouseEventHandler(this,MouseUpHandler);
	Paint += new PaintEventHandler(this, PaintHandler);  
	Closing += new CancelEventHandler(this, ClosingHandler);  
	Closed += new EventHandler(this,ClosedHandler);				
}

void CGDIPlusView::MouseDownHandler(Object* sender,MouseEventArgs* e)
{
	if(!this->Capture)
		return;
	try
	{
		Point* p = __nogc new Point(e->X, e->Y);
		//Need to box the Point because its a ValueType 
		__box Point* pt = __box(*p);
		pCurrentStroke = pDoc->NewStroke();
		pCurrentStroke->pPointArray->Add(pt);// Add first point to the new stroke	
		ptPrevPoint = *p;
	
		this->Capture = true; // Capture the mouse until button up	
	}
	catch(Exception* ex) {
		MessageBox::Show(ex->ToString());
	}
}

void CGDIPlusView::MouseMoveHandler(Object* sender,MouseEventArgs* e)
{
	if(!this->Capture)

		return;

	try
	{
		Point* p= __nogc new Point(e->X, e->Y);
		//Need to box the Point because its a ValueType 
		__box Point* pt = __box(*p);
		pCurrentStroke->pPointArray->Add(pt);
		Graphics* g = CreateGraphics();
		g->DrawLine(pDoc->GetCurrentPen(), ptPrevPoint, *p);
		ptPrevPoint = *p;			
	}
	catch (Exception* ex) { 
		MessageBox::Show(ex->ToString());			
    }
}

void CGDIPlusView::MouseUpHandler(Object* sender,MouseEventArgs* e)
{
	if(!pCurrentStroke)
			return;
	try
	{
		Point* p= __nogc new Point(e->X, e->Y);
		__box Point* pt = __box(*p);
		pCurrentStroke->pPointArray->Add(pt);
		Graphics* g = CreateGraphics();
		g->DrawLine(pDoc->GetCurrentPen(), ptPrevPoint, *p);
		
		ptPrevPoint=*p;	
		// Tell the stroke item that we're done adding points to it.
		// This is so it can finish computing its bounding rectangle.
		pCurrentStroke->FinishStroke();
		// Now that a stoke is added, inform all the views of the document about this
		pDoc->UpdateAllViews(this, pCurrentStroke);
        Capture = false;
	}
	catch (Exception* ex) { 
		MessageBox::Show(ex->ToString());			
    }
}

void CGDIPlusView::PaintHandler(Object* sender, PaintEventArgs* e)
{
	Rectangle rectClip = e->ClipRectangle ;
	rectClip.Inflate(1, 1);
	Rectangle rectStroke;
    
	for(int i=0; i < pDoc->strokeList->Count; i++)
	{
		CStroke* st = dynamic_cast<CStroke*>(pDoc->strokeList->Item[i]);
		rectStroke = st->GetBoundingRectangle();
		rectStroke.Inflate (1,1);			
		if(!rectStroke.IntersectsWith(rectClip))
			continue;
		st->DrawStroke(e->Graphics) ;
	}
}

void CGDIPlusView::ClosingHandler(Object* sender, CancelEventArgs* e)
{
	if( pDoc->bIsDirty && (pDoc->viewList->Count == 1) )
	{
		int nSave = MessageBox::Show("Do you want to Save changes ?", "GDIPlus", MessageBoxButtons::YesNoCancel);
		if(nSave == DialogResult::Yes)
		{
			SaveFileDialog* pSaveDlg = new SaveFileDialog();
			pSaveDlg->Filter = "GDIPlus Files (*.scb)|*.scb|All Files (*.*)|*.*";
			pSaveDlg->DefaultExt = ".scb";
			
			int nRes = pSaveDlg->ShowDialog();
			if(nRes == DialogResult::OK)
			{
				pDoc->SaveDocument(pSaveDlg->FileName);	
				pDoc->viewList->Remove(this);
			}
			else if(nRes == DialogResult::Cancel)
				e->Cancel = true;
				
		}
		else if(nSave == DialogResult::Cancel)
		{
				e->Cancel = true; //If user selected 'Cancel',don't close the form
		}
		else if(nSave == DialogResult::No)
				pDoc->viewList->Remove(this);
	}
	else
	{
		pDoc->viewList->Remove(this);
	}
}

void CGDIPlusView::ClosedHandler(Object* sender, EventArgs* e)
{
	//If there are no child views, then disable menu and toolbar items
	if(pMainWin->MdiChildren->Length == 0 )
		pMainWin->DisableItems();		
}

CGDIPlusDoc* CGDIPlusView::GetDocument()
{
	return pDoc;
}

void CGDIPlusView::HandleLineDraw()
{
	try
	{
		Graphics* g = CreateGraphics();
		g->DrawLine(pDoc->GetCurrentPen(), pDoc->nShapeLeft, pDoc->nShapeTop, pDoc->nShapeWidth, pDoc->nShapeHeight);  //Here width and height is a point
	}
	catch (Exception* ex) { 
		MessageBox::Show(ex->ToString());			
    }
}

void CGDIPlusView::HandleEllipseDraw()
{
	try
	{
		Graphics* g = CreateGraphics();
		g->DrawEllipse(pDoc->GetCurrentPen(), pDoc->nShapeLeft, pDoc->nShapeTop, pDoc->nShapeWidth, pDoc->nShapeHeight);
	}
	catch (Exception* ex) { 
		MessageBox::Show(ex->ToString());			
    }
}

void CGDIPlusView::HandleRectDraw()
{
	try
	{
		Graphics* g = CreateGraphics();
		g->DrawRectangle(pDoc->GetCurrentPen(), pDoc->nShapeLeft, pDoc->nShapeTop, pDoc->nShapeWidth, pDoc->nShapeHeight);
	}
	catch (Exception* ex) { 
		MessageBox::Show(ex->ToString());			
    }
}

void CGDIPlusView::HandleFilledEllipseDraw()
{
	try
	{
		Graphics* g = CreateGraphics();
		g->FillEllipse(pDoc->GetCurBrush(), pDoc->nShapeLeft, pDoc->nShapeTop, pDoc->nShapeWidth, pDoc->nShapeHeight);
	}
	catch (Exception* ex) { 
		MessageBox::Show(ex->ToString());			
    }
}

void CGDIPlusView::HandleFilledRectDraw()
{
	try
	{
		Graphics* g = CreateGraphics();
		g->FillRectangle(pDoc->GetCurBrush(), pDoc->nShapeLeft, pDoc->nShapeTop, pDoc->nShapeWidth, pDoc->nShapeHeight);
	}
	catch (Exception* ex) { 
		MessageBox::Show(ex->ToString());			
    }
}

void CGDIPlusView::HandleTextDraw(String* pStr, Drawing::Font* pFont, Color colorText)
{
	try
	{
		Point* p = __nogc new Point(20, 20);
		__box Point* pt = __box(*p);

		Graphics* g = CreateGraphics();
		g->DrawString(pStr, pFont, GetDocument()->GetCurBrush(), *pt);
	}
	catch (Exception* ex) { 
		MessageBox::Show(ex->ToString());			
    }
}

