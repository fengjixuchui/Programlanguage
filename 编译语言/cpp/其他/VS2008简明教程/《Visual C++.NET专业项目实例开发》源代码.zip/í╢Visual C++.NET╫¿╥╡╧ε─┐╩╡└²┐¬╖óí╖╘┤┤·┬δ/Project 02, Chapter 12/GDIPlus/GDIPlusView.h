#ifndef __GDIPLUSVIEW_H__
#define __GDIPLUSVIEW_H__

#using <mscorlib.dll>

#using <System.DLL>
#using <System.Drawing.DLL> 
#using <System.Windows.Forms.DLL>

using namespace System;
using namespace System::ComponentModel;
using namespace System::Windows::Forms;
using namespace System::Collections;
using namespace System::IO;
using namespace System::Drawing;
using namespace System::Drawing::Printing;
using namespace System::Collections;

#include "GDIPlusDoc.h"

__gc class CGDIPlusView : public Form
{
    /// <summary> 
    ///    Required designer variable
    /// </summary>
private:
	System::ComponentModel::Container* pComponents;
	CGDIPlusDoc* pDoc;
	CMainWindow* pMainWin;

public:
	 Point ptPrevPoint;
	 CStroke* pCurrentStroke;

     CGDIPlusView(CGDIPlusDoc* pDoc1, CMainWindow* pParent);
    ~CGDIPlusView();
    
     void InitializeComponent();

	 void MouseDownHandler(Object* sender,MouseEventArgs* e);
	 void MouseMoveHandler(Object* sender,MouseEventArgs* e);
	 void MouseUpHandler(Object* sender,MouseEventArgs* e);
	 void PaintHandler(Object* sender, PaintEventArgs* e);
	 void ClosingHandler(Object* sender, CancelEventArgs* e);	
	 void ClosedHandler(Object* sender, EventArgs* e);	
	 
	 CGDIPlusDoc* GetDocument();

public:
	void HandleLineDraw();
	void HandleEllipseDraw();
	void HandleRectDraw();
	void HandleTextDraw(String* pStr, Drawing::Font* pFont, Color colorText);
	void HandleFilledEllipseDraw();
	void HandleFilledRectDraw();
};

#endif __GDIPLUSVIEW_H__