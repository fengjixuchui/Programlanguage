#include "GDIPlus.h"
#include "GDIPlusView.h"
#include "GDIPlusDoc.h"


//CStroke
CStroke:: CStroke(int nPenWidth1)
{
	nPenWidth = nPenWidth1;
	pPointArray = new ArrayList();
}
CStroke::~CStroke()
{
}

void CStroke::DrawStroke(Graphics* g)
{		
	Pen* pPen = new Pen(Color::Black, (float)nPenWidth);
	for(int i=1; i < pPointArray->Count; i++)
	{			
		__box Point* p1 = dynamic_cast<__box Point*> (pPointArray->Item[i-1]);
		__box Point* p2 = dynamic_cast<__box Point*> (pPointArray->Item[i]);

		g->DrawLine(pPen, *p1, *p2);
	}
	pPen->Dispose();
}

void CStroke::FinishStroke()
{
	if(pPointArray->Count == 0)
	{
		rectBoundingRect.Size = Size::Empty;
		return;
	}

	__box Point* pt = dynamic_cast<__box Point*> (pPointArray->Item[0]);
	rectBoundingRect =  Rectangle (pt->X, pt->Y, 0, 0);
	for(int i=1; i < pPointArray->Count; i++)
	{
		pt = dynamic_cast<__box Point*> (pPointArray->Item[i]);
		rectBoundingRect = Rectangle::FromLTRB(Min(rectBoundingRect.Left, pt->X),Min(rectBoundingRect.Top, pt->Y),Max(rectBoundingRect.Right, pt->X) , Max(rectBoundingRect.Bottom, pt->Y));
	}
	rectBoundingRect.Inflate(Size((int)nPenWidth, (int)nPenWidth));
	return;			
}
	
//CGDIPlusDoc
CGDIPlusDoc:: CGDIPlusDoc(CMainWindow* pMainWin)
{
		bIsDirty= false;
		bIsThickPen=false;
		nThinWidth=3;
		nThickWidth=7;
		strokeList = new ArrayList() ;
		viewList = new ArrayList();

		pCurrentBrush = new SolidBrush(Color::Blue);
		ReplacePen();

		//Defaults
		nShapeLeft = 10;
		nShapeTop = 10;
		nShapeWidth = 50;
		nShapeHeight = 25;

		//Set the ID to be the current count + 1. This is so that the ID starts with 1
		nDocID = CMainWindow::nDocCount+1;
		//Create a view (Form) for this document
		CGDIPlusView* pView = new CGDIPlusView(this, pMainWin);
		viewList->Add(pView);
		pView->Show();
}

CGDIPlusDoc::~CGDIPlusDoc()
{
}

CStroke* CGDIPlusDoc:: NewStroke()
{
	CStroke*  s = new CStroke(nPenWidth);
	strokeList->Add(s);
	bIsDirty = true; //Now that the doc is modified, set the dirty flag
	return s;
}

void CGDIPlusDoc::ReplacePen()
{
	nPenWidth = bIsThickPen ? nThickWidth : nThinWidth;
	pCurrentPen = new Pen(Color::Black , (float)nPenWidth);
}

void CGDIPlusDoc::SaveDocument(String* fileName)
{
	try 
	{			
		Stream* s = File::Open(fileName, FileMode::Create);
		BinaryFormatter* b = new BinaryFormatter();
		b->Serialize(s, strokeList);
		s->Close();				
		//Now that the doc is saved, its no more dirty
		bIsDirty = false;
	}

	catch(Exception* ex)
	{
		MessageBox::Show(ex->ToString());
	}
}

void CGDIPlusDoc::OpenDocument(String* fileName)
{
	try 
	{
		Stream* s =  File::Open(fileName, FileMode::Open);
		BinaryFormatter* b = new BinaryFormatter();
		strokeList = dynamic_cast<ArrayList*>(b->Deserialize(s));
		s->Close();						
	}	
	catch(Exception* ex)
	{
		MessageBox::Show(ex->ToString());
	}
}

Pen* CGDIPlusDoc::GetCurrentPen()
{
	return pCurrentPen;
}

Brush* CGDIPlusDoc::GetCurBrush()
{
	return pCurrentBrush;
}

//Updates all the views of the document with the new data
void CGDIPlusDoc::UpdateAllViews(CGDIPlusView* sender, CStroke* newStroke)
{		
	CGDIPlusView* pView;
	for(int i=0; i < viewList->Count ; i++)
	{
		pView = dynamic_cast<CGDIPlusView*> (viewList->Item[i]);	

		if(pView->Equals(sender))
			continue;

		//If this is for a new stroke
		if(newStroke)
		{
			pView->Invalidate(newStroke->GetBoundingRectangle());							   
		}
		else
		{
			//must be ClearAll,hence invalidate the entire region
			pView->Invalidate();
		}
		pView->Update();
	}			
}

// Deletes the contents of the document
void CGDIPlusDoc::DeleteContents()
{		
	strokeList->Clear();
	UpdateAllViews(0, 0);				
}
