#include "GDIPlus.h"
#include "GDIPlusView.h"

CMainWindow::CMainWindow()
{        
	pParentWindow = this;

	InitializeComponent();	
	nDocCount=0;  
	CreateDocument();
}

CMainWindow::~CMainWindow()
{
	//pComponents->Dispose();
}

void CMainWindow::InitializeComponent()
{
	pComponents = new System::ComponentModel::Container();
	
	pPrintDoc = new Printing::PrintDocument();		
	pPrintDoc->PrintPage += new PrintPageEventHandler(this, PrintPage);
		
	AutoScaleBaseSize =  System::Drawing::Size(5, 13);
	Text = "GDIPlus";
	IsMdiContainer = true;
	Menu = pMainMenu;
	ClientSize =  System::Drawing::Size(600, 400);

	pHelpProvider = new System::Windows::Forms::HelpProvider();
	pHelpProvider->HelpNamespace = S"Help\\GDIPlus.chm";
	pHelpProvider->SetShowHelp(this, true);		

//File
	pNewMenuItem = new Windows::Forms::MenuItem(S"&New",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pOpenMenuItem = new Windows::Forms::MenuItem(S"&Open",	new EventHandler(this, &CMainWindow::MenuItemHandler));
	pCloseMenuItem = new Windows::Forms::MenuItem(S"&Close",	new EventHandler(this, &CMainWindow::MenuItemHandler));
	pSaveMenuItem = new Windows::Forms::MenuItem(S"&Save", 	new EventHandler(this, &CMainWindow::MenuItemHandler));
	pSaveAsMenuItem	= new Windows::Forms::MenuItem(S"Save &As", new EventHandler(this, &CMainWindow::MenuItemHandler));
	pLine1MenuItem = new Windows::Forms::MenuItem(S"-");
	pPrintMenuItem = new Windows::Forms::MenuItem(S"&Print",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pPrintPreviewMenuItem = new Windows::Forms::MenuItem(S"P&rintPreview",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pLine2MenuItem = new Windows::Forms::MenuItem(S"-");
	pLine3MenuItem = new Windows::Forms::MenuItem(S"-");		
	pExitMenuItem = new Windows::Forms::MenuItem(S"E&xit",new EventHandler(this, &CMainWindow::MenuItemHandler));

	Windows::Forms::MenuItem *rFileItems[] =
		new Windows::Forms::MenuItem *[10];

	rFileItems[0] = pNewMenuItem;
	rFileItems[1] = pOpenMenuItem;
	rFileItems[2] = pCloseMenuItem;
	rFileItems[3] = pSaveMenuItem;
	rFileItems[4] = pSaveAsMenuItem;
	rFileItems[5] = pLine1MenuItem;
	rFileItems[6] = pPrintMenuItem;
	rFileItems[7] = pPrintPreviewMenuItem;
	rFileItems[8] = pLine2MenuItem;
	rFileItems[9] = pExitMenuItem;

	pFileMenuItem = new Windows::Forms::MenuItem(S"&File", rFileItems);

	pClearAllMenuItem = new Windows::Forms::MenuItem(S"Clear &All",new EventHandler(this, &CMainWindow::MenuItemHandler));

	Windows::Forms::MenuItem *rEditItems[] =
		new Windows::Forms::MenuItem *[1];

	rEditItems[0] = pClearAllMenuItem;
	//rEditItems[1] = pLine3MenuItem;
	
	pEditMenuItem = new Windows::Forms::MenuItem(S"&Edit", rEditItems);

	//Pen
	pThickLineMenuItem = new Windows::Forms::MenuItem(S"Thick Line",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pPenWidthMenuItem = new Windows::Forms::MenuItem(S"Pen Width",new EventHandler(this, &CMainWindow::MenuItemHandler));

	Windows::Forms::MenuItem *rPenItems[] =
		new Windows::Forms::MenuItem *[2];

	rPenItems[0] = pThickLineMenuItem;
	rPenItems[1] = pPenWidthMenuItem;

	pPenMenuItem = new Windows::Forms::MenuItem(S"Pen", rPenItems);

	//View
	pToolbarMenuItem = new Windows::Forms::MenuItem(S"Toolbar",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pToolbarMenuItem->Checked = true;
	pStatusbarMenuItem = new Windows::Forms::MenuItem(S"Statusbar",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pStatusbarMenuItem->Checked = true;
	Windows::Forms::MenuItem *rviewItems[] =
		new Windows::Forms::MenuItem *[2];

	rviewItems[0] = pToolbarMenuItem;
	rviewItems[1] = pStatusbarMenuItem;

	pViewMenuItem = new Windows::Forms::MenuItem(S"View", rviewItems);

//START PSK
	pDrawLine = new Windows::Forms::MenuItem(S"Line",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pDrawEllipse = new Windows::Forms::MenuItem(S"Ellipse",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pDrawRect = new Windows::Forms::MenuItem(S"Rectangle",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pDrawText = new Windows::Forms::MenuItem(S"Text",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pDrawFilledEllipse = new Windows::Forms::MenuItem(S"Filled Ellipse",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pDrawFilledRect = new Windows::Forms::MenuItem(S"Filled Rect",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pDelegateHandler = new Windows::Forms::MenuItem(S"Delegate and Events",new EventHandler(this, &CMainWindow::MenuItemHandler));

	Windows::Forms::MenuItem *rDrawItems[] =
		new Windows::Forms::MenuItem *[7];

	rDrawItems[0] = pDrawLine;
	rDrawItems[1] = pDrawEllipse;
	rDrawItems[2] = pDrawRect;
	rDrawItems[3] = pDrawText;
	rDrawItems[4] = pDrawFilledEllipse;
	rDrawItems[5] = pDrawFilledRect;
	rDrawItems[6] = pDelegateHandler;

	pDrawMenuItem = new Windows::Forms::MenuItem(S"Draw", rDrawItems);
//END PSK

	//Windows
	pNewWindowMenuItem = new Windows::Forms::MenuItem(S"New Window",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pCascadeMenuItem = new Windows::Forms::MenuItem(S"Cascade",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pTileMenuItem = new Windows::Forms::MenuItem(S"Tile",new EventHandler(this, &CMainWindow::MenuItemHandler));

	Windows::Forms::MenuItem *rwindowItems[] =
		new Windows::Forms::MenuItem *[3];

	rwindowItems[0] = pNewWindowMenuItem;
	rwindowItems[1] = pCascadeMenuItem;
	rwindowItems[2] = pTileMenuItem;

	pWindowMenuItem = new Windows::Forms::MenuItem(S"Window", rwindowItems);

	//Help
	pHelpTopicsMenuItem = new Windows::Forms::MenuItem(S"Help Topics",new EventHandler(this, &CMainWindow::MenuItemHandler));
	pHelpAboutMenuItem = new Windows::Forms::MenuItem(S"About GDIPlus",new EventHandler(this, &CMainWindow::MenuItemHandler));

	Windows::Forms::MenuItem *rhelpItems[] =
		new Windows::Forms::MenuItem *[2];

	rhelpItems[0] = pHelpTopicsMenuItem;
	rhelpItems[1] = pHelpAboutMenuItem;

	pHelpMenuItem = new Windows::Forms::MenuItem(S"Help", rhelpItems);

	//MainMenu
	Windows::Forms::MenuItem *rMainItems[] = new Windows::Forms::MenuItem *[7];

	rMainItems[0] = pFileMenuItem;
	rMainItems[1] = pEditMenuItem;
	rMainItems[2] = pPenMenuItem; 
	rMainItems[3] = pViewMenuItem;
	rMainItems[4] = pDrawMenuItem;
	rMainItems[5] = pWindowMenuItem;
	rMainItems[6] = pHelpMenuItem;

	pMainMenu = new MainMenu(rMainItems);
	Menu = pMainMenu;

	//Toolbar and Status bar
	pStatusBar = new Windows::Forms::StatusBar();
	pStatusBar->TabIndex = 2;
	pStatusBar->Text = "For Help,  press F1";

	pHelpTBButton	= new Windows::Forms::ToolBarButton();
	pHelpTBButton->ImageIndex = 5;
	pHelpTBButton->ToolTipText = "Help";

	pPrintTBButton = new Windows::Forms::ToolBarButton();
	pPrintTBButton->ImageIndex = 4;
	pPrintTBButton->ToolTipText = "Print";

	pPreviewTBButton = new Windows::Forms::ToolBarButton();
	pPreviewTBButton->ImageIndex = 3;
	pPreviewTBButton->ToolTipText = "Print Preview";
	
	pSaveTBButton = new Windows::Forms::ToolBarButton();
	pSaveTBButton->ImageIndex = 2;
	pSaveTBButton->ToolTipText = "Save";

	pOpenTBButton = new Windows::Forms::ToolBarButton();
	pOpenTBButton->ImageIndex = 1;
	pOpenTBButton->ToolTipText = "Open";

	pNewTBButton = new Windows::Forms::ToolBarButton();
	pNewTBButton->ImageIndex = 0;
	pNewTBButton->ToolTipText = "New";

	pImageList = new Windows::Forms::ImageList();
	pImageList->ImageSize =  System::Drawing::Size(16, 16);
	pImageList->TransparentColor = System::Drawing::Color::Transparent;
	pImageList->Images->Add(Image::FromFile(S"Res\\new.bmp"));
	pImageList->Images->Add(Image::FromFile(S"Res\\open.bmp"));
	pImageList->Images->Add(Image::FromFile(S"Res\\save.bmp"));
	pImageList->Images->Add(Image::FromFile(S"Res\\preview.bmp"));
	pImageList->Images->Add(Image::FromFile(S"Res\\print.bmp"));
	pImageList->Images->Add(Image::FromFile(S"Res\\help.bmp"));

	pToolBar = new Windows::Forms::ToolBar();
	pToolBar->ImageList = pImageList;
	pToolBar->DropDownArrows = true;
	pToolBar->ShowToolTips = true;
	System::Windows::Forms::ToolBarButton* rToolbarButtons[]=new System::Windows::Forms::ToolBarButton*[6];
	rToolbarButtons[0]=pNewTBButton;
	rToolbarButtons[1]=pOpenTBButton;
	rToolbarButtons[2]=pSaveTBButton;
	rToolbarButtons[3]=pPreviewTBButton;
	rToolbarButtons[4]=pPrintTBButton;
	rToolbarButtons[5]=pHelpTBButton;

	pToolBar->Buttons->AddRange(rToolbarButtons);	
	pToolBar->ButtonClick += new System::Windows::Forms::ToolBarButtonClickEventHandler(this,&CMainWindow::ToolbarHandler);

	Control *rControls[] = new Control *[2];
	rControls[0] = pStatusBar;
	rControls[1] = pToolBar;
	this->Controls->AddRange(rControls);
}

void CMainWindow::MenuItemHandler(Object* sender, EventArgs* e)
{
	if(sender->Equals(pNewMenuItem))
	{
		New();
	}
	else if(sender->Equals(pOpenMenuItem))
	{
		Open();
	}
	else if(sender->Equals(pSaveMenuItem))
	{
		Save();
	}
	else if(sender->Equals(pPrintPreviewMenuItem))
	{
		PrintPreview();
	}
	else if(sender->Equals(pPrintMenuItem))
	{
		Print();
	}
	else if(sender->Equals(pHelpAboutMenuItem))
	{
		AboutHelp();
	}
	else if(sender->Equals(pExitMenuItem))
	{
		Exit();
	}
	else if(sender->Equals(pCloseMenuItem))
	{
		CloseView();
	}
	else if(sender->Equals(pTileMenuItem))
	{
		Tile();
	}
	else if(sender->Equals(pCascadeMenuItem))
	{
		Cascade();
	}
	else if(sender->Equals(pClearAllMenuItem))
	{
		ClearAll();
	}
	else if(sender->Equals(pSaveAsMenuItem))
	{
		Save();
	}
	else if(sender->Equals(pNewWindowMenuItem))
	{
		NewWindow();
	}
	else if(sender->Equals(pPenWidthMenuItem))
	{
		PenWidthsDlg();
	}
	else if(sender->Equals(pThickLineMenuItem))
	{
		ThickLine();			
	}
	else if(sender->Equals(pHelpTopicsMenuItem))
	{
		HelpTopics();			
	}
	else if(sender->Equals(pToolbarMenuItem))
	{
		pToolBar->Visible  =  !pToolBar->Visible ;
		pToolbarMenuItem->Checked  = pToolBar->Visible;
	}
	else if(sender->Equals(pStatusbarMenuItem))
	{
		pStatusBar->Visible = !pStatusBar->Visible;			
		pStatusbarMenuItem->Checked = pStatusBar->Visible;
	}
	else if(sender->Equals(pDrawLine))
	{
		DrawLine();
	}
	else if(sender->Equals(pDrawEllipse))
	{
		DrawEllipse();
	}
	else if(sender->Equals(pDrawRect))
	{
		DrawRect();
	}
	else if(sender->Equals(pDrawText))
	{
		DrawText();
	}
	else if(sender->Equals(pDrawFilledEllipse))
	{
		DrawFilledEllipse();
	}
	else if(sender->Equals(pDrawFilledRect))
	{
		DrawFilledRect();
	}
	else if(sender->Equals(pDelegateHandler))
	{
		HandleDelegate();
	}
}


void CMainWindow::ToolbarHandler(Object* sender, ToolBarButtonClickEventArgs* e)
{
	// Evaluate the Button property to determine which button was clicked.
	switch (this->pToolBar->Buttons->IndexOf(e->Button))
	{
    case 0:
        New();
        break;
    case 1:
        Open();
        break;
    case 2:
        Save();
        break;
	case 3:
        PrintPreview();
        break;
	case 4:
        Print();
        break;
	case 5:
        HelpTopics();
        break;
	default:
		break;		
	}
}
//About GDIPlus
void CMainWindow::AboutHelp()
{
	MessageBox::Show(S"GDIPlus Version 1.0", S"About GDIPlus");
}

//Help Topics
void CMainWindow::HelpTopics()
{
	Help::ShowHelp(this, S"help\\GDIPlus.chm");
}

//Print
void CMainWindow::Print()
{		
	try 
	{			
		pPrintDoc->Print();
	} 
	catch(Exception* e)
	{
		MessageBox::Show(e->ToString());
	}
}

//PrintPage 
void CMainWindow::PrintPage(Object* sender, PrintPageEventArgs* printEv)
{
	try{
		CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*>(this->ActiveMdiChild);
		CGDIPlusDoc* pActiveDoc = pActiveView->GetDocument();	

		for(int i=0; i < pActiveDoc->strokeList->Count; i++)
		{
			CStroke* st = dynamic_cast<CStroke*>(pActiveDoc->strokeList->Item[i]);
			st->DrawStroke(printEv->Graphics) ;
		}
		printEv->HasMorePages = false;
	}

	catch (Exception* ex)
	{
		MessageBox::Show(ex->ToString());
	}
}

//PrintPreview
void CMainWindow::PrintPreview()
{
	try {
		PrintPreviewDialog* pPrevDlg = new PrintPreviewDialog();
		pPrevDlg->Document = pPrintDoc;
		pPrevDlg->Size = System::Drawing::Size(600, 329);
		pPrevDlg->ShowDialog();
	}
	catch(Exception* ex)
	{
		MessageBox::Show(ex->ToString());
	}
}


//Exit
void CMainWindow::Exit()
{
	Form* paChildForm[] = this->MdiChildren ;
	//Make sure to ask for saving the doc before exiting the app
	for(int i=0; i < paChildForm->Length ; i++)
		paChildForm[i]->Close();
	Application::Exit();
}

//Close
void CMainWindow::CloseView()
{
	CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*> (this->ActiveMdiChild);
	pActiveView->Close();	
}

//Tile_Click
void CMainWindow::Tile()
{
	this->LayoutMdi(MdiLayout::TileHorizontal);	
}

//Cascade_Click
void CMainWindow::Cascade()
{
	this->LayoutMdi(MdiLayout::Cascade);	
}

//ClearAll
void CMainWindow::ClearAll()
{
	CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*> (this->ActiveMdiChild);
	if(pActiveView)
	{
		CGDIPlusDoc* pActiveDoc = pActiveView->GetDocument();
		pActiveDoc->DeleteContents();
	}
}

//Open
void CMainWindow::Open()
{
	OpenFileDialog* pOpenDlg = new OpenFileDialog();
	pOpenDlg->Filter = "GDIPlus Files (*.scb)|*.scb|All Files (*.*)|*.*";
	pOpenDlg->FileName = "" ;
	pOpenDlg->DefaultExt = ".scb";
	pOpenDlg->CheckFileExists = true;
	pOpenDlg->CheckPathExists = true;
		
	int nRes = pOpenDlg->ShowDialog ();

	if(nRes == DialogResult::OK)
	{
		if( !(pOpenDlg->FileName)->EndsWith(".scb") && !(pOpenDlg->FileName)->EndsWith(".SCB")) 
			MessageBox::Show("Unexpected file format","GDIPlus",MessageBoxButtons::OK );
		else
		{
			CGDIPlusDoc* pNewDoc = CreateDocument();
			pNewDoc->OpenDocument(pOpenDlg->FileName);
		}
	}
}

//Save
void CMainWindow::Save()
{
	try 
	{
		CGDIPlusView* pSelectedView = dynamic_cast<CGDIPlusView*>(this->ActiveMdiChild);
		SaveFileDialog* pSaveDlg = new SaveFileDialog();
		pSaveDlg->Filter = "GDIPlus Files (*.scb)|*.scb|All Files (*.*)|*.*";
		pSaveDlg->DefaultExt = ".scb";
		pSaveDlg->FileName = "GDIPlus1.scb";
		
		int nRes = pSaveDlg->ShowDialog();
		if(nRes == DialogResult::OK)
		{
			if(pSelectedView)
			{
				CGDIPlusDoc* pDoc = pSelectedView->GetDocument();
				pDoc->SaveDocument(pSaveDlg->FileName);	
			}			
		}
	}
	catch(Exception* ex)
	{
		MessageBox::Show(ex->ToString());
	}
}

//New
void CMainWindow::New()
{
	//If this is the first child window, enable the Menu and Toolbar items
	if(!this->ActiveMdiChild)
		EnableItems();
	CreateDocument();
}

//NewWindow
void CMainWindow::NewWindow()
{
	CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*>(this->ActiveMdiChild);
	CGDIPlusView* pNewView = new CGDIPlusView(pActiveView->GetDocument(), pParentWindow);
	pNewView->GetDocument()->viewList->Add(pNewView);
	pNewView->Show();	
}

//ThickLine
void CMainWindow::ThickLine()
{		 
	CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*> (this->ActiveMdiChild);
	CGDIPlusDoc* pActiveDoc = pActiveView->GetDocument();
	pActiveDoc->bIsThickPen = !pActiveDoc->bIsThickPen;
	pActiveDoc->ReplacePen();
	this->pThickLineMenuItem->Checked = pActiveDoc->bIsThickPen;
}

//PenWidthDlg
void CMainWindow::PenWidthsDlg()
{
	Form* f = new Form();

	//Get the document of active view
	CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*> (this->ActiveMdiChild);
	CGDIPlusDoc* pActiveDoc = pActiveView->GetDocument();

	f->AutoScaleBaseSize =  System::Drawing::Size(5, 13);
	f->Text = "Pen Width";
	
	f->ClientSize =  System::Drawing::Size(352, 125);
	
	Button* button1 = new Button();
	button1->Location =  System::Drawing::Point(264, 20);
	button1->Size =  System::Drawing::Size(75, 23);
	button1->TabIndex = 1;
	button1->Text = "OK";
	button1->DialogResult  = System::Windows::Forms::DialogResult::OK ;//Make this "OK" button

	Button* button2 = new Button();
	button2->Location =  System::Drawing::Point(264, 52);
	button2->Size =  System::Drawing::Size(75, 23);
	button2->TabIndex = 6;
	button2->Text = "Cancel";
	
	TextBox* textBox1 = new TextBox();		
	textBox1->Location =  System::Drawing::Point(120, 36);
	textBox1->Text = pActiveDoc->nThinWidth.ToString();
	textBox1->TabIndex = 1;
	textBox1->Size =  System::Drawing::Size(64, 20);

	TextBox* textBox2 = new TextBox();		
	textBox2->Location =  System::Drawing::Point(120, 76);
	textBox2->Text = pActiveDoc->nThickWidth.ToString();
	textBox2->TabIndex = 2;
	textBox2->Size =  System::Drawing::Size(64, 20);
	
	Label* label1 = new Label();
	label1->Location =  System::Drawing::Point(16, 36);
	label1->Text = "Thin Pen Width:";
	label1->Size =  System::Drawing::Size(88, 16);
	label1->TabIndex = 3;
	
	Label* label2 = new Label();
	label2->Location =  System::Drawing::Point(16, 76);
	label2->Text = "Thick Pen Width:";
	label2->Size =  System::Drawing::Size(95, 16);
	label2->TabIndex = 4;		
	
	f->FormBorderStyle = FormBorderStyle::FixedDialog;
	// Set the MaximizeBox to false to remove the maximize box.
	f->MaximizeBox = false;
	// Set the MinimizeBox to false to remove the minimize box.
	f->MinimizeBox = false;
	// Set the accept button of the form to button1.
	f->AcceptButton = button1;
	// Set the cancel button of the form to button2.
	f->CancelButton = button2;
	
	f->StartPosition = FormStartPosition::CenterScreen;		
	
	f->Controls->Add(button1);
	f->Controls->Add(button2);
	f->Controls->Add(label1);
	f->Controls->Add(label2);
	f->Controls->Add(textBox1);  
	f->Controls->Add(textBox2);			
		
	System::Windows::Forms::DialogResult res = f->ShowDialog();
			
	if(res == System::Windows::Forms::DialogResult::OK )
	{			
		pActiveDoc->nThinWidth = UInt32::Parse(textBox1->Text);
		pActiveDoc->nThickWidth = UInt32::Parse(textBox2->Text);
		pActiveDoc->ReplacePen();
		f->Close();
	}			
}

//Disable the menu and toolbar items when there is no active child form
void CMainWindow::DisableItems()
{
	this->pEditMenuItem->Visible=false;
	this->pPenMenuItem->Visible=false;
	this->pWindowMenuItem->Visible=false;
	this->pCloseMenuItem->Visible=false;
	this->pSaveMenuItem->Visible=false;
	this->pSaveAsMenuItem->Visible=false;
	this->pPrintMenuItem->Visible=false;
	this->pPrintPreviewMenuItem->Visible=false;
	this->pSaveTBButton->Enabled = false;
	this->pPreviewTBButton->Enabled=false;
	this->pPrintTBButton->Enabled=false;
}

//Enable the menu and toolbar items when the first child form is created
void CMainWindow::EnableItems()
{
	this->pEditMenuItem->Visible=true;
	this->pPenMenuItem->Visible=true;
	this->pWindowMenuItem->Visible=true;
	this->pCloseMenuItem->Visible=true;
	this->pSaveMenuItem->Visible=true;
	this->pSaveAsMenuItem->Visible=true;
	this->pPrintMenuItem->Visible=true;
	this->pPrintPreviewMenuItem->Visible=true;
	this->pSaveTBButton->Enabled = true;
	this->pPreviewTBButton->Enabled=true;
	this->pPrintTBButton->Enabled=true;
}
	
//Creates a new document
CGDIPlusDoc* CMainWindow::CreateDocument()
{
	CGDIPlusDoc* pNewDoc = new CGDIPlusDoc (pParentWindow);
	nDocCount++;
	return pNewDoc;
}

void CMainWindow::DrawEllipse()
{
	Form* f = new Form();
	//Get the document of active view
	CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*> (this->ActiveMdiChild);
	CGDIPlusDoc* pActiveDoc = pActiveView->GetDocument();

	f->AutoScaleBaseSize =  System::Drawing::Size(5, 13);
	f->Text = "Draw Ellipse";
	
	f->ClientSize =  System::Drawing::Size(300, 125);
	
	Button* button1 = new Button();
	button1->Location =  System::Drawing::Point(70, 100);
	button1->Size =  System::Drawing::Size(60, 20);
	button1->TabIndex = 1;
	button1->Text = "OK";
	button1->DialogResult  = System::Windows::Forms::DialogResult::OK ;//Make this "OK" button

	Button* button2 = new Button();
	button2->Location =  System::Drawing::Point(150, 100);
	button2->Size =  System::Drawing::Size(60, 20);
	button2->TabIndex = 6;
	button2->Text = "Cancel";
	
	//Left
	TextBox* textBox1 = new TextBox();		
	textBox1->Location =  System::Drawing::Point(80, 15);
	textBox1->Text = "10"; //pActiveDoc->nThinWidth.ToString();
	textBox1->TabIndex = 1;
	textBox1->Size =  System::Drawing::Size(64, 20);

	//Top
	TextBox* textBox2 = new TextBox();		
	textBox2->Location =  System::Drawing::Point(80, 45);
	textBox2->Text = "10"; //pActiveDoc->nThickWidth.ToString();
	textBox2->TabIndex = 2;
	textBox2->Size =  System::Drawing::Size(64, 20);
	
	Label* label1 = new Label();
	label1->Location =  System::Drawing::Point(15, 20);
	label1->Text = "Left:";
	label1->Size =  System::Drawing::Size(50, 16);
	label1->TabIndex = 3;
	
	Label* label2 = new Label();
	label2->Location =  System::Drawing::Point(15, 50);
	label2->Text = "Top:";
	label2->Size =  System::Drawing::Size(50, 16);
	label2->TabIndex = 4;		

	//PSK START
	TextBox* textBox3 = new TextBox();		
	textBox3->Location =  System::Drawing::Point(220, 15);
	textBox3->Text = "50"; //pActiveDoc->nThinWidth.ToString();
	textBox3->TabIndex = 1;
	textBox3->Size =  System::Drawing::Size(64, 20);

	TextBox* textBox4 = new TextBox();		
	textBox4->Location =  System::Drawing::Point(220, 45);
	textBox4->Text = "25"; //pActiveDoc->nThickWidth.ToString();
	textBox4->TabIndex = 2;
	textBox4->Size =  System::Drawing::Size(64, 20);
	
	Label* label3 = new Label();
	label3->Location =  System::Drawing::Point(155, 20);
	label3->Text = "Width:";
	label3->Size =  System::Drawing::Size(50, 16);
	label3->TabIndex = 3;
	
	Label* label4 = new Label();
	label4->Location =  System::Drawing::Point(155, 50);
	label4->Text = "Height:";
	label4->Size =  System::Drawing::Size(50, 16);
	label4->TabIndex = 4;		

	//END

	f->FormBorderStyle = FormBorderStyle::FixedDialog;
	// Set the MaximizeBox to false to remove the maximize box.
	f->MaximizeBox = false;
	// Set the MinimizeBox to false to remove the minimize box.
	f->MinimizeBox = false;
	// Set the accept button of the form to button1.
	f->AcceptButton = button1;
	// Set the cancel button of the form to button2.
	f->CancelButton = button2;
	
	f->StartPosition = FormStartPosition::CenterScreen;		
	
	f->Controls->Add(button1);
	f->Controls->Add(button2);
	f->Controls->Add(label1);
	f->Controls->Add(label2);
	f->Controls->Add(label3);
	f->Controls->Add(label4);
	f->Controls->Add(textBox1);  
	f->Controls->Add(textBox2);			
	f->Controls->Add(textBox3);
	f->Controls->Add(textBox4);
		
	System::Windows::Forms::DialogResult res = f->ShowDialog();
	if(res == System::Windows::Forms::DialogResult::OK )
	{			
		pActiveDoc->nShapeLeft = UInt16::Parse(textBox1->Text);
		pActiveDoc->nShapeTop = UInt16::Parse(textBox2->Text);
		pActiveDoc->nShapeWidth = UInt16::Parse(textBox3->Text);
		pActiveDoc->nShapeHeight = UInt16::Parse(textBox4->Text);
		pActiveView->HandleEllipseDraw();
		f->Close();
	}			
}
void CMainWindow::DrawRect()
{
	Form* f = new Form();
	//Get the document of active view
	CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*> (this->ActiveMdiChild);
	CGDIPlusDoc* pActiveDoc = pActiveView->GetDocument();

	f->AutoScaleBaseSize =  System::Drawing::Size(5, 13);
	f->Text = "Draw Rectangle";
	
	f->ClientSize =  System::Drawing::Size(300, 125);
	
	Button* button1 = new Button();
	button1->Location =  System::Drawing::Point(70, 100);
	button1->Size =  System::Drawing::Size(60, 20);
	button1->TabIndex = 1;
	button1->Text = "OK";
	button1->DialogResult  = System::Windows::Forms::DialogResult::OK ;//Make this "OK" button

	Button* button2 = new Button();
	button2->Location =  System::Drawing::Point(150, 100);
	button2->Size =  System::Drawing::Size(60, 20);
	button2->TabIndex = 6;
	button2->Text = "Cancel";
	
	//Left
	TextBox* textBox1 = new TextBox();		
	textBox1->Location =  System::Drawing::Point(80, 15);
	textBox1->Text = "10"; //pActiveDoc->nThinWidth.ToString();
	textBox1->TabIndex = 1;
	textBox1->Size =  System::Drawing::Size(64, 20);

	//Top
	TextBox* textBox2 = new TextBox();		
	textBox2->Location =  System::Drawing::Point(80, 45);
	textBox2->Text = "10"; //pActiveDoc->nThickWidth.ToString();
	textBox2->TabIndex = 2;
	textBox2->Size =  System::Drawing::Size(64, 20);
	
	Label* label1 = new Label();
	label1->Location =  System::Drawing::Point(15, 20);
	label1->Text = "Left:";
	label1->Size =  System::Drawing::Size(50, 16);
	label1->TabIndex = 3;
	
	Label* label2 = new Label();
	label2->Location =  System::Drawing::Point(15, 50);
	label2->Text = "Top:";
	label2->Size =  System::Drawing::Size(50, 16);
	label2->TabIndex = 4;		

	//PSK START
	TextBox* textBox3 = new TextBox();		
	textBox3->Location =  System::Drawing::Point(220, 15);
	textBox3->Text = "50"; //pActiveDoc->nThinWidth.ToString();
	textBox3->TabIndex = 1;
	textBox3->Size =  System::Drawing::Size(64, 20);

	TextBox* textBox4 = new TextBox();		
	textBox4->Location =  System::Drawing::Point(220, 45);
	textBox4->Text = "25"; //pActiveDoc->nThickWidth.ToString();
	textBox4->TabIndex = 2;
	textBox4->Size =  System::Drawing::Size(64, 20);
	
	Label* label3 = new Label();
	label3->Location =  System::Drawing::Point(155, 20);
	label3->Text = "Width:";
	label3->Size =  System::Drawing::Size(50, 16);
	label3->TabIndex = 3;
	
	Label* label4 = new Label();
	label4->Location =  System::Drawing::Point(155, 50);
	label4->Text = "Height:";
	label4->Size =  System::Drawing::Size(50, 16);
	label4->TabIndex = 4;		

	//END

	f->FormBorderStyle = FormBorderStyle::FixedDialog;
	// Set the MaximizeBox to false to remove the maximize box.
	f->MaximizeBox = false;
	// Set the MinimizeBox to false to remove the minimize box.
	f->MinimizeBox = false;
	// Set the accept button of the form to button1.
	f->AcceptButton = button1;
	// Set the cancel button of the form to button2.
	f->CancelButton = button2;
	
	f->StartPosition = FormStartPosition::CenterScreen;		
	
	f->Controls->Add(button1);
	f->Controls->Add(button2);
	f->Controls->Add(label1);
	f->Controls->Add(label2);
	f->Controls->Add(label3);
	f->Controls->Add(label4);
	f->Controls->Add(textBox1);  
	f->Controls->Add(textBox2);			
	f->Controls->Add(textBox3);
	f->Controls->Add(textBox4);
		
	System::Windows::Forms::DialogResult res = f->ShowDialog();
	if(res == System::Windows::Forms::DialogResult::OK )
	{			
		//Draw Rectange in the View
		pActiveDoc->nShapeLeft = Int16::Parse(textBox1->Text);
		pActiveDoc->nShapeTop = Int16::Parse(textBox2->Text);
		pActiveDoc->nShapeWidth = Int16::Parse(textBox3->Text);
		pActiveDoc->nShapeHeight = Int16::Parse(textBox4->Text);
		pActiveView->HandleRectDraw();
		f->Close();
	}			
}

void CMainWindow::DrawText()
{
	Form* f = new Form();

	//Get the document of active view
	CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*> (this->ActiveMdiChild);
	CGDIPlusDoc* pActiveDoc = pActiveView->GetDocument();

	f->AutoScaleBaseSize =  System::Drawing::Size(5, 13);
	f->Text = "Draw String";
	
	f->ClientSize =  System::Drawing::Size(200, 140);

	Button* button1 = new Button();
	button1->Location =  System::Drawing::Point(40, 100);
	button1->Size =  System::Drawing::Size(60, 20);
	button1->TabIndex = 1;
	button1->Text = "OK";
	button1->DialogResult  = System::Windows::Forms::DialogResult::OK ;//Make this "OK" button

	Button* button2 = new Button();
	button2->Location =  System::Drawing::Point(120, 100);
	button2->Size =  System::Drawing::Size(60, 20);
	button2->TabIndex = 6;
	button2->Text = "Cancel";
	
	TextBox* textBox1 = new TextBox();	
	textBox1->Location =  System::Drawing::Point(15, 40);
	textBox1->TabIndex = 1;
	textBox1->Size =  System::Drawing::Size(100, 20);

	Label* label1 = new Label();
	label1->Location =  System::Drawing::Point(15, 20);
	label1->Text = "Please Enter the text:";
	label1->Size =  System::Drawing::Size(130, 16);
	label1->TabIndex = 3;

	f->FormBorderStyle = FormBorderStyle::FixedDialog;
	f->MaximizeBox = false;
	f->MinimizeBox = false;
	f->AcceptButton = button1;
	f->CancelButton = button2;
	
	f->StartPosition = FormStartPosition::CenterScreen;		
	
	f->Controls->Add(button1);
	f->Controls->Add(button2);
	f->Controls->Add(label1);
	f->Controls->Add(textBox1);  
		
	String* pstrText;
	System::Windows::Forms::DialogResult res = f->ShowDialog();
	if(res == System::Windows::Forms::DialogResult::OK )
	{			
		pstrText = textBox1->Text;
		f->Close();
	}			
	else
	{
		return;
	}

	//END FORM
	FontDialog* pFontDialog;
	pFontDialog = new FontDialog();
	
	Color colorTxtColor = Color::Black;
	Drawing::Font* pTxtFont; 
	if ( pFontDialog->ShowDialog() != DialogResult::Cancel )
	{
		colorTxtColor = pFontDialog->get_Color();
		pTxtFont = pFontDialog->get_Font();
	}

	pActiveView->HandleTextDraw(pstrText, pTxtFont, colorTxtColor);
}

void CMainWindow::DrawLine()
{
	Form* f = new Form();
	//Get the document of active view
	CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*> (this->ActiveMdiChild);
	CGDIPlusDoc* pActiveDoc = pActiveView->GetDocument();

	f->AutoScaleBaseSize =  System::Drawing::Size(5, 13);
	f->Text = "Draw Line";
	
	f->ClientSize =  System::Drawing::Size(300, 125);
	
	Button* button1 = new Button();
	button1->Location =  System::Drawing::Point(70, 100);
	button1->Size =  System::Drawing::Size(60, 20);
	button1->TabIndex = 1;
	button1->Text = "OK";
	button1->DialogResult  = System::Windows::Forms::DialogResult::OK ;//Make this "OK" button

	Button* button2 = new Button();
	button2->Location =  System::Drawing::Point(150, 100);
	button2->Size =  System::Drawing::Size(60, 20);
	button2->TabIndex = 6;
	button2->Text = "Cancel";
	
	//Left
	TextBox* textBox1 = new TextBox();		
	textBox1->Location =  System::Drawing::Point(80, 15);
	textBox1->Text = "10"; //pActiveDoc->nThinWidth.ToString();
	textBox1->TabIndex = 1;
	textBox1->Size =  System::Drawing::Size(64, 20);

	//Top
	TextBox* textBox2 = new TextBox();		
	textBox2->Location =  System::Drawing::Point(80, 45);
	textBox2->Text = "10"; //pActiveDoc->nThickWidth.ToString();
	textBox2->TabIndex = 2;
	textBox2->Size =  System::Drawing::Size(64, 20);
	
	Label* label1 = new Label();
	label1->Location =  System::Drawing::Point(15, 20);
	label1->Text = "Point1-X:";
	label1->Size =  System::Drawing::Size(55, 16);
	label1->TabIndex = 3;
	
	Label* label2 = new Label();
	label2->Location =  System::Drawing::Point(15, 50);
	label2->Text = "Point1-Y:";
	label2->Size =  System::Drawing::Size(55, 16);
	label2->TabIndex = 4;		

	//PSK START
	TextBox* textBox3 = new TextBox();		
	textBox3->Location =  System::Drawing::Point(220, 15);
	textBox3->Text = "50"; //pActiveDoc->nThinWidth.ToString();
	textBox3->TabIndex = 1;
	textBox3->Size =  System::Drawing::Size(64, 20);

	TextBox* textBox4 = new TextBox();		
	textBox4->Location =  System::Drawing::Point(220, 45);
	textBox4->Text = "25"; //pActiveDoc->nThickWidth.ToString();
	textBox4->TabIndex = 2;
	textBox4->Size =  System::Drawing::Size(64, 20);
	
	Label* label3 = new Label();
	label3->Location =  System::Drawing::Point(155, 20);
	label3->Text = "Point2-X:";
	label3->Size =  System::Drawing::Size(55, 16);
	label3->TabIndex = 3;
	
	Label* label4 = new Label();
	label4->Location =  System::Drawing::Point(155, 50);
	label4->Text = "Point2-Y:";
	label4->Size =  System::Drawing::Size(55, 16);
	label4->TabIndex = 4;		

	//END

	f->FormBorderStyle = FormBorderStyle::FixedDialog;
	// Set the MaximizeBox to false to remove the maximize box.
	f->MaximizeBox = false;
	// Set the MinimizeBox to false to remove the minimize box.
	f->MinimizeBox = false;
	// Set the accept button of the form to button1.
	f->AcceptButton = button1;
	// Set the cancel button of the form to button2.
	f->CancelButton = button2;
	
	f->StartPosition = FormStartPosition::CenterScreen;		
	
	f->Controls->Add(button1);
	f->Controls->Add(button2);
	f->Controls->Add(label1);
	f->Controls->Add(label2);
	f->Controls->Add(label3);
	f->Controls->Add(label4);
	f->Controls->Add(textBox1);  
	f->Controls->Add(textBox2);			
	f->Controls->Add(textBox3);
	f->Controls->Add(textBox4);
		
	System::Windows::Forms::DialogResult res = f->ShowDialog();
	if(res == System::Windows::Forms::DialogResult::OK )
	{			
		pActiveDoc->nShapeLeft = UInt16::Parse(textBox1->Text);
		pActiveDoc->nShapeTop = UInt16::Parse(textBox2->Text);
		pActiveDoc->nShapeWidth = UInt16::Parse(textBox3->Text);
		pActiveDoc->nShapeHeight = UInt16::Parse(textBox4->Text);
		pActiveView->HandleLineDraw();
		f->Close();
	}			
}

void CMainWindow::DrawFilledEllipse()
{
	Form* f = new Form();
	//Get the document of active view
	CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*> (this->ActiveMdiChild);
	CGDIPlusDoc* pActiveDoc = pActiveView->GetDocument();

	f->AutoScaleBaseSize =  System::Drawing::Size(5, 13);
	f->Text = "Draw Filled Ellipse";
	
	f->ClientSize =  System::Drawing::Size(300, 125);
	
	Button* button1 = new Button();
	button1->Location =  System::Drawing::Point(70, 100);
	button1->Size =  System::Drawing::Size(60, 20);
	button1->TabIndex = 1;
	button1->Text = "OK";
	button1->DialogResult  = System::Windows::Forms::DialogResult::OK ;//Make this "OK" button

	Button* button2 = new Button();
	button2->Location =  System::Drawing::Point(150, 100);
	button2->Size =  System::Drawing::Size(60, 20);
	button2->TabIndex = 6;
	button2->Text = "Cancel";
	
	//Left
	TextBox* textBox1 = new TextBox();		
	textBox1->Location =  System::Drawing::Point(80, 15);
	textBox1->Text = "10"; //pActiveDoc->nThinWidth.ToString();
	textBox1->TabIndex = 1;
	textBox1->Size =  System::Drawing::Size(64, 20);

	//Top
	TextBox* textBox2 = new TextBox();		
	textBox2->Location =  System::Drawing::Point(80, 45);
	textBox2->Text = "10"; //pActiveDoc->nThickWidth.ToString();
	textBox2->TabIndex = 2;
	textBox2->Size =  System::Drawing::Size(64, 20);
	
	Label* label1 = new Label();
	label1->Location =  System::Drawing::Point(15, 20);
	label1->Text = "Left:";
	label1->Size =  System::Drawing::Size(50, 16);
	label1->TabIndex = 3;
	
	Label* label2 = new Label();
	label2->Location =  System::Drawing::Point(15, 50);
	label2->Text = "Top:";
	label2->Size =  System::Drawing::Size(50, 16);
	label2->TabIndex = 4;		

	//PSK START
	TextBox* textBox3 = new TextBox();		
	textBox3->Location =  System::Drawing::Point(220, 15);
	textBox3->Text = "50"; //pActiveDoc->nThinWidth.ToString();
	textBox3->TabIndex = 1;
	textBox3->Size =  System::Drawing::Size(64, 20);

	TextBox* textBox4 = new TextBox();		
	textBox4->Location =  System::Drawing::Point(220, 45);
	textBox4->Text = "25"; //pActiveDoc->nThickWidth.ToString();
	textBox4->TabIndex = 2;
	textBox4->Size =  System::Drawing::Size(64, 20);
	
	Label* label3 = new Label();
	label3->Location =  System::Drawing::Point(155, 20);
	label3->Text = "Width:";
	label3->Size =  System::Drawing::Size(50, 16);
	label3->TabIndex = 3;
	
	Label* label4 = new Label();
	label4->Location =  System::Drawing::Point(155, 50);
	label4->Text = "Height:";
	label4->Size =  System::Drawing::Size(50, 16);
	label4->TabIndex = 4;		

	//END

	f->FormBorderStyle = FormBorderStyle::FixedDialog;
	// Set the MaximizeBox to false to remove the maximize box.
	f->MaximizeBox = false;
	// Set the MinimizeBox to false to remove the minimize box.
	f->MinimizeBox = false;
	// Set the accept button of the form to button1.
	f->AcceptButton = button1;
	// Set the cancel button of the form to button2.
	f->CancelButton = button2;
	
	f->StartPosition = FormStartPosition::CenterScreen;		
	
	f->Controls->Add(button1);
	f->Controls->Add(button2);
	f->Controls->Add(label1);
	f->Controls->Add(label2);
	f->Controls->Add(label3);
	f->Controls->Add(label4);
	f->Controls->Add(textBox1);  
	f->Controls->Add(textBox2);			
	f->Controls->Add(textBox3);
	f->Controls->Add(textBox4);
		
	System::Windows::Forms::DialogResult res = f->ShowDialog();
	if(res == System::Windows::Forms::DialogResult::OK )
	{			
		pActiveDoc->nShapeLeft = UInt16::Parse(textBox1->Text);
		pActiveDoc->nShapeTop = UInt16::Parse(textBox2->Text);
		pActiveDoc->nShapeWidth = UInt16::Parse(textBox3->Text);
		pActiveDoc->nShapeHeight = UInt16::Parse(textBox4->Text);
		pActiveView->HandleFilledEllipseDraw();
		f->Close();
	}			
}

void CMainWindow::DrawFilledRect()
{
	Form* f = new Form();
	//Get the document of active view
	CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*> (this->ActiveMdiChild);
	CGDIPlusDoc* pActiveDoc = pActiveView->GetDocument();

	f->AutoScaleBaseSize =  System::Drawing::Size(5, 13);
	f->Text = "Draw Filled Rectangle";
	
	f->ClientSize =  System::Drawing::Size(300, 125);
	
	Button* button1 = new Button();
	button1->Location =  System::Drawing::Point(70, 100);
	button1->Size =  System::Drawing::Size(60, 20);
	button1->TabIndex = 1;
	button1->Text = "OK";
	button1->DialogResult  = System::Windows::Forms::DialogResult::OK ;//Make this "OK" button

	Button* button2 = new Button();
	button2->Location =  System::Drawing::Point(150, 100);
	button2->Size =  System::Drawing::Size(60, 20);
	button2->TabIndex = 6;
	button2->Text = "Cancel";
	
	//Left
	TextBox* textBox1 = new TextBox();		
	textBox1->Location =  System::Drawing::Point(80, 15);
	textBox1->Text = "10"; //pActiveDoc->nThinWidth.ToString();
	textBox1->TabIndex = 1;
	textBox1->Size =  System::Drawing::Size(64, 20);

	//Top
	TextBox* textBox2 = new TextBox();		
	textBox2->Location =  System::Drawing::Point(80, 45);
	textBox2->Text = "10"; //pActiveDoc->nThickWidth.ToString();
	textBox2->TabIndex = 2;
	textBox2->Size =  System::Drawing::Size(64, 20);
	
	Label* label1 = new Label();
	label1->Location =  System::Drawing::Point(15, 20);
	label1->Text = "Left:";
	label1->Size =  System::Drawing::Size(50, 16);
	label1->TabIndex = 3;
	
	Label* label2 = new Label();
	label2->Location =  System::Drawing::Point(15, 50);
	label2->Text = "Top:";
	label2->Size =  System::Drawing::Size(50, 16);
	label2->TabIndex = 4;		

	//PSK START
	TextBox* textBox3 = new TextBox();		
	textBox3->Location =  System::Drawing::Point(220, 15);
	textBox3->Text = "50"; //pActiveDoc->nThinWidth.ToString();
	textBox3->TabIndex = 1;
	textBox3->Size =  System::Drawing::Size(64, 20);

	TextBox* textBox4 = new TextBox();		
	textBox4->Location =  System::Drawing::Point(220, 45);
	textBox4->Text = "25"; //pActiveDoc->nThickWidth.ToString();
	textBox4->TabIndex = 2;
	textBox4->Size =  System::Drawing::Size(64, 20);
	
	Label* label3 = new Label();
	label3->Location =  System::Drawing::Point(155, 20);
	label3->Text = "Width:";
	label3->Size =  System::Drawing::Size(50, 16);
	label3->TabIndex = 3;
	
	Label* label4 = new Label();
	label4->Location =  System::Drawing::Point(155, 50);
	label4->Text = "Height:";
	label4->Size =  System::Drawing::Size(50, 16);
	label4->TabIndex = 4;		

	//END

	f->FormBorderStyle = FormBorderStyle::FixedDialog;
	// Set the MaximizeBox to false to remove the maximize box.
	f->MaximizeBox = false;
	// Set the MinimizeBox to false to remove the minimize box.
	f->MinimizeBox = false;
	// Set the accept button of the form to button1.
	f->AcceptButton = button1;
	// Set the cancel button of the form to button2.
	f->CancelButton = button2;
	
	f->StartPosition = FormStartPosition::CenterScreen;		
	
	f->Controls->Add(button1);
	f->Controls->Add(button2);
	f->Controls->Add(label1);
	f->Controls->Add(label2);
	f->Controls->Add(label3);
	f->Controls->Add(label4);
	f->Controls->Add(textBox1);  
	f->Controls->Add(textBox2);			
	f->Controls->Add(textBox3);
	f->Controls->Add(textBox4);
		
	System::Windows::Forms::DialogResult res = f->ShowDialog();
	if(res == System::Windows::Forms::DialogResult::OK )
	{			
		//Draw Rectange in the View
		pActiveDoc->nShapeLeft = Int16::Parse(textBox1->Text);
		pActiveDoc->nShapeTop = Int16::Parse(textBox2->Text);
		pActiveDoc->nShapeWidth = Int16::Parse(textBox3->Text);
		pActiveDoc->nShapeHeight = Int16::Parse(textBox4->Text);
		pActiveView->HandleFilledRectDraw();
		f->Close();
	}			
}

//START PSK -- Delegates and Events
public __delegate void MyDelegate(int, int);  //Declare delegate

// Managed class with virtual event
__gc class CMyClass
{
public:
	virtual __event MyDelegate *E;
};

// Implement virtual events
__gc class EventSource : public CMyClass
{
public:
	__event MyDelegate *E;
	void Fire_E(int n1, int n2)
	{
		E(n1, n2);
	}
};

// class to hold event handlers, the event receiver
public __gc struct EventReceiver
{
	void Add(int num1, int num2)
	{
		String* pStr;
		pStr = String::Format(" {0} + {1} = {2}", Convert::ToString(num1), Convert::ToString(num2), Convert::ToString(num1+num2));
		MessageBox::Show(pStr, "Addition");
	}
	void Subtract(int num1, int num2)
	{
		String* pStr;
		pStr = String::Format(" {0} - {1} = {2}", Convert::ToString(num1), Convert::ToString(num2), Convert::ToString(num1-num2));
		MessageBox::Show(pStr, "Subtraction");
	}
	void Multiply(int num1, int num2)
	{
		String* pStr;
		pStr = String::Format(" {0} * {1} = {2}", Convert::ToString(num1), Convert::ToString(num2), Convert::ToString(num1*num2));
		MessageBox::Show(pStr, "Multiplication");
	}
	void Divide(int num1, int num2)
	{
		if (num2 == 0)
		{
			MessageBox::Show("Divide by Zero eror", "Division");
			return;
		}

		String* pStr;
		pStr = String::Format(" {0} / {1} = {2} (Rounded)", Convert::ToString(num1), Convert::ToString(num2), Convert::ToString(num1/num2));
		MessageBox::Show(pStr, "Division");
	}
};

void CMainWindow::HandleDelegate()
{
	int nOp = 0;
	int nNum1 = 0;
	int nNum2 = 0;
	String* pOp;

	//Simple calculation form

	Form* f = new Form();

	//Get the document of active view
	CGDIPlusView* pActiveView = dynamic_cast<CGDIPlusView*> (this->ActiveMdiChild);
	CGDIPlusDoc* pActiveDoc = pActiveView->GetDocument();

	f->AutoScaleBaseSize =  System::Drawing::Size(5, 13);
	f->Text = "Simple Calculation";

	f->ClientSize =  System::Drawing::Size(200, 125);

	ComboBox* cmbBox1 = new ComboBox();
	cmbBox1->Location =  System::Drawing::Point(70, 40);
	cmbBox1->Size =  System::Drawing::Size(30, 20);
	cmbBox1->TabIndex = 2;
	cmbBox1->set_DropDownStyle(ComboBoxStyle::DropDownList);
	//Add existing operations
	cmbBox1->Items->Add(Convert::ToString("+"));
	cmbBox1->Items->Add(Convert::ToString("-"));
	cmbBox1->Items->Add(Convert::ToString("*"));
	cmbBox1->Items->Add(Convert::ToString("/"));

	Label* label1 = new Label();
	label1->Location =  System::Drawing::Point(15, 20);
	label1->Text = "Num1:";
	label1->Size =  System::Drawing::Size(40, 16);
	
	Label* label2 = new Label();
	label2->Location =  System::Drawing::Point(15, 48);
	label2->Text = "Operation:";
	label2->Size =  System::Drawing::Size(56, 16);

	Label* label3 = new Label();
	label3->Location =  System::Drawing::Point(15, 75);
	label3->Text = "Num2:";
	label3->Size =  System::Drawing::Size(40, 16);

	Button* button1 = new Button();
	button1->Location =  System::Drawing::Point(35, 100);
	button1->Size =  System::Drawing::Size(60, 20);
	button1->TabIndex = 4;
	button1->Text = "OK";
	button1->DialogResult  = System::Windows::Forms::DialogResult::OK ;//Make this "OK" button

	Button* button2 = new Button();
	button2->Location =  System::Drawing::Point(105, 100);
	button2->Size =  System::Drawing::Size(60, 20);
	button2->TabIndex = 5;
	button2->Text = "Cancel";
	
	TextBox* textBox1 = new TextBox();		
	textBox1->Location =  System::Drawing::Point(70, 15);
	textBox1->TabIndex = 1;
	textBox1->Size =  System::Drawing::Size(64, 20);

	TextBox* textBox2 = new TextBox();		
	textBox2->Location =  System::Drawing::Point(70, 65);
	textBox2->TabIndex = 3;
	textBox2->Size =  System::Drawing::Size(64, 20);
	
	f->FormBorderStyle = FormBorderStyle::FixedDialog;
	f->MaximizeBox = false;
	f->MinimizeBox = false;
	f->AcceptButton = button1;
	f->CancelButton = button2;
	
	f->StartPosition = FormStartPosition::CenterScreen;		
	
	f->Controls->Add(button1);
	f->Controls->Add(button2);
	f->Controls->Add(cmbBox1); 
	f->Controls->Add(textBox1);  
	f->Controls->Add(textBox2);			
	f->Controls->Add(label1);			
	f->Controls->Add(label2);			
	f->Controls->Add(label3);			
		
	System::Windows::Forms::DialogResult res = f->ShowDialog();
	if(res == System::Windows::Forms::DialogResult::OK )
	{	
		String *pStr1, *pStr2;
		pStr1 = textBox1->Text;
		pStr1 = pStr1->Trim();
		pStr2 = textBox2->Text;
		pStr2 = pStr2->Trim();
		//Check for Empty values
		if (pStr1 == "" || pStr2 == "")
		{
			MessageBox::Show("Operands missing...", "Message");
			return;
		}

		//Convert Strings to Integers
		nNum1 = Convert::ToInt16(pStr1);
		nNum2 = Convert::ToInt16(pStr2);
		//Get the operand from the Combo box
		pOp = cmbBox1->Text;

		//Check which operator (+,-,*,/) user has choosen
		if (pOp->CompareTo("+") == 0)
			nOp=1;
		else if (pOp->CompareTo("-") == 0)
			nOp=2;
		else if (pOp->CompareTo("*") == 0)
			nOp=3;
		else if (pOp->CompareTo("/") == 0)
			nOp=4;

		f->Close();
	}

	EventSource* pE = new EventSource;
	EventReceiver* pR = new EventReceiver;

	// Add event handlers
	if (nOp == 1)
		pE->E += new MyDelegate(pR, &EventReceiver::Add);
	else if (nOp == 2)
		pE->E += new MyDelegate(pR, &EventReceiver::Subtract);
	else if (nOp == 3)
		pE->E += new MyDelegate(pR, &EventReceiver::Multiply);
	else if (nOp == 4)
		pE->E += new MyDelegate(pR, &EventReceiver::Divide);

	// Raise events
	pE->Fire_E(nNum1, nNum2);
}

//Entry point
void main()
{
	Application::Run(new CMainWindow());
}
