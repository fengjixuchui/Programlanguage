#ifndef __GDIPLUS_H__
#define __GDIPLUS_H__

#using <mscorlib.dll>

#using <System.DLL>
#using <System.Drawing.DLL> 
#using <System.Windows.Forms.DLL>

using namespace System;
using namespace System::ComponentModel;
using namespace System::Windows::Forms;
using namespace System::Collections;
using namespace System::IO;
using namespace System::Drawing;
using namespace System::Drawing::Printing;

__gc class CGDIPlusDoc;  //Forward decleration

__gc class CMainWindow : public Form
{
public:
	CMainWindow();
	virtual ~CMainWindow();
	
	static int nDocCount;	// Keeps track of the opened doc count
	static CMainWindow* pParentWindow;

public:
	//Methods
	void EnableItems();
	void DisableItems();

private:
	void InitializeComponent();

	void MenuItemHandler(Object* sender, EventArgs* e);
	void ToolbarHandler(Object* sender, ToolBarButtonClickEventArgs* e);

	void AboutHelp();
	void HelpTopics();
	void Print();
	void PrintPage(Object* sender,PrintPageEventArgs* ev);	
	void PrintPreview();
	void Exit();

	void CloseView();
	void Tile();
	void Cascade();

	void ClearAll();  //Clear the contents

	void Open();
	void Save();
	void New();

	void NewWindow();

	void ThickLine();
	void PenWidthsDlg();

//START PSK
	void DrawLine();
	void DrawEllipse();
	void DrawRect();
	void DrawText();
	void DrawFilledEllipse();
	void DrawFilledRect();
	void HandleDelegate();
//END PSK

	CGDIPlusDoc* CreateDocument();

private:
	System::ComponentModel::Container* pComponents;
	PrintDocument* pPrintDoc;	
	HelpProvider* pHelpProvider;

	MenuItem* pFileMenuItem;	
	MenuItem* pEditMenuItem;
	MenuItem* pViewMenuItem;
	MenuItem* pPenMenuItem;
	MenuItem* pHelpMenuItem;
	MenuItem* pWindowMenuItem;
	MenuItem* pNewMenuItem;
	MenuItem* pOpenMenuItem;
	MenuItem* pCloseMenuItem;
	MenuItem* pSaveMenuItem;
	MenuItem* pSaveAsMenuItem;
	MenuItem* pPrintMenuItem;
	MenuItem* pPrintPreviewMenuItem;
	MenuItem* pExitMenuItem;
	MenuItem* pThickLineMenuItem;
	MenuItem* pNewWindowMenuItem;
	MenuItem* pCascadeMenuItem;
	MenuItem* pTileMenuItem;
	MenuItem* pClearAllMenuItem;
	MenuItem* pToolbarMenuItem;
	MenuItem* pStatusbarMenuItem;
	MenuItem* pHelpAboutMenuItem;
	MenuItem* pHelpTopicsMenuItem;
	MenuItem* pPenWidthMenuItem;

//PSK START
	MenuItem* pDrawMenuItem;	
	MenuItem* pDrawLine;
	MenuItem* pDrawEllipse;
	MenuItem* pDrawRect;
	MenuItem* pDrawText;
	MenuItem* pDrawFilledEllipse;
	MenuItem* pDrawFilledRect;
	MenuItem* pDelegateHandler;
//PSK END

	MainMenu* pMainMenu;
	MenuItem* pLine1MenuItem;
	MenuItem* pLine2MenuItem;
	MenuItem* pLine3MenuItem;
	
	//Toolbar
	ToolBar* pToolBar;
	StatusBar* pStatusBar;
	ImageList* pImageList;
	ToolBarButton* pHelpTBButton;
	ToolBarButton* pPrintTBButton;
	ToolBarButton* pPreviewTBButton;
	ToolBarButton* pSaveTBButton;
	ToolBarButton* pOpenTBButton;
	ToolBarButton* pNewTBButton;
};
#endif __GDIPLUS_H__