#ifndef __GDIPLUSDOC_H__
#define __GDIPLUSDOC_H__

#using <mscorlib.dll>

#using <System.DLL>
#using <System.Drawing.DLL> 
#using <System.Windows.Forms.DLL>
#using <System.Runtime.Remoting.DLL>

using namespace System;
using namespace System::Windows::Forms;
using namespace System::Collections;
using namespace System::IO;
using namespace System::Drawing;
using namespace System::Drawing::Printing;
using namespace System::Collections;
using namespace System::Runtime::Serialization;
using namespace System::Runtime::Serialization::Formatters::Binary ;

//Forward declaration of GDIPlusView to keep compiler happy

__gc class CGDIPlusView;

[Serializable] __gc  class CStroke 
{
public:
		 int nPenWidth;
		 ArrayList*	pPointArray;
		 Rectangle	rectBoundingRect;

		 CStroke(int nPenWidth1);
		 ~CStroke();
		 Rectangle GetBoundingRectangle() {return rectBoundingRect;}

		 void DrawStroke(Graphics* g);
		 void FinishStroke();		

		 int Min(int x,int y) {return (x < y) ? x : y;}
		 int Max(int x,int y) {return  (x > y) ? x : y ;}
};


//Document class
 __gc class CGDIPlusDoc
{
public:
	CGDIPlusDoc(CMainWindow* pMainWindow);
	~CGDIPlusDoc();

    void SaveDocument(String* pFileName);
	void OpenDocument(String* pFileName);
	
	Pen* GetCurrentPen();
	Brush* GetCurBrush();
	void ReplacePen();

	void UpdateAllViews(CGDIPlusView* pView, CStroke* newStroke);
	void DeleteContents();
	CStroke* NewStroke();

	ArrayList* strokeList ;
	ArrayList* viewList;

	bool bIsDirty;

	int nDocID; 

protected:
    UInt32 nPenWidth;
	Pen*  pCurrentPen;  
	SolidBrush* pCurrentBrush;  

public:
	bool bIsThickPen;
	UInt32 nThinWidth;
	UInt32 nThickWidth;	    

	//For drawing Ellipse & Rectangle
	UInt16 nShapeLeft;
	UInt16 nShapeTop;
	UInt16 nShapeWidth;
	UInt16 nShapeHeight;

};

#endif  __GDIPLUSDOC_H__