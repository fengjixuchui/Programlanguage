// This is the main DLL file.

#include "stdafx.h"

#include "ProcessOrder.h"

using namespace ProcessOrder;


//Method to add the new order to the order table
//In this example two separate commands are executed within the 
//context of a single transaction. When one fails the other is 
//rolled back. This can be checked by failing either of the database
//commands for example by providing an invalid connection string etc.

int Basket::updateBasket(String *strProdID,String *strCustID, String *strSessionID, String *strOrderDate, String *strOrderStatus)
{
	//Create a Connection object
SqlConnection *sConn=new SqlConnection();
	//Initialize and open the connection string
sConn->set_ConnectionString("Data Source=saik-d185;Initial Catalog=ArtShop;Integrated Security=SSPI");
sConn->Open(); 
SqlDataAdapter *dataAdapter=new SqlDataAdapter();
String *strCmd;
//try adding a new order into the order1 table
			try{
			
strCmd="insert into Order1(ProdId,CustId,SessionID,OrderDate,OrderStatus) values(";
strCmd=strCmd->Concat(strCmd,strProdID);
strCmd=strCmd->Concat(strCmd,",");
strCmd=strCmd->Concat(strCmd,strCustID);
strCmd=strCmd->Concat(strCmd,",'");
strCmd=strCmd->Concat(strCmd,strSessionID);
strCmd=strCmd->Concat(strCmd,"','");
strCmd=strCmd->Concat(strCmd,strOrderDate);
strCmd=strCmd->Concat(strCmd,"','");
strCmd=strCmd->Concat(strCmd,strOrderStatus);
strCmd=strCmd->Concat(strCmd,"')");


dataAdapter->UpdateCommand=new SqlCommand(NULL,sConn); 
dataAdapter->UpdateCommand->CommandText=strCmd; 
dataAdapter->UpdateCommand->ExecuteNonQuery();

			}
			catch(Exception *e)
			{
				Console::WriteLine(e->Message);  
				ContextUtil::SetAbort();
			}

//Update the status of the product in product table to 'sold'

SqlConnection *sConn2=new SqlConnection();
sConn2->set_ConnectionString("Data Source=saik-d185;Initial Catalog=ArtShop;Integrated Security=SSPI");
sConn2->Open(); 
SqlDataAdapter *dataAdapter2=new SqlDataAdapter();


try{

strCmd="Update Product set ProdStatus='Sold' where ProdID='";
strCmd=strCmd->Concat(strCmd,strProdID);
strCmd=strCmd->Concat(strCmd,"' and ProdStatus='unsold'  ");

dataAdapter2->UpdateCommand=new SqlCommand(NULL,sConn2); 
dataAdapter2->UpdateCommand->CommandText=strCmd; 
dataAdapter2->UpdateCommand->ExecuteNonQuery();

ContextUtil::SetComplete(); 
			}
			catch(Exception *e)
			{	
			Console::WriteLine(e->Message);  
			ContextUtil::SetAbort();
				return 1;
			}

return 0;
		}
