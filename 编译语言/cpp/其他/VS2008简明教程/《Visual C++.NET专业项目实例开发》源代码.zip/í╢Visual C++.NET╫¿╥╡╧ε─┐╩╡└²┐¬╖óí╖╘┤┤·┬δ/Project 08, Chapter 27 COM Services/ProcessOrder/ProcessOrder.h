//ProcessOrder.h
#using <System.dll>
#using <System.Data.dll>
#using <System.Enterpriseservices.dll>
#include <tchar.h>

using namespace System;
using System::String; 
using namespace System::Data;
using namespace System::EnterpriseServices;
using namespace System::Runtime::InteropServices; 
using namespace System::Data::SqlClient;
using System::EnterpriseServices::ServicedComponent;  
 
namespace ProcessOrder
{
	[Transaction(TransactionOption::Required)]

public __gc class Basket:public ServicedComponent
	{
		// TODO: Add your methods for this class here.
	public:
int updateBasket(String *strProdID,String *strCustID, String *strSessionID, String *strOrderDate, String *strOrderStatus);


	};
}
