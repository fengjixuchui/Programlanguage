#include "stdafx.h"
#include <tchar.h>

#using <mscorlib.dll>
#using <System.Runtime.Remoting.dll>
#using <RemoteObj.dll>

using namespace nsRemoting;

using namespace System;
using namespace System::Runtime::Remoting;
using namespace System::Runtime::Remoting::Channels;
using namespace System::Runtime::Remoting::Channels::Tcp;

// This is the entry point for this application
int _tmain(void)
{
	TcpChannel* pChannel2 = new TcpChannel(8085);
	ChannelServices::RegisterChannel(pChannel2);
	Type* pType = __typeof(nsRemoting::CQuizServer);
	RemotingConfiguration::RegisterWellKnownServiceType(pType, "Quiz", WellKnownObjectMode::SingleCall);
	Console::WriteLine("Please hit <ENTER> to exit...");
	Console::ReadLine();
	return 0;
}

