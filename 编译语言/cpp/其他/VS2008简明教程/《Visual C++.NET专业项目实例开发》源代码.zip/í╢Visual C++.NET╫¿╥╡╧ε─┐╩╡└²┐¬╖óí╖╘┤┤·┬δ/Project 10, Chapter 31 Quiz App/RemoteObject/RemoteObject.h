#pragma once

#include "stdafx.h"
using namespace System;

namespace nsRemoting
{
	public __gc class CQuizServer : public MarshalByRefObject
	{
	public:
		CQuizServer()
		{
		}

		~CQuizServer()
		{
		}

		String* DoWelcome(String* strName)
		{
			String* strTemp;
			strTemp = strName;
			strName = String::Concat(S"WELCOME ", strTemp);
			return strName;
		}

		//Sends the Questions to the client
		String* GetNextQuestion(int m_nNum)
		{
			String* pStrQ;
			switch(m_nNum)
			{
			case 1:
				pStrQ = "How many Continents are there in the world?";
				break;
			case 2:
				pStrQ = "How many States are there in United states of America?";
				break;
			case 3:
				pStrQ = "Which is the largest country in the world?";
				break;
			case 4:
				pStrQ = "In which state Golden Gate situated?";
				break;
			case 5:
				pStrQ = "Which is the largest planet of the solar system?";
				break;
			case 6:
				pStrQ = "Which planet is closet to the sun?";
				break;
			case 7:
				pStrQ = "Argentina is in which continent?";
				break;
			case 8:
				pStrQ = "What is the capital of India?";
				break;
			case 9:
				pStrQ = "What is the currency of Japan?";
				break;
			case 10:
				pStrQ = "Where is Effil Tower?";
				break;
			default:
				pStrQ = "?????";
				break;
			}

			return pStrQ;
		}

		//Sends the Question's all options to the client
		String* GetOptions(int nQNum, int nOption)
		{
			String* pstrOpt;
			switch(nQNum)
			{
			case 1:
				if (nOption == 1)
					pstrOpt = "6";
				else if (nOption == 2)
					pstrOpt = "5";
				else if (nOption == 3)
					pstrOpt = "7";
				break;
			case 2:
				if (nOption == 1)
					pstrOpt = "55";
				else if (nOption == 2)
					pstrOpt = "50";
				else if (nOption == 3)
					pstrOpt = "52";
				break;
			case 3:
				if (nOption == 1)
					pstrOpt = "Russia";
				else if (nOption == 2)
					pstrOpt = "India";
				else if (nOption == 3)
					pstrOpt = "China";
				break;
			case 4:
				if (nOption == 1)
					pstrOpt = "California";
				else if (nOption == 2)
					pstrOpt = "New York";
				else if (nOption == 3)
					pstrOpt = "Arizona";
				break;
			case 5:
				if (nOption == 1)
					pstrOpt = "Mars";
				else if (nOption == 2)
					pstrOpt = "Saturn";
				else if (nOption == 3)
					pstrOpt = "Jupiter";
				break;
			case 6:
				if (nOption == 1)
					pstrOpt = "Mars";
				else if (nOption == 2)
					pstrOpt = "Mercury";
				else if (nOption == 3)
					pstrOpt = "Earth";
				break;
			case 7:
				if (nOption == 1)
					pstrOpt = "North America";
				else if (nOption == 2)
					pstrOpt = "South America";
				else if (nOption == 3)
					pstrOpt = "Europe";
				break;
			case 8:
				if (nOption == 1)
					pstrOpt = "New Delhi";
				else if (nOption == 2)
					pstrOpt = "Bombay";
				else if (nOption == 3)
					pstrOpt = "Calcutta";
				break;
			case 9:
				if (nOption == 1)
					pstrOpt = "Dollar";
				else if (nOption == 2)
					pstrOpt = "Yuwan";
				else if (nOption == 3)
					pstrOpt = "Yen";
				break;
			case 10:
				if (nOption == 1)
					pstrOpt = "Germany";
				else if (nOption == 2)
					pstrOpt = "France";
				else if (nOption == 3)
					pstrOpt = "England";
				break;
			default:
				if (nOption == 1)
					pstrOpt = "000";
				else if (nOption == 2)
					pstrOpt = "000";
				else if (nOption == 3)
					pstrOpt = "000";
				break;
			}

			return pstrOpt;
		}

		//Sends the correct answer to the client
		int GetAnswer(int nNum)
		{
			int nAnswer;
			switch(nNum)
			{
			case 1:
				nAnswer = 3;
				break;
			case 2:
				nAnswer = 3;
				break;
			case 3:
				nAnswer = 1;
				break;
			case 4:
				nAnswer = 1;
				break;
			case 5:
				nAnswer = 3;
				break;
			case 6:
				nAnswer = 2;
				break;
			case 7:
				nAnswer = 2;
				break;
			case 8:
				nAnswer = 1;
				break;
			case 9:
				nAnswer = 3;
				break;
			case 10:
				nAnswer = 2;
				break;
			default:
				nAnswer = -1;
				break;
			}
			return nAnswer;
		}
	};
}
