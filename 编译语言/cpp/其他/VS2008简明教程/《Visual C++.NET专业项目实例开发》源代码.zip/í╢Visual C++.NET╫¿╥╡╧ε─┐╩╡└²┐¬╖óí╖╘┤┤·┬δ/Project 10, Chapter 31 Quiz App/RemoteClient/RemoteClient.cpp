// This is the main project file for VC++ application project 
// generated using an Application Wizard.

#include "stdafx.h"
#include <tchar.h>

#using <mscorlib.dll>
#using <System.dll>
#using <System.Windows.Forms.dll>
#using <System.Drawing.dll>
#using <System.Runtime.Remoting.dll>
#using "RemoteObj.dll"

using namespace System;
using namespace System::Runtime::Remoting;
using namespace System::Runtime::Remoting::Channels;
using namespace System::Runtime::Remoting::Channels::Tcp;
using namespace System::Threading;
using namespace System::ComponentModel; 
using namespace System::Windows::Forms; 
using namespace System::Drawing;
using namespace nsRemoting;

//////////////////////////////////////////////////
//Quiz Form Class
__gc class CQuizForm : public Form 
{ 
private:
	String* pCaption;	// Caption of the CQuizForm
	int	nWidth;			// Width of the CQuizForm
	int	nHeight;		// height of the CQuizForm

	Label* pLblQuestion;
	Label* pLblQNum;

	RadioButton* pRadioOpt1;
	RadioButton* pRadioOpt2;
	RadioButton* pRadioOpt3;

	Button *pBtnSubmit;
	Button *pBtnExit;

	//TcpChannel* m_pChannel;
	CQuizServer* m_pQuizServer;
	int m_nQNum;
	int m_nCorrect;

	bool bButttonReset;
	String* m_pUserName;
	
public: 
	CQuizForm()
	{
		pCaption = "Quiz Dialog";
		nWidth = 300;
		nHeight = 240;

		bButttonReset = false;
		m_nQNum = 1;
		m_nCorrect = 0;

		//Registers the channel for communication with Server
		//RegisterChannel();
		m_pQuizServer = (CQuizServer*) Activator::GetObject(__typeof(nsRemoting::CQuizServer), "tcp://localhost:8085/Quiz");;

		//Do the intialization
		InitForm();
	}

	void ~CQuizForm() 
	{ 
		// Form is being destroyed. Do any necessary cleanup here. 
		Form::Dispose(); 
	}

	void InitForm()
	{
		// Basic WinForm Settings
		Text = pCaption;
		Size = Drawing::Size(nWidth, nHeight);
		set_MaximizeBox(false);

		pLblQNum = new Label();
		pLblQNum->Text = "Question No. 1";
		pLblQNum->Size = Drawing::Size(100, 15);
		pLblQNum->BorderStyle = BorderStyle::FixedSingle;
		pLblQNum->Location = Drawing::Point(15, 15);
		pLblQNum->set_ForeColor(Color::Red);

		pLblQuestion = new Label();
		pLblQuestion->Text="Question appears here ";
		pLblQuestion->Size = Drawing::Size(260, 40);
		pLblQuestion->BorderStyle = BorderStyle::FixedSingle;
		pLblQuestion->Location = Drawing::Point(15, 40);
		pLblQuestion->set_TextAlign(ContentAlignment::MiddleCenter);
		pLblQuestion->set_ForeColor(Color::Blue);

		pRadioOpt1 = new RadioButton();
		pRadioOpt1->Text = "Option1";
		pRadioOpt1->TabIndex = 1;
		pRadioOpt1->Size = Drawing::Size(250, 20);
		pRadioOpt1->Location = Drawing::Point(30, 90);
		pRadioOpt1->Visible = false;

		pRadioOpt2 = new RadioButton();
		pRadioOpt2->Text = "Option2";
		pRadioOpt2->TabIndex = 2;
		pRadioOpt2->Size = Drawing::Size(250, 20);
		pRadioOpt2->Location = Drawing::Point(30, 115);
		pRadioOpt2->Visible = false;

		pRadioOpt3 = new RadioButton();
		pRadioOpt3->Text = "Option3";
		pRadioOpt3->TabIndex = 3;
		pRadioOpt3->Size = Drawing::Size(250, 20);
		pRadioOpt3->Location = Drawing::Point(30, 140);
		pRadioOpt3->Visible = false;

		pBtnSubmit = new Button();
		pBtnSubmit->Text = "&Start";
		pBtnSubmit->TabIndex = 4;
		pBtnSubmit->Size = Drawing::Size(55, 20);
		pBtnSubmit->Location = Drawing::Point(80, 180);
		pBtnSubmit->Click += (new EventHandler(this, &CQuizForm::OnSubmitButtonClick));

		pBtnExit = new Button();
		pBtnExit->Text = "E&xit";
		pBtnExit->TabIndex = 5;
		pBtnExit->Size = Drawing::Size(55, 20);
		pBtnExit->Location = Drawing::Point(165, 180);
		pBtnExit->Click += (new EventHandler(this, &CQuizForm::OnExitButtonClick));

		Controls->Add(pLblQNum);
		Controls->Add(pLblQuestion);
		Controls->Add(pRadioOpt1);
		Controls->Add(pRadioOpt2);
		Controls->Add(pRadioOpt3);
		Controls->Add(pBtnSubmit);
		Controls->Add(pBtnExit);

		//Set the pBtnSubmit as the default
		Form::set_AcceptButton(pBtnSubmit);
		pLblQNum->Visible = false;

		//Display he welcome message
		String* pstrWelcome = m_pQuizServer->DoWelcome(" BUDDY!");
		pstrWelcome = String::Concat(pstrWelcome, "\nPlease press Start button to start the Quiz.");
		pLblQuestion->Text = pstrWelcome;
	}
/*
	void RegisterChannel()
	{
		m_pChannel = new TcpChannel();
		ChannelServices::RegisterChannel(m_pChannel);
	}
*/	
	//Handles the Next button
	void OnSubmitButtonClick (Object *sender, EventArgs *e)
	{
		if (!bButttonReset)
		{
			pBtnSubmit->Text = "&Submit";
			pLblQNum->Visible = true;
			pLblQNum->set_TextAlign(ContentAlignment::MiddleLeft);
		}

		if (pRadioOpt1->get_Visible())
		{
			int nResult = m_pQuizServer->GetAnswer(m_nQNum - 1);
			bool bCorrect = false;
			switch(nResult)
			{
			case 1:
				if (pRadioOpt1->get_Checked())
					bCorrect = true;
				break;
			case 2:
				if (pRadioOpt2->get_Checked())
					bCorrect = true;
				break;
			case 3:
				if (pRadioOpt3->get_Checked())
					bCorrect = true;
				break;
			}
			
			if ( bCorrect )
			{
				MessageBox::Show("Correct Answer", "Result");
				m_nCorrect++;
			}
			else
			{
				MessageBox::Show("Incorrect Answer", "Result");
			}
		}

		if (!bButttonReset)
		{
			bButttonReset = true;
			pRadioOpt1->Visible = true;
			pRadioOpt2->Visible = true;
			pRadioOpt3->Visible = true;
		}

		if (m_nQNum > 10)
		{
			//It's only a 10 questions Quiz
			String* pStrTemp;
			pStrTemp = "Your score is ";
			if (m_nCorrect < 5)
				pStrTemp = String::Concat(pStrTemp, m_nCorrect.ToString(), " out of 10. ", "\nYou need to improve your GK.");
			else if (m_nCorrect > 5 && m_nCorrect < 7)
				pStrTemp = String::Concat(pStrTemp, m_nCorrect.ToString(), " out of 10. ", "\nGood work!");
			else
				pStrTemp = String::Concat(pStrTemp, m_nCorrect.ToString(), " out of 10. ", "\nExcellent job!");
			MessageBox::Show(pStrTemp, "Score");
			m_nQNum = 1;
			m_nCorrect = 0;

			bButttonReset = false;
			pBtnSubmit->Text = "&Start";
			pLblQNum->Visible = false;
			pRadioOpt1->Visible = false;
			pRadioOpt2->Visible = false;
			pRadioOpt3->Visible = false;

			String* pstrWelcome = m_pQuizServer->DoWelcome(" BUDDY!");
			pstrWelcome = String::Concat(pstrWelcome, "\nPlease press Start button to start the Quiz.");
			pLblQuestion->Text = pstrWelcome;

			return;
		}

		//Uncheck all the radio buttons for the next question
		pRadioOpt1->set_Checked(false);
		pRadioOpt2->set_Checked(false);
		pRadioOpt3->set_Checked(false);

		// Check for the Answer - Correct or not
		String* pStrTemp;
		pStrTemp = "Question No. ";
		pStrTemp = String::Concat(pStrTemp, m_nQNum.ToString());
		pLblQNum->Text = pStrTemp;

		//Query For Next Question from the server
		String* pstrQuestion = m_pQuizServer->GetNextQuestion(m_nQNum);
		pLblQuestion->Text = pstrQuestion;

		for (int i=1; i<4; i++)
		{
			String* pstrOpt = m_pQuizServer->GetOptions(m_nQNum, i);
			if (i == 1)
				pRadioOpt1->Text = pstrOpt;
			else if (i == 2)
				pRadioOpt2->Text = pstrOpt;
			else if (i == 3)
				pRadioOpt3->Text = pstrOpt;
		}
		
		m_nQNum++;
	}

	//Handles the Exit button
	void OnExitButtonClick(Object *sender, EventArgs *e)
	{
		Close();
	}
};

// This is the entry point for this application
int _tmain(void)
{
    // TODO: Please replace the sample code below with your own.
    Application::Run(new CQuizForm()); 
    return 0;
}

