create database Banking
GO
use banking
GO
print 'Creating table Account_Detail'
create table Account_Detail
(
   Account_Number int IDENTITY (10000,1) not null primary key,
   First_Name varchar(30) not null,
   Last_Name varchar(30) not null,
   date_birth varchar(10) not null,
   Permanent_Addr varchar(50) not null,
   Mailing_Addr varchar(50) not null,
   Phone_Number  varchar(15) not null,
   eMailID varchar(30) null,
   Type_account char(1) not null,
   Balance float not null,
   Valid_Acc char(2) not null,
   Ref_Acc_No int not null
)
go
insert Account_Detail
values('Masine','Philip','09/09/72','Street V Opp. Great Circle','Bldg-11, Avenue 2','91-20392012','mph@pinc.com','S',800,'VA',0)
go
print 'Creating table BankLogin'
create table BankLogin
(
  UserNm varchar(5) not null,
  Pwd varchar(15) not null
)
go
insert BankLogin
values('S103','password')
go