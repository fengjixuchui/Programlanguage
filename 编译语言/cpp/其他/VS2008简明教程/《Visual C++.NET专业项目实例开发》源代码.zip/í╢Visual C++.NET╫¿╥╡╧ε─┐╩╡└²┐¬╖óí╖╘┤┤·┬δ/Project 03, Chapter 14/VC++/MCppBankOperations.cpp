// This is the main project file for VC++ application project 
// generated using an Application Wizard.

// NOTE: This project is to demo the usage of various ADO.net
// classes in a managed C++ extension project

#include "stdafx.h"

// include all the required .NET DLLs
#using <mscorlib.dll>
#using <System.dll>
#using <System.Windows.Forms.dll>
#using <System.Drawing.dll>
#using "System.Data.dll"
#using "System.Xml.dll"

#include <tchar.h>

// Also specify the required namespaces
using namespace System;
using namespace System::ComponentModel; 
using namespace System::Windows::Forms; 
using namespace System::Drawing;
using namespace System::Data;
using namespace System::Data::SqlClient;
using namespace System::Xml;


// Main Class to show the login form
// this is a .net class so it is __gc prefixed

__gc class LoginForm: public Form 
{ 

// all private variables to take care of the form and control display
private:

	String		*caption;	// Caption of the WinForm
	int			width;		// width of the WinForm
	int			height;		// height of the WinForm

	TextBox     *loginid;
	TextBox		*pwd;
	Label		*lglabel;
	Label		*pwdlabel;

    Button		*submitbutton;
	Button		*cancelbutton;

	//HACK Made changes here
	ErrorProvider *error;

	int totallogincount;

public: 
	LoginForm()
	{
		caption = "Login form";
		width = 280;
		height = 180;
		LoginControls();
		totallogincount= 0;
	}
	void ~LoginForm() 
	{ 
	// Form is being destroyed. Do any necessary cleanup here. 
		
	}

	void LoginControls()
	{
		// Basic WinForm Settings
		Text = caption;
		Size = Drawing::Size(width, height);

		// Setup Login edit box  -- similarly we will password box
		loginid = new TextBox();
		loginid->Name="loginid";
		loginid->Size = Drawing::Size(120, 40);		
		loginid->TabIndex = 0;
		loginid->Location = Drawing::Point(width/2-5, height - 160);
		Controls->Add(loginid);

		// the following is to create and setup the password editbox
		pwd = new TextBox();
		pwd->Name="pwd";
		pwd->PasswordChar = '*';
		pwd->Size = Drawing::Size(120, 40);		
		pwd->TabIndex = 1;
		pwd->Location = Drawing::Point(width/2-5, height - 120);
		Controls->Add(pwd);

		// to put the labels
		lglabel = new Label();
		lglabel->Text="Login id";
		lglabel->Size = Drawing::Size(90, 20);		
		lglabel->Location = Drawing::Point(width/2-90, height - 160);
		Controls->Add(lglabel);

		// to put the labels
		pwdlabel = new Label();
		pwdlabel->Text="Password";
		pwdlabel->Size = Drawing::Size(90, 20);		
		pwdlabel->Location = Drawing::Point(width/2-90, height - 120);
		Controls->Add(pwdlabel);

		// The following code creates the buttons
		submitbutton = new Button();
		submitbutton->Text = "&Submit";
		submitbutton->Size = Drawing::Size(90, 30);
		submitbutton->TabIndex = 2;
		submitbutton->Location = Drawing::Point(width/2-100, height - 70);
		submitbutton->Click += (new EventHandler(this, &LoginForm::OnSubmitButtonClick));
		Controls->Add(submitbutton);

		// The following code creates the cancel button
		cancelbutton = new Button();
		cancelbutton->Text = "&Cancel";
		cancelbutton->Size = Drawing::Size(90, 30);
		cancelbutton->TabIndex = 3;
		cancelbutton->Location = Drawing::Point(width/2+10, height - 70);
		cancelbutton->Click += (new EventHandler(this, &LoginForm::OnCancelButtonClick));
		Controls->Add(cancelbutton);

		//HACK Made changes here
		//create the error provider control
		error=new ErrorProvider();
		error->BlinkRate=250;
		error->BlinkStyle=ErrorBlinkStyle::BlinkIfDifferentError;
    }

	// This function is called when the submit button is clicked
	void OnSubmitButtonClick(Object *sender, EventArgs *e) 
	{
	//HACK Made changes here
		if (loginid->Text->get_Length()==0)
		{
			error->SetError(loginid,"Invalid login name");
			return;
		}
		else
			error->SetError(loginid,"");
		if (pwd->Text->get_Length()==0)
		{
			error->SetError(pwd,"Invalid password");
			return;
		}
		else
			error->SetError(pwd,"");
		// user id and password
	String *userId = "sa";
	String *password = "";	

	// Connect to the SQL Database and issue a SELECT command all in one statement
	String *query = String::Format(S"SELECT * FROM BankLogin where usernm = '{0}' and pwd='{1}'",loginid->Text,pwd->Text);

	// build connect string with the userid and password
	String *connectString = String::Format(S"Data Source=localhost;Database=Banking;UID={0};Password={1};", userId, password);

	//You can use this format if you are connecting with a known user name and password,
	// however it is not recommended to store these in the source for security reasons
	
	// Create the SQL Connection object and pass it the connection string
	SqlConnection* sqlconn = new SqlConnection(connectString);
	
	// Open the connection
	sqlconn->Open();
	
	// Create the SQL Command to store the select query
	SqlCommand *sqlCommand = new SqlCommand(query, sqlconn);

	// Create a SqlDataReader to enumerate the result of executing the command against the database.
	SqlDataReader *dataReader = sqlCommand->ExecuteReader();
	
	// Always call Read before accessing data.
	int numrows = 0;

	// Find out if there was a record existing with that user name
	// and password - if yes then increase the numrows
	while (dataReader->Read()) 
	{
	numrows = numrows + 1;
	}

	// check if any rows were selected
	if(numrows == 0)
	{
		MessageBox::Show("Invalid login name or password. Please try again.");
		loginid->Text="";
		pwd->Text="";
		loginid->Focus();
		totallogincount = totallogincount + 1;
		if(totallogincount==3)
		{
		// No row found - hence invalid login
		// close the application after 3 tries are done.
			MessageBox::Show("You have exhausted your login attempts. The application will now close");
			Close();
			Application::Exit();
		}
	}
	else
	{
		dataReader->Close();
		sqlconn->Close();
		LoginForm::Dispose();
	}
	}

	// closes the application
	void OnCancelButtonClick(Object *sender, EventArgs *e) 
	{
		Close();
		Application::Exit();
	}
};

///////****************************************/////////

// Base class to denote the BankForm - the main application form

__gc class BankForm: public Form 
{ 

	// all variable declerations to initialize the various 
	// controls that are to be displayed on the form
private:
	StatusBar	*statusBar;

	Button		*prevbutton;
	Button		*nextbutton;
	Button		*firstbutton;
	Button		*lastbutton;
	Button		*insertrecord;
	Button		*updaterecord;
	Button		*clearfields;

	MainMenu	*mainMenu;
	MenuItem	*fileMenu;
	MenuItem	*recordmenu;
	MenuItem	*operatemenu;
	MenuItem	*helpmenu;

	LoginForm	*lgform;

	TextBox		*acno;
	TextBox		*fname;
	TextBox		*lname;
	TextBox		*dob;
	TextBox		*paddr;
	TextBox		*maddr;
	TextBox		*phno;
	TextBox		*emailid;
	TextBox		*refacno;
	TextBox		*amount;
	TextBox		*va;
	TextBox		*typeac;

	Label		*heading;

	//HACK Made changes here
	ErrorProvider *error;
	bool flag;

	String		*caption;	// Caption of the WinForm
	int			width;		// width of the WinForm
	int			height;		// height of the WinForm

	// a global variable to store the reference to the DataSet
	// this data set will be used across the application - once it 
	// has been populated
    DataSet *ds;

	// Create a SqlDataAdapter.
	SqlDataAdapter* myAdapter;

	// variable to store the number of the total records in the dataset at any point
	int lastrow;

	// a global variable to store which is the current record no.
	int currentrec;

public: 
	BankForm()
	{
		//HACK Made changes here
		//create the error provider control
		error=new ErrorProvider();
		error->BlinkRate=250;
		error->BlinkStyle=ErrorBlinkStyle::BlinkIfDifferentError;

		flag=false;

		caption = "Bank Operations";
		
		width = 600;
		height = 400;
		// the following code - calls the login form to be displayed
		// in a dialog mode and based on the result of the action
		// either exit the applicaiton or continue

		lgform = new LoginForm();

		if(lgform->ShowDialog(this) == 1)
		{
		}
		lgform->Dispose();

		// call the function to create all the controls on the 
		// bankform
		CreateControls();

		currentrec = 0;
		
		// Call the function to fetch the data from the database
		// put it into a Dataset and also populate the fields with
		// the first row that has been fetched
		FetchData();

	}
	void ~BankForm() 
	{ 
		// Form is being destroyed. Do any necessary cleanup here. 
		Form::Dispose(); 
	} 

	/** Function to create the Controls **/
	void CreateControls()
	{
		//create controls here
		
// FOR EACH CONTROL - the size, location etc. are set
		// also specified are the function handlers for buttons
		// and menu item controls

		// Basic WinForm Settings
		Text = caption;
		Size = Drawing::Size(width, height);

		// Setup Menu
		mainMenu = new MainMenu();
		fileMenu = new MenuItem("&File");
		mainMenu->MenuItems->Add(fileMenu);
		fileMenu->MenuItems->Add(new MenuItem("E&xit", new EventHandler(this, &BankForm::OnFileExit)));

		// create the records menu
		recordmenu = new MenuItem("&Record");
		mainMenu->MenuItems->Add(recordmenu);
		recordmenu->MenuItems->Add(new MenuItem("&First Record", new EventHandler(this, &BankForm::OnFirstRecord)));
		recordmenu->MenuItems->Add(new MenuItem("&Prev Record", new EventHandler(this, &BankForm::OnPrevRecord)));
		recordmenu->MenuItems->Add(new MenuItem("&Next Record", new EventHandler(this, &BankForm::OnNextRecord)));
		recordmenu->MenuItems->Add(new MenuItem("&Last Record", new EventHandler(this, &BankForm::OnLastRecord)));
		
		// create the Operation menu
		operatemenu = new MenuItem("Operate");
		mainMenu->MenuItems->Add(operatemenu);
		operatemenu->MenuItems->Add(new MenuItem("&Insert New Record", new EventHandler(this, &BankForm::OnInsertRecord)));
		operatemenu->MenuItems->Add(new MenuItem("&Update Current Record", new EventHandler(this, &BankForm::OnUpdateRecord)));

		Menu = mainMenu;

		// Set status bar
		statusBar = new StatusBar();
		statusBar->Text = "This is the Managed C++ based Bank Application developed by Vineet Arora";
		Controls->Add(statusBar);
		
		// Setup first Record Button -- similarly we will create other buttons
		firstbutton = new Button();
		firstbutton->Text = "&<< First";
		firstbutton->Size = Drawing::Size(75, 30);
		firstbutton->TabIndex = 0;
		firstbutton->Location = Drawing::Point(width/2-180, height - 160);
		firstbutton->Click += (new EventHandler(this, &BankForm::OnFirstRecord));
		Controls->Add(firstbutton);

		// Setup Prev Record Button -- similarly we will create other buttons
		prevbutton = new Button();
		prevbutton->Text = "&< Prev";
		prevbutton->Size = Drawing::Size(75, 30);
		prevbutton->TabIndex = 0;
		prevbutton->Location = Drawing::Point(width/2-80, height - 160);
		prevbutton->Click += (new EventHandler(this, &BankForm::OnPrevRecord));
		Controls->Add(prevbutton);

		// Setup Next Record Button -- similarly we will create other buttons
		nextbutton = new Button();
		nextbutton->Text = "& Next >";
		nextbutton->Size = Drawing::Size(75, 30);
		nextbutton->TabIndex = 0;
		nextbutton->Location = Drawing::Point(width/2+20, height - 160);
		nextbutton->Click += (new EventHandler(this, &BankForm::OnNextRecord));
		Controls->Add(nextbutton);

		// Setup last Record Button -- similarly we will create other buttons
		lastbutton = new Button();
		lastbutton->Text = "&Last >>";
		lastbutton->Size = Drawing::Size(75, 30);
		lastbutton->TabIndex = 0;
		lastbutton->Location = Drawing::Point(width/2+120, height - 160);
		lastbutton->Click += (new EventHandler(this, &BankForm::OnLastRecord));
		Controls->Add(lastbutton);

		// The following various pieces of code create the labels
		// and the corresponding edit box for the fields data to 
		// be displayed on the form

		heading = new Label();
		heading->Text="First Name";
		heading->Size = Drawing::Size(100, 20);		
		heading->Location = Drawing::Point(width/2-240, height - 360);
		Controls->Add(heading);

		fname = new TextBox();
		fname->Name="fname";
		fname->Size = Drawing::Size(150, 40);		
		fname->TabIndex = 2;
		fname->Location = Drawing::Point(width/2-120, height - 360);
		Controls->Add(fname);

		heading = new Label();
		heading->Text="Last Name";
		heading->Size = Drawing::Size(100, 20);		
		heading->Location = Drawing::Point(width/2-240, height - 340);
		Controls->Add(heading);

		lname = new TextBox();
		lname->Name="lname";
		lname->Size = Drawing::Size(150, 20);		
		lname->TabIndex = 2;
		lname->Location = Drawing::Point(width/2-120, height - 340);
		Controls->Add(lname);
		
		heading = new Label();
		heading->Text="Date of Birth";
		heading->Size = Drawing::Size(100, 20);		
		heading->Location = Drawing::Point(width/2-240, height - 320);
		Controls->Add(heading);

		dob = new TextBox();
		dob->Name="dob";
		dob->Size = Drawing::Size(150, 40);		
		dob->TabIndex = 2;
		dob->Location = Drawing::Point(width/2-120, height - 320);
		Controls->Add(dob);

		heading = new Label();
		heading->Text="Permanent Address";
		heading->Size = Drawing::Size(120, 20);		
		heading->Location = Drawing::Point(width/2-240, height - 300);
		Controls->Add(heading);

		paddr = new TextBox();
		paddr->Name="paddr";
		paddr->Size = Drawing::Size(150, 40);		
		paddr->TabIndex = 2;
		paddr->Location = Drawing::Point(width/2-120, height - 300);
		Controls->Add(paddr);

		heading = new Label();
		heading->Text="Mailing Address";
		heading->Size = Drawing::Size(100, 20);		
		heading->Location = Drawing::Point(width/2-240, height - 280);
		Controls->Add(heading);

		maddr = new TextBox();
		maddr->Name="maddr";
		maddr->Size = Drawing::Size(150, 40);		
		maddr->TabIndex = 2;
		maddr->Location = Drawing::Point(width/2-120, height - 280);
		Controls->Add(maddr);

		heading = new Label();
		heading->Text="Phone No:";
		heading->Size = Drawing::Size(100, 20);		
		heading->Location = Drawing::Point(width/2-240, height - 260);
		Controls->Add(heading);

		phno = new TextBox();
		phno->Name="phno";
		phno->Size = Drawing::Size(150, 40);		
		phno->TabIndex = 2;
		phno->Location = Drawing::Point(width/2-120, height - 260);
		Controls->Add(phno);

		heading = new Label();
		heading->Text="Email id:";
		heading->Size = Drawing::Size(100, 20);		
		heading->Location = Drawing::Point(width/2-240, height - 240);
		Controls->Add(heading);

		emailid = new TextBox();
		emailid->Name="emailid";
		emailid->Size = Drawing::Size(150, 40);		
		emailid->TabIndex = 2;
		emailid->Location = Drawing::Point(width/2-120, height - 240);
		Controls->Add(emailid);

		heading = new Label();
		heading->Text="Referal A/C no:";
		heading->Size = Drawing::Size(100, 20);		
		heading->Location = Drawing::Point(width/2-240, height - 220);
		Controls->Add(heading);

		refacno = new TextBox();
		refacno->Name="refacno";
		refacno->Size = Drawing::Size(150, 40);		
		refacno->TabIndex = 2;
		refacno->Location = Drawing::Point(width/2-120, height - 220);
		Controls->Add(refacno);

		heading = new Label();
		heading->Text="Amount:";
		heading->Size = Drawing::Size(50, 40);		
		heading->Location = Drawing::Point(width/2+40, height - 360);
		Controls->Add(heading);

		amount = new TextBox();
		amount->Name="amt";
		amount->Size = Drawing::Size(80, 40);		
		amount->TabIndex = 2;
		amount->Location = Drawing::Point(width/2+100, height - 360);
		Controls->Add(amount);

		// These are some of the hidden fields to store the values
		// that are required in the table but are not modified by
		// the user
		va = new TextBox();
		va->Name="validacc";
		va->Text="VA";
		va->Visible = false;		
		Controls->Add(va);

		typeac = new TextBox();
		typeac->Name="typeofacc";
		typeac->Text="S";
		typeac->Visible = false;		
		Controls->Add(typeac);

		// application heading
		heading = new Label();
		heading->Text="SaveMyMoneyBank Application";
		heading->Size = Drawing::Size(180, 50);		
		heading->Location = Drawing::Point(width/2-80, height - 380);
		Controls->Add(heading);

		// Setup Clear fields button
		clearfields = new Button();
		clearfields->Text = "Clear Fields";
		clearfields->Size = Drawing::Size(100, 30);
		clearfields->TabIndex = 0;
		clearfields->Location = Drawing::Point(width/2+80, height - 320);
		clearfields->Click += (new EventHandler(this, &BankForm::OnClearFields));
		Controls->Add(clearfields);

		// Setup Insert record button
		insertrecord = new Button();
		insertrecord->Text = "Insert New Record";
		insertrecord->Size = Drawing::Size(100, 30);
		insertrecord->TabIndex = 0;
		insertrecord->Location = Drawing::Point(width/2+80, height - 280);
		insertrecord->Click += (new EventHandler(this, &BankForm::OnInsertRecord));
		Controls->Add(insertrecord);

		// Setup the Update record button 
		updaterecord = new Button();
		updaterecord->Text = "Update Current Record";
		updaterecord->Size = Drawing::Size(100, 30);
		updaterecord->TabIndex = 0;
		updaterecord->Location = Drawing::Point(width/2+80, height - 240);
		updaterecord->Click += (new EventHandler(this, &BankForm::OnUpdateRecord));
		Controls->Add(updaterecord);

	}
	
	// function to handle the clear fields button click
	void OnClearFields(Object *sender, EventArgs *e) 
	{
		ClearForm();
	}

	// The following function is called on insert record click
	// make sure to click the clearfields button, enter values and
	// then click on this button

	void OnInsertRecord(Object *sender, EventArgs *e) 
	{
	    
		if (flag==false)
		{
			ClearForm();
			flag=true;
			insertrecord->Text="Submit";
			return;
		}
		if (ValidateForm()==true)
		{
		flag=false;
		insertrecord->Text="Insert New Record";
		DataRow *dr;
		// create a new datarow object
		dr = ds->get_Tables()->get_Item(0)->NewRow(); 
		
		// fill each Datarow field with the values on the form

		dr->set_Item("First_name", fname->Text->ToString());
		dr->set_Item("Last_name",lname->Text->ToString());
		dr->set_Item("date_birth",dob->Text->ToString());
		dr->set_Item("Permanent_Addr",paddr->Text->ToString());
		dr->set_Item("Mailing_Addr",maddr->Text->ToString());
		dr->set_Item("Phone_Number",phno->Text->ToString());
		dr->set_Item("eMailID",emailid->Text->ToString());
		dr->set_Item("Ref_Acc_no",refacno->Text);
		dr->set_Item("Balance",amount->Text);

		// random account number generation 
		// this can be replaced by some logic
		dr->set_Item("Account_number",amount->Text);

		// default values picked up for update requirements
		dr->set_Item("Type_account",typeac->Text);
		dr->set_Item("Valid_acc",va->Text);
		//dr->set_Item("curr_date",dob->Text->ToString());

		// add the row to the data set
		ds->get_Tables()->get_Item(0)->get_Rows()->Add(dr);
		
		// use the update method of the adapter to update the 
		// database from the contents of the dataset.
		// this can also be called later at any point
		myAdapter->Update(ds,"Account_Detail");

		// the following function is to refresh the form with the latest data
		FetchData();
		MessageBox::Show("Record added successfully.");
		}
	}
	
	// when the current record is displayed
	// the user changes any field and clicks on the update button
	// this function will ensure that it is updated in the database 

	void OnUpdateRecord(Object *sender, EventArgs *e) 
	{
		if (ValidateForm()==true)
		{
	  DataTable *dtab = new DataTable();
	  DataRow *dr;

	  // set an alias for the data table collections
      dtab = ds->get_Tables()->get_Item(0);
	
	  //set an alias for the data row collections for the current row
	  dr = dtab->get_Rows()->get_Item(currentrec);

	// fill each Datarow members with the latest values
		dr->set_Item("First_name", fname->Text->ToString());
		dr->set_Item("Last_name",lname->Text->ToString());
		dr->set_Item("date_birth",dob->Text->ToString());
		dr->set_Item("Permanent_Addr",paddr->Text->ToString());
		dr->set_Item("Mailing_Addr",maddr->Text->ToString());
		dr->set_Item("Phone_Number",phno->Text->ToString());
		dr->set_Item("eMailID",emailid->Text->ToString());
		dr->set_Item("Ref_Acc_no",refacno->Text);
		dr->set_Item("Balance",amount->Text);

		// random account number generation 
		// this can be replaced by some logic
		dr->set_Item("Account_number",amount->Text);

		// default values picked up for update requirements
		dr->set_Item("Type_account",typeac->Text);
		dr->set_Item("Valid_acc",va->Text);
//		dr->set_Item("curr_date",dob->Text->ToString());
	
		// use the update method of the adapter to update the 
		// database from the contents of the dataset.
		// this can also be called later at any point
		myAdapter->Update(ds,"Account_Detail");

		// the following function is to refresh the form with the latest data
		FetchData();
		MessageBox::Show("Record updated successfully.");
		}
	}
	
/** close the application **/
	void OnFileExit(Object *sender, EventArgs *e) 
	{
		Close();
	}

	void OnFirstRecord(Object *sender, EventArgs *e)
	{
	// call the functions to fill the fields with the records
	// passing 0 is for the first row
	  FillFields(0);
	  currentrec = 0;
	}

	void OnPrevRecord(Object *sender, EventArgs *e)
	{
	// call the functions to fill the fields with the records
	// pass current record - 1 for the prev row
	  if(currentrec != 0)
	  {
		  FillFields(currentrec-1);
		  currentrec = currentrec-1;
	  }
	}

	void OnNextRecord(Object *sender, EventArgs *e)
	{
	// call the functions to fill the fields with the records
    lastrow = (ds->get_Tables()->get_Item(0)->get_Rows()->get_Count() - 1);

	if(currentrec != lastrow)
		{
			FillFields(currentrec+1);
			currentrec = currentrec+1;
		}
	}

	void OnLastRecord(Object *sender, EventArgs *e)
	{
	// call the functions to fill the fields with the records
	// passing lastrow-1 for the last row
		lastrow = (ds->get_Tables()->get_Item(0)->get_Rows()->get_Count() - 1);
	    FillFields(lastrow);
	    currentrec = lastrow;
	}

	//*** Function to actually make the database connectione etc.
	//and populate the dataset **/
	void FetchData()
	{
		// user id and password
		String *userId = "sa";
		String *password = "";	

		// Connect to the SQL Database and issue a SELECT command all in one statement
		String *query = S"SELECT * FROM Account_Detail";

		// build connect string with the userid and password
		String *connectString = String::Format(S"Data Source=localhost;Database=Banking;UID={0};Password={1};", userId, password);

		// Create the connection object
		SqlConnection* sqlconn = new SqlConnection(connectString);
		sqlconn->Open();
	    
		// Create the command object - actually not required
		//SqlCommand* myCommand = new SqlCommand(query,sqlconn);

		// set the adapter with the main command
		myAdapter = new SqlDataAdapter(query,sqlconn);
		
		// set the Various commands to be operated on the database
		SqlCommandBuilder* DataAdapterCommands = new SqlCommandBuilder(myAdapter);
		
		// Create the Dataset
		ds = new DataSet();

		// Fill the dataset using the fill method of the adapter
		// also include which table has to be used to populate it
		myAdapter->Fill(ds, "Account_Detail");

		// call the functions to fill the fields with the records
		// passing 0 is for the first row
		FillFields(currentrec);

		// Close the connecition
		sqlconn->Close();
	}
	//function to clear the form
	void ClearForm()
	{
		fname->set_Text("");
		lname->set_Text("");
		dob->set_Text("");
		paddr->set_Text("");
		maddr->set_Text("");
		phno->set_Text("");
		emailid->set_Text("");
		refacno->set_Text("");
		amount->set_Text("");
	}
	//HACK Made changes here
	bool ValidateForm()
	{
		if (fname->Text->get_Length()==0)
		{
			error->SetError(fname,"Invalid name");
			return false;
		}
		else
			error->SetError(fname,"");
		if (lname->Text->get_Length()==0)
		{
			error->SetError(lname,"Invalid name");
			return false;
		}
		else
			error->SetError(lname,"");
		if (dob->Text->get_Length()==0)
		{
			error->SetError(dob,"Invalid date of birth");
			return false;
		}
		else
			error->SetError(dob,"");
		if (paddr->Text->get_Length()==0)
		{
			error->SetError(paddr,"Invalid permanent address");
			return false;
		}
		else
			error->SetError(paddr,"");

		if (maddr->Text->get_Length()==0)
		{
			error->SetError(maddr,"Invalid mailing address");
			return false;
		}
		else
			error->SetError(maddr,"");
		if (phno->Text->get_Length()==0)
		{
			error->SetError(phno,"Invalid phone number");
			return false;
		}
		else
			error->SetError(phno,"");
		if (emailid->Text->get_Length()==0)
		{
			error->SetError(emailid,"Invalid e-mail ID");
			return false;
		}
		else
			error->SetError(emailid,"");

		if (refacno->Text->get_Length()==0)
		{
			error->SetError(refacno,"Invalid referral account number");
			return false;
		}
		else
			error->SetError(refacno,"");
		if (amount->Text->get_Length()==0)
		{
			error->SetError(amount,"Invalid amount");
			return false;
		}
		else
			error->SetError(amount,"");
		try
		{
			Convert::ToDouble(amount->Text);
			Convert::ToInt32(refacno->Text);
		}
		catch(...)
		{
			MessageBox::Show("Please specify the amount and referral account number as integers.");
			return false;
		}
		return true;
	}
	/*** function to write into the fields displayed on the form ***/
	void FillFields(int i)
	{
	  DataTable *dtab = new DataTable();

	  DataRow *dr;

	  // set an alias for the data table collections
      dtab = ds->get_Tables()->get_Item(0);

	  //set an alias for the data row collections
	  // based on the value of i
	  dr = dtab->get_Rows()->get_Item(i);

	  if(dr != NULL)
	  {
	  // fill each field on the form with the current dataset row
	  	fname->set_Text(dr->get_Item("First_name")->ToString());
		lname->set_Text(dr->get_Item("Last_name")->ToString());
		dob->set_Text(dr->get_Item("date_birth")->ToString());
		paddr->set_Text(dr->get_Item("Permanent_Addr")->ToString());
		maddr->set_Text(dr->get_Item("Mailing_Addr")->ToString());
		phno->set_Text(dr->get_Item("Phone_Number")->ToString());
		emailid->set_Text(dr->get_Item("eMailID")->ToString());
		refacno->set_Text(dr->get_Item("Ref_Acc_no")->ToString());
		amount->set_Text(dr->get_Item("Balance")->ToString());
	  }
	}
};

// This is the entry point for this application
void main(void)
{
	int iscorrectlogin;
	iscorrectlogin = 1;

	// Call the function to display the bank form
	Application::Run(new BankForm()); 
}