// This is the main project file for VC++ application project 
// generated using an Application Wizard.
#pragma once

#include "stdafx.h"
#include "Chat.h"

//Chat window class
__gc class CChatForm : public Form 
{ 
private:
	String *pCaption;	// Caption of the CChatForm
	int	nWidth;			// Width of the CChatForm
	int	nHeight;		// height of the CChatForm

	TextBox *pTxtMessage;
	Label *pLblMessage;
	Label *pLblLoggedOnUser;

	ListBox* pLstBoxMessage;
	ListBox* pchkdLstBoxUserList;
	//CheckedListBox* pchkdLstBoxUserList;

	Button *pBtnSend;
	Button *pBtnSave;
	Button *pBtnExit;

	CChat* pChat;
	
	Thread* pChatThread;
	bool bThreadStarted;
	Encoding* pASCII;

public: 
	CChatForm()
	{
		pCaption = "Chat Dialog";
		nWidth = 500;
		nHeight = 255;
		bThreadStarted = false;

		//Prepare the Chat form
		InitForm();

		pChat = new CChat(pLstBoxMessage, pchkdLstBoxUserList);
	}

	void ~CChatForm() 
	{ 
		// Form is being destroyed. Do any necessary cleanup here. 
		Form::Dispose(); 
	}

	void InitForm()
	{
		// Basic WinForm Settings
		Text = pCaption;
		Size = Drawing::Size(nWidth, nHeight);
		set_MaximizeBox(false);
		//set_Bounds(Rectangle(0,0,200,200));

		pTxtMessage = new TextBox();
		pTxtMessage->Name="Edit_message";
		pTxtMessage->Size = Drawing::Size(280, 20);	
		pTxtMessage->TabIndex = 0;
		pTxtMessage->Location = Drawing::Point(10, 195);

		pLstBoxMessage = new ListBox();
		pLstBoxMessage->Name="ListBox_message";
		pLstBoxMessage->TabIndex = 1;
		pLstBoxMessage->set_HorizontalScrollbar(true);
		pLstBoxMessage->Location = Drawing::Point(10, 10);
		pLstBoxMessage->Size = Drawing::Size(350, 160);	
		pLstBoxMessage->Enabled = false;

		//pchkdLstBoxUserList = new CheckedListBox();
		pchkdLstBoxUserList = new ListBox();
		pchkdLstBoxUserList->Name="CheckedListBox_UserList";
		//pchkdLstBoxUserList->ThreeDCheckBoxes = true;
		//pchkdLstBoxUserList->CheckOnClick = true;
		//pchkdLstBoxUserList->HorizontalScrollbar = true;
		pchkdLstBoxUserList->set_HorizontalScrollbar(true);
		pchkdLstBoxUserList->TabIndex = 2;
		pchkdLstBoxUserList->Location = Drawing::Point(380, 30);
		pchkdLstBoxUserList->Size = Drawing::Size(100, 140);
		pchkdLstBoxUserList->Enabled = false;

		pLblLoggedOnUser = new Label();
		pLblLoggedOnUser->Text="Logged on Users:";
		pLblLoggedOnUser->Size = Drawing::Size(100, 20);		
		pLblLoggedOnUser->Location = Drawing::Point(380, 10);

		pLblMessage = new Label();
		pLblMessage->Text="Type the message here:";
		pLblMessage->Size = Drawing::Size(150, 20);		
		pLblMessage->Location = Drawing::Point(10, 175);

		pBtnSend = new Button();
		pBtnSend->Text = "Se&nd";
		pBtnSend->Size = Drawing::Size(55, 20);
		pBtnSend->TabIndex = 3;
		pBtnSend->Location = Drawing::Point(300, 195);
		pBtnSend->Click += (new EventHandler(this, &CChatForm::OnSendButtonClick));

		pBtnSave = new Button();
		pBtnSave->Text = "&Save";
		pBtnSave->Size = Drawing::Size(55, 20);
		pBtnSave->TabIndex = 4;
		pBtnSave->Location = Drawing::Point(362, 195);
		pBtnSave->Click += (new EventHandler(this, &CChatForm::OnSaveButtonClick));

		pBtnExit = new Button();
		pBtnExit->Text = "E&xit";
		pBtnExit->Size = Drawing::Size(55, 20);
		pBtnExit->TabIndex = 5;
		pBtnExit->Location = Drawing::Point(425, 195);
		pBtnExit->Click += (new EventHandler(this, &CChatForm::OnExitButtonClick));

		Controls->Add(pTxtMessage);
		Controls->Add(pLblMessage);
		Controls->Add(pLblLoggedOnUser);
		Controls->Add(pLstBoxMessage);
		Controls->Add(pchkdLstBoxUserList);
		Controls->Add(pBtnSend);
		Controls->Add(pBtnSave);
		Controls->Add(pBtnExit);

		//Set the pBtnSend as the default
		Form::set_AcceptButton(pBtnSend);

		//Initalize the Chat session
		pChat->Initialize();
	}

	//Handles the Exit button
	void OnExitButtonClick (Object *sender, EventArgs *e)
	{
		if ( bThreadStarted && (pChatThread != NULL) )
		{
			CChat::m_bDone = true;
			//Notify the listener, User is closing the app 
			String* pStrMsg;
			pStrMsg = S":@";

			Byte bytearrayBuffer [] = new Byte[pStrMsg->Length + 1];
			int nLen = pASCII->GetBytes( pStrMsg->ToCharArray(), 0, pStrMsg->Length, bytearrayBuffer, 0);
			int nECode = CChat::m_pClient->Send(bytearrayBuffer, 2, pChat->GetRemoteEP());

			//Raises a ThreadAbortException in the thread on which it is invoked, 
			//to begin the process of terminating the thread. 
			pChatThread->Abort();
			//Blocks the calling thread until a thread terminates
			pChatThread->Join();
			
			//Show the message in the list box
			pLstBoxMessage->Items->Add(S"Thank you for using My Chat App !!!");
			pLstBoxMessage->Refresh();

			//Terminate the Chat Session
			pChat->Terminate();
			Thread::Sleep(2000);
		}

		Close();
	}
	
	//Handles the Save button
	void OnSaveButtonClick (Object *sender, EventArgs *e)
	{
		//Code here for saving the chat content
		int nCount = pLstBoxMessage->Items->Count;
		String *pStrMessage, *pStrTemp;
		for (int i=0; i < nCount; i++)
		{
			pStrTemp = pLstBoxMessage->Items->get_Item(i)->ToString();
			pStrMessage = String::Concat(pStrMessage, S"\n", pStrTemp);
		}

		//Save pStrItem in a file
		SaveFileDialog* pFileDlg = new SaveFileDialog();
		pFileDlg->DefaultExt = "txt";
		pFileDlg->Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
		pFileDlg->FilterIndex = 2;
	    pFileDlg->RestoreDirectory = true;
		if (pFileDlg->ShowDialog() == DialogResult::OK) 
		{
			Stream *pStream; 
			if((pStream = pFileDlg->OpenFile()) != NULL)
			{
				Byte bytearrayBuffer [] = new Byte[pStrMessage->Length + 1];
				int nLen = pASCII->GetBytes( pStrMessage->ToCharArray(), 0, pStrMessage->Length, bytearrayBuffer, 0);
				pStream->Write(bytearrayBuffer, 0, pStrMessage->Length);
				pStream->Close();
			}
		}
	}

	//Handles the Send button
	void OnSendButtonClick (Object *sender, EventArgs *e)
	{
		if (!bThreadStarted)
		{
			pChatThread = new Thread(new ThreadStart(0, CChat::Listener));
			pChatThread->Start(); //Start the thread
			pASCII = Encoding::ASCII;
			bThreadStarted = true;
		}

		//Get the text from the message window and send it to active user
		String* pStrTemp = pTxtMessage->Text;
		String* pStrMsg = pStrTemp->Trim();
		if (pStrMsg->Length == 0)
		{
			//Nothing to send
			return;
		}
		else
		{
			//Format the user typed message
			String* pHostName = pChat->GetChatHostName();
			int nItemIndex = pchkdLstBoxUserList->FindStringExact(pHostName);
			if (nItemIndex == ListBox::NoMatches)
			{
				//pchkdLstBoxUserList->Items->Add(pHostName, true);
				pchkdLstBoxUserList->Items->Add(pHostName);
			}

			pStrMsg = String::Concat(pChat->GetChatHostName(), S":", pStrMsg);
		}

		Byte bytearrayBuffer [] = new Byte[pStrMsg->Length + 1];
		
		//Send data to remote peer
		int nLen = pASCII->GetBytes( pStrMsg->ToCharArray(), 0, pStrMsg->Length, bytearrayBuffer, 0);
		int nECode = CChat::m_pClient->Send(bytearrayBuffer, nLen, pChat->GetRemoteEP());
		if(nECode <= 0) 
		{
			String* pStr;
			pStr = String::Format("Error in send : {0}", nECode.ToString());
			pLstBoxMessage->Items->Add(pStr);
			//pLstBoxMessage->DisplayMember(
		}

		//Empty the Edit window
		pTxtMessage->Text = "";
		pTxtMessage->Focus();
	}
};

// This is the entry point for this application
int _tmain(void)
{
    // TODO: Please replace the sample code below with your own.
    Application::Run(new CChatForm()); 
    return 0;
}