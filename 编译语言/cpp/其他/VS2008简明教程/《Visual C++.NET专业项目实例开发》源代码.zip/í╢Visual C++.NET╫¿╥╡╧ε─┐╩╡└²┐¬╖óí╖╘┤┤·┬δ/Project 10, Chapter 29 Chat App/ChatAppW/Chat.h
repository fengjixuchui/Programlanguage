#pragma once

#include "stdafx.h"

//Chat class definition
__gc class CChat
{
	//Private member variables

public:
	//Public member variables
	static IPAddress* m_pGroupAddress;
	static IPHostEntry* m_pLocalHost;
	static IPEndPoint* m_pRemoteEP;

	static int nListenerPort = 8000;
	static int nSenderPort = 8000;
	static bool m_bDone = false;
	static UdpClient* m_pClient;  //For UDP network services
	static ListBox* m_pListBox;
	//static CheckedListBox* m_pchkdLstBoxUserList;
	static ListBox* m_pchkdLstBoxUserList;
public:
	//Constructor
	CChat()
	{
	}

	//CChat(ListBox* pListBox, CheckedListBox* pchkdLstBoxUserList)
	CChat(ListBox* pListBox, ListBox* pchkdLstBoxUserList)
	{
		m_pListBox = pListBox;
		m_pchkdLstBoxUserList = pchkdLstBoxUserList;
	}

	//Destructor
	void ~CChat()
	{
	}

	static String* GetChatHostName()
	{
		return Dns::GetHostName(); //Get the hostname of local computer
	}

	IPEndPoint* GetRemoteEP()
	{
		return m_pRemoteEP;
	}

	IPAddress* GetGroupAddress()
	{
		return m_pGroupAddress;
	}

	//Initializes the UdpClient
	void Initialize()
	{
		m_pClient = new UdpClient(nListenerPort);
		m_pGroupAddress = IPAddress::Parse("224.0.1.1");

		try 
		{
			//Adds a UdpClient to a multicast group
			m_pClient->JoinMulticastGroup(m_pGroupAddress, 50);
		} 
		catch(Exception* ep) 
		{
			m_pListBox->Items->Add(S"Unable to join multicast group");
		}

		//m_pRemoteEP Represents a network endpoint
		m_pRemoteEP = new IPEndPoint( m_pGroupAddress, nSenderPort);
	}

	void Terminate()
	{
		//Leaves a multicast group.
		m_pClient->DropMulticastGroup(m_pGroupAddress);
	}

	static void Listener()
	{
		Thread::Sleep(2000); 
		Encoding* pASCII = Encoding::ASCII;
		while(m_bDone != true) 
		{
			IPEndPoint* pEndPoint = NULL;
			Byte bytearrayData [] = m_pClient->Receive(&pEndPoint);

			String* pstrData = pASCII->GetString(bytearrayData);
			Char cSeparators [] = {':'};
			String* pVars [] = pstrData->Split(cSeparators);
			if( pstrData->IndexOf(S":@") > 0 ) 
			{
				String* pHostName = GetChatHostName();
				if( pVars[0] == pHostName ) 
				{
					m_pListBox->Items->Add(S"Shutting down Listener thread...");
				}
				else 
				{
					String* pStr;
					pStr = String::Format("{0} has left the conversation", pVars[0]);
					m_pListBox->Items->Add(pStr);
					m_pListBox->Items->Add(S"Shutting down Listener thread...");
				}

				//Remove this user from the "Logged On User:" list
				int nItemIndex = m_pchkdLstBoxUserList->FindStringExact(pVars[0]);
				m_pchkdLstBoxUserList->Items->RemoveAt(nItemIndex);
			}
			else 
			{
				int nItemIndex = m_pchkdLstBoxUserList->FindStringExact(pVars[0]);
				if (nItemIndex == ListBox::NoMatches)
				{
					//m_pchkdLstBoxUserList->Items->Add(pVars[0], true);
					m_pchkdLstBoxUserList->Items->Add(pVars[0]);
				}

				if( (pstrData->IndexOf(":") > 0) && (nItemIndex > -1) ) 
				{
					//if ( m_pchkdLstBoxUserList->GetItemCheckState(nItemIndex) == CheckState::Checked )
						m_pListBox->Items->Add(pstrData);
				}
			}
		}

		m_pListBox->Items->Add(S"Listener thread finished...");
		return;
	}
};
