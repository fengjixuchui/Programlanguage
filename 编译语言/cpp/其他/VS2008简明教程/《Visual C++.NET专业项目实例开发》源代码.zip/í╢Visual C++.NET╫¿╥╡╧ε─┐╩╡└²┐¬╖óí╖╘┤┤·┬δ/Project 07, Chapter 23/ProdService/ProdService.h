// ProdService.h

#pragma once

#using <System.Web.Services.dll>

using namespace System;
using namespace System::Web;
using namespace System::Web::Services;

#pragma once
#using <mscorlib.dll>
#using <System.dll>
#using <System.Data.dll>
#include <tchar.h>
#using <System.Web.Services.dll>


using namespace System;
using  System::String;
using namespace System::Data;
using namespace System::Data::SqlClient;


using namespace System;
using namespace System::Web;
using namespace System::Web::Services;

namespace ProdService
{
	  

__value public struct ArtData
	{
	
		String*	ProdID;
		String *ProdType;
		String *ProdName;
		String *Name;
		String *ProdPrice;
		String *PictureFile;
				
	};


typedef ArtData ArtArray[];

[WebService(Namespace="http://www.art-shop.com")]
    public __gc 
        class Class1 : public WebService
    {
        
    public:
		

        [System::Web::Services::WebMethod(MessageName="getArtList", Description="This method returns a list of products available at art-shop.com")] 
		ArtArray getArtList();
 [System::Web::Services::WebMethod(MessageName="placeOrder", Description="Allows affiliate partners to place an order at art-shop.com")] 
 int placeOrder(String *,String *,String *);
		
            
    };
}