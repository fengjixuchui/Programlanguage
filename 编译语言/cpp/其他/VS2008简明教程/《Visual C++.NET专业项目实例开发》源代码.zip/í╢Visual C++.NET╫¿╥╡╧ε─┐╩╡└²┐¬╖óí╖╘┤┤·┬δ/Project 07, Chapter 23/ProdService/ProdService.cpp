#include "stdafx.h"
#include "ProdService.h"
#include "Global.asax.h"


namespace ProdService
{
	
ArtArray Class1::getArtList()
	{
	int i=0;

	SqlConnection *sConn=new SqlConnection();
	sConn->set_ConnectionString("Data Source=saik-d185;Initial Catalog=ArtShop;Integrated Security=SSPI");
	sConn->Open(); 
	SqlCommand *sCommand=new SqlCommand(NULL,sConn);
	SqlDataReader *dataReader;
	
	sCommand->set_CommandText("select ProdID, ProdType, ProdName,ProdPrice,PictureFile from Product where ProdStatus='unsold'");
	
	try{
	dataReader=sCommand->ExecuteReader();
	while(dataReader->Read())
	{
		i++;
	}
	dataReader->Close(); 
	ArtArray list1=new ArtData __gc[i];

	dataReader=sCommand->ExecuteReader();
	i=0;
	while(dataReader->Read())
	{
	list1[i].ProdID=(dataReader->get_Item("ProdID"))->ToString();
	list1[i].ProdType=(String *)dataReader->get_Item("ProdType");
	list1[i].ProdName=(String *)dataReader->get_Item("ProdName");
	list1[i].ProdPrice=(dataReader->get_Item("ProdPrice"))->ToString();
	list1[i].PictureFile=(String *)dataReader->get_Item("PictureFile");
	i++;
	}
		
	dataReader->Close();
	return list1;
	}
	catch(Exception *e)
	{
		Console::WriteLine(e->Message); 
	}
	}
	
	int Class1::placeOrder(String *nProdID, String *nCustId,String *strDate)
	{
	String *strCmdTxt;
	SqlConnection *sConn=new SqlConnection();
	sConn->set_ConnectionString("Data Source=saik-d185;Initial Catalog=ArtShop;Integrated Security=SSPI");
	sConn->Open(); 
	SqlCommand *sCommand=new SqlCommand(NULL,sConn);
	SqlDataReader *dataReader;
	
	strCmdTxt="insert into order1(ProdID,CustID,OrderDate) values(";
	strCmdTxt=strCmdTxt->Concat(strCmdTxt,nProdID);
	strCmdTxt=strCmdTxt->Concat(strCmdTxt,",");
	strCmdTxt=strCmdTxt->Concat(strCmdTxt,nCustId);
	strCmdTxt=strCmdTxt->Concat(strCmdTxt,",'");
	strCmdTxt=strCmdTxt->Concat(strCmdTxt,strDate);
	strCmdTxt=strCmdTxt->Concat(strCmdTxt,"')");
	sCommand->set_CommandText(strCmdTxt);

	try{
	dataReader=sCommand->ExecuteReader(); 
	
		}	
	catch(Exception *e)
	{
		Console::WriteLine(e->Message); 
		return 1;
	}
	return 0;
	}
	};
