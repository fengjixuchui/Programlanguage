Unzip the the contents into a folder. The zip file has the following contents:
1.GuestBook Project folder
2.GuestBookIsapi Project folder
3.Default.HTM
4.GuestBook.xml
5.GuestBook.xsl


The solution file for the entire solution is in the Guestbook project folder. Open it from Visual Studio. Once the solution has been built and published, Visual Studio will create a virtual directory of the name GuestBook pointing to the inetpub/wwwroot/Guestbook folder.Copy the default.HTM, GuestBook.xml and GuestBook.xsl files into inetpub/wwwroot/Guestbook. To test the application connect to http://localhost/guestbook.