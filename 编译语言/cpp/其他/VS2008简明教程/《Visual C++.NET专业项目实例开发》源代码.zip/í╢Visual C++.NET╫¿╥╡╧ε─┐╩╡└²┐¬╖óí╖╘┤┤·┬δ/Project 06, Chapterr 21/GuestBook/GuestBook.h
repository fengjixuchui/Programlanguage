// GuestBook.h : Defines the ATL Server request handler class
//

#pragma once

[ request_handler("Default") ]
class CGuestBookHandler
{
private:
LPCSTR szName;
LPCSTR szEmail;
LPCSTR szWebsite;
LPCSTR szComments;

protected:

public:

	HTTP_CODE ValidateAndExchange()
	{
		// TODO: Put all initialization and validation code here
		CString strCookieString;
		// Set the content-type
		m_HttpResponse.SetContentType("text/html");
		const CHttpRequestParams& FormFields = m_HttpRequest.GetFormVars();
		szName=FormFields.Lookup("Name");
		szEmail=FormFields.Lookup("Email");
		szWebsite=FormFields.Lookup("Website");
		szComments=FormFields.Lookup("Comments");


	//Setting a Cookie

		strCookieString.Format("%s", szName);
		CCookie cookie;
		cookie.SetName("visitor");
		cookie.SetValue(strCookieString);
		cookie.SetPath("/");
		m_HttpResponse.AppendCookie(&cookie);

	//Save the visitor data into the XML file
		
		saveInXML();



		return HTTP_SUCCESS;
		}

		protected:
	// Here is an example of how to use a replacement tag with the stencil processor
	[ tag_name(name="Hello") ]
	HTTP_CODE OnHello(void)
	{
		m_HttpResponse << "Hello World!";
		return HTTP_SUCCESS;
	}

//What should happen when the stencil parser reaches the {{Name}} tag
	[ tag_name(name="Name") ]
	HTTP_CODE OnName(void)
	{
		m_HttpResponse << szName;
		return HTTP_SUCCESS;
	}
//What should happen when the stencil parser reaches the {{Website}} tag
	[ tag_name(name="Website") ]
	HTTP_CODE OnWebsite(void)
	{
		m_HttpResponse << szWebsite;
		return HTTP_SUCCESS;
	}



private:
	void saveInXML()
{
CString strPath;
//create a string having the path of the XML file
        m_HttpRequest.GetPhysicalPath(strPath);
        strPath.Append("guestbook.xml");
//Create the smart pointer for the XML DOM object
        CComPtr<IXMLDOMDocument> ptXMLDOM;
//Create an instance of the XML DOM
		HRESULT hr=ptXMLDOM.CoCreateInstance(_uuidof(DOMDocument));
		if(FAILED(hr))
		return;
		if(ptXMLDOM.p==NULL)
		return;
		VARIANT_BOOL bSuccess=false;
//Load the XML file contents into the DOM object
		CComVariant strP(strPath.AllocSysString());
		hr=ptXMLDOM->load(strP,&bSuccess);

		if(FAILED(hr))
		return;
//intialize a pointer to the root node
		CComBSTR bstrRoot(L"guestbook");
		CComPtr<IXMLDOMNode> ptRootNode;

		hr=ptXMLDOM->selectSingleNode(bstrRoot,&ptRootNode);
		if(FAILED(hr))
		return;

        if(ptRootNode.p==NULL)
		return;
		CComBSTR bstrText;
//Create a new Guest node
        CComPtr<IXMLDOMNode> ptGuestNode;
		hr=ptXMLDOM->createNode(CComVariant(NODE_ELEMENT),CComBSTR("Guest"),NULL, &ptGuestNode);

//create a <Name> node
		CComPtr<IXMLDOMNode> ptNameNode;
		CComPtr<IXMLDOMNode> ptInsertedNode;
		hr=ptXMLDOM->createNode(CComVariant(NODE_ELEMENT),CComBSTR("Name"),NULL, &ptNameNode);
		//Create a text node with the text from the name field
		CComPtr<IXMLDOMText> ptTxtNode;
		hr=ptXMLDOM->createTextNode(CComBSTR(szName),&ptTxtNode);
		//append the text node to the Name node
		hr=ptNameNode->appendChild(ptTxtNode,&ptInsertedNode);
		//Append the Name node to the Guest Node
		ptGuestNode->appendChild(ptNameNode, &ptInsertedNode);

//create an <Email> node
		CComPtr<IXMLDOMNode> ptEmailNode;
		hr=ptXMLDOM->createNode(CComVariant(NODE_ELEMENT),CComBSTR("Email"),NULL, &ptEmailNode);
        hr=ptXMLDOM->createTextNode(CComBSTR(szEmail),&ptTxtNode);
		hr=ptEmailNode->appendChild(ptTxtNode, &ptInsertedNode);
		ptGuestNode->appendChild(ptEmailNode, &ptInsertedNode);

//create the <Website> node

		CComPtr<IXMLDOMNode> ptWebsiteNode;
		hr=ptXMLDOM->createNode(CComVariant(NODE_ELEMENT),CComBSTR("Website"),NULL, &ptWebsiteNode);
        hr=ptXMLDOM->createTextNode(CComBSTR(szWebsite),&ptTxtNode);
		
		hr=ptWebsiteNode->appendChild(ptTxtNode, &ptInsertedNode);
		if(FAILED(hr))
		throw "Unable to append a text node";
		ptGuestNode->appendChild(ptWebsiteNode, &ptInsertedNode);

//create the <Comments> node


CComPtr<IXMLDOMNode> ptCommentsNode;
		hr=ptXMLDOM->createNode(CComVariant(NODE_ELEMENT),CComBSTR("Comments"),NULL, &ptCommentsNode);
        hr=ptXMLDOM->createTextNode(CComBSTR(szComments),&ptTxtNode);
		hr=ptCommentsNode->appendChild(ptTxtNode, &ptInsertedNode);
		//Append the Comments node to the Guest Node
		ptGuestNode->appendChild(ptCommentsNode, &ptInsertedNode);


//Append the Guest node to the root node and save the file.

		ptRootNode->appendChild(ptGuestNode, &ptInsertedNode);
		hr=ptXMLDOM->save(CComVariant(strP));
		//if(FAILED(hr))
		//throw("Unable to save the file");

}

}; // class CGuestBookHandler