// LoginComp.h

#pragma once
#using <mscorlib.dll>
#using <System.dll>
#using <System.Data.dll>
#include <tchar.h> //This is just for the NULLs used for some method parameters

using namespace System;
using  System::String;
using namespace System::Data;
using namespace System::Data::SqlClient;
//using namespace System::Data::OleDb; 
//using namespace System;

namespace LoginComp
{
	public __gc class Login
	{
		
	public:
	// TODO: Add your methods for this class here.
String * getPass(String *name);
int updatePass(String *login,String *oldPass, String *newPass);
int addUser(String *CustName, String *Address, String *ZipCode, String *LoginName, String *Password,String *Email);


};
}
