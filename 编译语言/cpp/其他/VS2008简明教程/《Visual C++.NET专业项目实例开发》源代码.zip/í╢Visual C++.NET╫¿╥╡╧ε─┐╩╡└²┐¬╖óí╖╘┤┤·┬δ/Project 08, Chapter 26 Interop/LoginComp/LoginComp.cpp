// This is the main DLL file.

#include "stdafx.h"

#include "LoginComp.h"
using namespace LoginComp;
int Login::addUser(String *CustName, String *Address, String *ZipCode, String *LoginName, String *Password,String *Email)
	{
//This method is used to add a user to the database
	try{
//Connect to the SQL Server
	SqlConnection *sConn=new SqlConnection();
	sConn->set_ConnectionString("Data Source=saik-d185;Initial Catalog=ArtShop;Integrated Security=SSPI");
	sConn->Open(); 
	SqlDataAdapter *dataAdapter=new SqlDataAdapter();
	String *strCmd;
//Create the insert string
	strCmd="insert into Customer(CustName,Address,ZipCode,LoginName,Password,Email) values('";
	strCmd=strCmd->Concat(strCmd,CustName);
	strCmd=strCmd->Concat(strCmd,"','");
	strCmd=strCmd->Concat(strCmd,Address);
	strCmd=strCmd->Concat(strCmd,"','");
	strCmd=strCmd->Concat(strCmd,ZipCode);
	strCmd=strCmd->Concat(strCmd,"','");
	strCmd=strCmd->Concat(strCmd,LoginName);
	strCmd=strCmd->Concat(strCmd,"','");
	strCmd=strCmd->Concat(strCmd,Password);
	strCmd=strCmd->Concat(strCmd,"','");
	strCmd=strCmd->Concat(strCmd,Email);
	strCmd=strCmd->Concat(strCmd,"')");
	//Execute the command
	dataAdapter->UpdateCommand=new SqlCommand(NULL,sConn); 
	dataAdapter->UpdateCommand->CommandText=strCmd; 
	dataAdapter->UpdateCommand->ExecuteNonQuery();
	}
	catch(Exception *e)
	{
	return 1; 
	}
}

	
int Login::updatePass(String *login,String *oldPass, String *newPass)
{
	//Method to alter password of a registered user
	//Connect to SQL server database
try{
	SqlConnection *sConn=new SqlConnection();
	sConn->set_ConnectionString("Data Source=saik-d185;Initial Catalog=ArtShop;Integrated Security=SSPI");
	sConn->Open(); 
	SqlDataAdapter *dataAdapter=new SqlDataAdapter();
    //prepare the update command string
	String *strCmd;
	strCmd="Update Customer set Password='";
	strCmd=strCmd->Concat(strCmd,newPass);
	strCmd=strCmd->Concat(strCmd,(String *)"' where LoginName='" );
	strCmd=strCmd->Concat(strCmd,login );
	strCmd=strCmd->Concat(strCmd,(String *) "' and Password='");
	strCmd=strCmd->Concat(strCmd,oldPass );
	strCmd=strCmd->Concat(strCmd,(String *) "'");
	//execute the command
	dataAdapter->UpdateCommand=new SqlCommand(NULL,sConn); 
	dataAdapter->UpdateCommand->CommandText=strCmd; 
	dataAdapter->UpdateCommand->ExecuteNonQuery();
	}
	catch(Exception *e)
	{
		return 1;
	}
	return 0;
	}

String * Login::getPass(String *name)
{
	//Method accepts a loginname and returns the corresponding password.
	//used for visitor validation

	//Connect to the SQL Server database
	SqlConnection *sConn=new SqlConnection();
	sConn->set_ConnectionString("Data Source=saik-d185;Initial Catalog=ArtShop;Integrated Security=SSPI");
	sConn->Open(); 
	SqlCommand *sCommand=new SqlCommand(NULL,sConn);
	sCommand->set_CommandText("select LoginName, Password from Customer");
	//Create a DataReader object since you just need to retrieve data
	SqlDataReader *dataReader;
	try{
	dataReader=sCommand->ExecuteReader();
	//Get all the records from the table
	//For each record in the dataset check if the login name matches
	//If it does return the password
	while(dataReader->Read())
	{
	if(name->CompareTo(static_cast<String *> (dataReader->get_Item("LoginName")))==0)
	{
	String  *str1=static_cast<String *>(dataReader->get_Item("Password"));
	dataReader->Close();
	return str1;
	}
	}
	dataReader->Close();
	return "NoUser";
	}
	catch(Exception *e)
	{
		return "Error";
	}
}