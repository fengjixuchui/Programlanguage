// LuhnChecker.cpp : Implementation of DLL Exports.
//
// Note: COM+ 1.0 Information:
//      Please remember to run Microsoft Transaction Explorer to install the component(s).
//      Registration is not done by default. 

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{8F61C082-609C-4B45-8D19-A99F2C8C6601}", 
		 name = "LuhnChecker", 
		 helpstring = "LuhnChecker 1.0 Type Library",
		 resource_name = "IDR_LUHNCHECKER") ];
