// CardCheck.cpp : Implementation of CCardCheck

#include "stdafx.h"
#include "CardCheck.h"
#include <atlconv.h>

// CCardCheck
//The get method for the CardType property

STDMETHODIMP CCardCheck::get_CardType(BSTR* pVal)
{
	// TODO: Add your implementation code here
	*pVal=SysAllocString(bstrCardType);
	return S_OK;
}

//The set method for the CardType property
STDMETHODIMP CCardCheck::put_CardType(BSTR newVal)
{
	// TODO: Add your implementation code here
	bstrCardType=SysAllocString(newVal);
	return S_OK;
}


STDMETHODIMP CCardCheck::Validate(BSTR bstrCardNo, VARIANT* vRetVal)
{
	// TODO: Add your implementation code here

	int i;
	int nSum;

	int len = wcslen(bstrCardNo);
	char * pszCardNo = new char[len+1];
    //Convert BSTR to char *
	int last = WideCharToMultiByte(CP_ACP,0,bstrCardNo,len,pszCardNo,len,0,0);
	pszCardNo[last] = 0;

 	//Convert BSTR to char *
	len = wcslen(bstrCardType);
	char *pszCardType=new char[len+1];
	last = WideCharToMultiByte(CP_ACP,0,bstrCardType,len,pszCardType,len,0,0);
	pszCardType[last] = 0;

	CString s(pszCardType);

	//If the card type is not one of the valid types return 1
	if(s.CompareNoCase("VISA")!=0 && s.CompareNoCase("MASTER")!=0 && s.CompareNoCase("AMEX")!=0)
	{
		CComVariant n(1);
		*vRetVal=(VARIANT)n;
		return S_OK;
	}

//if card is visa, check if the number starts with a 5 and is 13 or 16 digits long.
	if(s.CompareNoCase("VISA")==0)
	{
		if(strlen(pszCardNo)!=13 && strlen(pszCardNo)!=16)
		{
			CComVariant n(1);
			*vRetVal=(VARIANT)n;
			return S_OK;
		}

	if(pszCardNo[0]!='4')
		{
			CComVariant n(1);
			*vRetVal=(VARIANT)n;
			return S_OK;
		}
	}

//if card is master, check if the number starts with a number in the range 51-55 and is  16 digits long.

if(s.CompareNoCase("MASTER")==0)
{

	if(strlen(pszCardNo)!=16)
	{

		CComVariant n(1);
		*vRetVal=(VARIANT)n;
		return S_OK;
	}

  if(pszCardNo[0] != '5')
  {
		CComVariant n(1);
		*vRetVal=(VARIANT)n;
		return S_OK;
  }
  if(pszCardNo[1] < '1' || pszCardNo[1] > '6')
	{
		CComVariant n(1);
		*vRetVal=(VARIANT)n;
		return S_OK;
	}
}

//if card is visa, check if the number starts with a 3 and is 15 digits long.


if(s.CompareNoCase("AMEX")==0)
{
	if(strlen(pszCardNo)!=15)
	{
		CComVariant n(1);
		*vRetVal=(VARIANT)n;
		return S_OK;
	}


	if(pszCardNo[0]!='3')
	{
		CComVariant n(1);
		*vRetVal=(VARIANT)n;
		return S_OK;
	}

  if(pszCardNo[1]!='4' && pszCardNo[1] != '7')
  {
		CComVariant n(1);
		*vRetVal=(VARIANT)n;
		return S_OK;
  }

}

//if it is a valid number for the card type specified, check for Luhn

	 for(i = 0, nSum = 0; i < 16; i += 2)
	  {
	    int nDigit = (pszCardNo[i] - 48) * 2;

		if(nDigit < 10)
		{nSum=nSum + nDigit;
		}
		else
		{
			nSum =nSum + nDigit/10;
			nSum = nSum + nDigit%10;
		}
		nSum=nSum + (pszCardNo[i+1]-48);

	}
	  nSum=nSum%10;
	 CComVariant p(nSum);
	*vRetVal=(VARIANT)p;

	return S_OK;
}
