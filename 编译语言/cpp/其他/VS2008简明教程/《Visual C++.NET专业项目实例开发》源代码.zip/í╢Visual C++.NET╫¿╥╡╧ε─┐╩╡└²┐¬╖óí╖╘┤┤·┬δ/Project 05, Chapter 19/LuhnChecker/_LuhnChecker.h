
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0347 */
/* at Thu Feb 28 10:09:17 2002
 */
/* Compiler settings for _LuhnChecker.idl:
    Os, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef ___LuhnChecker_h__
#define ___LuhnChecker_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __ICardCheck_FWD_DEFINED__
#define __ICardCheck_FWD_DEFINED__
typedef interface ICardCheck ICardCheck;
#endif 	/* __ICardCheck_FWD_DEFINED__ */


#ifndef __CCardCheck_FWD_DEFINED__
#define __CCardCheck_FWD_DEFINED__

#ifdef __cplusplus
typedef class CCardCheck CCardCheck;
#else
typedef struct CCardCheck CCardCheck;
#endif /* __cplusplus */

#endif 	/* __CCardCheck_FWD_DEFINED__ */


/* header files for imported files */
#include "prsht.h"
#include "mshtml.h"
#include "mshtmhst.h"
#include "exdisp.h"
#include "objsafe.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

#ifndef __ICardCheck_INTERFACE_DEFINED__
#define __ICardCheck_INTERFACE_DEFINED__

/* interface ICardCheck */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICardCheck;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("52449C35-55FE-4368-84E5-C2CA49A68985")
    ICardCheck : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_CardType( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_CardType( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Validate( 
            /* [in] */ BSTR bstrCardNo,
            /* [retval][out] */ VARIANT *vRetVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICardCheckVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ICardCheck * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ICardCheck * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ICardCheck * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ICardCheck * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ICardCheck * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ICardCheck * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ICardCheck * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_CardType )( 
            ICardCheck * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_CardType )( 
            ICardCheck * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Validate )( 
            ICardCheck * This,
            /* [in] */ BSTR bstrCardNo,
            /* [retval][out] */ VARIANT *vRetVal);
        
        END_INTERFACE
    } ICardCheckVtbl;

    interface ICardCheck
    {
        CONST_VTBL struct ICardCheckVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICardCheck_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICardCheck_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICardCheck_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICardCheck_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICardCheck_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICardCheck_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICardCheck_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICardCheck_get_CardType(This,pVal)	\
    (This)->lpVtbl -> get_CardType(This,pVal)

#define ICardCheck_put_CardType(This,newVal)	\
    (This)->lpVtbl -> put_CardType(This,newVal)

#define ICardCheck_Validate(This,bstrCardNo,vRetVal)	\
    (This)->lpVtbl -> Validate(This,bstrCardNo,vRetVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICardCheck_get_CardType_Proxy( 
    ICardCheck * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ICardCheck_get_CardType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ICardCheck_put_CardType_Proxy( 
    ICardCheck * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ICardCheck_put_CardType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICardCheck_Validate_Proxy( 
    ICardCheck * This,
    /* [in] */ BSTR bstrCardNo,
    /* [retval][out] */ VARIANT *vRetVal);


void __RPC_STUB ICardCheck_Validate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICardCheck_INTERFACE_DEFINED__ */



#ifndef __LuhnChecker_LIBRARY_DEFINED__
#define __LuhnChecker_LIBRARY_DEFINED__

/* library LuhnChecker */
/* [helpstring][uuid][version] */ 


EXTERN_C const IID LIBID_LuhnChecker;

EXTERN_C const CLSID CLSID_CCardCheck;

#ifdef __cplusplus

class DECLSPEC_UUID("C6569332-8514-4754-8CCF-52DB74151699")
CCardCheck;
#endif
#endif /* __LuhnChecker_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long *, unsigned long            , VARIANT * ); 
unsigned char * __RPC_USER  VARIANT_UserMarshal(  unsigned long *, unsigned char *, VARIANT * ); 
unsigned char * __RPC_USER  VARIANT_UserUnmarshal(unsigned long *, unsigned char *, VARIANT * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long *, VARIANT * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


