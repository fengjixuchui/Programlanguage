// CardCheck.h : Declaration of the CCardCheck

#pragma once
#include "resource.h"       // main symbols


// ICardCheck
[
	object,
	uuid("52449C35-55FE-4368-84E5-C2CA49A68985"),
	dual,	helpstring("ICardCheck Interface"),
	pointer_default(unique)
]
__interface ICardCheck : IDispatch
{
	[propget, id(1), helpstring("property CardType")] HRESULT CardType([out, retval] BSTR* pVal);
	[propput, id(1), helpstring("property CardType")] HRESULT CardType([in] BSTR newVal);
	[id(2), helpstring("method Validate")] HRESULT Validate([in] BSTR bstrCardNo, [out,retval] VARIANT* vRetVal);
};



// CCardCheck

[
	coclass,
	threading("apartment"),
	vi_progid("LuhnChecker.CardCheck"),
	progid("LuhnChecker.CardCheck.1"),
	version(1.0),
	uuid("C6569332-8514-4754-8CCF-52DB74151699"),
	helpstring("CardCheck Class")
]
class ATL_NO_VTABLE CCardCheck : 
	public ICardCheck
{
private:
	BSTR bstrCardType;
public:
	CCardCheck()
	{
		
	}


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}


public:

	STDMETHOD(get_CardType)(BSTR* pVal);
	STDMETHOD(put_CardType)(BSTR newVal);
	STDMETHOD(Validate)(BSTR bstrCardNo, VARIANT* vRetVal);
};

