// This is the main project file for VC++ application project 
// generated using an Application Wizard.

#include "stdafx.h"

#using <mscorlib.dll>
#using <System.dll>
#using <System.Drawing.dll>
#using <System.Windows.Forms.dll>
#using <System.data.dll>
#using <System.xml.dll>
#include <tchar.h>

using namespace System;

using namespace System::IO;
using namespace System::Drawing;
using namespace System::Collections;
using namespace System::ComponentModel;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Data::SqlClient;
using namespace System::Xml; 
using namespace System::Xml::Xsl; 




__gc class MyForm : public Form
{
public:
	MyForm();

private:
	//event handlers 
	void getData_Click(Object *sender, System::EventArgs *e);
	void ConvHtm_Click(Object *sender, System::EventArgs *e);
	
//The various controls for the UI form
	ListView *lv;
	ListViewItem *lvi;
	Button *getData, *ConvHtm;
	TextBox *txt; 	
	Label *lbl;
};


MyForm::MyForm()
{
	//Create the UI

this->Size=System::Drawing::Size(550,350);

lbl=new Label();
lbl->Text="Enter your Name:";
lbl->Location=System::Drawing::Point(8,5);  

txt=new TextBox();
txt->Name="txt";
txt->Size= System::Drawing::Size(128,20);
txt->Location=System::Drawing::Point(125,5);  
txt->TabIndex=2;
txt->Text=""; 



lv=new ListView();
lv->View=View::Details;	
lv->Location=System::Drawing::Point(8,48);
lv->Size=System::Drawing::Size(504,192);
lv->Columns->Add("ID",50,HorizontalAlignment::Left);
lv->Columns->Add("Date",75,HorizontalAlignment::Left);
lv->Columns->Add("Location",150,HorizontalAlignment::Left);
lv->Columns->Add("Category",150,HorizontalAlignment::Left);
lv->Columns->Add("Detail",150,HorizontalAlignment::Left);
lv->Columns->Add("Customer Number",150,HorizontalAlignment::Left);



getData=new Button();
ConvHtm=new Button();

getData->Location =   System::Drawing::Point(332, 248);
getData->Name = "getData";
getData->Size =  System::Drawing::Size(150, 24);
getData->Location=System::Drawing::Point(290,5);  
getData->TabIndex = 0;
getData->Text = "Get Details";
getData->Click += new System::EventHandler(this,getData_Click);


ConvHtm->Location =   System::Drawing::Point(200, 264);
ConvHtm->Name = "ConvHtm";
ConvHtm->Size =   System::Drawing::Size(130, 24);
ConvHtm->TabIndex =1;
ConvHtm->Text = "Generate List(HTM)";
ConvHtm->Click +=  new System::EventHandler(this,ConvHtm_Click);
ConvHtm->Enabled=0;


this->Controls->Add(lbl);
this->Controls->Add(txt);
this->Controls->Add(getData);
this->Controls->Add(lv);
this->Controls->Add(ConvHtm);

}



void MyForm::getData_Click(Object *sender, System::EventArgs *e)
{

if((txt->Text)->Length==0)
{MessageBox::Show("Please enter your login name:","Error");
return;
}
SqlDataAdapter *adapter=new SqlDataAdapter(); 
SqlConnection *conn=new SqlConnection();
SqlCommand *cmd=new SqlCommand();
String *strConn="Data Source=saik-d185;Initial Catalog=ArtShop;Integrated Security=SSPI";
String *strCmd="select ID,ReqDate, ReqLocation, Category, Detail, CustomerNo from techsupport where TechSup='";
strCmd=strCmd->Concat(strCmd,(String *)txt->Text); 
strCmd=strCmd->Concat(strCmd,(String *)"'"); 
conn->ConnectionString=strConn;
cmd->CommandText=strCmd; 
adapter->SelectCommand=cmd;
adapter->SelectCommand->Connection =conn ;
conn->Open();


try{
DataSet *ds=new DataSet();
adapter->Fill(ds,"TechSupport");

FileStream *fs=new FileStream("Schedule.xml",FileMode::OpenOrCreate,FileAccess::Write);
StreamWriter *sw=new StreamWriter(fs);

XmlTextWriter *xmlw;
xmlw=new XmlTextWriter(sw);

ds->WriteXml(xmlw);
fs->Close(); 

ConvHtm->Enabled=1; 
}
catch(Exception *e)
{
	Console::WriteLine(e->Message);  
	return ;
}
//Read the XML

//Create and XmlTextReader object and load the xml file

XmlTextReader *reader= new XmlTextReader("Schedule.xml");
try{
while(reader->Read())
			{
//MessageBox::Show (reader->Name);
if(reader->NodeType==XmlNodeType::Element)
{
	//Check of the node is ID and start a new row
	if(String::Compare(reader->Name,"ID")==0)
				{
					//MessageBox::Show (reader->Name);
					reader->Read();
					lvi=lv->Items->Add(reader->Value);
				}	
//Check if ReqDate, truncate date
if(String::Compare(reader->Name,"ReqDate")==0)
				{
					
					reader->Read();
					//MessageBox::Show (reader->Value);
					lvi->SubItems->Add((reader->Value)->Substring(0,10)) ;
				}	

}
				else
				{
					if(reader->NodeType==XmlNodeType::Text)
					{
					lvi->SubItems->Add(reader->Value);   
					}
				}

			}
}
catch(Exception *e)
{
	Console::WriteLine(e->Message); 
}
		reader->Close(); 

		}

void MyForm::ConvHtm_Click(Object *sender, System::EventArgs *e)
		{
			XslTransform *xTrans=new XslTransform();
			xTrans->Load("Schedule.xsl");
			try
			{
			xTrans->Transform("Schedule.xml","Schedule.html");
			}
			catch(System::Xml::XmlException *ex)
			{
				MessageBox::Show(ex->Message,"   "); 
			}

		}








// This is the entry point for this application
int _tmain(void)
{
    // TODO: Please replace the sample code below with your own.

	Application::Run(new MyForm());

    return 0;
}