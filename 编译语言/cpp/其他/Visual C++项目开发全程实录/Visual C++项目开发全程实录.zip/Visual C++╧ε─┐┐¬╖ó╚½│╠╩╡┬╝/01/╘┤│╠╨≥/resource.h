//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Capture.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CAPTURE_DIALOG              102
#define IDD_OVERLAY_DIALOG              103
#define IDD_PANEL_DIALOG                104
#define IDR_MAINFRAME                   128
#define IDB_NOSIGNAL                    129
#define IDI_ICON1                       130
#define IDB_BKBUTTON                    132
#define IDB_BKGROUND                    135
#define IDB_BOTTOMBAR                   136
#define IDB_CLOSEBT                     137
#define IDB_CLOSEHOTBT                  138
#define IDB_LEFTBAR                     139
#define IDB_LEFTTITLE                   140
#define IDB_MAXBT                       141
#define IDB_MAXHOTBT                    142
#define IDB_MIDTITLE                    143
#define IDB_MINBT                       144
#define IDB_MINHOTBT                    145
#define IDB_RIGHTBAR                    146
#define IDB_RIGHTTITLE                  147
#define IDD_CONTROLFORM_DIALOG          149
#define IDD_AUTOMATISM_DIALOG           151
#define IDD_PLAY_DIALOG                 152
#define IDD_LOGIN_DIALOG                155
#define IDD_MANAGE_DIALOG               156
#define IDB_LOGIN                       159
#define IDC_PANEL                       1000
#define IDC_STOPPREVIEW                 1003
#define IDC_SNAPSHOT                    1004
#define IDC_BMP                         1005
#define IDC_JPG                         1006
#define IDC_CAPTURE                     1007
#define IDC_CONTROL                     1007
#define IDC_AUTOMATISM                  1008
#define IDC_KINESCOPE                   1009
#define IDC_PLAY                        1010
#define IDC_MANAGE                      1011
#define IDC_BUTTON1                     1014
#define IDC_RELEN                       1014
#define IDC_PORTSET                     1014
#define IDC_BUTTONADD                   1014
#define IDC_VGA                         1015
#define IDC_BUTTONMOD                   1015
#define IDC_PCI                         1016
#define IDC_BUTTONDEL                   1016
#define IDC_SETTING                     1017
#define IDC_BUTTON4                     1017
#define IDC_REFOCI                      1018
#define IDC_INFOCI                      1019
#define IDC_INLEN                       1020
#define IDC_REAPERTURE                  1021
#define IDC_INAPERTURE                  1022
#define IDC_INBRUSH                     1023
#define IDC_REBRUSH                     1024
#define IDC_BUTTONUP                    1025
#define IDC_BUTTONLEFT                  1026
#define IDC_BUTTONRIGHT                 1027
#define IDC_BUTTONDOWN                  1028
#define IDC_MSCOMM1                     1029
#define IDC_PORT                        1030
#define IDC_SETTINGS                    1031
#define IDC_ACTIONS                     1032
#define IDC_CMDSET                      1033
#define IDC_BYTE1                       1034
#define IDC_BYTE2                       1035
#define IDC_TIMECHECK                   1035
#define IDC_BYTE3                       1036
#define IDC_DATETIMEPICKER1             1036
#define IDC_BYTE4                       1037
#define IDC_DATETIMEPICKER2             1037
#define IDC_BYTE5                       1038
#define IDC_AMPLITUDE                   1038
#define IDC_BYTE6                       1039
#define IDC_HORIZONTAL                  1039
#define IDC_BYTE7                       1040
#define IDC_VERTICAL                    1040
#define IDC_BYTE8                       1041
#define IDC_STOP                        1041
#define IDC_BYTENUM                     1042
#define IDC_OK                          1042
#define IDC_ACTIONNUM                   1043
#define IDC_MEDIAPLAYER1                1045
#define IDC_PATH                        1046
#define IDC_CANCEL                      1047
#define IDC_EDIT1                       1048
#define IDC_EDIT2                       1049
#define IDC_LIST1                       1050
#define IDC_STATIC1                     1051
#define IDC_EDIT3                       1052
#define IDC_STATIC2                     1053

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        160
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1054
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
