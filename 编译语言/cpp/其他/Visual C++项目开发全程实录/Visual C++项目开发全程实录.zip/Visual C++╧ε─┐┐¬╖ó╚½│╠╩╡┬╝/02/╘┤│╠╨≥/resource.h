//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NoteManage.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_NOTEMANAGE_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDD_SENDNOTE_DIALOG             130
#define IDD_PHONEBOOK_DIALOG            131
#define IDD_OFTENNOTE_DIALOG            133
#define IDD_RECVNOTE_DIALOG             134
#define IDD_RESTORE_DIALOG              135
#define IDD_NOTE_DIALOG                 136
#define IDD_BOOK_DIALOG                 137
#define IDD_LOGIN_DIALOG                138
#define IDD_USER_DIALOG                 139
#define IDI_ICONUSER                    140
#define IDI_ICONNOTE                    141
#define IDI_ICONBOOK                    142
#define IDI_ICONSEND                    143
#define IDI_ICONRECV                    144
#define IDI_ICON1                       146
#define IDB_BITMAP1                     147
#define IDB_BUTADD2                     148
#define IDB_BUTADD1                     149
#define IDB_BUTMOD1                     150
#define IDB_BUTMOD2                     151
#define IDI_ICONSET                     152
#define IDD_NOTESET_DIALOG              153
#define IDD_NEWNOTE_DIALOG              156
#define IDB_NEWNOTE                     157
#define IDB_BUTDEL1                     158
#define IDB_BUTDEL2                     159
#define IDB_RESTORE1                    160
#define IDB_RESTORE2                    161
#define IDB_CANCEL1                     162
#define IDB_CANCEL2                     163
#define IDB_BUTBOOK1                    164
#define IDB_BUTBOOK2                    165
#define IDB_BUTCLEAR1                   166
#define IDB_BUTCLEAR2                   167
#define IDB_BUTNOTE1                    168
#define IDB_BUTNOTE2                    169
#define IDB_BUTSEND1                    170
#define IDB_BUTSEND2                    171
#define IDB_BUTGET1                     172
#define IDB_BUTGET2                     173
#define IDB_BUTSAVE1                    174
#define IDB_BUTSAVE2                    175
#define IDB_BUTDEP1                     176
#define IDB_BUTDEP2                     177
#define IDB_BUTDUTY1                    178
#define IDB_BUTDUTY2                    179
#define IDB_BUTALL1                     180
#define IDB_BUTALL2                     181
#define IDB_BITMAP2                     182
#define IDC_LIST1                       1000
#define IDC_EDIT1                       1001
#define IDC_BUTADD                      1002
#define IDC_EDIT3                       1002
#define IDC_BUTMOD                      1003
#define IDC_BUTSEND                     1005
#define IDC_COMBO1                      1006
#define IDC_COMBO2                      1007
#define IDC_COMBO3                      1008
#define IDC_EDIT2                       1009
#define IDC_BUTCLEAR                    1010
#define IDC_BUTBOOK                     1011
#define IDC_BUTDEL                      1012
#define IDC_BUTNOTE                     1013
#define IDC_EDIT5                       1018
#define IDC_EDIT4                       1018
#define IDC_BUTTONADD                   1020
#define IDC_BUTTONMOD                   1021
#define IDC_BUTTONDEL                   1022
#define IDC_CANCEL                      1023
#define IDC_BUTTON1                     1027
#define IDC_BUTTONALL                   1027
#define IDC_BUTGET                      1027
#define IDC_BUTTON2                     1028
#define IDC_BUTTONDEP                   1028
#define IDC_BUTSAVE                     1028
#define IDC_BUTTON3                     1029
#define IDC_BUTTONDUTY                  1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        183
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
