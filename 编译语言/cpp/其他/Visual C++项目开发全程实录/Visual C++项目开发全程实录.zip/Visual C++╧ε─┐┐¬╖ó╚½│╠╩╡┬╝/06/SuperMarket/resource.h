//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SuperMarket.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SUPERMARKET_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       130
#define IDI_ICONSHANGP                  131
#define IDI_ICONSELLQ                   132
#define IDI_ICONUSER                    133
#define IDI_ICONNDEPOT                  134
#define IDI_ICONDAY                     135
#define IDI_ICONDEPOT                   136
#define IDD_SHANGPIN_DIALOG             137
#define IDD_EMPLOYEES_DIALOG            139
#define IDD_PROVIDE_DIALOG              140
#define IDD_BACK_DIALOG                 142
#define IDD_SELLQ_DIALOG                143
#define IDD_BACKQ_DIALOG                144
#define IDD_DEPOT_DIALOG                145
#define IDD_BDEPOT_DIALOG               146
#define IDD_NDEPOT_DIALOG               147
#define IDD_DAY_DIALOG                  148
#define IDD_MONTH_DIALOG                149
#define IDD_USER_DIALOG                 150
#define IDD_LOGIN_DIALOG                152
#define IDD_BDEPOTQ_DIALOG              153
#define IDI_ICON1                       154
#define IDB_BITMAP1                     160
#define IDB_BITMAPSM                    161
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_EDIT4                       1003
#define IDC_EDIT5                       1004
#define IDC_EDIT6                       1005
#define IDC_EDIT7                       1006
#define IDC_EDIT8                       1007
#define IDC_EDIT9                       1008
#define IDC_BUTADD                      1009
#define IDC_BUTMOD                      1010
#define IDC_BUTSAVE                     1011
#define IDC_BUTDEL                      1012
#define IDC_LIST1                       1013
#define IDC_COMBO1                      1014
#define IDC_COMBO2                      1015
#define IDC_BUTQUERY                    1016
#define IDC_COMBO3                      1017
#define IDC_COMBO4                      1018
#define IDC_COMBO5                      1019
#define IDC_DATETIMEPICKER1             1021
#define IDC_CANCEL                      1023
#define IDC_EDIT10                      1024
#define IDC_QUERY                       1026
#define ID_MENU_SHANGP                  32771
#define ID_MENU_EMP                     32772
#define ID_MENU_PROVIDE                 32773
#define ID_MENU_BACK                    32774
#define ID_MENU_SELLQ                   32775
#define ID_MENU_BACKQ                   32776
#define ID_MENU_DEPOT                   32777
#define ID_MENU_BDEPOT                  32778
#define ID_MENU_NDEPOT                  32779
#define ID_MENU_DAY                     32780
#define ID_MENU_MONTH                   32781
#define ID_MENU_USER                    32782
#define ID_MENU_ABOUT                   32783
#define ID_MENU_BDEPOTQ                 32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        162
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
