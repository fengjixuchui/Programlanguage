// Shuliangdlg.cpp : implementation file
//

#include "stdafx.h"
#include "��������.h"
#include "Shuliangdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShuliangdlg dialog


CShuliangdlg::CShuliangdlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShuliangdlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShuliangdlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CShuliangdlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShuliangdlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CShuliangdlg, CDialog)
	//{{AFX_MSG_MAP(CShuliangdlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShuliangdlg message handlers
