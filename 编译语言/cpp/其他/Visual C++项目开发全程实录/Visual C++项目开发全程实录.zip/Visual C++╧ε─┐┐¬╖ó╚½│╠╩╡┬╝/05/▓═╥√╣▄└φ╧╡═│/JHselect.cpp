// JHselect.cpp : implementation file
//

#include "stdafx.h"
#include "��������.h"
#include "JHselect.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJHselect dialog


CJHselect::CJHselect(CWnd* pParent /*=NULL*/)
	: CDialog(CJHselect::IDD, pParent)
{
	//{{AFX_DATA_INIT(CJHselect)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CJHselect::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CJHselect)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CJHselect, CDialog)
	//{{AFX_MSG_MAP(CJHselect)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJHselect message handlers
