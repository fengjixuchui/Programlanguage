//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PhoneRecord.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PHONERECORD_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDR_MENU2                       130
#define IDD_EMPLOYEES_DIALOG            131
#define IDD_CLIENT_DIALOG               133
#define IDD_MANUFACTURE_DIALOG          134
#define IDI_MANUFACTURE                 137
#define IDB_BUT_DOWN                    138
#define IDB_BUT_MOVE                    139
#define IDB_BUT_UP                      140
#define IDI_EMPLOYEE                    141
#define IDD_DIALUP_DIALOG               142
#define IDD_INCEPT_DIALOG               143
#define IDD_PHONEOUT_DIALOG             144
#define IDD_PHONEIN_DIALOG              145
#define IDD_RECORD_DIALOG               146
#define IDD_PHONEBOOK_DIALOG            147
#define IDD_LOGIN_DIALOG                148
#define IDC_LIST1                       1000
#define IDC_EDIT1                       1001
#define IDC_EDIT2                       1002
#define IDC_EDIT3                       1003
#define IDC_EDIT4                       1004
#define IDC_COMBO1                      1005
#define IDC_EDIT5                       1006
#define IDC_COMBO2                      1006
#define IDC_EDIT6                       1007
#define IDC_EDIT7                       1008
#define IDC_EDIT8                       1009
#define IDC_BUTADD                      1010
#define IDC_BUTSAVE                     1011
#define IDC_BUTMOD                      1012
#define IDC_BUTDEL                      1013
#define IDC_PHONEIN                     1014
#define IDC_BUTQUERY                    1014
#define IDC_PHONEOUT                    1015
#define IDC_RECORD                      1016
#define IDC_CLIENT                      1017
#define IDC_EMPLOYEE                    1018
#define IDC_MANUFACTURE                 1019
#define IDC_DIALUP                      1020
#define IDC_HANGUP                      1021
#define IDC_BUTDIALUP                   1022
#define IDC_PHONEBOOK                   1022
#define IDC_BUTPATH                     1024
#define IDC_BUTMODPATH                  1025
#define IDC_BUTPLAY                     1027
#define WM_ONTRAY                       10001
#define ID_MENUDIALUP                   32771
#define ID_MENUINCEPT                   32772
#define ID_MENUPHONEOUT                 32773
#define ID_MENUPHONEIN                  32774
#define ID_MENURECORD                   32775
#define ID_MENUCLIENT                   32776
#define ID_MENUEMPLOYEES                32777
#define ID_MENUMANUFACTURE              32778
#define ID_MENUABOUT                    32779
#define ID_MENUEXIT                     32780
#define ID_MENUSHOW                     32781
#define ID_MENUHIDE                     32782
#define ID_MENUCLOSE                    32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
