//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Server.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SERVER_DIALOG               102
#define IDD_SYSSETTING_DIALOG           103
#define IDD_LOGIN_DIALOG                104
#define IDD_OPRMANAGE_DIALOG            105
#define IDI_APP                         127
#define IDR_MAINFRAME                   128
#define IDI_MAIN                        129
#define IDB_BITMAP1                     133
#define IDI_ICON2                       136
#define IDB_BTBMP                       137
#define IDB_BKBUTTON                    139
#define IDB_HEADER                      141
#define IDC_BTUP                        1001
#define IDC_BTLEFT                      1002
#define IDC_BTRIGHT                     1003
#define IDC_BTDOWN                      1004
#define IDC_BTRESTORE                   1005
#define IDC_BACKGROUND                  1007
#define IDC_SYSSETTING                  1010
#define IDC_CLIENTIP                    1012
#define IDC_CONFIRM                     1013
#define IDC_CANCEL                      1014
#define IDC_BUTTON1                     1014
#define IDC_LOGIN                       1014
#define IDC_OPERATORMGE                 1014
#define IDC_BTADD                       1014
#define IDC_BTCANCLE                    1015
#define IDC_BTUPDATE                    1015
#define IDC_QUIT                        1015
#define IDC_BTDELETE                    1016
#define IDC_USERNAME                    1017
#define IDC_PASSWORD                    1018
#define IDC_LISTINFO                    1018
#define IDC_USER                        1019
#define IDC_PASS                        1020
#define IDC_CONFIRMPASS                 1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
