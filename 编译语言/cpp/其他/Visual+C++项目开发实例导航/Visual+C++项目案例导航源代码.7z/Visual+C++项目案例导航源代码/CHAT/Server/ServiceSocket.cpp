// ServiceSocket.cpp : implementation file
//

#include "stdafx.h"
#include "Server.h"
#include "ServiceSocket.h"

#include "ServerDoc.h"
#include "Message.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServiceSocket

CServiceSocket::CServiceSocket(CServerDoc *pDoc)
{
	m_pDoc = pDoc;
	m_pFile = NULL;
	m_pArchiveIn = NULL;
	m_pArchiveOut = NULL;
}

CServiceSocket::~CServiceSocket()
{
	if (m_pArchiveOut != NULL)
		delete m_pArchiveOut;

	if (m_pArchiveIn != NULL)
		delete m_pArchiveIn;

	if (m_pFile != NULL)
		delete m_pFile;
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CServiceSocket, CSocket)
	//{{AFX_MSG_MAP(CServiceSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CServiceSocket member functions

void CServiceSocket::OnReceive(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CSocket::OnReceive(nErrorCode);
	m_pDoc->ProcessRecieveMessage(this);
}

void CServiceSocket::Init()
{
	m_pFile = new CSocketFile(this);
	m_pArchiveIn = new CArchive(m_pFile,CArchive::load);
	m_pArchiveOut = new CArchive(m_pFile,CArchive::store);

}

void CServiceSocket::ReceiveMsg(CMessage *pMsg)
{
	pMsg->Serialize(*m_pArchiveIn);

}

void CServiceSocket::SendMsg(CMessage *pMsg)
{
	pMsg->Serialize(*m_pArchiveOut);
	m_pArchiveOut->Flush();
}

void CServiceSocket::Abort()
{
	if (m_pArchiveOut != NULL){
		m_pArchiveOut->Abort();
		delete m_pArchiveOut;
		m_pArchiveOut = NULL;
	}
}

IMPLEMENT_DYNAMIC(CServiceSocket, CSocket)
