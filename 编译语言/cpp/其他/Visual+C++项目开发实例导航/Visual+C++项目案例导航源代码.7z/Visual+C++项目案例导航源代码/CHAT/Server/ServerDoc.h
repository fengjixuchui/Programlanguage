// ServerDoc.h : interface of the CServerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SERVERDOC_H__15B467E4_5E3F_454B_9B09_B833B10E61D2__INCLUDED_)
#define AFX_SERVERDOC_H__15B467E4_5E3F_454B_9B09_B833B10E61D2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Message.h"
#include "AcceptSocket.h"
#include "ServiceSocket.h"

class CServerDoc : public CDocument
{
protected: // create from serialization only
	CServerDoc();
	DECLARE_DYNCREATE(CServerDoc)

// Attributes
public:
	CAcceptSocket* m_pAcceptSocket;

	CPtrList m_connectionList;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void DeleteContents();
	//}}AFX_VIRTUAL

// Implementation
public:
	CAcceptSocket* m_pSocket;
	CMessage *m_pShortMessage;
	int m_nPort;
	void ProcessRecieveMessage(CServiceSocket *pSocket);
	void ProcessAccept();
	CMessage* ReadMsg(CServiceSocket* pSocket);
	void SendMsg(CServiceSocket* pSocket, CMessage* pMsg);
	void CloseSocket(CServiceSocket* pSocket);
	void DisplayMsg(int Type, CString From, CString To, CString ShortMessage);
	void DisplayStringWithCRLF(LPCTSTR lpszMessage);
	void DisplayString(LPCTSTR lpszMessage);
	virtual ~CServerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CServerDoc)
	afx_msg void OnConfig();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVERDOC_H__15B467E4_5E3F_454B_9B09_B833B10E61D2__INCLUDED_)
