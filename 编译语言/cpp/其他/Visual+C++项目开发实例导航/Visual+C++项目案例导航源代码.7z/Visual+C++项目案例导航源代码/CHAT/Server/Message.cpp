// Message.cpp: implementation of the CMessage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Message.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMessage::CMessage()
{
	Type = 0;
	From = _T("");
	To = _T("");
	ShortMessage = _T("");
}

CMessage::~CMessage()
{
}

void CMessage::Serialize(CArchive &ar)
{
	if (ar.IsStoring()){
		ar << Type;
		ar << ShortMessage;
		ar << From;
		ar << To;
	}
	else{

		ar >> Type;
		ar >> ShortMessage;
		ar >> From;
		ar >> To;
	}
}

void CMessage::Reset()
{
	Type = 0;
	From = _T("");
	To = _T("");
	ShortMessage = _T("");
}
