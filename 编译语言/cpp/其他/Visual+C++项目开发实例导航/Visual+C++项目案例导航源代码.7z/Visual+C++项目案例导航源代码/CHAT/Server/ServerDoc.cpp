// ServerDoc.cpp : implementation of the CServerDoc class
//

#include "stdafx.h"
#include "Server.h"

#include "ServerDoc.h"
#include "ServerView.h"
#include "ParamDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServerDoc

IMPLEMENT_DYNCREATE(CServerDoc, CDocument)

BEGIN_MESSAGE_MAP(CServerDoc, CDocument)
	//{{AFX_MSG_MAP(CServerDoc)
	ON_COMMAND(ID_CONFIG, OnConfig)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerDoc construction/destruction

CServerDoc::CServerDoc()
{
	// TODO: add one-time construction code here
	m_pSocket = NULL;
	m_pShortMessage = new CMessage();
	m_nPort = 6666;
}

CServerDoc::~CServerDoc()
{
	if(m_pSocket != NULL)
		delete m_pSocket;
	m_pSocket = NULL;
	if(m_pShortMessage != NULL)
	{
		delete m_pShortMessage;
	}

}

BOOL CServerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	((CEditView*)m_viewList.GetHead())->SetWindowText(NULL);

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)
	m_pSocket = new CAcceptSocket(this);
	if (m_pSocket->Create(m_nPort)){
		if (m_pSocket->Listen())
			return TRUE;
	}

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CServerDoc serialization

void CServerDoc::Serialize(CArchive& ar)
{
	// CEditView contains an edit control which handles all serialization
	((CEditView*)m_viewList.GetHead())->SerializeRaw(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CServerDoc diagnostics

#ifdef _DEBUG
void CServerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CServerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CServerDoc commands

void CServerDoc::ProcessAccept()
{
	CServiceSocket* pSocket = new CServiceSocket(this);
	//CServiceSocket* pSock;

	if (m_pSocket->Accept(*pSocket))
	{
		pSocket->Init();
		m_connectionList.AddTail(pSocket);

		/*
		CMessage *pMsg;
		pMsg = new CMessage();
		pMsg->ShortMessage = "Come in";
		pMsg->To = "";
		pMsg->From = "";
		pMsg->Type = 1;

		POSITION posname;

		for( posname=m_connectionList.GetHeadPosition();posname;)
		{				
			pSock = (CServiceSocket *)m_connectionList.GetNext(posname);
			if(pSock->Name != pMsg->From  )
			{
				SendMsg(pSock, pMsg);
			}
		}
		delete pMsg;
		*/
	}
	else
		delete pSocket;

}

void CServerDoc::ProcessRecieveMessage(CServiceSocket *pSocket)
{
	CServiceSocket *pSocketTemp;
	CString m_strAddrTemp;
	long	m_nPortTemp;
	CServiceSocket *pSock;
	POSITION posname;
	CMessage* pMsg;

	if (pSocket == NULL)
		return;
	try
	{

	do{
		pMsg = ReadMsg(pSocket);
		if(pMsg == NULL) 
			return;
		switch(pMsg->Type)
		{
		case 1:
			pSocket->Name = pMsg->From ;
			for( posname=m_connectionList.GetHeadPosition();posname;)
			{				
				pSock = (CServiceSocket *)m_connectionList.GetNext(posname);
				if(pSock->Name != pMsg->From  )
				{
					SendMsg(pSock, pMsg);
				}
			}
			break;
		case 2:
			pMsg->ShortMessage = "Go with the wind ....";
			pMsg->To = "";
			for( posname=m_connectionList.GetHeadPosition();posname;)
			{				
				pSock = (CServiceSocket *)m_connectionList.GetNext(posname);
				if(pSock->Name == pMsg->From  )
				{
					CloseSocket(pSock);
				}
				else
				{
					SendMsg(pSock, pMsg);
				}
			}
			break;
		
		case 3:
			for( posname=m_connectionList.GetHeadPosition();posname;)
			{				
				pSock = (CServiceSocket *)m_connectionList.GetNext(posname);
				if(pSock->Name == pMsg->To )
				{
					SendMsg(pSock, pMsg);
					break;
				}
			}
			break;

		case 4:
			pMsg->To = "";
			for( posname=m_connectionList.GetHeadPosition();posname;)
			{				
				pSock = (CServiceSocket *)m_connectionList.GetNext(posname);
				if(pSock->Name != pMsg->From )
				{
					SendMsg(pSock, pMsg);
				}
			}
			break;
		case 5:
			//pSocket->Name = pMsg->From ;
			pMsg->ShortMessage = "";
			for( posname=m_connectionList.GetHeadPosition();posname;)
			{				
				pSock = (CServiceSocket *)m_connectionList.GetNext(posname);
				pMsg->ShortMessage = pMsg->ShortMessage + pSock->Name;
				pMsg->ShortMessage = pMsg->ShortMessage + "##";
			}
			SendMsg(pSocket, pMsg);
			break;

		case 6:
			for( posname=m_connectionList.GetHeadPosition();posname;)
			{				
				pSock = (CServiceSocket *)m_connectionList.GetNext(posname);
				if (pSock->Name == pMsg->To)
				{
					//pSock->GetPeerName(m_strAddrTemp,(unsigned long &) &m_nPortTemp);
					pMsg->ShortMessage = m_strAddrTemp;
				}
			}
			SendMsg(pSocket, pMsg);
			break;
		}

		DisplayMsg(pMsg->Type ,pMsg->From ,pMsg->To ,pMsg->ShortMessage );

	}while (!pSocket->m_pArchiveIn->IsBufferEmpty());

	}
	catch(...)
	{
		CString m_strTemp01;
		m_strTemp01 = "";
		for( posname=m_connectionList.GetHeadPosition();posname;)
		{				
			pSock = (CServiceSocket *)m_connectionList.GetNext(posname);
			m_strTemp01 = m_strTemp01 + pSock->Name;
			m_strTemp01 = m_strTemp01 + "##";
		}

		for( posname=m_connectionList.GetHeadPosition();posname;)
		{				
			pSock = (CServiceSocket *)m_connectionList.GetNext(posname);
			if (pSock->Name == pMsg->To)
			{
				//pSock->GetPeerName(m_strAddrTemp,(unsigned long &) &m_nPortTemp);
				CloseSocket(pSock);
				
			}
			else
			{
				pMsg->ShortMessage = "Logout";
				pMsg->Type = 2;
				pMsg->From = pSock->Name ;
				pMsg->To = pSock->Name;
				SendMsg(pSock, pMsg);

				pMsg->ShortMessage = m_strTemp01;
				pMsg->Type = 5;
				pMsg->From = "Server";
				pMsg->To = pSock->Name;
				SendMsg(pSock, pMsg);
			}
		}


	}

}


void CServerDoc::SendMsg(CServiceSocket *pSocket, CMessage *pMessage)
{
	pSocket->SendMsg(pMessage);
}

CMessage* CServerDoc::ReadMsg(CServiceSocket *pSocket)
{
	pSocket->ReceiveMsg(m_pShortMessage);

	return m_pShortMessage;

}


void CServerDoc::DisplayString(LPCTSTR lpszMessage)
{
	((CServerView*)m_viewList.GetHead())->DisplayString(lpszMessage);

}

void CServerDoc::DisplayStringWithCRLF(LPCTSTR lpszMessage)
{
	((CServerView*)m_viewList.GetHead())->DisplayStringWithCRLF(lpszMessage);
}

void CServerDoc::CloseSocket(CServiceSocket *pSocket)
{
	pSocket->Close();

	POSITION pos,temp;
	for(pos = m_connectionList.GetHeadPosition(); pos != NULL;)
	{
		temp = pos;
		CServiceSocket* pSock = (CServiceSocket *)m_connectionList.GetNext(pos);
		if (pSock == pSocket){
			m_connectionList.RemoveAt(temp);
			break;
		}
	}

	delete pSocket;
	pSocket = NULL;
}

void CServerDoc::DisplayMsg(int Type, CString From, CString To, CString ShortMessage)
{
	DisplayString(From);
	DisplayString(" say towards ");
	DisplayString(To);
	DisplayString(" : ");
	DisplayString(ShortMessage);
	DisplayString("\r\n");

}

void CServerDoc::DeleteContents() 
{
	// TODO: Add your specialized code here and/or call the base class
	delete m_pSocket;
	m_pSocket = NULL;

	CString temp;
	temp="Server has been shutdown!";
	
	CMessage* pMsg = new CMessage;
	while(!m_connectionList.IsEmpty())
	{
		CServiceSocket* pSocket = (CServiceSocket *)m_connectionList.RemoveHead();
		if(pSocket==NULL ) 
			continue;
		if (pMsg == NULL) 
			continue;
		pMsg->From = pSocket->Name ;
		pMsg->ShortMessage  = _TEXT("Server has been shutdown!");
		pMsg->To = _TEXT("All");
		pMsg->Type = 9;

		SendMsg(pSocket, pMsg);
		
		if(!pSocket->IsAborted())
		{
			pSocket->ShutDown();
			BYTE Buffer[50];
			while (pSocket->Receive(Buffer,50) > 0);
			delete pSocket;
		}
	}
	delete pMsg;

	if (!m_viewList.IsEmpty())
		((CEditView*)m_viewList.GetHead())->SetWindowText(_T(""));
	
	CDocument::DeleteContents();
}


void CServerDoc::OnConfig() 
{
	// TODO: Add your command handler code here
	CParamDlg m_dlgParam;
	m_dlgParam.m_nPort = m_nPort;
	if (m_dlgParam.DoModal() == IDOK)
	{
		m_nPort = m_dlgParam.m_nPort ;

		CString temp;
		temp="Server has been shutdown!";
		
		CMessage* pMsg = new CMessage;
		while(!m_connectionList.IsEmpty())
		{
			CServiceSocket* pSocket = (CServiceSocket *)m_connectionList.RemoveHead();
			if(pSocket==NULL ) 
				continue;
			if (pMsg == NULL) 
				continue;
			pMsg->From = pSocket->Name ;
			pMsg->ShortMessage  = _TEXT("Server has been shutdown!");
			pMsg->To = _TEXT("All");
			pMsg->Type = 9;

			SendMsg(pSocket, pMsg);
			
			if(!pSocket->IsAborted())
			{
				pSocket->ShutDown();
				BYTE Buffer[50];
				while (pSocket->Receive(Buffer,50) > 0);
				delete pSocket;
			}
		}
		delete pMsg;

		delete m_pSocket;

		m_pSocket = new CAcceptSocket(this);
		if (m_pSocket->Create(m_nPort)){
			if (m_pSocket->Listen())
				return ;
	}

	}
	
}
