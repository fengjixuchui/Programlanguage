#if !defined(AFX_ACCEPTSOCKET_H__B08A4DEC_C78C_443D_BA14_C8C6C9BF6189__INCLUDED_)
#define AFX_ACCEPTSOCKET_H__B08A4DEC_C78C_443D_BA14_C8C6C9BF6189__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AcceptSocket.h : header file
//
class CServerDoc;
/////////////////////////////////////////////////////////////////////////////
// CAcceptSocket command target

class CAcceptSocket : public CSocket
{
	DECLARE_DYNAMIC(CAcceptSocket);
private:
	CAcceptSocket( const CAcceptSocket& sSrc);
	CAcceptSocket& operator=( const CAcceptSocket& sSrc);
// Attributes
public:
// Operations
public:
	CAcceptSocket(CServerDoc *pDoc);
	virtual ~CAcceptSocket();

// Overrides
public:
	CServerDoc* m_pDoc;
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAcceptSocket)
	public:
	virtual void OnAccept(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CAcceptSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ACCEPTSOCKET_H__B08A4DEC_C78C_443D_BA14_C8C6C9BF6189__INCLUDED_)
