#if !defined(AFX_SERVICESOCKET_H__E0DEAA9A_6813_4106_BD43_572C2FA38DB2__INCLUDED_)
#define AFX_SERVICESOCKET_H__E0DEAA9A_6813_4106_BD43_572C2FA38DB2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ServiceSocket.h : header file
//

class CServerDoc;
class CMessage;

/////////////////////////////////////////////////////////////////////////////
// CServiceSocket command target

class CServiceSocket : public CSocket
{
	DECLARE_DYNAMIC(CServiceSocket);
// Attributes
public:

// Operations
public:
	//CServiceSocket(){}
	CServiceSocket(CServerDoc *pDoc);
	virtual ~CServiceSocket();
	void Init();
	void Abort();
	void SendMsg(CMessage* pMsg);
	void ReceiveMsg(CMessage* pMsg);
	BOOL IsAborted() { return m_pArchiveOut == NULL; }
private:
	CServiceSocket( const CServiceSocket& sSrc);
	CServiceSocket& operator=( const CServiceSocket& sSrc);
// Overrides
public:
	CString Name;
	CServerDoc* m_pDoc;
	CSocketFile* m_pFile;
	CArchive* m_pArchiveIn;
	CArchive* m_pArchiveOut;

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServiceSocket)
	public:
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CServiceSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVICESOCKET_H__E0DEAA9A_6813_4106_BD43_572C2FA38DB2__INCLUDED_)
