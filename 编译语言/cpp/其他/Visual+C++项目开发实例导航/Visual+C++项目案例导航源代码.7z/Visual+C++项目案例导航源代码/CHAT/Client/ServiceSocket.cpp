// ChatSocket.cpp : implementation file
//

#include "stdafx.h"
#include "Client.h"
#include "ServiceSocket.h"

#include "Message.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "UserDlg.h"

#define SAFEDELETE(x) if(x!=NULL){delete x;x=NULL;}


/////////////////////////////////////////////////////////////////////////////
// CServiceSocket
class CUserDlg;

CServiceSocket::CServiceSocket(CUserDlg* pDlg)
{
	m_pDlg = pDlg;
}

CServiceSocket::~CServiceSocket()
{
	SAFEDELETE(m_pArchiveIn);
	SAFEDELETE(m_pArchiveOut);
	SAFEDELETE(m_pFile);

}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CServiceSocket, CSocket)
	//{{AFX_MSG_MAP(CServiceSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CServiceSocket member functions

void CServiceSocket::OnReceive(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CSocket::OnReceive(nErrorCode);
	m_pDlg->ProcessReadMessage();
}

void CServiceSocket::Init()
{
	m_pFile = new CSocketFile(this);
	m_pArchiveIn = new CArchive(m_pFile,CArchive::load);
	m_pArchiveOut = new CArchive(m_pFile,CArchive::store);
}

void CServiceSocket::ReceiveMsg(CMessage *pMsg)
{
	pMsg->Serialize(*m_pArchiveIn);
}

void CServiceSocket::SendMsg(CMessage *pMsg)
{
	if (m_pArchiveOut != NULL){
		pMsg->Serialize(*m_pArchiveOut);
		m_pArchiveOut->Flush();
	}
}

BOOL CServiceSocket::OnMessagePending() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CSocket::OnMessagePending();
}

void CServiceSocket::OnClose(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	CMessage *m_pCloseMsg;
	m_pCloseMsg = new CMessage();
	m_pCloseMsg->From = Name;
	m_pCloseMsg->To = "All";
	m_pCloseMsg->Type = 2;
	m_pCloseMsg->ShortMessage = "Logout!";
	
	SendMsg(m_pCloseMsg);

	delete m_pCloseMsg;

	CSocket::OnClose(nErrorCode);
}
