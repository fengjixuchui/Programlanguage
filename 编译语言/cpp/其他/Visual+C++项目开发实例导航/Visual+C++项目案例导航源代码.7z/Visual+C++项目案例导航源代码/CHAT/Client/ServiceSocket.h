#if !defined(AFX_CHATSOCKET_H__945FCEC1_0678_47E0_BD38_0572AEDCAE60__INCLUDED_)
#define AFX_CHATSOCKET_H__945FCEC1_0678_47E0_BD38_0572AEDCAE60__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CServiceSocket.h : header file
//

class CMessage;
class CUserDlg;

/////////////////////////////////////////////////////////////////////////////
// CServiceSocket command target

class CServiceSocket : public CSocket
{
// Attributes
public:

// Operations
public:
	CServiceSocket(CUserDlg* pDlg);
	virtual ~CServiceSocket();
	void Init();
	void SendMsg(CMessage* pMsg);
	void ReceiveMsg(CMessage* pMsg);

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServiceSocket)
	public:
	virtual void OnReceive(int nErrorCode);
	virtual BOOL OnMessagePending();
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CServiceSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
public:
	CUserDlg* m_pDlg;
	CString Name;
	CSocketFile* m_pFile;
	CArchive* m_pArchiveIn;
	CArchive* m_pArchiveOut;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHATSOCKET_H__945FCEC1_0678_47E0_BD38_0572AEDCAE60__INCLUDED_)
