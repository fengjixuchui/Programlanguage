// MsgDlg.cpp : implementation file
//

#include "stdafx.h"
#include "client.h"
#include "MsgDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMsgDlg dialog


CMsgDlg::CMsgDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMsgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMsgDlg)
	m_strFrom = _T("");
	m_strMsg = _T("");
	m_strTo = _T("");
	//}}AFX_DATA_INIT
}


void CMsgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMsgDlg)
	DDX_Text(pDX, IDC_FROM, m_strFrom);
	DDX_Text(pDX, IDC_MESSAGE, m_strMsg);
	DDV_MaxChars(pDX, m_strMsg, 100);
	DDX_Text(pDX, IDC_TO, m_strTo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMsgDlg, CDialog)
	//{{AFX_MSG_MAP(CMsgDlg)
	ON_BN_CLICKED(IDC_REPLY, OnReply)
	ON_BN_CLICKED(IDC_CLOSE, OnClose)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMsgDlg message handlers

void CMsgDlg::OnReply() 
{
	// TODO: Add your control notification handler code here
	if ( !m_bSend)
	{
		GetDlgItem(IDC_REPLY)->SetWindowText("����");
		CString m_strTemp;
		m_strTemp = m_strFrom;
		m_strFrom = m_strTo;
		m_strTo = m_strTemp;
		m_strMsg = "";
		GetDlgItem(IDC_MESSAGE)->EnableWindow(TRUE);
		UpdateData(FALSE);
		m_bSend = TRUE;
	}
	else
	{
		CDialog::OnOK();
	}

}

void CMsgDlg::OnClose() 
{
	// TODO: Add your control notification handler code here
	CDialog::OnCancel();
}

void CMsgDlg::ShowMsg(CString From, CString To, CString Msg, int Type)
{
	if (Type == 3)
		m_strTo = To;
	else
		m_strTo = "";
	m_strFrom = From;
	m_strMsg = Msg;
	UpdateData(FALSE);
}

BOOL CMsgDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	if (m_bSend)
	{
		GetDlgItem(IDC_MESSAGE)->EnableWindow(TRUE);
		GetDlgItem(IDC_REPLY)->SetWindowText("����");
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
