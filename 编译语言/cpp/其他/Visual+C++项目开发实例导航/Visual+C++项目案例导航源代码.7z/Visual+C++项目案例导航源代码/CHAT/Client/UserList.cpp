// UserList.cpp : implementation file
//

#include "stdafx.h"
#include "UserList.h"

#include "Client.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUserList

CUserList::CUserList()
{

}

CUserList::~CUserList()
{
}

BEGIN_MESSAGE_MAP(CUserList, CListCtrl)
	//{{AFX_MSG_MAP(CUserList)
	ON_WM_CREATE()
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblclk)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUserList message handlers
int CUserList::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CListCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	//m_imgList.Create(IDB_IMAGE, 16, 1, RGB(0, 255, 0));
	//HIMAGELIST him = m_imgList.m_hImageList;
	//::SendMessage(this->m_hWnd,LVM_SETIMAGELIST,(WPARAM)LVSIL_SMALL,(LPARAM)him);
	//ImageList_SetBkColor(him,CLR_NONE);

	return 0;
}

void CUserList::AddItem(short i, char* Name, char* Text)
{
	LVITEM			lvi;

	lvi.mask = LVIF_TEXT | LVIF_IMAGE | LVIF_PARAM;
	lvi.iItem = GetItemCount();
    //lvi.iImage = i;
	lvi.iSubItem = 0;
	lvi.pszText = Name;
	lvi.cchTextMax = 64;
	lvi.lParam = 0;
	InsertItem(&lvi);

	lvi.mask = LVIF_TEXT;
	lvi.pszText = Text;
	lvi.cchTextMax = 32;
	lvi.iSubItem = 1;
	SetItem(&lvi);
}

void CUserList::OnDblclk(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	CString str;
	int iSel = pNMListView->iItem;
	if (iSel >= 0 ){
		str = GetItemText(iSel,0);
		CWnd* pParentWnd = GetParent();
		if (pParentWnd != NULL)
	       pParentWnd->SendMessage(WM_DBCLICKITEM, 0, (LPARAM)&str);
	}
	*pResult = 0;
}

void CUserList::Remove(char *Name)
{
	CString m_strName;
	for(int i = 0; i < GetItemCount(); i++){
		m_strName = GetItemText(i,0);
		if(strcmp(m_strName, Name) == 0){
			DeleteItem(i);
			break;
		}
	}
}

void CUserList::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CListCtrl::OnLButtonDblClk(nFlags, point);
}

void CUserList::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	/*
	CClientApp* app = (CClientApp*)AfxGetApp();
	HMENU hmenu = LoadMenu(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(IDR_POPUP));
	HMENU hpopup = GetSubMenu(hmenu, 0);
	switch (TrackPopupMenu(hpopup,            // Popup menu to track
		TPM_RETURNCMD |    // Return menu code
		TPM_RIGHTBUTTON,   // Track right mouse button?
		point.x, point.y,        // screen coordinates
		0,                 // reserved
		this->m_hWnd,            // owner
		NULL))             // LPRECT user can click in
			// without dismissing menu
		{
		case ID_SENDMSG: 
			SendNotifyMessage(NM_DBLCLK,0,0);
			break;
		}
	*/
	CListCtrl::OnRButtonDown(nFlags, point);
}
