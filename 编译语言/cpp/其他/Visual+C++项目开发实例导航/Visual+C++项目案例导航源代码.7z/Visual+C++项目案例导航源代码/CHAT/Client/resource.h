//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Client.rc
//
#define IDD_CLIENT_DIALOG               102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDC_LISTBOX                     104
#define ID_SYSTRAY                      105
#define IDR_MAINFRAME                   128
#define IDD_USERLIST                    129
#define IDR_MENUTRAY                    130
#define IDR_POPUP                       131
#define IDD_RCVMSG                      132
#define IDC_USERNAME                    1000
#define IDC_PASSWORD                    1001
#define IDC_CONFIRM                     1002
#define IDC_CANCEL                      1003
#define IDC_FROM                        1003
#define IDC_TO                          1004
#define IDC_ADDRESS                     1004
#define IDC_MESSAGE                     1005
#define IDC_PORT                        1005
#define IDC_REPLY                       1006
#define IDC_CLOSE                       1007
#define ID_RESTORE                      32771
#define ID_CLOSE                        32772
#define ID_SENDMSG                      32773
#define ID_ONLINE                       32774
#define ID_OFFLINE                      32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
