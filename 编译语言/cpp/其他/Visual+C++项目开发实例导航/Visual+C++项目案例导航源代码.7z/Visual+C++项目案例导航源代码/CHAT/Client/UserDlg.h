#if !defined(AFX_USERDLG_H__ED00CBCE_905A_422A_9652_0752AFB06E3B__INCLUDED_)
#define AFX_USERDLG_H__ED00CBCE_905A_422A_9652_0752AFB06E3B__INCLUDED_


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UserDlg.h : header file
//
#define WM_ADDLIST			WM_USER + 1001
#define WM_DBCLICKITEM		WM_USER + 1003
#define WM_SYSTRAY			WM_USER + 1005

#include "UserList.h"
#include "ServiceSocket.h"

#include "Message.h"
#include "ServiceSocket.h"

/////////////////////////////////////////////////////////////////////////////
// CUserDlg dialog

class CUserDlg : public CDialog
{
// Construction
public:
	void SendCloseMsg();
	CUserList* m_ListCtrl;
	void DisplayMsg();
	void SendMsg();
	void ReceiveMsg();
	void ProcessReadMessage();
	CMessage* m_pMsg;
	BOOL m_bOnline;
	BOOL ConnectToServer();
	unsigned int m_nPort;
	CString m_strAddress;
	CString Name;
	CServiceSocket* m_pSocket;

	NOTIFYICONDATA pnid;
	void AddExStyle(DWORD dwNewStyle);
	CUserDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUserDlg)
	enum { IDD = IDD_USERLIST };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUserDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	
	afx_msg void OnDblClickItem(WPARAM wParam, LPARAM lParam);
	afx_msg void OnRemoveMember(WPARAM wParam, LPARAM lParam);
	afx_msg void OnAddMember(WPARAM wParam, LPARAM lParam);
	afx_msg void OnSysTray(WPARAM wParam,LPARAM lParam);

	// Generated message map functions
	//{{AFX_MSG(CUserDlg)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnCloseDlg();
	afx_msg void OnOffline();
	afx_msg void OnOnline();
	afx_msg void OnRestore();
	afx_msg void OnSendmsg();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USERDLG_H__ED00CBCE_905A_422A_9652_0752AFB06E3B__INCLUDED_)
