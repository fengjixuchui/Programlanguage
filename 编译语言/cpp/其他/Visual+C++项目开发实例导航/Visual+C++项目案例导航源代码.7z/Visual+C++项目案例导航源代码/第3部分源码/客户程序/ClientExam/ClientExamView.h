// ClientExamView.h : interface of the CClientExamView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CLIENTEXAMVIEW_H__BF592397_73A0_42F3_B9E5_DFC3A91BC960__INCLUDED_)
#define AFX_CLIENTEXAMVIEW_H__BF592397_73A0_42F3_B9E5_DFC3A91BC960__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CClientExamView : public CFormView
{
protected: // create from serialization only
	CClientExamView();
	DECLARE_DYNCREATE(CClientExamView)

public:
	//{{AFX_DATA(CClientExamView)
	enum { IDD = IDD_CLIENTEXAM_FORM };
	CButton	m_chkA5;
	CButton	m_chkA4;
	CButton	m_chkA3;
	CButton	m_chkA2;
	CButton	m_chkA1;
	BOOL	m_chkAnswer1;
	BOOL	m_chkAnswer2;
	BOOL	m_chkAnswer3;
	BOOL	m_chkAnswer4;
	BOOL	m_chkAnswer5;
	CString	m_strContent;
	CString	m_strNumber;
	//}}AFX_DATA

// Attributes
public:
	CClientExamDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientExamView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	void MakeVisible();
	void MakeInvisibleAll();
	void MakeUnvisible();
	void SaveAnswer(int  x_nForward);
	void CheckAnswer();
	CString m_strQ1;
	CString m_strQ2;
	CString m_strQ3;
	CString m_strQ4;
	CString m_strQ5;
	int m_nType;
	void GetQuestionInfo();
	void ShowHeader();
	int GetAnswer();
	int m_nAnswer;
	long m_nQID;
	int m_nScore;
	int GetCurrentQuestionNumber();
	int m_nCurrentQuestion;
	void ShowScore();
	int GetScore();
	void GetStudentInfo();
	BOOL CheckFinish();
	BOOL CheckExamExist();
	void ShowMultiplyQuestion();
	void ShowSingleQuestion();
	void ShowLogicQuestion();
	void ShowExam();
	void GenerateExam();
	CString m_strName;
	int m_nSID;
	CString m_strStudentNo;
	virtual ~CClientExamView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CClientExamView)
	afx_msg void OnNext();
	afx_msg void OnFinish();
	afx_msg void OnPrior();
	afx_msg void OnLogin();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnRadio3();
	afx_msg void OnRadio4();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ClientExamView.cpp
inline CClientExamDoc* CClientExamView::GetDocument()
   { return (CClientExamDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTEXAMVIEW_H__BF592397_73A0_42F3_B9E5_DFC3A91BC960__INCLUDED_)
