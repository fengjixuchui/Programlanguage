// Register.cpp : implementation file
//

#include "stdafx.h"
#include "ClientExam.h"
#include "Register.h"
#include "UserInfo.h"
#include "Atlbase.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRegister dialog


CRegister::CRegister(CWnd* pParent /*=NULL*/)
	: CDialog(CRegister::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRegister)
	m_Username = _T("");
	m_StudentNO = _T("");
	m_School = _T("");
	m_Password = _T("");
	m_Name = _T("");
	m_Email = _T("");
	m_Department = _T("");
	m_Class = _T("");
	m_Type = 0;
	m_NameForQ = _T("");
	//}}AFX_DATA_INIT

}


void CRegister::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRegister)
	DDX_Text(pDX, IDC_EDITUserName, m_Username);
	DDX_Text(pDX, IDC_EDITStudentNO, m_StudentNO);
	DDX_Text(pDX, IDC_EDITSchool, m_School);
	DDX_Text(pDX, IDC_EDITPassword, m_Password);
	DDX_Text(pDX, IDC_EDITName, m_Name);
	DDX_Text(pDX, IDC_EDITEmail, m_Email);
	DDX_Text(pDX, IDC_EDITDepartment, m_Department);
	DDX_Text(pDX, IDC_EDITClass, m_Class);

	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRegister, CDialog)
	//{{AFX_MSG_MAP(CRegister)
	ON_BN_CLICKED(IDC_BUTTONINS, OnInsert)
	ON_BN_CLICKED(IDC_BUTTONQUT, OnQuit)
	ON_BN_CLICKED(IDC_RADIOTYPE1, OnRadiotype)
	ON_BN_CLICKED(IDC_RADIOTYPE2, OnRadiotypes)
	ON_BN_CLICKED(IDC_BUTTONDEL, OnDelete)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRegister message handlers

void CRegister::DisplayRecord()
{
/*	IUser m_User;
	if(!m_User.CreateDispatch("UserInfo.User.1"))
	{
		::AfxMessageBox("Create UserInfo failed");
		return;
	}
	m_UserID=m_User.GetUserID();
	m_Username=m_User.GetUsername();
	m_Name=m_User.GetName();
	m_Department=m_User.GetDepartment();
	m_School=m_User.GetSchool();
	if(m_Type)
	{
		m_Class=m_User.GetClass();
		m_StudentNO=m_User.GetStudentNO();

	}
	else
		m_Email=m_User.GetEmail();
	UpdateData(FALSE);    */
}

void CRegister::SetTextState()
{  /*
	CWnd  *pWnd;
	if(m_edit)
	{
		pWnd=GetDlgItem(IDC_EditCLass);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_EditDepartment);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_EditEmail);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_EditName);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_EditPassword);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_EditSchool);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_EditStudentNO);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_EditUsername);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_RadioTCH);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_RadioSTD);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_EditUserID);
		pWnd->EnableWindow(FALSE);
	}
	else
	{
		pWnd=GetDlgItem(IDC_EditCLass);
		pWnd->EnableWindow(FALSE);
		pWnd=GetDlgItem(IDC_EditDepartment);
		pWnd->EnableWindow(FALSE);
		pWnd=GetDlgItem(IDC_EditEmail);
		pWnd->EnableWindow(FALSE);
		pWnd=GetDlgItem(IDC_EditName);
		pWnd->EnableWindow(FALSE);
		pWnd=GetDlgItem(IDC_EditPassword);
		pWnd->EnableWindow(FALSE);
		pWnd=GetDlgItem(IDC_EditSchool);
		pWnd->EnableWindow(FALSE);
		pWnd=GetDlgItem(IDC_EditStudentNO);
		pWnd->EnableWindow(FALSE);
		pWnd=GetDlgItem(IDC_EditUsername);
		pWnd->EnableWindow(FALSE);
		pWnd=GetDlgItem(IDC_EditUserID);
		pWnd->EnableWindow(TRUE);
	}  */
}

void CRegister::SetButtonState()
{
/*	CWnd	*pWnd;
	if(m_edit)
	{
		pWnd=GetDlgItem(IDC_ButtonINS);
		pWnd->EnableWindow(FALSE);
		pWnd=GetDlgItem(IDC_ButtonDEL);
		pWnd->EnableWindow(FALSE);
		pWnd=GetDlgItem(IDC_ButtonMOD);
		pWnd->EnableWindow(fALSE);
		pWnd=GetDlgItem(IDC_ButtonSAV);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_ButtonCAL);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_ButtonQRY);
		pWnd->EnableWindow(FALSE);
	
		return ;
	}
	else
	{
		pWnd=GetDlgItem(IDC_ButtonINS);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_ButtonDEL);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_ButtonMOD);
		pWnd->EnableWindow(TRUE);
		pWnd=GetDlgItem(IDC_ButtonSAV);
		pWnd->EnableWindow(FALSE);
		pWnd=GetDlgItem(IDC_ButtonCAL);
		pWnd->EnableWindow(FALSE);
		pWnd=GetDlgItem(IDC_ButtonQRY);
		pWnd->EnableWindow(TRUE);
	}    */
}

void CRegister::OnInsert() 
{
	
	IUser   m_User;
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if(!m_User.CreateDispatch("USERINFO.USER.1"))
	{
		::AfxMessageBox("Create UserInfo error");
		return;
	}

	if((m_Username=="")||(m_Name==""))
	{
		::AfxMessageBox("�û�������������Ϊ��!");
		return ;
	}
	m_User.SetUsername(m_Username);
	m_User.SetName(m_Name);
	m_User.SetPassword(m_Password);
	m_User.SetSchool(m_School);
	m_User.SetDepartment(m_Department);
	if(!m_Type)
	{
		m_User.SetStudentNO(m_StudentNO);
		m_User.SetClass(m_Class);
	}
	else
		m_User.SetEmail(m_Email);
	m_User.InsertUserInfo(m_Type);
	m_User.ReleaseDispatch();

	::AfxMessageBox("Succeed in inserting Student Infomation");

	m_Class="";
	m_Department="";
	m_Email="";
	m_Name="";
	m_Password="";
	m_School="";
	m_StudentNO="";
	m_Username="";
	UpdateData(FALSE);
}

void CRegister::OnQuit() 
{
	// TODO: Add your control notification handler code here
	CDialog::OnCancel();
	
}

void CRegister::OnRadiotype() 
{
	// TODO: Add your control notification handler code here
	CWnd *pWnd;
	m_Type=1;
	((CButton *)GetDlgItem(IDC_RADIOTYPE2))->SetCheck(0);
	m_Class="";
	m_StudentNO="";
	UpdateData(FALSE);
	pWnd=GetDlgItem(IDC_EDITClass);
	pWnd->EnableWindow(FALSE);
	pWnd=GetDlgItem(IDC_EDITStudentNO);
	pWnd->EnableWindow(FALSE);
	pWnd=GetDlgItem(IDC_EDITEmail);
	pWnd->EnableWindow(TRUE);
	
}

void CRegister::OnRadiotypes() 
{
	// TODO: Add your control notification handler code here
	CWnd *pWnd;
	m_Type=0;
	((CButton *)GetDlgItem(IDC_RADIOTYPE1))->SetCheck(0);
	pWnd=GetDlgItem(IDC_EDITClass);
	pWnd->EnableWindow(TRUE);
	pWnd=GetDlgItem(IDC_EDITStudentNO);
	pWnd->EnableWindow(TRUE);
	m_Email="";
	UpdateData(FALSE);
	pWnd=GetDlgItem(IDC_EDITEmail);
	pWnd->EnableWindow(FALSE);
	
}



void CRegister::OnDelete() 
{
	// TODO: Add your control notification handler code here
	IUser m_User;

	if(!m_User.CreateDispatch("UserInfo.User.1"))
	{
		::AfxMessageBox(" Create User failed!");
		return;
	}

	UpdateData(TRUE);
	CComBSTR	m_bstrTemp;
	m_bstrTemp.Append(m_NameForQ);
	if((m_Type!=0)&&(m_Type!=1))
	{
		::AfxMessageBox("Choosing the type of the User!");
		return;
	}
	if(m_Username=="")
	{
		::AfxMessageBox("Pls Input the proper Username!");
		return;
	}

	m_User.GetUser(m_Type,m_Username);
	m_UserID=m_User.GetUserID();

	m_User.DeleteUserInfo(m_Type,m_UserID);

	::AfxMessageBox("Succeed in deleting Student Infomation");

	m_Class="";
	m_Department="";
	m_Email="";
	m_Name="";
	m_Password="";
	m_School="";
	m_StudentNO="";
	m_Username="";
	UpdateData(FALSE);
	m_User.ReleaseDispatch();
	
}
