// ClientExamView.cpp : implementation of the CClientExamView class
//

#include "stdafx.h"
#include "ClientExam.h"

#include "ClientExamDoc.h"
#include "ClientExamView.h"

#include "Login.h"

#include "Exam.h"
#include "QuestionInfo.h"
//#include "UserInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClientExamView

IMPLEMENT_DYNCREATE(CClientExamView, CFormView)

BEGIN_MESSAGE_MAP(CClientExamView, CFormView)
	//{{AFX_MSG_MAP(CClientExamView)
	ON_BN_CLICKED(IDC_NEXT, OnNext)
	ON_BN_CLICKED(IDC_FINISH, OnFinish)
	ON_BN_CLICKED(IDC_PRIOR, OnPrior)
	ON_COMMAND(ID_LOGIN, OnLogin)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	ON_BN_CLICKED(IDC_RADIO4, OnRadio4)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientExamView construction/destruction

CClientExamView::CClientExamView()
	: CFormView(CClientExamView::IDD)
{
	//{{AFX_DATA_INIT(CClientExamView)
	m_chkAnswer1 = FALSE;
	m_chkAnswer2 = FALSE;
	m_chkAnswer3 = FALSE;
	m_chkAnswer4 = FALSE;
	m_chkAnswer5 = FALSE;
	m_strContent = _T("");
	m_strNumber = _T("");
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CClientExamView::~CClientExamView()
{
}

void CClientExamView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClientExamView)
	DDX_Control(pDX, IDC_CHECK5, m_chkA5);
	DDX_Control(pDX, IDC_CHECK4, m_chkA4);
	DDX_Control(pDX, IDC_CHECK3, m_chkA3);
	DDX_Control(pDX, IDC_CHECK2, m_chkA2);
	DDX_Control(pDX, IDC_CHECK1, m_chkA1);
	DDX_Check(pDX, IDC_CHECK1, m_chkAnswer1);
	DDX_Check(pDX, IDC_CHECK2, m_chkAnswer2);
	DDX_Check(pDX, IDC_CHECK3, m_chkAnswer3);
	DDX_Check(pDX, IDC_CHECK4, m_chkAnswer4);
	DDX_Check(pDX, IDC_CHECK5, m_chkAnswer5);
	DDX_Text(pDX, IDC_CONTENT, m_strContent);
	DDX_Text(pDX, IDC_NUMBER, m_strNumber);
	//}}AFX_DATA_MAP
}

BOOL CClientExamView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CClientExamView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
	MakeInvisibleAll();

	if(!AfxOleInit())
	{
		AfxMessageBox("Error in ole initalized!");
	}

}

/////////////////////////////////////////////////////////////////////////////
// CClientExamView diagnostics

#ifdef _DEBUG
void CClientExamView::AssertValid() const
{
	CFormView::AssertValid();
}

void CClientExamView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CClientExamDoc* CClientExamView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CClientExamDoc)));
	return (CClientExamDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CClientExamView message handlers

void CClientExamView::OnNext() 
{
	// TODO: Add your control notification handler code here
	CheckAnswer();
	SaveAnswer(1);

	if(m_nCurrentQuestion >= 80)
	{
		return;
	}
	else
	{
		m_nCurrentQuestion++;
	}
	ShowExam();
	
}

void CClientExamView::OnFinish() 
{
	// TODO: Add your control notification handler code here
	ICaculateScore m_CalculateScore;
	m_CalculateScore.CreateDispatch("Exam.CaculateScore.1");
	m_CalculateScore.CaculateScore(m_nSID);
	m_nScore=m_CalculateScore.GetScore(m_nSID);
	m_CalculateScore.ReleaseDispatch();
	ShowScore();
}

void CClientExamView::OnPrior() 
{
	// TODO: Add your control notification handler code here
	CheckAnswer();
	SaveAnswer(0);
	if(m_nCurrentQuestion <= 1)
	{
		return;
	}
	else
	{
		m_nCurrentQuestion--;
	}
	ShowExam();
}

void CClientExamView::OnLogin() 
{
	// TODO: Add your command handler code here
	CLogin m_dlgLogin;
	if (m_dlgLogin.DoModal() != IDOK)
		return;
	m_strStudentNo = m_dlgLogin.m_strStudentNo;
	m_nSID = m_dlgLogin.m_nSID;
	//m_strStudentNo = "44444444";
	//m_strName = "TEST";
	//m_nSID =4;

	//GetStudentInfo();

	if (!CheckExamExist())
	{
		GenerateExam();
	}
	if(CheckFinish())
	{
		m_nScore = GetScore();
		ShowScore();
		return;
	}

	m_nCurrentQuestion = GetCurrentQuestionNumber();
	if (m_nCurrentQuestion == -1)
		return;


	ShowExam();

	
}

void CClientExamView::GenerateExam()
{
	IGenerateExam m_GenerateExam;
	if(!m_GenerateExam.CreateDispatch("Exam.GenerateExam.1"))
	{
		::AfxMessageBox("Couldn't Create component");
		return;
	}
	AfxMessageBox(m_GenerateExam.GenerateExam(m_nSID));
	m_GenerateExam.ReleaseDispatch();
}

void CClientExamView::ShowExam()
{
	GetAnswer();

	IExamState m_ExamState;
	if(!m_ExamState.CreateDispatch("Exam.ExamState.1"))
	{
		AfxMessageBox("Couldn't create Check component!");
		return ;
	}
	m_ExamState.GetExamDetail(m_nSID, m_nCurrentQuestion);
	m_nType=m_ExamState.GetQType();
	m_nQID=m_ExamState.GetQid();
	m_ExamState.ReleaseDispatch();

	GetQuestionInfo();

	MakeUnvisible();
	MakeVisible();
	
	switch(m_nType)
	{
	case 0:
		ShowLogicQuestion();
		break;
	case 1:
		ShowSingleQuestion();
		break;
	case 2:
		ShowMultiplyQuestion();
		break;
	}

}

void CClientExamView::ShowLogicQuestion()
{
	ShowHeader();
	((CButton *)GetDlgItem(IDC_RADIO1))->SetWindowText(m_strQ1);
	((CButton *)GetDlgItem(IDC_RADIO2))->SetWindowText(m_strQ2);

	if (m_nAnswer == 1)
		((CButton *)GetDlgItem(IDC_RADIO1))->CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO1);

	if (m_nAnswer == 2)
		((CButton *)GetDlgItem(IDC_RADIO2))->CheckRadioButton(IDC_RADIO1, IDC_RADIO2, IDC_RADIO2);

	((CButton *)GetDlgItem(IDC_RADIO1))->ShowWindow(SW_SHOW);
	((CButton *)GetDlgItem(IDC_RADIO2))->ShowWindow(SW_SHOW);



}

void CClientExamView::ShowSingleQuestion()
{
	ShowHeader();
	((CButton *)GetDlgItem(IDC_RADIO1))->SetWindowText(m_strQ1);
	((CButton *)GetDlgItem(IDC_RADIO2))->SetWindowText(m_strQ2);
	((CButton *)GetDlgItem(IDC_RADIO3))->SetWindowText(m_strQ3);
	((CButton *)GetDlgItem(IDC_RADIO4))->SetWindowText(m_strQ4);

	if (m_nAnswer == 1)
		((CButton *)GetDlgItem(IDC_RADIO1))->CheckRadioButton(IDC_RADIO1, IDC_RADIO4, IDC_RADIO1);

	if (m_nAnswer == 2)
		((CButton *)GetDlgItem(IDC_RADIO2))->CheckRadioButton(IDC_RADIO1, IDC_RADIO4, IDC_RADIO2);

	if (m_nAnswer == 4)
		((CButton *)GetDlgItem(IDC_RADIO3))->CheckRadioButton(IDC_RADIO1, IDC_RADIO4, IDC_RADIO3);

	if (m_nAnswer == 8)
		((CButton *)GetDlgItem(IDC_RADIO4))->CheckRadioButton(IDC_RADIO1, IDC_RADIO4, IDC_RADIO4);

	((CButton *)GetDlgItem(IDC_RADIO1))->ShowWindow(SW_SHOW);
	((CButton *)GetDlgItem(IDC_RADIO2))->ShowWindow(SW_SHOW);
	((CButton *)GetDlgItem(IDC_RADIO3))->ShowWindow(SW_SHOW);
	((CButton *)GetDlgItem(IDC_RADIO4))->ShowWindow(SW_SHOW);

}

void CClientExamView::ShowMultiplyQuestion()
{
	ShowHeader();
	m_chkA1.SetWindowText(m_strQ1);
	m_chkA2.SetWindowText(m_strQ2);
	m_chkA3.SetWindowText(m_strQ3);
	m_chkA4.SetWindowText(m_strQ4);
	m_chkA5.SetWindowText(m_strQ5);

	m_chkA1.ShowWindow(SW_SHOW);
	m_chkA2.ShowWindow(SW_SHOW);
	m_chkA3.ShowWindow(SW_SHOW);
	m_chkA4.ShowWindow(SW_SHOW);
	m_chkA5.ShowWindow(SW_SHOW);

	int m_nTemp = m_nAnswer;
	if(m_nTemp >= 16)
		m_chkA5.SetCheck(1);
	else
		m_chkA5.SetCheck(0);


	m_nTemp = m_nAnswer % 16;
	if(m_nTemp >= 8)
		m_chkA4.SetCheck(1);
	else
		m_chkA4.SetCheck(0);

	m_nTemp = m_nAnswer % 8;
	if(m_nTemp >= 4)
		m_chkA3.SetCheck(1);
	else
		m_chkA3.SetCheck(0);

	m_nTemp = m_nAnswer % 4;
	if(m_nTemp >= 2)
		m_chkA2.SetCheck(1);
	else
		m_chkA2.SetCheck(0);

	m_nTemp = m_nAnswer % 2;
	if(m_nTemp >= 1)
		m_chkA1.SetCheck(1);
	else
		m_chkA1.SetCheck(0);
	
}

BOOL CClientExamView::CheckExamExist()
{
	IExamState m_CheckExist;
	BOOL m_bResult = FALSE;

	if(!m_CheckExist.CreateDispatch("EXAM.ExamState.1"))
	{
		::AfxMessageBox("Create Component failed");
		return true;
	}
	CString m_strResult = m_CheckExist.CheckExist(m_nSID);
	if(m_strResult.GetAt(0) == 'Y')
		m_bResult = TRUE;
	else
		m_bResult = FALSE;
	m_CheckExist.ReleaseDispatch();
	return m_bResult;
}

BOOL CClientExamView::CheckFinish()
{
	IExamState m_CheckFinish;
	BOOL m_bResult;

	if(!m_CheckFinish.CreateDispatch("Exam.ExamState.1"))
	{
		AfxMessageBox("Couldn't create Check component!");
		return TRUE;
	}
	CString m_strResult = m_CheckFinish.CheckFinish(m_nSID);
	if (m_strResult.GetAt(0) == 'Y')
		m_bResult = TRUE;
	else
	{
		AfxMessageBox(m_strResult.GetBuffer(2));
		m_bResult = FALSE;
	}
	m_CheckFinish.ReleaseDispatch();
	return m_bResult;

}

void CClientExamView::GetStudentInfo()
{
	IUser m_StudentInfo;
	if(!m_StudentInfo.CreateDispatch("UserInfo.User.1"))
	{
		AfxMessageBox("Couldn't create studentinfo component!");
		return;
	}
	m_StudentInfo.GetUserInfo(0,m_nSID);
	m_strName = m_StudentInfo.GetUsername();
	m_StudentInfo.ReleaseDispatch();
	
}

int CClientExamView::GetScore()
{
	ICaculateScore m_GetScore;
	int m_nResult;
	m_GetScore.CreateDispatch("Exam.CaculateScore.1");
	m_nResult = m_GetScore.GetScore(m_nSID);
	m_GetScore.ReleaseDispatch();
	return m_nResult;

}

void CClientExamView::ShowScore()
{
	CString m_strResult;
	m_strResult = m_strName;
	m_strResult += "'s score is :";
	char m_szBuf[10];
	_itoa(m_nScore, m_szBuf, 10);
	m_strResult += m_szBuf;

	AfxMessageBox(m_strResult);

}

int CClientExamView::GetCurrentQuestionNumber()
{
	IExamState m_ExamState;
	if(!m_ExamState.CreateDispatch("Exam.ExamState.1"))
	{
		AfxMessageBox("Couldn't create Check component!");
		return TRUE;
	}
	m_nCurrentQuestion = m_ExamState.GetCurrentQuestion(m_nSID);
	//m_ExamState.GetCurrentQuestion(m_nSID);
	m_ExamState.ReleaseDispatch();
	return m_nCurrentQuestion;
}


int CClientExamView::GetAnswer()
{
	IExamState m_ExamState;
	if(!m_ExamState.CreateDispatch("Exam.ExamState.1"))
	{
		AfxMessageBox("Couldn't create Check component!");
		return TRUE;
	}
	m_nAnswer = m_ExamState.GetAnswer(m_nSID, m_nCurrentQuestion);
	m_ExamState.ReleaseDispatch();
	return m_nAnswer;

}

void CClientExamView::ShowHeader()
{
	char m_szBuf[10];
	_itoa(m_nCurrentQuestion, m_szBuf, 10);

	CString m_strTemp(m_szBuf);

	m_strNumber = "No. " + m_strTemp;
	UpdateData(FALSE);

}

void CClientExamView::GetQuestionInfo()
{
	IQuestion m_Question;
	if(!m_Question.CreateDispatch("QuestionInfo.Question.1"))
	{
		::AfxMessageBox("Create Component failed");
		return;
	}
	m_Question.GetQuestion(m_nType, m_nQID);
	m_strContent = m_Question.GetContent();
	if(m_nType == 0)
	{
		m_strQ1 = "TRUE";
		m_strQ2 = "FALSE";
	}
	else
	{
		if(m_nType >= 1)
		{
			m_strQ1 = m_Question.GetQ1() ;
			m_strQ2 = m_Question.GetQ2() ;
			m_strQ3 = m_Question.GetQ3() ;
			m_strQ4 = m_Question.GetQ4() ;
		}
		if (m_nType == 2)
		{
			m_strQ5 = m_Question.GetQ5() ;
		}
		
	}
	m_Question.ReleaseDispatch();

}

void CClientExamView::OnRadio1() 
{
	// TODO: Add your control notification handler code here
	m_nAnswer = 1;
	
}

void CClientExamView::OnRadio2() 
{
	// TODO: Add your control notification handler code here
	m_nAnswer = 4;
	
}

void CClientExamView::OnRadio3() 
{
	// TODO: Add your control notification handler code here
	m_nAnswer = 8;
	
}

void CClientExamView::OnRadio4() 
{
	// TODO: Add your control notification handler code here
	m_nAnswer = 16;
}

void CClientExamView::CheckAnswer()
{
	if (m_nType != 2)
		return;
	m_nAnswer = 0;
	if (m_chkA1.GetCheck() == 1)
		m_nAnswer += 1;

	if (m_chkA2.GetCheck() == 1)
		m_nAnswer += 2;

	if (m_chkA3.GetCheck() == 1)
		m_nAnswer += 4;

	if (m_chkA4.GetCheck() == 1)
		m_nAnswer += 8;

	if (m_chkA5.GetCheck() == 1)
		m_nAnswer += 16;

}


void CClientExamView::SaveAnswer(int  x_nForward)
{
	ISaveCurrentAnswer m_SaveCurrentAnswer;
	if(!m_SaveCurrentAnswer.CreateDispatch("Exam.SaveCurrentAnswer.1"))
	{
		::AfxMessageBox("Create Component failed");
		return;
	}
	m_SaveCurrentAnswer.SaveAnswer(m_nSID, m_nCurrentQuestion, m_nAnswer, 120, x_nForward);
	m_SaveCurrentAnswer.ReleaseDispatch();

}

void CClientExamView::MakeUnvisible()
{
	m_chkA1.ShowWindow(SW_HIDE);
	m_chkA2.ShowWindow(SW_HIDE);
	m_chkA3.ShowWindow(SW_HIDE);
	m_chkA4.ShowWindow(SW_HIDE);
	m_chkA5.ShowWindow(SW_HIDE);

	((CButton *)GetDlgItem(IDC_RADIO1))->ShowWindow(SW_HIDE);
	((CButton *)GetDlgItem(IDC_RADIO2))->ShowWindow(SW_HIDE);
	((CButton *)GetDlgItem(IDC_RADIO3))->ShowWindow(SW_HIDE);
	((CButton *)GetDlgItem(IDC_RADIO4))->ShowWindow(SW_HIDE);

}

void CClientExamView::MakeInvisibleAll()
{
	MakeUnvisible();
	((CWnd *)GetDlgItem(IDC_NUMBER))->ShowWindow(SW_HIDE);
	((CWnd *)GetDlgItem(IDC_CONTENT))->ShowWindow(SW_HIDE);
	((CWnd *)GetDlgItem(IDC_NEXT))->ShowWindow(SW_HIDE);
	((CWnd *)GetDlgItem(IDC_PRIOR))->ShowWindow(SW_HIDE);
	((CWnd *)GetDlgItem(IDC_FINISH))->ShowWindow(SW_HIDE);
}

void CClientExamView::MakeVisible()
{
	((CWnd *)GetDlgItem(IDC_NUMBER))->ShowWindow(SW_SHOW);
	((CWnd *)GetDlgItem(IDC_CONTENT))->ShowWindow(SW_SHOW);
	((CWnd *)GetDlgItem(IDC_NEXT))->ShowWindow(SW_SHOW);
	((CWnd *)GetDlgItem(IDC_PRIOR))->ShowWindow(SW_SHOW);
	((CWnd *)GetDlgItem(IDC_FINISH))->ShowWindow(SW_SHOW);

}
