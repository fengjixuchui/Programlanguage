// Machine generated IDispatch wrapper class(es) created with ClassWizard

#include "stdafx.h"
#include "exam.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// ICaculateScore properties

/////////////////////////////////////////////////////////////////////////////
// ICaculateScore operations

long ICaculateScore::GetScore()
{
	long result;
	InvokeHelper(0x1, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void ICaculateScore::SetScore(long nNewValue)
{
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x1, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 nNewValue);
}

CString ICaculateScore::CaculateScore(long x_nSID)
{
	CString result;
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x2, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		x_nSID);
	return result;
}

long ICaculateScore::GetScore(long x_nSID)
{
	long result;
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x3, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		x_nSID);
	return result;
}


/////////////////////////////////////////////////////////////////////////////
// IGenerateExam properties

/////////////////////////////////////////////////////////////////////////////
// IGenerateExam operations

CString IGenerateExam::GenerateExam(long x_nSID)
{
	CString result;
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x1, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		x_nSID);
	return result;
}


/////////////////////////////////////////////////////////////////////////////
// ISaveCurrentAnswer properties

/////////////////////////////////////////////////////////////////////////////
// ISaveCurrentAnswer operations

CString ISaveCurrentAnswer::SaveAnswer(long x_nSID, long x_nQID, long x_nAnswer, long x_nTimeLeft, long x_nForward)
{
	CString result;
	static BYTE parms[] =
		VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_I4;
	InvokeHelper(0x1, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		x_nSID, x_nQID, x_nAnswer, x_nTimeLeft, x_nForward);
	return result;
}


/////////////////////////////////////////////////////////////////////////////
// IExamState properties

/////////////////////////////////////////////////////////////////////////////
// IExamState operations

CString IExamState::CheckExist(long x_nSID)
{
	CString result;
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x1, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		x_nSID);
	return result;
}

CString IExamState::CheckFinish(long x_nSID)
{
	CString result;
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x2, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		x_nSID);
	return result;
}

long IExamState::GetAnswer(long x_nSID, long x_nQID)
{
	long result;
	static BYTE parms[] =
		VTS_I4 VTS_I4;
	InvokeHelper(0x3, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		x_nSID, x_nQID);
	return result;
}

long IExamState::GetCurrentQuestion(long x_nSID)
{
	long result;
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x4, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		x_nSID);
	return result;
}

short IExamState::GetQType()
{
	short result;
	InvokeHelper(0x5, DISPATCH_PROPERTYGET, VT_I2, (void*)&result, NULL);
	return result;
}

long IExamState::GetTimeLeft()
{
	long result;
	InvokeHelper(0x6, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}

void IExamState::SetQTypeforbstr(BSTR* newValue)
{
	static BYTE parms[] =
		VTS_PBSTR;
	InvokeHelper(0x7, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms,
		 newValue);
}

CString IExamState::GetExamInfo(long x_nSID)
{
	CString result;
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x8, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		x_nSID);
	return result;
}

CString IExamState::GetExamDetail(long x_nSID, long x_nQNO)
{
	CString result;
	static BYTE parms[] =
		VTS_I4 VTS_I4;
	InvokeHelper(0x9, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms,
		x_nSID, x_nQNO);
	return result;
}

long IExamState::GetQid()
{
	long result;
	InvokeHelper(0xa, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
	return result;
}
