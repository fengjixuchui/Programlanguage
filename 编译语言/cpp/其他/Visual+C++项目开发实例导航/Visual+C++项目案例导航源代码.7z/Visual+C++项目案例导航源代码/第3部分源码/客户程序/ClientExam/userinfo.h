// Machine generated IDispatch wrapper class(es) created with ClassWizard
/////////////////////////////////////////////////////////////////////////////
// IUser wrapper class

class IUser : public COleDispatchDriver
{
public:
	IUser() {}		// Calls COleDispatchDriver default constructor
	IUser(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IUser(const IUser& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	CString GetUsername();
	void SetUsername(LPCTSTR lpszNewValue);
	CString GetPassword();
	void SetPassword(LPCTSTR lpszNewValue);
	CString GetName();
	void SetName(LPCTSTR lpszNewValue);
	CString GetSchool();
	void SetSchool(LPCTSTR lpszNewValue);
	CString GetDepartment();
	void SetDepartment(LPCTSTR lpszNewValue);
	CString GetClass();
	void SetClass(LPCTSTR lpszNewValue);
	CString GetEmail();
	void SetEmail(LPCTSTR lpszNewValue);
	CString GetStudentNO();
	void SetStudentNO(LPCTSTR lpszNewValue);
	long GetUserID();
	void SetUserID(long nNewValue);
	CString CheckValid(long x_nType, LPCTSTR x_No, LPCTSTR x_Password);
	CString GetUserInfo(long x_nType, long x_UID);
	long InsertUserInfo(long x_nType);
	CString DeleteUserInfo(long x_nType, long x_UID);
	void GetUser(long x_nType, LPCTSTR x_mUsername);
};
