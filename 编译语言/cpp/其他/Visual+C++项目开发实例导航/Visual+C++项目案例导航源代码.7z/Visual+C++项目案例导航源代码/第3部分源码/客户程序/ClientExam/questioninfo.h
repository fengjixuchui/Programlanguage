// Machine generated IDispatch wrapper class(es) created with ClassWizard
/////////////////////////////////////////////////////////////////////////////
// IQuestion wrapper class

class IQuestion : public COleDispatchDriver
{
public:
	IQuestion() {}		// Calls COleDispatchDriver default constructor
	IQuestion(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IQuestion(const IQuestion& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	CString GetContent();
	void SetContent(LPCTSTR lpszNewValue);
	CString GetQ1();
	void SetQ1(LPCTSTR lpszNewValue);
	CString GetQ2();
	void SetQ2(LPCTSTR lpszNewValue);
	CString GetQ3();
	void SetQ3(LPCTSTR lpszNewValue);
	CString GetQ4();
	void SetQ4(LPCTSTR lpszNewValue);
	CString GetQ5();
	void SetQ5(LPCTSTR lpszNewValue);
	CString GetQuestion(long x_nType, long x_nQID);
	long PutQuestion(long x_nType);
	long DeleteQuestion(long x_nType, long x_nQID);
	short GetAnswer();
	void SetAnswer(short nNewValue);
};
