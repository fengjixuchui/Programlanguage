//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ClientExam.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_CLIENTEXAM_FORM             101
#define IDR_MAINFRAME                   128
#define IDR_CLIENTTYPE                  129
#define IDD_LOGIN                       130
#define IDD_DIALOGRGT                   132
#define IDC_CONTENT                     1001
#define IDC_NUMBER                      1002
#define IDC_RADIO1                      1003
#define IDC_RADIO2                      1004
#define IDC_RADIO3                      1005
#define IDC_RADIO4                      1006
#define IDC_CHECK1                      1007
#define IDC_CHECK2                      1008
#define IDC_CHECK3                      1009
#define IDC_CHECK4                      1010
#define IDC_CHECK5                      1011
#define IDC_PRIOR                       1012
#define IDC_NEXT                        1013
#define IDC_STUDENTNO                   1013
#define IDC_FINISH                      1014
#define IDC_PASSWORD                    1014
#define IDC_CONFIRM                     1015
#define IDC_CANCEL                      1016
#define HJK                             1016
#define IDC_EDITUserName                1017
#define IDC_EDITPassword                1018
#define IDC_EDITStudentNO               1019
#define IDC_EDITName                    1020
#define IDC_EDITSchool                  1021
#define IDC_EDITDepartment              1022
#define IDC_EDITClass                   1023
#define IDC_EDITEmail                   1024
#define IDC_RADIOTYPE2                  1025
#define IDC_RADIOTYPE1                  1026
#define IDC_BUTTONINS                   1031
#define IDC_BUTTONDEL                   1032
#define IDC_BUTTONQUT                   1036
#define IDC_EDITNAMEFORQ                1039
#define ID_LOGIN                        32771
#define ID_MENUITEMREGISER              32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
