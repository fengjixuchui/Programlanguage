// Machine generated IDispatch wrapper class(es) created with ClassWizard
/////////////////////////////////////////////////////////////////////////////
// ICaculateScore wrapper class

class ICaculateScore : public COleDispatchDriver
{
public:
	ICaculateScore() {}		// Calls COleDispatchDriver default constructor
	ICaculateScore(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	ICaculateScore(const ICaculateScore& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	long GetScore();
	void SetScore(long nNewValue);
	CString CaculateScore(long x_nSID);
	long GetScore(long x_nSID);
};
/////////////////////////////////////////////////////////////////////////////
// IGenerateExam wrapper class

class IGenerateExam : public COleDispatchDriver
{
public:
	IGenerateExam() {}		// Calls COleDispatchDriver default constructor
	IGenerateExam(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IGenerateExam(const IGenerateExam& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	CString GenerateExam(long x_nSID);
};
/////////////////////////////////////////////////////////////////////////////
// ISaveCurrentAnswer wrapper class

class ISaveCurrentAnswer : public COleDispatchDriver
{
public:
	ISaveCurrentAnswer() {}		// Calls COleDispatchDriver default constructor
	ISaveCurrentAnswer(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	ISaveCurrentAnswer(const ISaveCurrentAnswer& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	CString SaveAnswer(long x_nSID, long x_nQID, long x_nAnswer, long x_nTimeLeft, long x_nForward);
};
/////////////////////////////////////////////////////////////////////////////
// IExamState wrapper class

class IExamState : public COleDispatchDriver
{
public:
	IExamState() {}		// Calls COleDispatchDriver default constructor
	IExamState(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IExamState(const IExamState& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	CString CheckExist(long x_nSID);
	CString CheckFinish(long x_nSID);
	long GetAnswer(long x_nSID, long x_nQID);
	long GetCurrentQuestion(long x_nSID);
	short GetQType();
	long GetTimeLeft();
	// method 'GetQTypeforbstr' not emitted because of invalid return type or parameter type
	void SetQTypeforbstr(BSTR* newValue);
	CString GetExamInfo(long x_nSID);
	CString GetExamDetail(long x_nSID, long x_nQNO);
	long GetQid();
};
