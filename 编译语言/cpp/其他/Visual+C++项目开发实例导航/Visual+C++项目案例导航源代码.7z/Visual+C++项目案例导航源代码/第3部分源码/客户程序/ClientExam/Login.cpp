// Login.cpp : implementation file
//

#include "stdafx.h"
#include "ClientExam.h"
#include "Login.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLogin dialog


CLogin::CLogin(CWnd* pParent /*=NULL*/)
	: CDialog(CLogin::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLogin)
	m_strPassword = _T("");
	m_strStudentNo = _T("");
	//}}AFX_DATA_INIT
	m_bPass = FALSE;
	m_nSID = 0;
}


void CLogin::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLogin)
	DDX_Text(pDX, IDC_PASSWORD, m_strPassword);
	DDV_MaxChars(pDX, m_strPassword, 10);
	DDX_Text(pDX, IDC_STUDENTNO, m_strStudentNo);
	DDV_MaxChars(pDX, m_strStudentNo, 10);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLogin, CDialog)
	//{{AFX_MSG_MAP(CLogin)
	ON_BN_CLICKED(IDC_CONFIRM, OnConfirm)
	ON_BN_CLICKED(IDC_CANCEL, OnCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLogin message handlers

void CLogin::OnCancel() 
{
	// TODO: Add your control notification handler code here
	CDialog::OnCancel();
}

void CLogin::OnConfirm() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if(!m_CheckStudent.CreateDispatch("UserInfo.User.1"))
	{
		AfxMessageBox("Couldn't create component!");
		CDialog::OnCancel();
	}
	m_CheckStudent.CheckValid(0,m_strStudentNo, m_strPassword);
	
	m_nSID = m_CheckStudent.GetUserID();
	m_CheckStudent.ReleaseDispatch();

	CDialog::OnOK();
}

BOOL CLogin::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
