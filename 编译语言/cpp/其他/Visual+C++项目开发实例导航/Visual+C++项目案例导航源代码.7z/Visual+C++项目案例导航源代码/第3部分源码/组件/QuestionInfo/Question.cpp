// Question.cpp : Implementation of CQuestion
#include "stdafx.h"
#include "QuestionInfo.h"
#include "Question.h"

#define null 0

/////////////////////////////////////////////////////////////////////////////
// CQuestion


STDMETHODIMP CQuestion::get_content(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrcontent;
	return S_OK;
}

STDMETHODIMP CQuestion::put_content(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrcontent=newVal;
	return S_OK;
}

STDMETHODIMP CQuestion::get_Q1(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrQ1;
	return S_OK;
}

STDMETHODIMP CQuestion::put_Q1(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrQ1=newVal;
	return S_OK;
}

STDMETHODIMP CQuestion::get_Q2(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrQ2;
	return S_OK;
}

STDMETHODIMP CQuestion::put_Q2(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrQ2=newVal;
	return S_OK;
}

STDMETHODIMP CQuestion::get_Q3(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrQ3;
	return S_OK;
}

STDMETHODIMP CQuestion::put_Q3(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrQ3=newVal;
	return S_OK;
}

STDMETHODIMP CQuestion::get_Q4(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrQ4;
	return S_OK;
}

STDMETHODIMP CQuestion::put_Q4(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrQ4=newVal;
	return S_OK;
}

STDMETHODIMP CQuestion::get_Q5(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrQ5;
	return S_OK;
}

STDMETHODIMP CQuestion::put_Q5(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrQ5=newVal;
	return S_OK;
}

STDMETHODIMP CQuestion::GetQuestion(int x_nType, int x_nQID, BSTR *x_QInfo)
{
		// TODO: Add your implementation code here
	try
	{

		if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
		{
			*x_QInfo = ::SysAllocString(L"N#Couldn't create connection component!");
			return S_OK;
		}

		if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
		{
			*x_QInfo = ::SysAllocString(L"N#Couldn't open connection!");
			return S_OK;
		}

		CComBSTR m_bstrSql;
		
		switch(x_nType)
		{
		case 0:
			m_bstrSql.Append("SELECT * FROM LOGIC WHERE QID=");
			break;
		case 1:
			m_bstrSql.Append("SELECT * FROM SINGLE WHERE QID=");
			break;
		case 2:
			m_bstrSql.Append("SELECT * FROM MULTIPLY WHERE QID=");
			break;
		default:
			*x_QInfo = ::SysAllocString(L"N#Type error!");
			return S_OK;
			break;
		}

		char m_strBuf[10];
		_itoa(x_nQID, m_strBuf, 10);

		m_bstrSql.Append(m_strBuf);

		_bstr_t m_bstrResult(m_bstrSql,FALSE);
		

		CComVariant m_varNum;

		pRs = pConn->Execute(m_bstrResult, &m_varNum, -1);

		if (pRs->ADOEOF)
		{
			*x_QInfo = ::SysAllocString(L"N#Couldn't find records!");
			return S_OK;
		}

		CComVariant m_varData;
		CComBSTR m_bstrInfo;
		m_bstrInfo.Append("Y#");

		char m_strFieldName[20];

		pRs->GetFields()->GetItem("CONTENT")->get_Value(&m_varData);
		if(m_varData.vt != VT_NULL)
		{
			m_bstrInfo.AppendBSTR(m_varData.bstrVal);
			m_bstrcontent.AppendBSTR(m_varData.bstrVal);
		}

		m_bstrInfo.Append("#");

		if (x_nType >= 1)
		{
			pRs->GetFields()->GetItem("ANSWERA")->get_Value(&m_varData);
			if(m_varData.vt != VT_NULL)
			{
				m_bstrInfo.AppendBSTR(m_varData.bstrVal);
				m_bstrQ1.AppendBSTR(m_varData.bstrVal);
			}
			m_bstrInfo.Append("#");
			
			pRs->GetFields()->GetItem("ANSWERB")->get_Value(&m_varData);
			if(m_varData.vt != VT_NULL)
			{
				m_bstrInfo.AppendBSTR(m_varData.bstrVal);
				m_bstrQ2.AppendBSTR(m_varData.bstrVal);
			}

			m_bstrInfo.Append("#");

			pRs->GetFields()->GetItem("ANSWERC")->get_Value(&m_varData);
			if(m_varData.vt != VT_NULL)
			{
				m_bstrInfo.AppendBSTR(m_varData.bstrVal);
				m_bstrQ3.AppendBSTR(m_varData.bstrVal);
			}

			m_bstrInfo.Append("#");

			pRs->GetFields()->GetItem("ANSWERD")->get_Value(&m_varData);
			if(m_varData.vt != VT_NULL)
			{
				m_bstrInfo.AppendBSTR(m_varData.bstrVal);
				m_bstrQ4.AppendBSTR(m_varData.bstrVal);
			}

		}
		m_bstrInfo.Append("#");
		
		if (x_nType == 2)
		{
			pRs->GetFields()->GetItem("ANSWERA")->get_Value(&m_varData);
			if(m_varData.vt != VT_NULL)
			{
				m_bstrInfo.AppendBSTR(m_varData.bstrVal);
				m_bstrQ5.AppendBSTR(m_varData.bstrVal);
			}
		}
		pRs->GetFields()->GetItem("ANSWER")->get_Value(&m_varData);
		if(m_varData.vt != VT_NULL)
		{
			
			m_shortAnswer=m_varData.intVal;
		}
	
		*x_QInfo = m_bstrInfo;
	}
	catch(...)
	{
		*x_QInfo = ::SysAllocString(L"Error occurs!");
		return S_OK;

	}

	return S_OK;
}

STDMETHODIMP CQuestion::PutQuestion(int x_nType, int *x_QID)
{
		// TODO: Add your implementation code here
	if(FAILED(pConn.CreateInstance(__uuidof(Connection))))
	{
		*x_QID=-1;
		return S_OK;
	}
	if(FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
	{
		*x_QID=-1;
		return S_OK;
	}
	CComBSTR m_bstrSQL;

	switch(x_nType)
	{
	case 0:
		m_bstrSQL.Append("Insert into Logic(");
		break;
	case 1:
		m_bstrSQL.Append("Insert into Single(");
		break;
	case 2:
		m_bstrSQL.Append("Insert into Multiply(");
		break;
	default:
		*x_QID=-1;
		return S_OK;
	}
	CComBSTR m_bstrTemp;
	char m_charAnswer[10];
	_itoa(m_shortAnswer,m_charAnswer,10);
	m_bstrTemp.Append("values(");
	if(m_bstrcontent!=null)
	{
		m_bstrSQL.Append("content");
		m_bstrTemp.Append("'");
		m_bstrTemp.AppendBSTR(m_bstrcontent);
		m_bstrTemp.Append("'");
		m_bstrSQL.Append(",answer");
		m_bstrTemp.Append(m_charAnswer);
	}

	if(x_nType>0)
	{
		m_bstrSQL.Append(",AnswerA,AnswerB,AnswerC,AnswerD");
		m_bstrTemp.Append(",'");
		m_bstrTemp.AppendBSTR(m_bstrQ1);
		m_bstrTemp.Append("','");
		m_bstrTemp.AppendBSTR(m_bstrQ2);
		m_bstrTemp.Append("','");
		m_bstrTemp.AppendBSTR(m_bstrQ3);
		m_bstrTemp.Append("','");
		m_bstrTemp.AppendBSTR(m_bstrQ4);
		m_bstrTemp.Append("'");
	}
	if(x_nType==2)
	{
		m_bstrSQL.Append(",AnswerE");
		m_bstrTemp.Append(",'");
		m_bstrTemp.AppendBSTR(m_bstrQ5);
		m_bstrTemp.Append("'");
	}
	m_bstrTemp.Append(")");
	m_bstrSQL.Append(") ");
	m_bstrSQL.AppendBSTR(m_bstrTemp);
	
	_bstr_t  m_bstrResult(m_bstrSQL,FALSE);

	CComVariant m_varNum;
	pConn->Execute(m_bstrResult,&m_varNum,-1);
	if(m_varNum.lVal!=1)
	{
		*x_QID=-1;
		return S_OK;
	}
	*x_QID=1;

	return S_OK;
}

STDMETHODIMP CQuestion::DeleteQuestion(int x_nType, int x_nQID, int *x_Success)
{
	// TODO: Add your implementation code here
	if(FAILED(pConn.CreateInstance(__uuidof(Connection))))
	{
		*x_Success=-1;
		return S_OK;
	}
	if(FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
	{
		*x_Success=-1;
		return S_OK;
	}
	CComBSTR m_bstrSQL;

	switch(x_nType)
	{
	case 0:
		m_bstrSQL.Append("DELETE Logic WHERE QID=");
		break;
	case 1:
		m_bstrSQL.Append("DELETE Single WHERE QID=");
		break;
	case 2:
		m_bstrSQL.Append("DELETE Multiply WHERE QID=");
		break;
	default:
		*x_Success=-1;
		return S_OK;
	}
	char m_charQID[10];
	_itoa(x_nQID,m_charQID,10);
	
	m_bstrSQL.Append(m_charQID);
	
	_bstr_t  m_bstrResult(m_bstrSQL,FALSE);

	CComVariant m_varNum;
	HRESULT hr=pConn->Execute(m_bstrResult,&m_varNum,-1);
	if(FAILED(hr))
	{
		*x_Success=-1;
		return S_OK;
	}
	*x_Success=1;

	return S_OK;
}

STDMETHODIMP CQuestion::get_Answer(short *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_shortAnswer;

	return S_OK;
}

STDMETHODIMP CQuestion::put_Answer(short newVal)
{
	// TODO: Add your implementation code here
	m_shortAnswer=newVal;
	return S_OK;
}
