// ExamState.h : Declaration of the CExamState

#ifndef __EXAMSTATE_H_
#define __EXAMSTATE_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CExamState
class ATL_NO_VTABLE CExamState : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CExamState, &CLSID_ExamState>,
	public IDispatchImpl<IExamState, &IID_IExamState, &LIBID_EXAMLib>
{
public:
	CExamState()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_EXAMSTATE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CExamState)
	COM_INTERFACE_ENTRY(IExamState)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IExamState
public:
	STDMETHOD(get_QID)(/*[out, retval]*/ long *pVal);
	STDMETHOD(GetExamDetail)(/*[in]*/ long x_nSID,/*[in]*/ int x_nQNO,/*[out,retval]*/ BSTR * x_Success);
	STDMETHOD(GetExamInfo)(/*[in]*/ long x_nSID,/*[out,retval]*/ BSTR *x_Success);
	STDMETHOD(get_QTypeforbstr)(/*[out, retval]*/ BSTR* *pVal);
	STDMETHOD(put_QTypeforbstr)(/*[in]*/ BSTR* newVal);
	STDMETHOD(get_TimeLeft)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_QType)(/*[out, retval]*/ short *pVal);
	STDMETHOD(GetCurrentQuestion)(/*[in]*/ int x_nSID,/*[out,retval]*/ long *x_lCurrentQuestion);
	STDMETHOD(GetAnswer)(/*[in]*/ int x_nSID,/*[in]*/ int x_nQID,/*[out,retval]*/ long *x_lAnswer);

	STDMETHOD(CheckFinish)(/*[in]*/ int x_nSID,/*[out,retval]*/ BSTR * x_Success);
	STDMETHOD(CheckExist)(/*[in]*/ int x_nSID,/*[out,retval]*/ BSTR *x_Success);
private:
	long m_QID;
	int m_CurrentQuestion;
	long m_TimeLeft;
	int m_QType;
	_RecordsetPtr pRs;
	_ConnectionPtr pConn;
};

#endif //__EXAMSTATE_H_
