// SaveCurrentAnswer.h : Declaration of the CSaveCurrentAnswer

#ifndef __SAVECURRENTANSWER_H_
#define __SAVECURRENTANSWER_H_

#include "resource.h"       // main symbols
#include <mtx.h>

/////////////////////////////////////////////////////////////////////////////
// CSaveCurrentAnswer
class ATL_NO_VTABLE CSaveCurrentAnswer : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSaveCurrentAnswer, &CLSID_SaveCurrentAnswer>,
	public IObjectControl,
	public IDispatchImpl<ISaveCurrentAnswer, &IID_ISaveCurrentAnswer, &LIBID_EXAMLib>
{
public:
	CSaveCurrentAnswer()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SAVECURRENTANSWER)

DECLARE_PROTECT_FINAL_CONSTRUCT()

DECLARE_NOT_AGGREGATABLE(CSaveCurrentAnswer)

BEGIN_COM_MAP(CSaveCurrentAnswer)
	COM_INTERFACE_ENTRY(ISaveCurrentAnswer)
	COM_INTERFACE_ENTRY(IObjectControl)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IObjectControl
public:
	STDMETHOD(Activate)();
	STDMETHOD_(BOOL, CanBePooled)();
	STDMETHOD_(void, Deactivate)();

	CComPtr<IObjectContext> m_spObjectContext;

// ISaveCurrentAnswer
public:
	STDMETHOD(SaveAnswer)(/*[in]*/ int x_nSID,/*[in]*/  int x_nQID,/*[in]*/ int x_nAnswer,/*[in]*/ int x_nTimeLeft, /*[in]*/ int x_nForward,/*[out,retval]*/ BSTR *x_Success);
private:
	_RecordsetPtr pRs;
	_ConnectionPtr pConn;
};

#endif //__SAVECURRENTANSWER_H_
