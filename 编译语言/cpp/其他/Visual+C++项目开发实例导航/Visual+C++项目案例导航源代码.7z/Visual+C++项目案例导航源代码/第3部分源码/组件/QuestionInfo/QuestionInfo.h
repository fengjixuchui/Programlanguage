/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Jul 04 10:16:09 2002
 */
/* Compiler settings for F:\��Visual C++��Ŀ����������Դ����\��3����Դ��\���\QuestionInfo\QuestionInfo.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __QuestionInfo_h__
#define __QuestionInfo_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IQuestion_FWD_DEFINED__
#define __IQuestion_FWD_DEFINED__
typedef interface IQuestion IQuestion;
#endif 	/* __IQuestion_FWD_DEFINED__ */


#ifndef __Question_FWD_DEFINED__
#define __Question_FWD_DEFINED__

#ifdef __cplusplus
typedef class Question Question;
#else
typedef struct Question Question;
#endif /* __cplusplus */

#endif 	/* __Question_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IQuestion_INTERFACE_DEFINED__
#define __IQuestion_INTERFACE_DEFINED__

/* interface IQuestion */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IQuestion;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("362ABD33-561C-4541-9E21-300573AB2163")
    IQuestion : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_content( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_content( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Q1( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Q1( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Q2( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Q2( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Q3( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Q3( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Q4( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Q4( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Q5( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Q5( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetQuestion( 
            /* [in] */ int x_nType,
            /* [in] */ int x_nQID,
            /* [retval][out] */ BSTR __RPC_FAR *x_QInfo) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE PutQuestion( 
            /* [in] */ int x_nType,
            /* [retval][out] */ int __RPC_FAR *x_QID) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteQuestion( 
            /* [in] */ int x_nType,
            /* [in] */ int x_nQID,
            /* [retval][out] */ int __RPC_FAR *x_Success) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Answer( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Answer( 
            /* [in] */ short newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IQuestionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IQuestion __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IQuestion __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IQuestion __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_content )( 
            IQuestion __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_content )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Q1 )( 
            IQuestion __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Q1 )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Q2 )( 
            IQuestion __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Q2 )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Q3 )( 
            IQuestion __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Q3 )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Q4 )( 
            IQuestion __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Q4 )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Q5 )( 
            IQuestion __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Q5 )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetQuestion )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ int x_nType,
            /* [in] */ int x_nQID,
            /* [retval][out] */ BSTR __RPC_FAR *x_QInfo);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PutQuestion )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ int x_nType,
            /* [retval][out] */ int __RPC_FAR *x_QID);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteQuestion )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ int x_nType,
            /* [in] */ int x_nQID,
            /* [retval][out] */ int __RPC_FAR *x_Success);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Answer )( 
            IQuestion __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Answer )( 
            IQuestion __RPC_FAR * This,
            /* [in] */ short newVal);
        
        END_INTERFACE
    } IQuestionVtbl;

    interface IQuestion
    {
        CONST_VTBL struct IQuestionVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IQuestion_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IQuestion_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IQuestion_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IQuestion_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IQuestion_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IQuestion_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IQuestion_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IQuestion_get_content(This,pVal)	\
    (This)->lpVtbl -> get_content(This,pVal)

#define IQuestion_put_content(This,newVal)	\
    (This)->lpVtbl -> put_content(This,newVal)

#define IQuestion_get_Q1(This,pVal)	\
    (This)->lpVtbl -> get_Q1(This,pVal)

#define IQuestion_put_Q1(This,newVal)	\
    (This)->lpVtbl -> put_Q1(This,newVal)

#define IQuestion_get_Q2(This,pVal)	\
    (This)->lpVtbl -> get_Q2(This,pVal)

#define IQuestion_put_Q2(This,newVal)	\
    (This)->lpVtbl -> put_Q2(This,newVal)

#define IQuestion_get_Q3(This,pVal)	\
    (This)->lpVtbl -> get_Q3(This,pVal)

#define IQuestion_put_Q3(This,newVal)	\
    (This)->lpVtbl -> put_Q3(This,newVal)

#define IQuestion_get_Q4(This,pVal)	\
    (This)->lpVtbl -> get_Q4(This,pVal)

#define IQuestion_put_Q4(This,newVal)	\
    (This)->lpVtbl -> put_Q4(This,newVal)

#define IQuestion_get_Q5(This,pVal)	\
    (This)->lpVtbl -> get_Q5(This,pVal)

#define IQuestion_put_Q5(This,newVal)	\
    (This)->lpVtbl -> put_Q5(This,newVal)

#define IQuestion_GetQuestion(This,x_nType,x_nQID,x_QInfo)	\
    (This)->lpVtbl -> GetQuestion(This,x_nType,x_nQID,x_QInfo)

#define IQuestion_PutQuestion(This,x_nType,x_QID)	\
    (This)->lpVtbl -> PutQuestion(This,x_nType,x_QID)

#define IQuestion_DeleteQuestion(This,x_nType,x_nQID,x_Success)	\
    (This)->lpVtbl -> DeleteQuestion(This,x_nType,x_nQID,x_Success)

#define IQuestion_get_Answer(This,pVal)	\
    (This)->lpVtbl -> get_Answer(This,pVal)

#define IQuestion_put_Answer(This,newVal)	\
    (This)->lpVtbl -> put_Answer(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IQuestion_get_content_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IQuestion_get_content_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IQuestion_put_content_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IQuestion_put_content_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IQuestion_get_Q1_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IQuestion_get_Q1_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IQuestion_put_Q1_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IQuestion_put_Q1_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IQuestion_get_Q2_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IQuestion_get_Q2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IQuestion_put_Q2_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IQuestion_put_Q2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IQuestion_get_Q3_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IQuestion_get_Q3_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IQuestion_put_Q3_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IQuestion_put_Q3_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IQuestion_get_Q4_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IQuestion_get_Q4_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IQuestion_put_Q4_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IQuestion_put_Q4_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IQuestion_get_Q5_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IQuestion_get_Q5_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IQuestion_put_Q5_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IQuestion_put_Q5_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IQuestion_GetQuestion_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [in] */ int x_nType,
    /* [in] */ int x_nQID,
    /* [retval][out] */ BSTR __RPC_FAR *x_QInfo);


void __RPC_STUB IQuestion_GetQuestion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IQuestion_PutQuestion_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [in] */ int x_nType,
    /* [retval][out] */ int __RPC_FAR *x_QID);


void __RPC_STUB IQuestion_PutQuestion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IQuestion_DeleteQuestion_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [in] */ int x_nType,
    /* [in] */ int x_nQID,
    /* [retval][out] */ int __RPC_FAR *x_Success);


void __RPC_STUB IQuestion_DeleteQuestion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IQuestion_get_Answer_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IQuestion_get_Answer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IQuestion_put_Answer_Proxy( 
    IQuestion __RPC_FAR * This,
    /* [in] */ short newVal);


void __RPC_STUB IQuestion_put_Answer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IQuestion_INTERFACE_DEFINED__ */



#ifndef __QUESTIONINFOLib_LIBRARY_DEFINED__
#define __QUESTIONINFOLib_LIBRARY_DEFINED__

/* library QUESTIONINFOLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_QUESTIONINFOLib;

EXTERN_C const CLSID CLSID_Question;

#ifdef __cplusplus

class DECLSPEC_UUID("7672935A-B914-466A-BB82-9EC892636123")
Question;
#endif
#endif /* __QUESTIONINFOLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
