/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Jan 27 18:14:34 2002
 */
/* Compiler settings for D:\old21\vcbook\UserInfo\UserInfo.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __UserInfo_h__
#define __UserInfo_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IUser_FWD_DEFINED__
#define __IUser_FWD_DEFINED__
typedef interface IUser IUser;
#endif 	/* __IUser_FWD_DEFINED__ */


#ifndef __User_FWD_DEFINED__
#define __User_FWD_DEFINED__

#ifdef __cplusplus
typedef class User User;
#else
typedef struct User User;
#endif /* __cplusplus */

#endif 	/* __User_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IUser_INTERFACE_DEFINED__
#define __IUser_INTERFACE_DEFINED__

/* interface IUser */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IUser;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8A16D6E2-DD06-40F0-9B57-A6C4B3570F60")
    IUser : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Username( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Username( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Password( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Password( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Name( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_School( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_School( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Department( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Department( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Class( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Class( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Email( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Email( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_StudentNO( 
            /* [retval][out] */ BSTR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_StudentNO( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_UserID( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_UserID( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CheckValid( 
            /* [in] */ int x_nType,
            /* [in] */ BSTR x_No,
            /* [in] */ BSTR x_Password,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetUserInfo( 
            /* [in] */ int x_nType,
            /* [in] */ int x_UID,
            /* [retval][out] */ BSTR __RPC_FAR *x_UserInfo) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE InsertUserInfo( 
            /* [in] */ int x_nType,
            /* [retval][out] */ int __RPC_FAR *x_Success) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeleteUserInfo( 
            /* [in] */ int x_nType,
            /* [in] */ int x_UID,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetUser( 
            /* [in] */ int x_nType,
            /* [in] */ BSTR x_mUsername) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IUserVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IUser __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IUser __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IUser __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IUser __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IUser __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IUser __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IUser __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Username )( 
            IUser __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Username )( 
            IUser __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Password )( 
            IUser __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Password )( 
            IUser __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Name )( 
            IUser __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Name )( 
            IUser __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_School )( 
            IUser __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_School )( 
            IUser __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Department )( 
            IUser __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Department )( 
            IUser __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Class )( 
            IUser __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Class )( 
            IUser __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Email )( 
            IUser __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Email )( 
            IUser __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_StudentNO )( 
            IUser __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_StudentNO )( 
            IUser __RPC_FAR * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_UserID )( 
            IUser __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_UserID )( 
            IUser __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CheckValid )( 
            IUser __RPC_FAR * This,
            /* [in] */ int x_nType,
            /* [in] */ BSTR x_No,
            /* [in] */ BSTR x_Password,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetUserInfo )( 
            IUser __RPC_FAR * This,
            /* [in] */ int x_nType,
            /* [in] */ int x_UID,
            /* [retval][out] */ BSTR __RPC_FAR *x_UserInfo);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *InsertUserInfo )( 
            IUser __RPC_FAR * This,
            /* [in] */ int x_nType,
            /* [retval][out] */ int __RPC_FAR *x_Success);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteUserInfo )( 
            IUser __RPC_FAR * This,
            /* [in] */ int x_nType,
            /* [in] */ int x_UID,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetUser )( 
            IUser __RPC_FAR * This,
            /* [in] */ int x_nType,
            /* [in] */ BSTR x_mUsername);
        
        END_INTERFACE
    } IUserVtbl;

    interface IUser
    {
        CONST_VTBL struct IUserVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IUser_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IUser_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IUser_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IUser_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IUser_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IUser_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IUser_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IUser_get_Username(This,pVal)	\
    (This)->lpVtbl -> get_Username(This,pVal)

#define IUser_put_Username(This,newVal)	\
    (This)->lpVtbl -> put_Username(This,newVal)

#define IUser_get_Password(This,pVal)	\
    (This)->lpVtbl -> get_Password(This,pVal)

#define IUser_put_Password(This,newVal)	\
    (This)->lpVtbl -> put_Password(This,newVal)

#define IUser_get_Name(This,pVal)	\
    (This)->lpVtbl -> get_Name(This,pVal)

#define IUser_put_Name(This,newVal)	\
    (This)->lpVtbl -> put_Name(This,newVal)

#define IUser_get_School(This,pVal)	\
    (This)->lpVtbl -> get_School(This,pVal)

#define IUser_put_School(This,newVal)	\
    (This)->lpVtbl -> put_School(This,newVal)

#define IUser_get_Department(This,pVal)	\
    (This)->lpVtbl -> get_Department(This,pVal)

#define IUser_put_Department(This,newVal)	\
    (This)->lpVtbl -> put_Department(This,newVal)

#define IUser_get_Class(This,pVal)	\
    (This)->lpVtbl -> get_Class(This,pVal)

#define IUser_put_Class(This,newVal)	\
    (This)->lpVtbl -> put_Class(This,newVal)

#define IUser_get_Email(This,pVal)	\
    (This)->lpVtbl -> get_Email(This,pVal)

#define IUser_put_Email(This,newVal)	\
    (This)->lpVtbl -> put_Email(This,newVal)

#define IUser_get_StudentNO(This,pVal)	\
    (This)->lpVtbl -> get_StudentNO(This,pVal)

#define IUser_put_StudentNO(This,newVal)	\
    (This)->lpVtbl -> put_StudentNO(This,newVal)

#define IUser_get_UserID(This,pVal)	\
    (This)->lpVtbl -> get_UserID(This,pVal)

#define IUser_put_UserID(This,newVal)	\
    (This)->lpVtbl -> put_UserID(This,newVal)

#define IUser_CheckValid(This,x_nType,x_No,x_Password,x_Success)	\
    (This)->lpVtbl -> CheckValid(This,x_nType,x_No,x_Password,x_Success)

#define IUser_GetUserInfo(This,x_nType,x_UID,x_UserInfo)	\
    (This)->lpVtbl -> GetUserInfo(This,x_nType,x_UID,x_UserInfo)

#define IUser_InsertUserInfo(This,x_nType,x_Success)	\
    (This)->lpVtbl -> InsertUserInfo(This,x_nType,x_Success)

#define IUser_DeleteUserInfo(This,x_nType,x_UID,x_Success)	\
    (This)->lpVtbl -> DeleteUserInfo(This,x_nType,x_UID,x_Success)

#define IUser_GetUser(This,x_nType,x_mUsername)	\
    (This)->lpVtbl -> GetUser(This,x_nType,x_mUsername)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUser_get_Username_Proxy( 
    IUser __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUser_get_Username_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUser_put_Username_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IUser_put_Username_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUser_get_Password_Proxy( 
    IUser __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUser_get_Password_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUser_put_Password_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IUser_put_Password_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUser_get_Name_Proxy( 
    IUser __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUser_get_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUser_put_Name_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IUser_put_Name_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUser_get_School_Proxy( 
    IUser __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUser_get_School_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUser_put_School_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IUser_put_School_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUser_get_Department_Proxy( 
    IUser __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUser_get_Department_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUser_put_Department_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IUser_put_Department_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUser_get_Class_Proxy( 
    IUser __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUser_get_Class_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUser_put_Class_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IUser_put_Class_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUser_get_Email_Proxy( 
    IUser __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUser_get_Email_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUser_put_Email_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IUser_put_Email_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUser_get_StudentNO_Proxy( 
    IUser __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pVal);


void __RPC_STUB IUser_get_StudentNO_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUser_put_StudentNO_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IUser_put_StudentNO_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IUser_get_UserID_Proxy( 
    IUser __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IUser_get_UserID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IUser_put_UserID_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB IUser_put_UserID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUser_CheckValid_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ int x_nType,
    /* [in] */ BSTR x_No,
    /* [in] */ BSTR x_Password,
    /* [retval][out] */ BSTR __RPC_FAR *x_Success);


void __RPC_STUB IUser_CheckValid_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUser_GetUserInfo_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ int x_nType,
    /* [in] */ int x_UID,
    /* [retval][out] */ BSTR __RPC_FAR *x_UserInfo);


void __RPC_STUB IUser_GetUserInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUser_InsertUserInfo_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ int x_nType,
    /* [retval][out] */ int __RPC_FAR *x_Success);


void __RPC_STUB IUser_InsertUserInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUser_DeleteUserInfo_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ int x_nType,
    /* [in] */ int x_UID,
    /* [retval][out] */ BSTR __RPC_FAR *x_Success);


void __RPC_STUB IUser_DeleteUserInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IUser_GetUser_Proxy( 
    IUser __RPC_FAR * This,
    /* [in] */ int x_nType,
    /* [in] */ BSTR x_mUsername);


void __RPC_STUB IUser_GetUser_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IUser_INTERFACE_DEFINED__ */



#ifndef __USERINFOLib_LIBRARY_DEFINED__
#define __USERINFOLib_LIBRARY_DEFINED__

/* library USERINFOLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_USERINFOLib;

EXTERN_C const CLSID CLSID_User;

#ifdef __cplusplus

class DECLSPEC_UUID("DB34E282-8936-4419-A9BC-4DDF8E456F6E")
User;
#endif
#endif /* __USERINFOLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
