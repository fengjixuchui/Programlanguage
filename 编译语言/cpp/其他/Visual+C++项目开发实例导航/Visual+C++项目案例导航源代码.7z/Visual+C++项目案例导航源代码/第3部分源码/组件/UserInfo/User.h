// User.h : Declaration of the CUser

#ifndef __USER_H_
#define __USER_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CUser
class ATL_NO_VTABLE CUser : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CUser, &CLSID_User>,
	public IDispatchImpl<IUser, &IID_IUser, &LIBID_USERINFOLib>
{
public:
	CUser()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_USER)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CUser)
	COM_INTERFACE_ENTRY(IUser)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IUser
public:
	STDMETHOD(GetUser)(/*[in] */ int x_nType,/*[in]*/ BSTR  x_mUsername);
	STDMETHOD(DeleteUserInfo)(/*[in]*/int x_nType,/*[in]*/ int x_UID,/*[out retval]*/ BSTR *x_Success);
	STDMETHOD(InsertUserInfo)(/*[in]*/ int x_nType,/*[out,retval] */int *x_Success);
	STDMETHOD(GetUserInfo)(/*[in]*/int x_nType,/*[in]*/ int x_UID,/*[out,retval]*/BSTR  *x_UserInfo);
	STDMETHOD(CheckValid)(/*[in]*/ int x_nType,/*[in]*/ BSTR x_No,/*[in]*/ BSTR x_Password,/*[out,retval]*/ BSTR *x_Success);
	_RecordsetPtr pRs;
	_ConnectionPtr pConn;
	STDMETHOD(get_UserID)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_UserID)(/*[in]*/ long newVal);
	STDMETHOD(get_StudentNO)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_StudentNO)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Email)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Email)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Class)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Class)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Department)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Department)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_School)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_School)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Name)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Name)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Password)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Password)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Username)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Username)(/*[in]*/ BSTR newVal);
private:
	bool m_bExist;
	long m_UserID;
	CComBSTR m_bstrStudentNO;
	CComBSTR m_bstrEmail;
	CComBSTR m_bstrClass;
	CComBSTR m_bstrDepartment;
	CComBSTR m_bstrSchool;
	CComBSTR m_bstrName;
	CComBSTR m_bstrPassword;
	CComBSTR m_bstrUsername;
};

#endif //__USER_H_
