/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed Jan 02 16:53:02 2002
 */
/* Compiler settings for D:\old21\vcbook\EXAM1\EXAM.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __EXAM_h__
#define __EXAM_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ICaculateScore_FWD_DEFINED__
#define __ICaculateScore_FWD_DEFINED__
typedef interface ICaculateScore ICaculateScore;
#endif 	/* __ICaculateScore_FWD_DEFINED__ */


#ifndef __IGenerateExam_FWD_DEFINED__
#define __IGenerateExam_FWD_DEFINED__
typedef interface IGenerateExam IGenerateExam;
#endif 	/* __IGenerateExam_FWD_DEFINED__ */


#ifndef __ISaveCurrentAnswer_FWD_DEFINED__
#define __ISaveCurrentAnswer_FWD_DEFINED__
typedef interface ISaveCurrentAnswer ISaveCurrentAnswer;
#endif 	/* __ISaveCurrentAnswer_FWD_DEFINED__ */


#ifndef __IExamState_FWD_DEFINED__
#define __IExamState_FWD_DEFINED__
typedef interface IExamState IExamState;
#endif 	/* __IExamState_FWD_DEFINED__ */


#ifndef __CaculateScore_FWD_DEFINED__
#define __CaculateScore_FWD_DEFINED__

#ifdef __cplusplus
typedef class CaculateScore CaculateScore;
#else
typedef struct CaculateScore CaculateScore;
#endif /* __cplusplus */

#endif 	/* __CaculateScore_FWD_DEFINED__ */


#ifndef __GenerateExam_FWD_DEFINED__
#define __GenerateExam_FWD_DEFINED__

#ifdef __cplusplus
typedef class GenerateExam GenerateExam;
#else
typedef struct GenerateExam GenerateExam;
#endif /* __cplusplus */

#endif 	/* __GenerateExam_FWD_DEFINED__ */


#ifndef __SaveCurrentAnswer_FWD_DEFINED__
#define __SaveCurrentAnswer_FWD_DEFINED__

#ifdef __cplusplus
typedef class SaveCurrentAnswer SaveCurrentAnswer;
#else
typedef struct SaveCurrentAnswer SaveCurrentAnswer;
#endif /* __cplusplus */

#endif 	/* __SaveCurrentAnswer_FWD_DEFINED__ */


#ifndef __ExamState_FWD_DEFINED__
#define __ExamState_FWD_DEFINED__

#ifdef __cplusplus
typedef class ExamState ExamState;
#else
typedef struct ExamState ExamState;
#endif /* __cplusplus */

#endif 	/* __ExamState_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ICaculateScore_INTERFACE_DEFINED__
#define __ICaculateScore_INTERFACE_DEFINED__

/* interface ICaculateScore */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICaculateScore;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("0F21423C-1338-4C27-973F-05B204B6F3D0")
    ICaculateScore : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Score( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Score( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CaculateScore( 
            /* [in] */ int x_nSID,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetScore( 
            /* [in] */ int x_nSID,
            /* [retval][out] */ int __RPC_FAR *x_nScore) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICaculateScoreVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICaculateScore __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICaculateScore __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICaculateScore __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ICaculateScore __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ICaculateScore __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ICaculateScore __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ICaculateScore __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Score )( 
            ICaculateScore __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Score )( 
            ICaculateScore __RPC_FAR * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CaculateScore )( 
            ICaculateScore __RPC_FAR * This,
            /* [in] */ int x_nSID,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetScore )( 
            ICaculateScore __RPC_FAR * This,
            /* [in] */ int x_nSID,
            /* [retval][out] */ int __RPC_FAR *x_nScore);
        
        END_INTERFACE
    } ICaculateScoreVtbl;

    interface ICaculateScore
    {
        CONST_VTBL struct ICaculateScoreVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICaculateScore_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICaculateScore_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICaculateScore_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICaculateScore_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICaculateScore_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICaculateScore_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICaculateScore_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICaculateScore_get_Score(This,pVal)	\
    (This)->lpVtbl -> get_Score(This,pVal)

#define ICaculateScore_put_Score(This,newVal)	\
    (This)->lpVtbl -> put_Score(This,newVal)

#define ICaculateScore_CaculateScore(This,x_nSID,x_Success)	\
    (This)->lpVtbl -> CaculateScore(This,x_nSID,x_Success)

#define ICaculateScore_GetScore(This,x_nSID,x_nScore)	\
    (This)->lpVtbl -> GetScore(This,x_nSID,x_nScore)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICaculateScore_get_Score_Proxy( 
    ICaculateScore __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ICaculateScore_get_Score_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ICaculateScore_put_Score_Proxy( 
    ICaculateScore __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ICaculateScore_put_Score_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICaculateScore_CaculateScore_Proxy( 
    ICaculateScore __RPC_FAR * This,
    /* [in] */ int x_nSID,
    /* [retval][out] */ BSTR __RPC_FAR *x_Success);


void __RPC_STUB ICaculateScore_CaculateScore_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICaculateScore_GetScore_Proxy( 
    ICaculateScore __RPC_FAR * This,
    /* [in] */ int x_nSID,
    /* [retval][out] */ int __RPC_FAR *x_nScore);


void __RPC_STUB ICaculateScore_GetScore_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICaculateScore_INTERFACE_DEFINED__ */


#ifndef __IGenerateExam_INTERFACE_DEFINED__
#define __IGenerateExam_INTERFACE_DEFINED__

/* interface IGenerateExam */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IGenerateExam;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2FD534D2-E3DF-4FFD-9578-C23626B34D59")
    IGenerateExam : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GenerateExam( 
            /* [in] */ int x_nSID,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IGenerateExamVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IGenerateExam __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IGenerateExam __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IGenerateExam __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IGenerateExam __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IGenerateExam __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IGenerateExam __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IGenerateExam __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GenerateExam )( 
            IGenerateExam __RPC_FAR * This,
            /* [in] */ int x_nSID,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success);
        
        END_INTERFACE
    } IGenerateExamVtbl;

    interface IGenerateExam
    {
        CONST_VTBL struct IGenerateExamVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IGenerateExam_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IGenerateExam_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IGenerateExam_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IGenerateExam_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IGenerateExam_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IGenerateExam_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IGenerateExam_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IGenerateExam_GenerateExam(This,x_nSID,x_Success)	\
    (This)->lpVtbl -> GenerateExam(This,x_nSID,x_Success)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IGenerateExam_GenerateExam_Proxy( 
    IGenerateExam __RPC_FAR * This,
    /* [in] */ int x_nSID,
    /* [retval][out] */ BSTR __RPC_FAR *x_Success);


void __RPC_STUB IGenerateExam_GenerateExam_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IGenerateExam_INTERFACE_DEFINED__ */


#ifndef __ISaveCurrentAnswer_INTERFACE_DEFINED__
#define __ISaveCurrentAnswer_INTERFACE_DEFINED__

/* interface ISaveCurrentAnswer */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISaveCurrentAnswer;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("DFC80869-90AB-4053-BAA7-65AFE216CC83")
    ISaveCurrentAnswer : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SaveAnswer( 
            /* [in] */ int x_nSID,
            /* [in] */ int x_nQID,
            /* [in] */ int x_nAnswer,
            /* [in] */ int x_nTimeLeft,
            /* [in] */ int x_nForward,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISaveCurrentAnswerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISaveCurrentAnswer __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISaveCurrentAnswer __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISaveCurrentAnswer __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISaveCurrentAnswer __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISaveCurrentAnswer __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISaveCurrentAnswer __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISaveCurrentAnswer __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaveAnswer )( 
            ISaveCurrentAnswer __RPC_FAR * This,
            /* [in] */ int x_nSID,
            /* [in] */ int x_nQID,
            /* [in] */ int x_nAnswer,
            /* [in] */ int x_nTimeLeft,
            /* [in] */ int x_nForward,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success);
        
        END_INTERFACE
    } ISaveCurrentAnswerVtbl;

    interface ISaveCurrentAnswer
    {
        CONST_VTBL struct ISaveCurrentAnswerVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISaveCurrentAnswer_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISaveCurrentAnswer_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISaveCurrentAnswer_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISaveCurrentAnswer_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISaveCurrentAnswer_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISaveCurrentAnswer_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISaveCurrentAnswer_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISaveCurrentAnswer_SaveAnswer(This,x_nSID,x_nQID,x_nAnswer,x_nTimeLeft,x_nForward,x_Success)	\
    (This)->lpVtbl -> SaveAnswer(This,x_nSID,x_nQID,x_nAnswer,x_nTimeLeft,x_nForward,x_Success)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISaveCurrentAnswer_SaveAnswer_Proxy( 
    ISaveCurrentAnswer __RPC_FAR * This,
    /* [in] */ int x_nSID,
    /* [in] */ int x_nQID,
    /* [in] */ int x_nAnswer,
    /* [in] */ int x_nTimeLeft,
    /* [in] */ int x_nForward,
    /* [retval][out] */ BSTR __RPC_FAR *x_Success);


void __RPC_STUB ISaveCurrentAnswer_SaveAnswer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISaveCurrentAnswer_INTERFACE_DEFINED__ */


#ifndef __IExamState_INTERFACE_DEFINED__
#define __IExamState_INTERFACE_DEFINED__

/* interface IExamState */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IExamState;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("03619FC2-96E0-466D-A2CD-A35C9C59BB80")
    IExamState : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CheckExist( 
            /* [in] */ int x_nSID,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CheckFinish( 
            /* [in] */ int x_nSID,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetAnswer( 
            /* [in] */ int x_nSID,
            /* [in] */ int x_nQID,
            /* [retval][out] */ long __RPC_FAR *x_lAnswer) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCurrentQuestion( 
            /* [in] */ int x_nSID,
            /* [retval][out] */ long __RPC_FAR *x_lCurrentQuestion) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_QType( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TimeLeft( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_QTypeforbstr( 
            /* [retval][out] */ BSTR __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_QTypeforbstr( 
            /* [in] */ BSTR __RPC_FAR *newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetExamInfo( 
            /* [in] */ long x_nSID,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetExamDetail( 
            /* [in] */ long x_nSID,
            /* [in] */ int x_nQNO,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_QID( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IExamStateVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IExamState __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IExamState __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IExamState __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IExamState __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IExamState __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IExamState __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IExamState __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CheckExist )( 
            IExamState __RPC_FAR * This,
            /* [in] */ int x_nSID,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CheckFinish )( 
            IExamState __RPC_FAR * This,
            /* [in] */ int x_nSID,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAnswer )( 
            IExamState __RPC_FAR * This,
            /* [in] */ int x_nSID,
            /* [in] */ int x_nQID,
            /* [retval][out] */ long __RPC_FAR *x_lAnswer);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCurrentQuestion )( 
            IExamState __RPC_FAR * This,
            /* [in] */ int x_nSID,
            /* [retval][out] */ long __RPC_FAR *x_lCurrentQuestion);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_QType )( 
            IExamState __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TimeLeft )( 
            IExamState __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_QTypeforbstr )( 
            IExamState __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *__RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_QTypeforbstr )( 
            IExamState __RPC_FAR * This,
            /* [in] */ BSTR __RPC_FAR *newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetExamInfo )( 
            IExamState __RPC_FAR * This,
            /* [in] */ long x_nSID,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetExamDetail )( 
            IExamState __RPC_FAR * This,
            /* [in] */ long x_nSID,
            /* [in] */ int x_nQNO,
            /* [retval][out] */ BSTR __RPC_FAR *x_Success);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_QID )( 
            IExamState __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        END_INTERFACE
    } IExamStateVtbl;

    interface IExamState
    {
        CONST_VTBL struct IExamStateVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IExamState_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IExamState_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IExamState_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IExamState_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IExamState_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IExamState_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IExamState_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IExamState_CheckExist(This,x_nSID,x_Success)	\
    (This)->lpVtbl -> CheckExist(This,x_nSID,x_Success)

#define IExamState_CheckFinish(This,x_nSID,x_Success)	\
    (This)->lpVtbl -> CheckFinish(This,x_nSID,x_Success)

#define IExamState_GetAnswer(This,x_nSID,x_nQID,x_lAnswer)	\
    (This)->lpVtbl -> GetAnswer(This,x_nSID,x_nQID,x_lAnswer)

#define IExamState_GetCurrentQuestion(This,x_nSID,x_lCurrentQuestion)	\
    (This)->lpVtbl -> GetCurrentQuestion(This,x_nSID,x_lCurrentQuestion)

#define IExamState_get_QType(This,pVal)	\
    (This)->lpVtbl -> get_QType(This,pVal)

#define IExamState_get_TimeLeft(This,pVal)	\
    (This)->lpVtbl -> get_TimeLeft(This,pVal)

#define IExamState_get_QTypeforbstr(This,pVal)	\
    (This)->lpVtbl -> get_QTypeforbstr(This,pVal)

#define IExamState_put_QTypeforbstr(This,newVal)	\
    (This)->lpVtbl -> put_QTypeforbstr(This,newVal)

#define IExamState_GetExamInfo(This,x_nSID,x_Success)	\
    (This)->lpVtbl -> GetExamInfo(This,x_nSID,x_Success)

#define IExamState_GetExamDetail(This,x_nSID,x_nQNO,x_Success)	\
    (This)->lpVtbl -> GetExamDetail(This,x_nSID,x_nQNO,x_Success)

#define IExamState_get_QID(This,pVal)	\
    (This)->lpVtbl -> get_QID(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IExamState_CheckExist_Proxy( 
    IExamState __RPC_FAR * This,
    /* [in] */ int x_nSID,
    /* [retval][out] */ BSTR __RPC_FAR *x_Success);


void __RPC_STUB IExamState_CheckExist_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IExamState_CheckFinish_Proxy( 
    IExamState __RPC_FAR * This,
    /* [in] */ int x_nSID,
    /* [retval][out] */ BSTR __RPC_FAR *x_Success);


void __RPC_STUB IExamState_CheckFinish_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IExamState_GetAnswer_Proxy( 
    IExamState __RPC_FAR * This,
    /* [in] */ int x_nSID,
    /* [in] */ int x_nQID,
    /* [retval][out] */ long __RPC_FAR *x_lAnswer);


void __RPC_STUB IExamState_GetAnswer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IExamState_GetCurrentQuestion_Proxy( 
    IExamState __RPC_FAR * This,
    /* [in] */ int x_nSID,
    /* [retval][out] */ long __RPC_FAR *x_lCurrentQuestion);


void __RPC_STUB IExamState_GetCurrentQuestion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IExamState_get_QType_Proxy( 
    IExamState __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IExamState_get_QType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IExamState_get_TimeLeft_Proxy( 
    IExamState __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IExamState_get_TimeLeft_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IExamState_get_QTypeforbstr_Proxy( 
    IExamState __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB IExamState_get_QTypeforbstr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IExamState_put_QTypeforbstr_Proxy( 
    IExamState __RPC_FAR * This,
    /* [in] */ BSTR __RPC_FAR *newVal);


void __RPC_STUB IExamState_put_QTypeforbstr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IExamState_GetExamInfo_Proxy( 
    IExamState __RPC_FAR * This,
    /* [in] */ long x_nSID,
    /* [retval][out] */ BSTR __RPC_FAR *x_Success);


void __RPC_STUB IExamState_GetExamInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IExamState_GetExamDetail_Proxy( 
    IExamState __RPC_FAR * This,
    /* [in] */ long x_nSID,
    /* [in] */ int x_nQNO,
    /* [retval][out] */ BSTR __RPC_FAR *x_Success);


void __RPC_STUB IExamState_GetExamDetail_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IExamState_get_QID_Proxy( 
    IExamState __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB IExamState_get_QID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IExamState_INTERFACE_DEFINED__ */



#ifndef __EXAMLib_LIBRARY_DEFINED__
#define __EXAMLib_LIBRARY_DEFINED__

/* library EXAMLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_EXAMLib;

EXTERN_C const CLSID CLSID_CaculateScore;

#ifdef __cplusplus

class DECLSPEC_UUID("1B9BE4C5-74A9-4BA8-8035-2EF72E2DDC32")
CaculateScore;
#endif

EXTERN_C const CLSID CLSID_GenerateExam;

#ifdef __cplusplus

class DECLSPEC_UUID("F0DB826B-A7E4-4987-8F28-24BDE59CF8C3")
GenerateExam;
#endif

EXTERN_C const CLSID CLSID_SaveCurrentAnswer;

#ifdef __cplusplus

class DECLSPEC_UUID("9EFE7F5C-5B80-4B16-9188-16D3C7B768C5")
SaveCurrentAnswer;
#endif

EXTERN_C const CLSID CLSID_ExamState;

#ifdef __cplusplus

class DECLSPEC_UUID("15F86C3A-EDC1-4E13-A009-DD442B0F965E")
ExamState;
#endif
#endif /* __EXAMLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
