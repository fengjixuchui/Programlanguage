// CheckFinish.h : Declaration of the CCheckFinish

#ifndef __CHECKFINISH_H_
#define __CHECKFINISH_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCheckFinish
class ATL_NO_VTABLE CCheckFinish : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCheckFinish, &CLSID_CheckFinish>,
	public IDispatchImpl<ICheckFinish, &IID_ICheckFinish, &LIBID_EXAMLib>
{
public:
	CCheckFinish()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CHECKFINISH)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCheckFinish)
	COM_INTERFACE_ENTRY(ICheckFinish)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ICheckFinish
public:
};

#endif //__CHECKFINISH_H_
