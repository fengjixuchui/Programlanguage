/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Jan 27 18:14:34 2002
 */
/* Compiler settings for D:\old21\vcbook\UserInfo\UserInfo.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IUser = {0x8A16D6E2,0xDD06,0x40F0,{0x9B,0x57,0xA6,0xC4,0xB3,0x57,0x0F,0x60}};


const IID LIBID_USERINFOLib = {0xD333747E,0x43A3,0x4B32,{0x82,0x96,0xFC,0xBA,0x74,0xD8,0x6F,0x92}};


const CLSID CLSID_User = {0xDB34E282,0x8936,0x4419,{0xA9,0xBC,0x4D,0xDF,0x8E,0x45,0x6F,0x6E}};


#ifdef __cplusplus
}
#endif

