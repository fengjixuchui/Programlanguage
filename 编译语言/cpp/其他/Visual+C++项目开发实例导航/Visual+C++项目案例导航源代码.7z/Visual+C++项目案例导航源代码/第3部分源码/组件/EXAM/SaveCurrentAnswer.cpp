// SaveCurrentAnswer.cpp : Implementation of CSaveCurrentAnswer
#include "stdafx.h"
#include "EXAM.h"
#include "SaveCurrentAnswer.h"

/////////////////////////////////////////////////////////////////////////////
// CSaveCurrentAnswer

HRESULT CSaveCurrentAnswer::Activate()
{
	HRESULT hr = GetObjectContext(&m_spObjectContext);
	if (SUCCEEDED(hr))
		return S_OK;
	return hr;
} 

BOOL CSaveCurrentAnswer::CanBePooled()
{
	return FALSE;
} 

void CSaveCurrentAnswer::Deactivate()
{
	m_spObjectContext.Release();
} 


STDMETHODIMP CSaveCurrentAnswer::SaveAnswer(int x_nSID, int x_nQID, int x_nAnswer, int x_nTimeLeft, int x_nForward, BSTR *x_Success)
{
	// TODO: Add your implementation code here
	try
	{
		if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
		{
			*x_Success = ::SysAllocString(L"Couldn't create connection component!");
			return S_OK;
		}
		if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
		{
			*x_Success = ::SysAllocString(L"Couldn't open connection!");
			return S_OK;
		}
		char m_strSql[256];
		char m_strBuf[10];
		strcpy(m_strSql,"Update testproc set currentquestion=");
		if (x_nForward == 0)
		{
			if (x_nQID == 1)
				_itoa(x_nQID, m_strBuf, 10);
			else
				_itoa(x_nQID-1, m_strBuf, 10);
		}
		else
		{
			if (x_nQID == 80)
				_itoa(x_nQID, m_strBuf, 10);
			else
				_itoa(x_nQID+1, m_strBuf, 10);
		}
		strcat(m_strSql, m_strBuf);
		strcat(m_strSql, ",TIMELEFT=");
		_itoa(x_nTimeLeft, m_strBuf, 10);
		strcat(m_strSql, m_strBuf);
		strcat(m_strSql, " WHERE SID=");
		_itoa(x_nSID, m_strBuf, 10);
		strcat(m_strSql, m_strBuf);
		CComVariant m_varNum;
		pConn->Execute(m_strSql, &m_varNum, -1);
		strcpy(m_strSql,"Update testprocdetail set a=");
		_itoa(x_nAnswer, m_strBuf, 10);
		strcat(m_strSql, m_strBuf);
		strcat(m_strSql," where QNO=");
		_itoa(x_nQID, m_strBuf, 10);
		strcat(m_strSql,m_strBuf);
		strcat(m_strSql,"  and sid=");
		_itoa(x_nSID, m_strBuf, 10);
		strcat(m_strSql, m_strBuf);
		pConn->Execute(m_strSql, &m_varNum, -1);
		pConn->Close();
		m_spObjectContext->SetComplete();
		*x_Success = ::SysAllocString(L"Successful!");
	}
	catch(...)
	{
		if (pConn != NULL)
		{
			pConn->Close();
		}
		*x_Success = ::SysAllocString(L"Error occurs!");
		m_spObjectContext->SetAbort();
		return S_OK;
	}
	return S_OK;
}
