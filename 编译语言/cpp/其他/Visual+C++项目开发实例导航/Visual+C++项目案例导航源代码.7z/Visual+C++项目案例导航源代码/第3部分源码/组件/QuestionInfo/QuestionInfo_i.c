/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Jul 04 10:16:09 2002
 */
/* Compiler settings for F:\��Visual C++��Ŀ����������Դ����\��3����Դ��\���\QuestionInfo\QuestionInfo.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IQuestion = {0x362ABD33,0x561C,0x4541,{0x9E,0x21,0x30,0x05,0x73,0xAB,0x21,0x63}};


const IID LIBID_QUESTIONINFOLib = {0x4C4867FA,0xF331,0x400D,{0x9A,0x4E,0xF8,0x61,0x57,0x22,0x98,0x63}};


const CLSID CLSID_Question = {0x7672935A,0xB914,0x466A,{0xBB,0x82,0x9E,0xC8,0x92,0x63,0x61,0x23}};


#ifdef __cplusplus
}
#endif

