// User.cpp : Implementation of CUser
#include "stdafx.h"
#include "UserInfo.h"
#include "User.h"

/////////////////////////////////////////////////////////////////////////////
// CUser


STDMETHODIMP CUser::get_Username(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrUsername;
	return S_OK;
}

STDMETHODIMP CUser::put_Username(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrUsername=newVal;
	return S_OK;
}

STDMETHODIMP CUser::get_Password(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrPassword;
	return S_OK;
}

STDMETHODIMP CUser::put_Password(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrPassword=newVal;
	return S_OK;
}

STDMETHODIMP CUser::get_Name(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrName;
	return S_OK;
}

STDMETHODIMP CUser::put_Name(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrName=newVal;
	return S_OK;
}

STDMETHODIMP CUser::get_School(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrSchool;
	return S_OK;
}

STDMETHODIMP CUser::put_School(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrSchool=newVal;
	return S_OK;
}

STDMETHODIMP CUser::get_Department(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrDepartment;
	return S_OK;
}

STDMETHODIMP CUser::put_Department(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrDepartment=newVal;
	return S_OK;
}

STDMETHODIMP CUser::get_Class(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrClass;
	return S_OK;
}

STDMETHODIMP CUser::put_Class(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrClass=newVal;
	return S_OK;
}

STDMETHODIMP CUser::get_Email(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrEmail;
	return S_OK;
}

STDMETHODIMP CUser::put_Email(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrEmail=newVal;
	return S_OK;
}

STDMETHODIMP CUser::get_StudentNO(BSTR *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_bstrStudentNO;
	return S_OK;
}

STDMETHODIMP CUser::put_StudentNO(BSTR newVal)
{
	// TODO: Add your implementation code here
	m_bstrStudentNO=newVal;
	return S_OK;
}

STDMETHODIMP CUser::get_UserID(long *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_UserID;
	return S_OK;
}

STDMETHODIMP CUser::put_UserID(long newVal)
{
	// TODO: Add your implementation code here
	m_UserID=newVal;
	return S_OK;
}

STDMETHODIMP CUser::CheckValid(int x_nType,BSTR x_No, BSTR x_Password, BSTR *x_Success)
{
	// TODO: Add your implementation code here
	if(FAILED(pConn.CreateInstance(__uuidof(Connection))))
	{
		*x_Success = ::SysAllocString(L"Couldn't create connection component");
		return S_OK;
	}

	CComBSTR m_bstrSql;

	switch(x_nType)
	{
	case 0:
		m_bstrSql.Append("SELECT SID FROM STUDENTACCOUNT WHERE USERNAME='");
		break;
	case 1:
		m_bstrSql.Append("SELECT TID FROM TEACHERACCOUNT WHERE USERNAME='");
		break;
	default:
		*x_Success=::SysAllocString(L"the type does not exist");
		return S_OK;
	}

	m_bstrSql.AppendBSTR(x_No);
	m_bstrSql.Append("' AND PASSWORD='");
	m_bstrSql.AppendBSTR(x_Password);
	m_bstrSql.Append("'");

	//if (FAILED(pConn->Open("Provider=SQLOLEDB.1;Password=;Persist Security Info=True;User ID=sa;Data Source=202.112.113.114;Initial Catalog=EXAM","","",-1)))
	if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
	{
		*x_Success = ::SysAllocString(L"Couldn't open connection");
		return S_OK;
	}

	CComVariant m_varNumber;
	_bstr_t m_bstrTemp(m_bstrSql,FALSE);

	//pRs = pConn->Execute(m_bstrSql, &m_varNumber, -1);
	pRs = pConn->Execute(m_bstrTemp, &m_varNumber, -1);

	if (m_varNumber.lVal == 0)
	{
		*x_Success = ::SysAllocString(L"Couldn't find records!");
		return S_OK;
	}
	
	CComVariant m_varData;

	switch(x_nType)
	{
	case 0:
		pRs->Fields->GetItem("SID")->get_Value(&m_varData);
		break;
	case 1:
		pRs->Fields->GetItem("TID")->get_Value(&m_varData);
		break;
	default:
		return S_OK;
	}
	m_UserID = m_varData.iVal;

	*x_Success = ::SysAllocString(L"Y");

	m_bExist = TRUE;

	return S_OK;

}

STDMETHODIMP CUser::GetUserInfo(int x_nType, int x_UID, BSTR *x_UserInfo)
{
	// TODO: Add your implementation code here
	
	if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
	{
		*x_UserInfo = ::SysAllocString(L"N#Couldn't create connection component!");
		return S_OK;
	}

	if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
	{
		*x_UserInfo = ::SysAllocString(L"N#Couldn't open connection!");
		return S_OK;
	}

	char m_strBuf[10];
	_itoa(x_UID, m_strBuf, 10);
	
	CComBSTR m_bstrSql;
	switch(x_nType)
	{
	case 0:
		m_bstrSql.Append("SELECT * FROM STUDENTACCOUNT WHERE SID=");
		break;
	case 1:
		m_bstrSql.Append("SELECT * FROM TEACHERACCOUNT WHERE TID=");
		break;
	default:
		*x_UserInfo=::SysAllocString(L"The Type does not exist.");
		return S_OK;
	}
	m_bstrSql.Append(m_strBuf);

	_bstr_t m_bstrResult(m_bstrSql,FALSE);
	

	CComVariant m_varNum;

	pRs = pConn->Execute(m_bstrResult, &m_varNum, -1);
	/*
	if (m_varNum.lVal == 0)
	{
		*x_nScore = 0;
		return S_OK;
	}
	*/
	if (pRs->ADOEOF)
	{
		*x_UserInfo = ::SysAllocString(L"N#Couldn't find records!");
		return S_OK;
	}

	CComVariant m_varData;
	CComBSTR m_bstrInfo;
	m_bstrInfo.Append("Y#");

	pRs->GetFields()->GetItem("USERNAME")->get_Value(&m_varData);
	if(m_varData.vt = VT_BSTR)
	{
		m_bstrInfo.AppendBSTR(m_varData.bstrVal );
		m_bstrUsername.Empty();
		m_bstrUsername.AppendBSTR(m_varData.bstrVal);
	}
	m_bstrInfo.Append("#");
	

	pRs->GetFields()->GetItem("PASSWORD")->get_Value(&m_varData);
	if(m_varData.vt = VT_BSTR)
	{
		m_bstrInfo.AppendBSTR(m_varData.bstrVal );
		m_bstrPassword.Empty();
		m_bstrPassword.AppendBSTR(m_varData.bstrVal);
	}
	m_bstrInfo.Append("#");

	pRs->GetFields()->GetItem("NAME")->get_Value(&m_varData);
	if(m_varData.vt = VT_BSTR)
	{
		m_bstrInfo.AppendBSTR(m_varData.bstrVal );
		m_bstrName.Empty();
		m_bstrName.AppendBSTR(m_varData.bstrVal);
	}
	m_bstrInfo.Append("#");

	pRs->GetFields()->GetItem("SCHOOL")->get_Value(&m_varData);
	if(m_varData.vt = VT_BSTR)
	{
		m_bstrInfo.AppendBSTR(m_varData.bstrVal );
		m_bstrSchool.Empty();
		m_bstrSchool.AppendBSTR(m_varData.bstrVal);
	}
	m_bstrInfo.Append("#");

	pRs->GetFields()->GetItem("DEPARTMENT")->get_Value(&m_varData);
	if(m_varData.vt = VT_BSTR)
	{
		m_bstrInfo.AppendBSTR(m_varData.bstrVal );
		m_bstrDepartment.Empty();
		m_bstrDepartment.AppendBSTR(m_varData.bstrVal);
	}
	m_bstrInfo.Append("#");


	if(x_nType==0)
	{
		pRs->GetFields()->GetItem("STUDENTNO")->get_Value(&m_varData);
		if(m_varData.vt = VT_BSTR)
		{
			m_bstrInfo.AppendBSTR(m_varData.bstrVal );
			m_bstrStudentNO.AppendBSTR(m_varData.bstrVal);
		}
		m_bstrInfo.Append("#");

		pRs->GetFields()->GetItem("CLASS")->get_Value(&m_varData);
		if(m_varData.vt = VT_BSTR)
		{
			m_bstrInfo.AppendBSTR(m_varData.bstrVal );
			m_bstrClass.Empty();
			m_bstrClass.AppendBSTR(m_varData.bstrVal);
		}
		m_bstrInfo.Append("#");
	}
	if(x_nType==1)
	{
		pRs->GetFields()->GetItem("EMAIL")->get_Value(&m_varData);
		if(m_varData.vt = VT_BSTR)
		{
			m_bstrInfo.AppendBSTR(m_varData.bstrVal );
			m_bstrClass.Empty();
			m_bstrClass.AppendBSTR(m_varData.bstrVal);
		}
		m_bstrInfo.Append("#");
	}

	*x_UserInfo = m_bstrInfo;

	pRs->Close();
	pConn->Close();

	return S_OK;
}

STDMETHODIMP CUser::InsertUserInfo(int x_nType,int *x_Success)
{
	// TODO: Add your implementation code here
	if(FAILED(pConn.CreateInstance(__uuidof(Connection))))
	{
		*x_Success=-1;
		return S_OK;
	}
	if(FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
	{
		*x_Success=-1;
		return S_OK;
	}
	CComBSTR m_bstrSQL;

	switch(x_nType)
	{
	case 0:
		m_bstrSQL.Append("Insert into STUDENTACCOUNT(");
		break;
	case 1:
		m_bstrSQL.Append("Insert into TEACHERACCOUNT(");
		break;
	default:
		*x_Success=-1;
		return S_OK;
	}
	CComBSTR m_bstrTemp;

	m_bstrTemp.Append("values(");




	m_bstrSQL.Append("Username,password,Name");
	m_bstrTemp.Append("'");
	m_bstrTemp.AppendBSTR(m_bstrUsername);
	m_bstrTemp.Append("','");
	m_bstrTemp.AppendBSTR(m_bstrPassword);
	m_bstrTemp.Append("','");
	m_bstrTemp.AppendBSTR(m_bstrName);
	m_bstrTemp.Append("'");
	m_bstrTemp.Append(")");
	m_bstrSQL.Append(")");
	m_bstrSQL.AppendBSTR(m_bstrTemp);
	
	_bstr_t  m_bstrResult(m_bstrSQL,FALSE);

	CComVariant m_varNum;
	HRESULT hr=pConn->Execute(m_bstrResult,&m_varNum,-1);
	if(FAILED(hr))
	{
		*x_Success=-1;
		return S_OK;
	}

	m_bstrSQL.Empty();

	switch(x_nType)
	{
	case 0:
		m_bstrSQL.Append("UPDATE STUDENTACCOUNT SET School=");
		break;
	case 1:
		m_bstrSQL.Append("UPDATE TEACHERACCOUNT SET School=");
		break;
	default:
		*x_Success=-1;
		return S_OK;
	}
	m_bstrSQL.Append("'");
	m_bstrSQL.AppendBSTR(m_bstrSchool);
	m_bstrSQL.Append("',");
	m_bstrSQL.Append("Department='");
	m_bstrSQL.AppendBSTR(m_bstrDepartment);
	m_bstrSQL.Append("',");


	switch(x_nType)
	{
	case 0:
		m_bstrSQL.Append("CLASS='");
		m_bstrSQL.AppendBSTR(m_bstrClass);
		m_bstrSQL.Append("',");
		m_bstrSQL.Append("StudentNO='");
		m_bstrSQL.AppendBSTR(m_bstrStudentNO);
		m_bstrSQL.Append("'");
		break;
	case 1:
	    m_bstrSQL.Append("EMAIL='");
		m_bstrSQL.AppendBSTR(m_bstrEmail);
		m_bstrSQL.Append("'");
		break;
	default:
		*x_Success=-1;
		return S_OK;
	}
	
	m_bstrSQL.Append("  WHERE Name=");
	m_bstrSQL.Append("'");
	m_bstrSQL.AppendBSTR(m_bstrName);
	m_bstrSQL.Append("'");
	

    _bstr_t m_bstrResult1(m_bstrSQL,FALSE);
	hr=pConn->Execute(m_bstrResult1,&m_varNum,-1);
	if(FAILED(hr))
	{
		*x_Success=-1;
		return S_OK;
	}
	*x_Success=1;
	return S_OK;
}

STDMETHODIMP CUser::DeleteUserInfo(int x_nType,int x_UID, BSTR *x_Success)
{
	// TODO: Add your implementation code here
	if(FAILED(pConn.CreateInstance(__uuidof(Connection))))
	{
		*x_Success=::SysAllocString(L"Create Instance error");
		return S_OK;
	}
	if(FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
	{
		*x_Success=::SysAllocString(L"Open Connection error");
		return S_OK;
	}
	CComBSTR m_bstrSQL;
	char	m_charUID[10];
	_itoa(x_UID,m_charUID,10);

	switch(x_nType)
	{
		case 0:
			m_bstrSQL.Append("delete STUDENTACCOUNT where SID=");
			break;
		case 1:
			m_bstrSQL.Append("delete TEACHERACCOUNT where TID=");
			break;
		default:
			*x_Success=::SysAllocString(L"type does not exist");
			return S_OK;
	}
	m_bstrSQL.Append(m_charUID);
	_bstr_t m_bstrResult(m_bstrSQL,FALSE);
	CComVariant m_varNum;
	pConn->Execute(m_bstrResult,&m_varNum,-1);
	if(m_varNum.lVal!=1)
	{
		*x_Success=::SysAllocString(L"delete operation doesn't succeed");
		return S_OK;
	}
	pConn->Close();
	return S_OK;
}

STDMETHODIMP CUser::GetUser(int x_nType,BSTR x_mUsername)
{
	// TODO: Add your implementation code here
	if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
	{
		return S_OK;
	}

	if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
	{
		
		return S_OK;
	}

//	char m_strBuf[10];
//	_itoa(x_UID, m_strBuf, 10);
	
	CComBSTR m_bstrSql;
	switch(x_nType)
	{
	case 0:
		m_bstrSql.Append("SELECT * FROM STUDENTACCOUNT WHERE USERNAME=");
		break;
	case 1:
		m_bstrSql.Append("SELECT * FROM TEACHERACCOUNT WHERE USERNAME=");
		break;
	default:
	
		return S_OK;
	}
	m_bstrSql.Append("'");
	m_bstrSql.AppendBSTR(x_mUsername);
	m_bstrSql.Append("'");

	_bstr_t m_bstrResult(m_bstrSql,FALSE);
	

	CComVariant m_varNum;

	pRs = pConn->Execute(m_bstrResult, &m_varNum, -1);
	
	if (pRs->ADOEOF)
	{
	
		return S_OK;
	}

	CComVariant m_varData;
	CComBSTR m_bstrInfo;
	m_bstrInfo.Append("Y#");
	

	pRs->GetFields()->GetItem("PASSWORD")->get_Value(&m_varData);
	if(m_varData.vt = VT_BSTR)
	{
		m_bstrInfo.AppendBSTR(m_varData.bstrVal );
		m_bstrPassword.Empty();
		m_bstrPassword.AppendBSTR(m_varData.bstrVal);
	}
	m_bstrInfo.Append("#");

	pRs->GetFields()->GetItem("NAME")->get_Value(&m_varData);
	if(m_varData.vt = VT_BSTR)
	{
		m_bstrInfo.AppendBSTR(m_varData.bstrVal );
		m_bstrName.Empty();
		m_bstrName.AppendBSTR(m_varData.bstrVal);
	}
	m_bstrInfo.Append("#");

	pRs->GetFields()->GetItem("SCHOOL")->get_Value(&m_varData);
	if(m_varData.vt = VT_BSTR)
	{
		m_bstrInfo.AppendBSTR(m_varData.bstrVal );
		m_bstrSchool.Empty();
		m_bstrSchool.AppendBSTR(m_varData.bstrVal);
	}
	m_bstrInfo.Append("#");

	pRs->GetFields()->GetItem("DEPARTMENT")->get_Value(&m_varData);
	if(m_varData.vt = VT_BSTR)
	{
		m_bstrInfo.AppendBSTR(m_varData.bstrVal );
		m_bstrDepartment.Empty();
		m_bstrDepartment.AppendBSTR(m_varData.bstrVal);
	}
	m_bstrInfo.Append("#");


	if(x_nType==0)
	{
		pRs->GetFields()->GetItem("STUDENTNO")->get_Value(&m_varData);
		if(m_varData.vt = VT_BSTR)
		{
			m_bstrInfo.AppendBSTR(m_varData.bstrVal );
			m_bstrStudentNO.AppendBSTR(m_varData.bstrVal);
		}
		m_bstrInfo.Append("#");

		pRs->GetFields()->GetItem("SID")->get_Value(&m_varData);
		m_UserID=m_varData.lVal ;
		m_bstrInfo.Append("#");

		pRs->GetFields()->GetItem("CLASS")->get_Value(&m_varData);
		if(m_varData.vt = VT_BSTR)
		{
			m_bstrInfo.AppendBSTR(m_varData.bstrVal );
			m_bstrClass.Empty();
			m_bstrClass.AppendBSTR(m_varData.bstrVal);
		}
		m_bstrInfo.Append("#");
	}
	if(x_nType==1)
	{
		pRs->GetFields()->GetItem("EMAIL")->get_Value(&m_varData);
		if(m_varData.vt = VT_BSTR)
		{
			m_bstrInfo.AppendBSTR(m_varData.bstrVal );
			m_bstrClass.Empty();
			m_bstrClass.AppendBSTR(m_varData.bstrVal);
		}
		m_bstrInfo.Append("#");

		pRs->GetFields()->GetItem("TID")->get_Value(&m_varData);
		m_UserID=m_varData.lVal ;
		m_bstrInfo.Append("#");
	}

	pRs->Close();
	pConn->Close();

	return S_OK;

}
