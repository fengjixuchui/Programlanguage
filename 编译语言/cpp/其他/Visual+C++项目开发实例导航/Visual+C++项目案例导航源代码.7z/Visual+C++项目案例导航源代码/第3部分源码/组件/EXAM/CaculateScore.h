// CaculateScore.h : Declaration of the CCaculateScore

#ifndef __CACULATESCORE_H_
#define __CACULATESCORE_H_

#include "resource.h"       // main symbols
#include <mtx.h>


/////////////////////////////////////////////////////////////////////////////
// CCaculateScore
class ATL_NO_VTABLE CCaculateScore : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCaculateScore, &CLSID_CaculateScore>,
	public IObjectControl,
	public IDispatchImpl<ICaculateScore, &IID_ICaculateScore, &LIBID_EXAMLib>
{
public:
	CCaculateScore()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CACULATESCORE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

DECLARE_NOT_AGGREGATABLE(CCaculateScore)

BEGIN_COM_MAP(CCaculateScore)
	COM_INTERFACE_ENTRY(ICaculateScore)
	COM_INTERFACE_ENTRY(IObjectControl)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IObjectControl
public:
	STDMETHOD(Activate)();
	STDMETHOD_(BOOL, CanBePooled)();
	STDMETHOD_(void, Deactivate)();

	CComPtr<IObjectContext> m_spObjectContext;
	IQuestionPtr m_pQuestion;

// ICaculateScore
public:
	STDMETHOD(GetScore)(/*[in]*/ int x_nSID,/*[out,retval]*/ int *x_nScore);
	STDMETHOD(CaculateScore)(/*[in]*/ int x_nSID,/*[out,retval]*/ BSTR *x_Success);

	STDMETHOD(get_Score)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_Score)(/*[in]*/ long newVal);

private:
	int m_nScore;
	_RecordsetPtr pRsTemp;
	_RecordsetPtr pRs;
	_ConnectionPtr pConn;
};

#endif //__CACULATESCORE_H_
