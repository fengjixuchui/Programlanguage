// GenerateExam.cpp : Implementation of CGenerateExam
#include "stdafx.h"
#include "EXAM.h"
#include "GenerateExam.h"

#include "time.h"
#include "stdlib.h"

/////////////////////////////////////////////////////////////////////////////
// CGenerateExam

HRESULT CGenerateExam::Activate()
{
	HRESULT hr = GetObjectContext(&m_spObjectContext);
	if (SUCCEEDED(hr))
		return S_OK;
	return hr;
} 

BOOL CGenerateExam::CanBePooled()
{
	return FALSE;
} 

void CGenerateExam::Deactivate()
{
	m_spObjectContext.Release();
} 


STDMETHODIMP CGenerateExam::GenerateExam(int x_nSID, BSTR *x_Success)
{
	// TODO: Add your implementation code here
	int i;
	int j;
	int k;
	
	try
	{
		if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
		{
			*x_Success = ::SysAllocString(L"Create Instance error");
			return S_OK;
		}

		if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
		{
			*x_Success = ::SysAllocString(L"Open SQL Server error");
			return S_OK;
		}

		char m_strBuf[10];
		char m_strSID[10];
		_itoa(x_nSID, m_strSID, 10);
	
		CComBSTR m_bstrSql;

		
		m_bstrSql.Append("INSERT INTO TESTPROC(SID,TIMELEFT) VALUES(" );
		m_bstrSql.Append(m_strSID);
		m_bstrSql.Append(",7200)");

		_bstr_t m_bstrResult(m_bstrSql,FALSE);
		CComVariant m_varNum;
		pConn->Execute(m_bstrResult, &m_varNum, -1);
		i = 1;
		CComVariant m_varData;
		char m_strSql[256];



		pRs = pConn->Execute("SELECT QID FROM LOGIC", &m_varNum, -1);
		k = 0;
		while (!pRs->ADOEOF)
		{
			k = k + 1;
			pRs->MoveNext();
		}


		pRs->MoveFirst();

		if (k < 28)
		{

			while(!pRs->ADOEOF)
			{
				strcpy(m_strSql,"Insert Testprocdetail(SID,QNO,QType,Q) values(");
				strcat(m_strSql,m_strSID);
				strcat(m_strSql,",");
				_itoa(i, m_strBuf, 10);
				strcat(m_strSql,m_strBuf);
				strcat(m_strSql,",");
				strcat(m_strSql,"0");
				strcat(m_strSql,",");
				pRs->Fields->GetItem("QID")->get_Value(&m_varData);
				_itoa(m_varData.iVal, m_strBuf, 10);
				strcat(m_strSql,m_strBuf);
				strcat(m_strSql,")");
				pConn->Execute(m_strSql, &m_varNum, -1);
				i++;
				pRs->MoveNext();
			}

		}
		else
		{
			srand((unsigned) time(NULL));
			j = rand();
			j = (j * 20 ) % ( k - 27);

			while(j > 0)
			{
				pRs->MoveNext();
				j--;
			}

			while(!pRs->ADOEOF)
			{
				//modified by lee
				strcpy(m_strSql,"Insert Testprocdetail(SID,QNO,QType,Q) values(");
				strcat(m_strSql,m_strSID);
				strcat(m_strSql,",");
				_itoa(i, m_strBuf, 10);
				strcat(m_strSql,m_strBuf);
				strcat(m_strSql,",");
				strcat(m_strSql,"0");
				strcat(m_strSql,",");
				pRs->Fields->GetItem("QID")->get_Value(&m_varData);
				_itoa(m_varData.iVal, m_strBuf, 10);
				strcat(m_strSql,m_strBuf);
				strcat(m_strSql,")");
				pConn->Execute(m_strSql, &m_varNum, -1);
				i++;
				if (i > 27) 
					break;
				pRs->MoveNext();
				
			}

		}

		pRs->Close();

		pRs = pConn->Execute("SELECT QID FROM SINGLE", &m_varNum, -1);
		k = 0;
		while (!pRs->ADOEOF)
		{
			k = k + 1;
			pRs->MoveNext();
		}

		pRs->MoveFirst();

		if (k < 28)
		{

			while(!pRs->ADOEOF)
			{
				strcpy(m_strSql,"Insert Testprocdetail(sid,QNO,QType,Q) values(");
				strcat(m_strSql,m_strSID);
				strcat(m_strSql,",");
				_itoa(i, m_strBuf, 10);
				strcat(m_strSql,m_strBuf);
				strcat(m_strSql,",");
				strcat(m_strSql,"1");
				strcat(m_strSql,",");
				pRs->Fields->GetItem("QID")->get_Value(&m_varData);
				_itoa(m_varData.iVal, m_strBuf, 10);
				strcat(m_strSql,m_strBuf);
				strcat(m_strSql,")");

				pConn->Execute(m_strSql, &m_varNum, -1);
				
				i++;

				pRs->MoveNext();
				
			}

		}
		else
		{
			srand((unsigned) time(NULL));
			j = rand();
			j = (j * 20 ) % ( k - 27);

			while(j > 0)
			{
				pRs->MoveNext();
				j--;
			}

			while(!pRs->ADOEOF)
			{
				
				strcpy(m_strSql,"Insert Testprocdetail(SID,QNO,QType,Q) values(");
				strcat(m_strSql,m_strSID);
				strcat(m_strSql,",");
				_itoa(i, m_strBuf, 10);
				strcat(m_strSql,m_strBuf);
				strcat(m_strSql,",");
				strcat(m_strSql,"1");
				strcat(m_strSql,",");
				pRs->Fields->GetItem("QID")->get_Value(&m_varData);
				_itoa(m_varData.iVal, m_strBuf, 10);
				strcat(m_strSql,m_strBuf);
				strcat(m_strSql,")");
				

				pConn->Execute(m_strSql, &m_varNum, -1);
				
				i++;

				if (i > 54)
					break;

				pRs->MoveNext();
				
			}

		}

		pRs->Close();

		pRs = pConn->Execute("SELECT QID FROM MULTIPLY", &m_varNum, -1);
		k = 0;
		while (!pRs->ADOEOF)
		{
			k = k + 1;
			pRs->MoveNext();
		}

		pRs->MoveFirst();

		if (k < 28)
		{

			while(!pRs->ADOEOF)
			{
				
				strcpy(m_strSql,"Insert Testprocdetail(SID,QNO,QType,Q) values(");
				strcat(m_strSql,m_strSID);
				strcat(m_strSql,",");
				_itoa(i, m_strBuf, 10);
				strcat(m_strSql,m_strBuf);
				strcat(m_strSql,",");
				strcat(m_strSql,"2");
				strcat(m_strSql,",");
				pRs->Fields->GetItem("QID")->get_Value(&m_varData);
				_itoa(m_varData.iVal, m_strBuf, 10);
				strcat(m_strSql,m_strBuf);
				strcat(m_strSql,")");
				

				pConn->Execute(m_strSql, &m_varNum, -1);
				
				i++;

				pRs->MoveNext();
				
			}

		}
		else
		{
			srand((unsigned) time(NULL));
			j = rand();
			j = (j * 20 ) % ( k - 27);

			while(j > 0)
			{
				pRs->MoveNext();
				j--;
			}

			while(!pRs->ADOEOF)
			{
				
				strcpy(m_strSql,"Insert into Testprocdetail(Sid,QNO,QType,Q) values(");
				strcat(m_strSql,m_strSID);
				strcat(m_strSql,",");
				_itoa(i, m_strBuf, 10);
				strcat(m_strSql,m_strBuf);
				strcat(m_strSql,",");
				strcat(m_strSql,"2");
				strcat(m_strSql,",");
				pRs->Fields->GetItem("QID")->get_Value(&m_varData);
				_itoa(m_varData.iVal, m_strBuf, 10);
				strcat(m_strSql,m_strBuf);
				strcat(m_strSql,")");
				

				pConn->Execute(m_strSql, &m_varNum, -1);
				
				i++;

				if (i > 80)
					break;

				pRs->MoveNext();
				
			}

		}
	
		pRs->Close();
		pConn->Close();

		*x_Success=::SysAllocString(L"Operate Succeed");

	}
	catch(...)
	{
		if (pConn != NULL)
		{
			pConn->Close();
		}
		*x_Success = ::SysAllocString(L"Error Occured");

		return S_OK;
	}
	
	return S_OK;
}
