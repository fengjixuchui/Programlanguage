// Question.h : Declaration of the CQuestion

#ifndef __QUESTION_H_
#define __QUESTION_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CQuestion
class ATL_NO_VTABLE CQuestion : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CQuestion, &CLSID_Question>,
	public IDispatchImpl<IQuestion, &IID_IQuestion, &LIBID_QUESTIONINFOLib>
{
public:
	CQuestion()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_QUESTION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CQuestion)
	COM_INTERFACE_ENTRY(IQuestion)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IQuestion
public:
	STDMETHOD(get_Answer)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_Answer)(/*[in]*/ short newVal);
	STDMETHOD(DeleteQuestion)(/*[in]*/ int x_nType,/*[in]*/ int x_nQID,/*[out,retval]*/ int *x_Success);
	_RecordsetPtr pRs;
	_ConnectionPtr pConn;
	STDMETHOD(PutQuestion)(/*[in]*/ int x_nType,/*[out,retval]*/ int *x_QID);
	STDMETHOD(GetQuestion)(/*[in]*/ int x_nType,/*[in]*/ int x_nQID,/*[out,retval]*/ BSTR *x_QInfo);
	
	STDMETHOD(get_Q5)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Q5)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Q4)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Q4)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Q3)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Q3)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Q2)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Q2)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_Q1)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Q1)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_content)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_content)(/*[in]*/ BSTR newVal);
private:
	short m_shortAnswer;
	CComBSTR m_bstrQ5;
	CComBSTR m_bstrQ4;
	CComBSTR m_bstrQ3;
	CComBSTR m_bstrQ2;
	CComBSTR m_bstrcontent;
	CComBSTR m_bstrQ1;
};

#endif //__QUESTION_H_
