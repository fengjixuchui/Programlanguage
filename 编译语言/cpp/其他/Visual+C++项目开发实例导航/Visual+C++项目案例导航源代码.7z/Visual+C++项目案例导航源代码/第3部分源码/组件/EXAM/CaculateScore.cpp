// CaculateScore.cpp : Implementation of CCaculateScore
#include "stdafx.h"
#include "EXAM.h"
#include "CaculateScore.h"

//#import "QuestionInfo.tlb"



/////////////////////////////////////////////////////////////////////////////
// CCaculateScore

HRESULT CCaculateScore::Activate()
{
	HRESULT hr = GetObjectContext(&m_spObjectContext);
	if (SUCCEEDED(hr))
		return S_OK;
	return hr;
} 

BOOL CCaculateScore::CanBePooled()
{
	return FALSE;
} 

void CCaculateScore::Deactivate()
{
	m_spObjectContext.Release();
} 


STDMETHODIMP CCaculateScore::get_Score(long *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_nScore;

	return S_OK;
}

STDMETHODIMP CCaculateScore::put_Score(long newVal)
{
	// TODO: Add your implementation code here
	m_nScore=newVal;
	return S_OK;
}

STDMETHODIMP CCaculateScore::CaculateScore(int x_nSID, BSTR *x_Success)
{
	// TODO: Add your implementation code here
	try
	{
		if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
		{
			*x_Success = ::SysAllocString(L"Couldn't create connection component!");
			return S_OK;
		}

		if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
		{
			*x_Success = ::SysAllocString(L"Couldn't open connection!");
			return S_OK;
		}

		char m_strBuf[10];
		char m_strSql[256];
		CComBSTR m_bstrSql;
		CComVariant m_varNum;
		CComVariant m_varData;
		strcpy(m_strSql,"select * from testprocdetail where SID=");
		_itoa(x_nSID, m_strBuf, 10);
		strcat(m_strSql, m_strBuf);
		pRs = pConn->Execute(m_strSql, &m_varNum, -1);
		if (pRs->ADOEOF)
		{
			*x_Success = ::SysAllocString(L"No such records for the specified student!");
			return S_OK;
		}
		CComVariant m_varData1;
		pRs->MoveFirst();
		int i=1;
		m_nScore=0;
		while(!pRs->ADOEOF)
		{
			char m_strFieldName[20];
			int m_iQtype,m_iQID;
			short m_iAnswer;
			strcpy(m_strFieldName, "QTYPE");
			pRs->Fields->GetItem(m_strFieldName)->get_Value(&m_varData);
			if(m_varData.vt != VT_NULL)
			{
				m_iQtype=m_varData.iVal;
				strcpy(m_strFieldName,"Q");
				pRs->Fields->GetItem(m_strFieldName)->get_Value(&m_varData);
				if (m_varData.vt != NULL)
				{
					m_iQID=m_varData.iVal;
					if(!::CoInitialize((LPVOID)0))
					{
						*x_Success=::SysAllocString(L"Initianlize failed");
						return S_OK;
					}
					if(FAILED(m_pQuestion.CreateInstance(__uuidof(Question))))
					{
						*x_Success=::SysAllocString(L"Failed in creating Instance");
						return S_OK;
					}
					m_pQuestion->GetQuestion(m_iQtype,m_iQID);
					m_pQuestion->get_Answer(&m_iAnswer);
					strcpy(m_strFieldName, "A");
					pRs->Fields->GetItem(m_strFieldName)->get_Value(&m_varData);
					if(m_varData.vt != VT_NULL)
					{
						if(m_varData.iVal == m_iAnswer )
						{
							m_nScore += 2;
						}
					}

				}
				else
				{
					*x_Success=::SysAllocString(L"one question no answer.");
				}
			}

				pRs->MoveNext();
		}
		strcpy(m_strSql, "INSERT INTO TESTRESULT(SID,TESTDATE,SCORE) VALUES(" );
		_itoa(x_nSID, m_strBuf, 10);
		strcat(m_strSql, m_strBuf);
		strcat(m_strSql, ",GETDATE(),");
		_itoa(m_nScore, m_strBuf, 10);
		strcat(m_strSql, m_strBuf);
		strcat(m_strSql, ")");
		pConn->Execute(m_strSql, &m_varNum, -1);
		strcpy(m_strSql, "UPDATE TESTPROC SET FINISHFLAG='Y' WHERE SID=");
		_itoa(x_nSID, m_strBuf, 10);
		strcat(m_strSql, m_strBuf);
		pConn->Execute(m_strSql, &m_varNum, -1);
		pConn->Close();
		m_spObjectContext->SetComplete();
		*x_Success = ::SysAllocString(L"Successfully!");
		::CoUninitialize();
	}
	catch(...)
	{
		*x_Success = ::SysAllocString(L"Error occurs!");
		if (pConn != NULL)
		{
			pConn->Close();
		}
		m_spObjectContext->SetAbort();
		::CoUninitialize();
		return S_OK;
	}
	::CoUninitialize();
	return S_OK;
}

STDMETHODIMP CCaculateScore::GetScore(int x_nSID, int *x_nScore)
{
	// TODO: Add your implementation code here
	if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
	{
		*x_nScore = 0;
		return S_OK;
	}

	if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
	{
		*x_nScore = 0;
		return S_OK;
	}

	char m_strBuf[10];
	_itoa(x_nSID, m_strBuf, 10);
	
	CComBSTR m_bstrSql;
	m_bstrSql.Append("SELECT SCORE FROM TESTRESULT WHERE SID=");
	m_bstrSql.Append(m_strBuf);

	_bstr_t m_bstrResult(m_bstrSql,FALSE);
	

	CComVariant m_varNum;

	pRs = pConn->Execute(m_bstrResult, &m_varNum, -1);

	if (pRs->ADOEOF)
	{
		*x_nScore = 0;
		return S_OK;
	}

	CComVariant m_varData;
	pRs->GetFields()->GetItem("SCORE")->get_Value(&m_varData);
	
	
	*x_nScore = m_varData.iVal;

	pRs->Close();
	pConn->Close();
	return S_OK;
}
