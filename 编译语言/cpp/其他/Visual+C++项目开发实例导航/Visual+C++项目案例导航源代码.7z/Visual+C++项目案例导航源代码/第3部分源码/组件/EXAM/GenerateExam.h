// GenerateExam.h : Declaration of the CGenerateExam

#ifndef __GENERATEEXAM_H_
#define __GENERATEEXAM_H_

#include "resource.h"       // main symbols
#include <mtx.h>

/////////////////////////////////////////////////////////////////////////////
// CGenerateExam
class ATL_NO_VTABLE CGenerateExam : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CGenerateExam, &CLSID_GenerateExam>,
	public IObjectControl,
	public IDispatchImpl<IGenerateExam, &IID_IGenerateExam, &LIBID_EXAMLib>
{
public:
	CGenerateExam()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_GENERATEEXAM)

DECLARE_PROTECT_FINAL_CONSTRUCT()

DECLARE_NOT_AGGREGATABLE(CGenerateExam)

BEGIN_COM_MAP(CGenerateExam)
	COM_INTERFACE_ENTRY(IGenerateExam)
	COM_INTERFACE_ENTRY(IObjectControl)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IGenerateExam
public:
	STDMETHOD(GenerateExam)(/*[in]*/ int x_nSID,/*[out, retval]*/ BSTR *x_Success);
	STDMETHOD(Activate)();
	STDMETHOD_(BOOL, CanBePooled)();
	STDMETHOD_(void, Deactivate)();

	CComPtr<IObjectContext> m_spObjectContext;

private:
	_RecordsetPtr pRs;
	_ConnectionPtr pConn;
};

#endif //__GENERATEEXAM_H_
