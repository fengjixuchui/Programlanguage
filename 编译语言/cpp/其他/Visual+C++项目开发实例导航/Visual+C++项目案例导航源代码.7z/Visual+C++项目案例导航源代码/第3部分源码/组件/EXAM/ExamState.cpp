// ExamState.cpp : Implementation of CExamState
#include "stdafx.h"
#include "EXAM.h"
#include "ExamState.h"

/////////////////////////////////////////////////////////////////////////////
// CExamState


STDMETHODIMP CExamState::CheckExist(int x_nSID, BSTR *x_Success)
{
	if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
	{
		*x_Success = ::SysAllocString(L"Couldn't create connection component!");
		return S_OK;
	}

	if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
	{
		*x_Success = ::SysAllocString(L"Couldn't open connection");
		return S_OK;
	}

	
	CComBSTR m_bstrSql;

	char m_strBuf[10];
	_itoa(x_nSID, m_strBuf, 10);

	m_bstrSql.Append("SELECT SID FROM TESTPROC WHERE SID=");
	m_bstrSql.Append(m_strBuf);

	_bstr_t m_bstrResult(m_bstrSql,FALSE);
	

	CComVariant m_varNum;

	pRs = pConn->Execute(m_bstrResult, &m_varNum, -1);

	if(pRs->ADOEOF)
	{
		*x_Success = ::SysAllocString(L"N");
		return S_OK;
	}
	*x_Success = ::SysAllocString(L"Y");

	pRs->Close();
	pConn->Close();
	return S_OK;
}

STDMETHODIMP CExamState::CheckFinish(int x_nSID, BSTR *x_Success)
{
// TODO: Add your implementation code here
	

	if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
	{
		*x_Success = ::SysAllocString(L"Couldn't create connection component!");
		return S_OK;
	}

	if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
	{
		*x_Success = ::SysAllocString(L"Couldn't open connection");
		return S_OK;
	}

	
	CComBSTR m_bstrSql;

	char m_strBuf[10];
	_itoa(x_nSID, m_strBuf, 10);

	m_bstrSql.Append("SELECT SID FROM TESTPROC WHERE SID=");
	m_bstrSql.Append(m_strBuf);
	m_bstrSql.Append(" AND FINISHFLAG = 'Y'");


	_bstr_t m_bstrResult(m_bstrSql,FALSE);
	

	CComVariant m_varNum;

	pRs = pConn->Execute(m_bstrResult, &m_varNum, -1);

	if (m_varNum.lVal == 0)
	{
		*x_Success = ::SysAllocString(L"N");
		return S_OK;
	}

	*x_Success = ::SysAllocString(L"Y");

	pRs->Close();
	pConn->Close();
	return S_OK;
	
}


STDMETHODIMP CExamState::GetAnswer(int x_nSID, int x_nQID, long *x_lAnswer)
{
	// TODO: Add your implementation code here
	try
	{

		if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
		{
			*x_lAnswer = -1;
			return S_OK;
		}

		if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
		{
			*x_lAnswer = -1;
			return S_OK;
		}

		char m_strBuf[10];
		_itoa(x_nSID, m_strBuf, 10);
		
		CComBSTR m_bstrSql;
		m_bstrSql.Append("SELECT * FROM TESTPROCDETAIL WHERE SID=");
		m_bstrSql.Append(m_strBuf);
		m_bstrSql.Append(" and QNO=");
		_itoa(x_nQID,m_strBuf,10);
		m_bstrSql.Append(m_strBuf);


		_bstr_t m_bstrResult(m_bstrSql,FALSE);
		

		CComVariant m_varNum;

		pRs = pConn->Execute(m_bstrResult, &m_varNum, -1);

		if (pRs->ADOEOF)
		{
			*x_lAnswer = -1;
			return S_OK;
		}

		CComVariant m_varData;

		char m_strFieldName[20];
		strcpy(m_strFieldName, "A");

		pRs->GetFields()->GetItem(m_strFieldName)->get_Value(&m_varData);
		if(m_varData.vt != VT_NULL)
		{
			*x_lAnswer = m_varData.iVal;
		}

		pRs->Close();
		pConn->Close();
		
	}
	catch(...)
	{
		*x_lAnswer = -1;
		return S_OK;

	}

	return S_OK;
}

STDMETHODIMP CExamState::GetCurrentQuestion(int x_nSID, long *x_lCurrentQuestion)
{
	// TODO: Add your implementation code here
	try
	{

		if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
		{
			*x_lCurrentQuestion = -1;
			return S_OK;
		}

		if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
		{
			*x_lCurrentQuestion = -1;
			return S_OK;
		}

		char m_strBuf[10];
		_itoa(x_nSID, m_strBuf, 10);
		
		CComBSTR m_bstrSql;
		m_bstrSql.Append("SELECT * FROM TESTPROC WHERE SID=");
		m_bstrSql.Append(m_strBuf);

		_bstr_t m_bstrResult(m_bstrSql,FALSE);
		

		CComVariant m_varNum;

		pRs = pConn->Execute(m_bstrResult, &m_varNum, -1);

		if (pRs->ADOEOF)
		{
			*x_lCurrentQuestion = -1;
			return S_OK;
		}

		CComVariant m_varData;

		pRs->GetFields()->GetItem("CURRENTQUESTION")->get_Value(&m_varData);
		if(m_varData.vt != VT_NULL)
		{
			*x_lCurrentQuestion = m_varData.iVal;
		}

		pRs->Close();
		pConn->Close();

	}
	catch(...)
	{
		*x_lCurrentQuestion = -1;
		return S_OK;
	
	}

	return S_OK;
}

STDMETHODIMP CExamState::get_QType(short *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_QType;
	return S_OK;
}

STDMETHODIMP CExamState::get_TimeLeft(long *pVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CExamState::get_QTypeforbstr(BSTR **pVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CExamState::put_QTypeforbstr(BSTR *newVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CExamState::GetExamInfo(long x_nSID, BSTR *x_Success)
{
	// TODO: Add your implementation code here
	try
	{

		if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
		{
			*x_Success = ::SysAllocString(L"CreateInstance Error");
			return S_OK;
		}

		if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
		{
			*x_Success = ::SysAllocString(L"Connection Open error");
			return S_OK;
		}

		char m_strBuf[10];
		_itoa(x_nSID, m_strBuf, 10);
		
		CComBSTR m_bstrSql;
		m_bstrSql.Append("SELECT * FROM TESTPROC WHERE SID=");
		m_bstrSql.Append(m_strBuf);

		_bstr_t m_bstrResult(m_bstrSql,FALSE);
		

		CComVariant m_varNum;

		pRs = pConn->Execute(m_bstrResult, &m_varNum, -1);

		if (pRs->ADOEOF)
		{
			*x_Success = ::SysAllocString(L"Error occured");
			return S_OK;
		}

		CComVariant m_varData;

		pRs->GetFields()->GetItem("CURRENTQUESTION")->get_Value(&m_varData);
		if(m_varData.vt != VT_NULL)
		{
			m_CurrentQuestion = m_varData.iVal;
		}

		pRs->GetFields()->GetItem("TIMELEFT")->get_Value(&m_varData);
		if(m_varData.vt!=VT_NULL)
		{
			m_TimeLeft=m_varData.lVal;
		}

		pRs->Close();
		pConn->Close();

	}
	catch(...)
	{
		*x_Success = ::SysAllocString(L"Error occured");
		return S_OK;
	
	}

	return S_OK;
}

STDMETHODIMP CExamState::GetExamDetail(long x_nSID, int x_nQNO, BSTR *x_Success)
{
	// TODO: Add your implementation code here
	try
	{

		if (FAILED(pConn.CreateInstance(__uuidof(Connection))))
		{
			*x_Success = ::SysAllocString(L"CreateInstance Error");
			return S_OK;
		}

		if (FAILED(pConn->Open("Provider=MSDASQL.1;Password=;Persist Security Info=True;User ID=SA;Data Source=EXAM;Initial Catalog=EXAM","","",-1)))
		{
			*x_Success = ::SysAllocString(L"Connection Open error");
			return S_OK;
		}

		char m_strBuf[10];
		_itoa(x_nSID, m_strBuf, 10);
		
		CComBSTR m_bstrSql;
		m_bstrSql.Append("SELECT * FROM TESTPROCDETAIL WHERE SID=");
		m_bstrSql.Append(m_strBuf);
		m_bstrSql.Append(" and QNO=");
		_itoa(x_nQNO,m_strBuf,10);
		m_bstrSql.Append(m_strBuf);


		_bstr_t m_bstrResult(m_bstrSql,FALSE);
		

		CComVariant m_varNum;

		pRs = pConn->Execute(m_bstrResult, &m_varNum, -1);

		if (pRs->ADOEOF)
		{
			*x_Success = ::SysAllocString(L"No Records");
			return S_OK;
		}

		CComVariant m_varData;

		char m_strFieldName[20];
		strcpy(m_strFieldName, "QTYPE");

		pRs->GetFields()->GetItem(m_strFieldName)->get_Value(&m_varData);
		if(m_varData.vt != VT_NULL)
		{
			m_QType = m_varData.iVal;
		}
	
		strcpy(m_strFieldName,"Q");
		pRs->GetFields()->GetItem(m_strFieldName)->get_Value(&m_varData);
		if(m_varData.vt!=VT_NULL)
		{
			m_QID=m_varData.lVal;
		}

		pRs->Close();
		pConn->Close();
	}
	catch(...)
	{
		*x_Success=::SysAllocString(L"Error occured");
		return S_OK;
	}


	return S_OK;
}

STDMETHODIMP CExamState::get_QID(long *pVal)
{
	// TODO: Add your implementation code here
	*pVal=m_QID;
	return S_OK;
}
