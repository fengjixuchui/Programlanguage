//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Library.rc
//
#define IDD_ABOUTBOX                    100
#define ID_CURRENT_USER                 101
#define IDR_MAINFRAME                   128
#define IDR_LIBRARTYPE                  129
#define IDD_LOGIN                       130
#define IDD_READER_MAINTAIN             131
#define IDD_CLERK_MAINTAIN              132
#define IDD_BOOK_MAINTAIN               134
#define IDD_LENDOUT                     136
#define IDD_FINE                        137
#define IDD_SETODBC                     138
#define IDD_ReturnBook                  139
#define IDD_DIALOG1                     140
#define IDD_DLGREADERQRY                140
#define IDD_DIALOGQRY                   141
#define IDC_LOGIN_NAME                  1000
#define IDC_LOGIN_PASSWORD              1001
#define IDC_CONFIRM                     1002
#define IDC_CANCEL                      1003
#define IDC_READER_NAME_FOR_Q           1003
#define IDC_READER_ID_FOR_Q             1004
#define IDC_READER_ID                   1005
#define IDC_READER_NAME                 1006
#define IDC_IDCARD                      1007
#define IDC_FIRST                       1008
#define IDC_FINE_DATE                   1008
#define IDC_PRIOR                       1009
#define IDC_NEXT                        1010
#define IDC_LAST                        1011
#define IDC_NEW                         1012
#define IDC_EDIT                        1013
#define IDC_SAVE                        1014
#define IDC_CANCEL_REC                  1015
#define IDC_ENQUERY                     1016
#define IDC_DELETE                      1017
#define IDC_EXIT                        1018
#define IDC_PASSWORD                    1019
#define IDC_POSITION                    1020
#define IDC_PRESSDATE                   1020
#define IDC_USERNAME_Q                  1021
#define IDC_USERID_Q                    1022
#define IDC_USERID                      1023
#define IDC_USERNAME                    1024
#define IDC_BOOKNAME_Q                  1025
#define IDC_BOOKID_Q                    1026
#define IDC_BOOKID                      1027
#define IDC_BOOKNAME                    1028
#define IDC_AUTHOR                      1029
#define IDC_PRESS                       1030
#define IDC_FLAG_BORROW                 1031
#define IDC_BOOK_ID                     1032
#define IDC_BORROW_LIST                 1034
#define IDC_DAYS                        1035
#define IDC_AMOUNT                      1036
#define IDC_ODBCDSN                     1037
#define IDC_FILENAME                    1038
#define IDC_CREATE                      1041
#define IDC_EDITBook_ID                 1042
#define IDC_EDITReaderName              1044
#define IDC_EDITBorrowDate              1045
#define IDC_EDITReturnDate              1046
#define IDC_EDITDays                    1047
#define IDC_EDIT1                       1052
#define IDC_READERID                    1052
#define IDC_EDIT2                       1053
#define IDC_READERNAME                  1053
#define IDC_READERIDCARD                1054
#define IDC_EDITID_CARD                 1055
#define IDC_DBGRIDReaderInfo            1060
#define IDC_REMOTEDATACTLReaderQry      1061
#define IDC_EDITReaderID                1062
#define IDC_EDITName                    1063
#define IDC_LISTBOOK                    1064
#define IDC_QUERY                       1065
#define ID_LOGIN_IN                     32771
#define ID_LOGIN_OUT                    32772
#define ID_USER_MAINTAIN                32773
#define ID_BOOK_MAINTAIN                32774
#define ID_CONFIG_MAINTAIN              32775
#define ID_LEND_OUT                     32776
#define ID_RETURN_BACK                  32777
#define ID_FINE                         32778
#define ID_READER_MAINTAIN              32779
#define ID_ReaderQry                    32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1066
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
