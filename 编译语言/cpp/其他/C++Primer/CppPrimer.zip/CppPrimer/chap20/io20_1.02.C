// #include <iostream>
// #include <cstring>

#include <iostream.h>
#include <string.h>

/**
 ** The length of ``ulysses'' is:   7
 ** The size of ``ulysses'' is:     8
 **
 **/

int main() {
    cout << "The length of ``ulysses'' is:\t";
    cout << strlen( "ulysses" );
    cout << '\n';
    cout << "The size of ``ulysses'' is:\t";
    cout << sizeof( "ulysses" );
    cout << endl;
}
