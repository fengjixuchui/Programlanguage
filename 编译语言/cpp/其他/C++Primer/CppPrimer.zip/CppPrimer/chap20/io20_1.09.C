#include <iostream>

/**
 ** note: unable to compile this --
 **       no available boolalpha() implementation
 **/

int main()
{
	cout << "default bool values:
	     << true << " " << false
	     << "\nalpha bool values: "
	     << boolalpha()
	     << true << " " << false
	     << endl;
}





