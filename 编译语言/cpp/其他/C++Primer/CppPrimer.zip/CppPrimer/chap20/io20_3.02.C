// #include <iostream>
#include <iostream.h>

/**
 ** a.out
 ** ineluctable modality of the visible
 ** ineluctable modality of the visible
 **
 **/


int main() 
{
	int ch;

	// alternatively: while ( ch = cin.get() && ch != EOF )
	while (( ch = cin.get()) != EOF )
		 cout.put( ch );

	return 0;
}
