// iostream.h is preStandard form
// #include <iostream>
#include <iostream.h>

/**
 ** 2 raised to the power of 10: 1024
 **/

int main() {
    // a first solution
    cout << "2 raised to the power of 10: ";
    cout << 2 * 2 * 2 * 2 * 2 * 2 * 2 * 2 * 2 * 2;
    cout << endl;
    return 0;
}
