void rswap( int &v1, int &v2 ) {
        int tmp = v2;
        v2 = v1;
        v1 = tmp;
}
