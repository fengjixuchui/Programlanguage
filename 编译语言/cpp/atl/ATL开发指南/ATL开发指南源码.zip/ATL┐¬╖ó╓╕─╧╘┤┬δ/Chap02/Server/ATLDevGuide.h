//
// ATLDevGuide.h - The component category used for all of the
//                  examples in the ATL: Developer's Guide
//

// {73038960-8306-11d3-A3ED-00203586EF11}
DEFINE_GUID( CATID_ATLDevGuide, 
             0x73038960, 0x8306, 0x11d3, 0xa3, 0xed, 0x0, 0x20, 0x35, 0x86, 0xef, 0x11);


