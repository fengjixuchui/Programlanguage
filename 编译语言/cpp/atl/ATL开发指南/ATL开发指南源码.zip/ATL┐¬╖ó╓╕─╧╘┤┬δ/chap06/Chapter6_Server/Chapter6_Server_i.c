/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 3.01.75 */
/* at Wed Oct 29 19:50:22 1997
 */
/* Compiler settings for Chapter6_Server.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IMath = {0xDCA4F88E,0x4952,0x11D1,{0x88,0x3A,0x44,0x45,0x53,0x54,0x00,0x00}};


const IID IID_IMath2 = {0x9F21BD41,0x4E25,0x11d1,{0x88,0x3A,0x44,0x45,0x53,0x54,0x00,0x00}};


const IID IID_IAdvancedMath = {0x9F21BD45,0x4E25,0x11d1,{0x88,0x3A,0x44,0x45,0x53,0x54,0x00,0x00}};


const IID LIBID_CHAPTER6_SERVERLib = {0xDCA4F881,0x4952,0x11D1,{0x88,0x3A,0x44,0x45,0x53,0x54,0x00,0x00}};


const CLSID CLSID_Math = {0xDCA4F88F,0x4952,0x11D1,{0x88,0x3A,0x44,0x45,0x53,0x54,0x00,0x00}};


#ifdef __cplusplus
}
#endif

