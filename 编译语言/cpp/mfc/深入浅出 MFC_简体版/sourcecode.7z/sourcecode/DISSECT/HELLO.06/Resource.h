// resource.h
#define IDM_ABOUT   100
