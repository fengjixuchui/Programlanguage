//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GridDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDC_SLIDER                      121
#define IDC_EDITHORZ                    122
#define IDC_EDITVERT                    124
#define IDR_MAINFRAME                   128
#define IDR_GRIDDETYPE                  129
#define IDD_SETTINGDLG                  130
#define IDC_SPINHORZ                    1000
#define IDC_SPINVERT                    1001
#define ID_OPTIONS_GRID_SETTINGS        32771
#define IDS_SLIDER                      61204
#define IDS_EDITHORZ                    61205
#define IDS_EDITVERT                    61206

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
