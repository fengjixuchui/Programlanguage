//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PropDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_PROPDETYPE                  129
#define IDD_SIZE_PAGE                   130
#define IDD_COLOR_PAGE                  131
#define IDC_WIDTH                       1000
#define IDC_RED                         1000
#define IDC_HEIGHT                      1001
#define IDC_GREEN                       1001
#define IDC_INCHES                      1002
#define IDC_BLUE                        1002
#define IDC_CENTIMETERS                 1003
#define IDC_PIXELS                      1004
#define ID_FILE_PROPERTIES              32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
