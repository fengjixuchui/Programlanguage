//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DlgCalc.rc
//
#define IDD_DLGCALC_DIALOG              102
#define IDC_0                           120
#define IDC_1                           121
#define IDC_2                           122
#define IDC_3                           123
#define IDC_4                           124
#define IDC_5                           125
#define IDC_6                           126
#define IDC_7                           127
#define IDR_MAINFRAME                   128
#define IDC_8                           128
#define IDC_9                           129
#define IDR_ACCEL                       129
#define IDC_CHGSIGN                     130
#define IDC_EXP                         131
#define IDC_STO                         132
#define IDC_RCL                         133
#define IDC_ENTER                       134
#define IDC_FIX                         135
#define IDC_CLX                         136
#define IDC_SUBTRACT                    137
#define IDC_ADD                         138
#define IDC_MULTIPLY                    139
#define IDC_DIVIDE                      140
#define IDC_DECIMAL                     141
#define IDC_DEL                         142
#define IDC_DISPLAYRECT                 150

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
