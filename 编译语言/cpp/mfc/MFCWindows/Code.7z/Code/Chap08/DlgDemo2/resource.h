//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DlgDemo2.rc
//
#define IDC_RESET                       3
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_DLGDEMTYPE                  129
#define IDD_OPTIONS                     130
#define IDC_WIDTH                       1000
#define IDC_HEIGHT                      1001
#define IDC_INCHES                      1002
#define IDC_CENTIMETERS                 1003
#define IDC_PIXELS                      1004
#define ID_FILE_OPTIONS                 32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
