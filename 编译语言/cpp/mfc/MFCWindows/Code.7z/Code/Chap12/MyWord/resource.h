//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyWord.rc
//
#define IDR_CNTR_INPLACE                6
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDC_FONTNAMES                   101
#define IDP_FAILED_TO_CREATE            102
#define IDC_FONTSIZES                   102
#define IDW_STYLE_BAR                   103
#define IDR_MAINFRAME                   128
#define IDR_MYWORDTYPE                  129
#define IDR_STYLE_BAR                   130
#define ID_CANCEL_EDIT_CNTR             32768
#define ID_VIEW_STYLE_BAR               32771
#define ID_CHAR_BOLD                    32773
#define ID_CHAR_ITALIC                  32774
#define ID_CHAR_UNDERLINE               32775
#define ID_PARA_LEFT                    32776
#define ID_PARA_CENTER                  32777
#define ID_PARA_RIGHT                   32778
#define ID_DUMMY1                       32779
#define ID_DUMMY2                       32780
#define ID_INDICATOR_LINE               61204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
