<?php

require_once("page.php");

$class = new ReflectionClass("Page");
echo "<pre>".$class."</pre>";

?>
