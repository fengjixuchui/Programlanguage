  <!-- page footer -->
  <footer>
      <p>&copy; TLA Consulting Pty Ltd.<br />
      Please see our 
      <a href="legal.php">legal information page</a>.</p>
  </footer>

</body>
</html>

