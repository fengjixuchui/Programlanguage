<html>
<head>
    <?php $__env->startSection('stylesheets'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
    <?php echo $__env->yieldSection(); ?>
</head>
<body>
    <div class="container">
    
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <?php if(Session::has('success')): ?>
    <div class="alert alert-success" role="alert"><?php echo e(Session::get('success')); ?></div>
    <?php endif; ?>
    
    <?php if(Session::has('error')): ?>
    <div class="alert alert-danger" role="alert"><?php echo e(Session::get('error')); ?></div>
    <?php endif; ?>
    
    <?php if(Session::has('warning')): ?>
    <div class="alert alert-warning" role="alert"><?php echo e(Session::get('warning')); ?></div>
    <?php endif; ?>
    
    <?php if(Session::has('info')): ?>
    <div class="alert alert-info" role="alert"><?php echo e(Session::get('info')); ?></div>
    <?php endif; ?>
    
    <?php echo $__env->yieldContent('main'); ?>
    </div>
</body>
    <?php $__env->startSection('javascript'); ?>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    <?php echo $__env->yieldSection(); ?>
</html>
